# Clumpy models in PEACOCK

PEACOCK uses one cloud geometry and motion model across its spectral lines.
Each transition supplies its own atomic data, scattering rules and conversion
from physical velocities to Doppler units. Cloud motion is implemented once
in `src/core/cloud_motion.c`. The shared configuration reader applies the
same velocity laws to the cloud populations used by each run.

Set `cloud_mode_schema = 2` in each configuration section that lists `clouds`.
One row of placement settings and one row of motion settings describe each
population.

## Placement

| `cloud_placing_modes` | Geometry | Placement parameters |
| --- | --- | --- |
| 1 | Random uniform shell | None |
| 2 | Close-packed lattice with count adjustment | Optional buffer; default 1.54 |
| 3 | Read a complete cloud-position catalogue | None |

`cloud_Rin` and `cloud_Rout` are in pc. The filling factor and cloud radius
set the requested count. Generated placements check containment and overlap.
In a spherical grid, uniform placement draws proposals uniformly in
volume. HDF5 cloud reconstruction uses the same proposals when the file
omits cloud positions.

Catalogue coordinates are Cartesian cm. Generate the complete catalogue for
the requested count; the catalogue, rather than a placement parameter,
defines any radial number-density profile. The GPU example generator uses
FCC positions with shell quotas for a configurable volume density exponent.

For custom single-catalogue CUDA inputs, pass `--clump-file` to `prepare`
or `run`. For CPU C II, set `TLAC_CLUMP_FILE`. For CPU multilevel UV,
set `TLAC_CLUMP_POS_FILE`. The native CPU Lyα paired-catalogue loader
reads both populations from `clump_pos_Ncl1_<N1>_Ncl2_<N2>.txt` in
`TLAC_CLUMP_DIR`.

## Motion

| `cloud_motion_modes` | Component | Parameters |
| --- | --- | --- |
| 0 | No motion | None |
| 1 | Constant radial bulk speed | Signed speed (km/s) |
| 2 | Isotropic Gaussian dispersion | Per-axis standard deviation (km/s) |
| 3 | T15 varying-alpha radial wind | `v0` (km/s), `R`, `alpha`, `Rmin` (pc), `Rmax` (pc) |

Gaussian dispersion draws three independent zero-mean Cartesian velocity
components, each with standard deviation `sigma_cl`. The engine adds bulk
motion along the radial direction.

For a single population with dispersion and a wind, for example:

```ini
cloud_mode_schema = 2
cloud_motion_modes = ((2,3))
cloud_motion_params = ((25,80,10,1.5,100,950))
```

The first parameter is the dispersion; the next five belong to the wind. A
row has up to two components. The first slot uses one position in the parameter
row (including an unused zero for mode 0), or five for a wind. A second
component starts immediately after that slot. The native CPU Lyα backend
applies both configured components when processing each population.
On the other backends, processing the second population applies only its
first component.

The selected line supplies its atomic mass for the conversion to Doppler
units. Choose it with `peacock.py run --line` or `peacock.py prepare --line`
after building the backend. See the [line selection guide](line-selection.md).
