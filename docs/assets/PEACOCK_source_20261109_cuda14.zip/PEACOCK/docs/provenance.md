# Provenance and citation

PEACOCK extends the `tlac` three-dimensional Lyα Monte Carlo radiative
transfer code developed by Max Gronke and described by Gronke & Dijkstra
(2014). The source retains the `tlac` lineage and existing attribution,
including the INI parser credit to Nicolas Devillard.

- Zhihui Li et al. (2026), [PEACOCK method and multi-ion application](https://arxiv.org/abs/2603.06546).
- Max Gronke and Mark Dijkstra (2014), [description of `tlac`](https://arxiv.org/abs/1406.6709).
- Zhihui Li et al. (2026), [C IV application](https://arxiv.org/abs/2609.11497).

## Licensing

The bundled INI parser retains its [upstream MIT license](../THIRD_PARTY/iniparser-LICENSE.txt).
Project-wide redistribution terms for the PEACOCK transport source are
unspecified in this package.

See [UV atomic and dust data notices](uv-data-provenance.md) for the
multilevel reference tables.
