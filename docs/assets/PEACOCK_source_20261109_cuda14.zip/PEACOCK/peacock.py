"""Build a PEACOCK backend once and select a spectral line at run time."""

import argparse
from pathlib import Path
import subprocess
import sys

from tools.engine_layout import ROOT, line_profiles, source_view
from tools.runtime_build import build, build_record, runtime_environment


def positive(value):
    number = int(value)
    if not 1 <= number <= 2147483647:
        raise argparse.ArgumentTypeError('Expected a positive 32-bit count')
    return number


def parser():
    root = argparse.ArgumentParser(description=__doc__)
    commands = root.add_subparsers(dest='command',required=True)
    commands.add_parser('lines',help='List runtime line profiles')
    compile_command = commands.add_parser('build',help='Build all operators for one backend')
    compile_command.add_argument('--backend',choices=('cpu','cuda'),required=True)
    compile_command.add_argument('--output',type=Path)
    compile_command.add_argument('--jobs',type=positive,default=4)
    for name in ('cc','cxx','nm','compiler-prefix','libs','nvrtc-library'):
        compile_command.add_argument('--'+name)
    for name in ('include-dir','library-dir','cuda-include'):
        compile_command.add_argument('--'+name,action='append',default=[])
    compile_command.add_argument('--arch',default='compute_120')
    compile_command.add_argument('--nvidia-root',type=Path)
    compile_command.add_argument('--host-only',action='store_true',help='Build CUDA input exporter only')
    compile_command.add_argument('--openmp',action='store_true')
    compile_command.add_argument('--hdf5',action='store_true')
    for name in ('run','prepare','execute'):
        sub = commands.add_parser(name,help={
            'run':'Run a line with an existing backend build',
            'prepare':'Prepare CUDA inputs', 'execute':'Run CUDA on prepared inputs',
        }[name])
        sub.add_argument('--line',required=True)
        sub.add_argument('--build-dir',type=Path)
        if name=='run':
            sub.add_argument('--backend',choices=('cpu','cuda'))
            sub.add_argument('--template',action='append',default=[])
        if name in ('run','prepare'):
            sub.add_argument('--output',type=Path,required=True)
            sub.add_argument('--config',type=Path)
            sub.add_argument('--nphot',type=positive)
            sub.add_argument('--clump-file',type=Path)
            sub.add_argument('--geometry-cache',type=Path)
        if name in ('run','execute'):
            sub.add_argument('--batch',type=positive,default=1024)
        if name=='execute':
            sub.add_argument('--input',type=Path,required=True)
    return root


def main(argv=None):
    args = parser().parse_args(argv)
    profiles = line_profiles()
    if args.command=='lines':
        for profile in profiles:
            print(f"{profile['name']:10} {profile['label']:19} {', '.join(profile['backends'])}")
        return 0
    try:
        if args.command=='build':
            args.output = args.output or ROOT/'build'/args.backend
            build(args)
            return 0
        requested = args.line.casefold()
        profile = next((p for p in profiles if requested in (p['name'].casefold(), p['id'].casefold())), None)
        if profile is None:
            raise ValueError(f'Unknown line {args.line!r}. Use `peacock.py lines` to list line IDs.')
        backend = (args.backend or profile['backends'][0]) if args.command=='run' else 'cuda'
        if backend not in profile['backends']:
            raise ValueError(f"{profile['name']} supports {', '.join(profile['backends'])}.")
        directory = (args.build_dir or ROOT/'build'/backend).resolve()
        atom = ROOT/'lines/runtime'/f"{profile['name']}.atom"
        if args.command=='execute':
            # A device host can run prepared inputs with the shared PTX and
            # its runtime tables. The runner verifies the module and input ABI.
            from backends.cuda.runtime import execute_bundle
            execute_bundle(ROOT,profile,atom,directory,args.input.resolve(),args.batch)
            return 0
        view = source_view()
        record, executable = build_record(backend,directory,view)
        if backend=='cpu':
            if args.clump_file or args.geometry_cache:
                raise ValueError('Use the CPU catalogue environment settings in the cloud guide.')
            from tools.peacock_cpu import run
            run(view,profile,executable,args.config,args.output,args.nphot,args.template,
                atom=atom,env=runtime_environment(record))
        else:
            if args.command=='run' and 'device' not in record:
                raise ValueError('Use a complete CUDA build for transport. The host-only build prepares inputs.')
            if args.command=='run' and args.template:
                raise ValueError('CUDA preparation takes a resolved configuration file.')
            from tools.runtime_prepare import prepare
            case = prepare(view,profile,atom,record,executable,args.output,args.config,args.nphot,
                           args.clump_file,args.geometry_cache)
            if args.command=='run':
                from backends.cuda.runtime import execute_bundle
                execute_bundle(ROOT,profile,atom,directory,case,args.batch)
        return 0
    except subprocess.CalledProcessError as error:
        print(f'PEACOCK stopped with exit code {error.returncode}.',file=sys.stderr)
        return error.returncode if error.returncode>0 else 1
    except (ValueError,OSError,RuntimeError,KeyError) as error:
        print(f'PEACOCK: {error}',file=sys.stderr)
        return 2


if __name__=='__main__':
    sys.exit(main())
