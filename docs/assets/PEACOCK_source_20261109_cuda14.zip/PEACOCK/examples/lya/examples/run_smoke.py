#!/usr/bin/env python3
"""Run the bundled Lyα model and bin the escaping packets in velocity."""

import argparse
import configparser
import csv
import math
import os
from pathlib import Path
import subprocess
import tempfile


CONFIG = Path(__file__).with_name("smoke.cfg").resolve()
LIGHT_SPEED_KM_S = 299792.458
REFERENCE_FREQUENCY_HZ = 2.466e15
V_MIN = -700
V_MAX = 700
BIN_WIDTH = 20


def bin_packets(path):
    """Return direct and scattered packet counts plus the total outside the bins."""
    n_bins = (V_MAX - V_MIN) // BIN_WIDTH
    direct = [0] * n_bins
    scattered = [0] * n_bins
    n_outside = 0
    n_escaped = 0
    n_scattered = 0

    with path.open() as packets:
        for line in packets:
            if line.startswith("#") or not line.strip():
                continue
            fields = line.split()
            observed_x = float(fields[6])
            doppler_width_hz = float(fields[8])
            scatter_count = int(fields[12])
            frequency_hz = REFERENCE_FREQUENCY_HZ + observed_x * doppler_width_hz
            if not math.isfinite(frequency_hz) or frequency_hz <= 0 or scatter_count < 0:
                raise ValueError(f"Invalid escaped packet in {path}: {line.rstrip()}")
            velocity = LIGHT_SPEED_KM_S * (REFERENCE_FREQUENCY_HZ / frequency_hz - 1)
            n_escaped += 1
            n_scattered += int(scatter_count > 0)
            if V_MIN <= velocity < V_MAX:
                index = int((velocity - V_MIN) / BIN_WIDTH)
                counts = scattered if scatter_count else direct
                counts[index] += 1
            else:
                n_outside += 1
    return direct, scattered, n_outside, n_escaped, n_scattered


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("executable", type=Path)
    args = parser.parse_args()
    executable = args.executable.resolve(strict=True)

    config = configparser.ConfigParser()
    config.read(CONFIG)
    n_injected = config.getint("run", "nphot")
    output_parent = Path.cwd() / "build"
    output_parent.mkdir(exist_ok=True)
    output_dir = Path(tempfile.mkdtemp(prefix="smoke-lya-", dir=output_parent))

    environment = dict(os.environ, OMP_NUM_THREADS="1")
    subprocess.run(
        [str(executable), str(CONFIG), "lya_"],
        cwd=output_dir,
        env=environment,
        check=True,
    )
    packet_files = list(output_dir.glob("lya_*.dat"))
    if len(packet_files) != 1:
        raise RuntimeError(f"Expected one ASCII packet file in {output_dir}")
    direct, scattered, n_outside, n_escaped, n_scattered = bin_packets(packet_files[0])

    # This particular cloud model is dust-free and should have both populations.
    if n_escaped != n_injected or not 0 < n_scattered < n_escaped:
        raise RuntimeError(
            f"Unexpected packet counts: injected={n_injected}, escaped={n_escaped}, "
            f"scattered={n_scattered}"
        )
    spectrum_path = output_dir / "spectrum.csv"
    with spectrum_path.open("w", newline="") as spectrum:
        writer = csv.writer(spectrum)
        writer.writerow(["velocity_km_s", "direct_count", "scattered_count", "total_count"])
        for index, (n_direct, n_scatter) in enumerate(zip(direct, scattered)):
            center = V_MIN + (index + 0.5) * BIN_WIDTH
            writer.writerow([center, n_direct, n_scatter, n_direct + n_scatter])

    print(f"Escaped {n_escaped}/{n_injected} packets, including {n_scattered} scattered.")
    print(f"Packets outside [{V_MIN}, {V_MAX}) km/s: {n_outside}")
    print(f"Binned spectrum: {spectrum_path}")


if __name__ == "__main__":
    main()
