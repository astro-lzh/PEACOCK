"""Prepare a CUDA case with the single linked native exporter."""

import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

from tools.engine_layout import ROOT
from tools.peacock_cpu import _resolve_config, _run_section, native_prefix
from tools.runtime_build import runtime_environment, sha


def write_json(path, value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')


def prepare(_view, profile, atom, record, exporter, output, config=None, nphot=None,
            clump_file=None, geometry_cache=None):
    line = profile['id']
    multilevel = profile['operator'] == 'multilevel'
    default = 'multilevel' if multilevel else line
    template = config.resolve() if config else ROOT/f'examples/cuda/{default}.cfg'
    text = template.read_text(encoding='utf8')
    _, run_settings = _run_section(text.splitlines(keepends=True))
    if 'nphot' not in run_settings:
        raise ValueError('The configuration needs an integer primary nphot count.')
    if nphot is None:
        nphot = int(run_settings['nphot'][2])
    if not 1 <= nphot <= 2147483647:
        raise ValueError('The packet count must be a positive signed 32-bit integer.')
    if 'nphot_uv' in run_settings and int(run_settings['nphot_uv'][2]) != 0:
        raise ValueError('Use the primary nphot stream for CUDA preparation.')
    if config is not None and clump_file is None and re.search(r'(?mi)^[ \t]*cloud_placing_modes\s*=[^#;\n]*\b3\b',text):
        raise ValueError('Catalogue placement requires --clump-file with the complete catalogue.')
    if clump_file is not None:
        clump_file = clump_file.resolve(strict=True)
        if not clump_file.is_file():
            raise ValueError('The clump catalogue must be a file.')

    case = output.resolve()
    text = _resolve_config(text,native_prefix(case/'host_output'),nphot,False)
    case.mkdir(parents=True,exist_ok=True)
    if any(case.iterdir()):
        raise ValueError(f'Choose a new or empty case directory: {case}')
    resolved = case/'resolved.cfg'
    with resolved.open('x',encoding='utf8',newline='\n') as stream:
        stream.write(text)
    atom_bytes = atom.read_bytes()
    atom_copy = case/'atomic.atom'
    atom_copy.write_bytes(atom_bytes)
    atom_digest = hashlib.sha256(atom_bytes).hexdigest()
    env = runtime_environment(record)
    env.update(TLAC_GPU_EXPORT=str(case/'case'),TLAC_GPU_SKIP_REFERENCE='1',OMP_NUM_THREADS='1')
    if clump_file is not None:
        if multilevel:
            env['TLAC_CLUMP_POS_FILE'] = str(clump_file)
        else:
            env.update(TLAC_CLUMP_FILE=str(clump_file),TLAC_CLUMP_DIR=str(clump_file.parent))
    elif config is None and not multilevel:
        from tools.fcc_clump_geometry import prepare_geometry
        # A short cache also works for the native Windows path length limits.
        cache = geometry_cache or Path(tempfile.gettempdir())/'peacock-fcc-cache'
        geometry = prepare_geometry(cache,fv=.01,radius_pc=50,rmin_pc=100,rmax_pc=950,
                                    volume_beta=2,seed=2026110601,shell_width_pc=100)
        for key, name in (('positions_file','clumps.txt'),('arrays_file','geometry_arrays.npz'),('audit_file','geometry_audit.json')):
            shutil.copyfile(geometry[key],case/name)
            geometry[key] = str(case/name)
        geometry['clump_position_file'] = geometry['positions_file']
        geometry['manifest_file'] = str(case/'geometry_manifest.json')
        write_json(case/'geometry_manifest.json',geometry)
        env.update(TLAC_CLUMP_FILE=str(case/'clumps.txt'),TLAC_CLUMP_DIR=str(case))
    cwd = case if config is None else Path.cwd()
    with (case/'prepare.log').open('wb') as log:
        result = subprocess.run([str(exporter),'--line',line,'--atom',str(atom_copy),
                                 str(resolved)],cwd=cwd,env=env,
                                stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'Native preparation failed. See {case / "prepare.log"}.')
    meta_path = case/'case.json'
    meta = json.loads(meta_path.read_text(encoding='utf8'))
    if meta['nphot']!=nphot or meta['cpu_transport_seconds']!=0 or (case/'case.cpu.bin').exists():
        raise ValueError('The exporter returned an unexpected packet count or CPU transport result.')
    if (case/'case.photons.bin').stat().st_size != nphot*meta['photon_size']:
        raise ValueError('The native packet file has an unexpected size.')
    meta.update(peacock_model=line,peacock_atom_sha256=atom_digest)
    if record.get('device'):
        meta['peacock_device_source_sha256'] = record['device']['device_source_sha256']
        meta['peacock_device_bundle_sha256'] = record['device']['device_bundle_sha256']
    write_json(meta_path,meta)
    write_json(case/'prepare_report.json',{
        'line':line,'packets':nphot,'cpu_transport_executed':False,
        'atomic_data_sha256':atom_digest,'executable_sha256':record['executable_sha256'],
        'inputs':{name:sha(case/name) for name in ('case.json','case.grid.bin','case.photons.bin','case.emission.bin')},
    })
    print(f'Prepared {nphot} packets for {line} in {case}')
    return case
