"""Build and run the native CPU engine selected by a PEACOCK line profile."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


def _run_section(lines):
    """Locate the effective assignments in the native INI [run] section."""
    current = ""
    end = None
    entries = {}
    index = 0
    while index < len(lines):
        start = index
        line = lines[index].strip()
        index += 1
        while line.endswith("\\") and index < len(lines):
            line = line[:-1] + lines[index].strip()
            index += 1
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].strip().lower()
        if current != "run":
            continue
        end = index
        if line.startswith(("#", ";")) or "=" not in line:
            continue
        key, value = line.split("=", 1)
        match = re.fullmatch(r"""\s*(?:"([^"]*)"|'([^']*)'|([^;#]*?))\s*([;#].*)?""", value)
        if match:
            parsed = next(part for part in match.groups()[:3] if part is not None).strip()
            entries[key.strip().lower()] = (start, index, parsed, match[4])
    return end, entries


def _resolve_config(text, prefix, nphot, preserve_templates):
    lines = text.splitlines(keepends=True)
    end, entries = _run_section(lines)
    updates = {"filename_prefix": prefix}
    if nphot is not None:
        updates["nphot"] = str(nphot)
    additions = []
    edits = []
    for key, value in updates.items():
        if key not in entries:
            additions.append(f"{key} = {value}\n")
            continue
        first, last, original, comment = entries[key]
        suffix = " " + comment if comment else ""
        edits.append((first, last, f"{key} = {value}{suffix}\n"))
        if preserve_templates and original.startswith("<") and original.endswith(">"):
            # The native parser counts each template occurrence. Keep its index
            # when an explicit output or packet-count override replaces its value.
            backup = f"peacock_original_{key}"
            while backup in entries:
                backup += "_"
            additions.append(f"{backup} = {original}\n")
    if end is None:
        end = len(lines)
        additions.insert(0, "\n[run]\n")
    elif additions and end > 0 and not lines[end - 1].endswith(("\n", "\r")):
        additions.insert(0, "\n")
    lines[end:end] = additions
    for first, last, replacement in sorted(edits, reverse=True):
        lines[first:last] = [replacement]
    return "".join(lines)


def native_prefix(path):
    prefix = str(path)
    # The native resolved-config filename has a 256-byte buffer.
    if len(os.fsencode(prefix)) + len("YYMMDD-HHMMSS.cfg") >= 256:
        raise ValueError("Choose a shorter output directory for native packet files.")
    if any(character in prefix for character in "\r\n"):
        raise ValueError("The output directory cannot contain line breaks.")
    if ";" in prefix or "#" in prefix:
        quote = next((character for character in ('"', "'") if character not in prefix), None)
        if quote is None:
            raise ValueError("This output path cannot be quoted in a native configuration.")
        prefix = f"{quote}{prefix}{quote}"
    return prefix


def run(view: Path, profile: dict, executable: Path, config: Path | None,
        output: Path, nphot: int | None = None, template_values=(), *,
        atom: Path, env=None) -> Path:
    """Run the selected native executable in a new output directory."""
    if nphot is not None and not 0 <= nphot <= 2**31 - 1:
        raise ValueError("The packet count must be between 0 and 2147483647.")
    templates = tuple(template_values)
    default_example = config is None
    source = (view / profile["cpu_example"] if default_example else config).resolve()
    original = source.read_bytes()
    executable = executable.resolve(strict=True)
    output = output.resolve()
    prefix = native_prefix(output / "packets_")

    resolved = _resolve_config(original.decode("utf-8", errors="surrogateescape"),
                               prefix, nphot, bool(templates))
    output.mkdir(parents=True, exist_ok=True)
    if any(output.iterdir()):
        raise FileExistsError(f"Use a new, empty output directory: {output}")
    config_path = output / "resolved.cfg"
    resolved_bytes = resolved.encode("utf-8", errors="surrogateescape")
    with config_path.open("xb") as stream:
        stream.write(resolved_bytes)
    atom_bytes = atom.read_bytes()
    atom_copy = output / "atomic.atom"
    with atom_copy.open("xb") as stream:
        stream.write(atom_bytes)

    # Custom configurations may read files relative to the caller's directory.
    cwd = output if default_example else Path.cwd()
    subprocess.run([str(executable), "--line", profile["id"], "--atom", str(atom_copy),
                    str(config_path), *templates], cwd=cwd, env=env, check=True)
    native_configs = sorted(output.glob("packets_*.cfg"))
    details = {}
    if native_configs:
        _, entries = _run_section(native_configs[0].read_text(
            encoding="utf-8", errors="surrogateescape").splitlines(keepends=True))
        for key in ("nphot", "random_seed"):
            if key in entries:
                details[key] = entries[key][2]
    record = {
        "backend": "cpu",
        "line": profile.get("id", profile.get("line")),
        "configuration": source.name,
        "configuration_sha256": hashlib.sha256(original).hexdigest(),
        "resolved_configuration_sha256": hashlib.sha256(resolved_bytes).hexdigest(),
        "executable_sha256": hashlib.sha256(executable.read_bytes()).hexdigest(),
        "atomic_data_sha256": hashlib.sha256(atom_bytes).hexdigest(),
        **details,
    }
    (output / "run.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    return output
