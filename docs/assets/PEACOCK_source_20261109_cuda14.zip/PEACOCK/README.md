# PEACOCK

Profiles of Emission and Absorption from Clumpy Outflows with Complex Kinematics

PEACOCK uses three-dimensional Monte Carlo radiative transfer to model UV
emission and absorption in clumpy galactic winds. It follows resonance
scattering, fluorescent re-emission in the applicable atomic networks, and
dust interactions. The engine builds on Max Gronke's `tlac`.

## Build once, then choose a line

Run these commands from the source directory. The catalog lists 14 line
profiles. All 14 support CUDA transport, and 12 also support CPU transport.

```sh
python3 peacock.py lines
```

The CPU build requires Python 3.9 or later, a C compiler, `nm`, and the GNU
Scientific Library (GSL). On Debian or Ubuntu, install `build-essential`,
`libgsl-dev` and `python3`. On macOS, install the Xcode command-line tools
and GSL with `brew install gsl`.

```sh
python3 peacock.py build --backend cpu
python3 peacock.py run --line HI1216 --backend cpu --output run/lya
python3 peacock.py run --line NV1239 --backend cpu --output run/nv1239
```

Both runs use the same `peacock-cpu` executable. The selected line loads
its atomic table from `lines/runtime/` and chooses its scattering operator
when the run starts.

A full CUDA build creates one native input exporter and one `transport.ptx`
for the chosen CUDA architecture. The same module runs all 14 profiles.

```sh
python3 peacock.py build --backend cuda
python3 peacock.py run --line CIV1548 --backend cuda --output run/civ
python3 peacock.py run --line SiII1190 --backend cuda --output run/si1190
```

See the [CUDA guide](docs/gpu-workflow.md) for the Windows compiler setup,
NVRTC options and separate preparation and execution commands.

## Inputs and reproducibility

Give each run a new or empty output directory. Keep the resolved
configuration and the copied `atomic.atom` with the packet files. CPU
`run.json` records the line and SHA-256 checksums for the configuration,
atomic table and native executable. CUDA preparation and execution records
also identify the native inputs, device source and compiled PTX.

The [line selection guide](docs/line-selection.md) lists the supported
networks and explains how to supply a custom configuration. The [cloud model
guide](docs/cloud-model.md) documents cloud schema 2, placement and the
common Cartesian Gaussian dispersion.

See [provenance and citation](docs/provenance.md) for source attribution,
papers and license information.
