# C II quickstart wind

`quickstart.cfg` defines the dust-free C II 1334/1335 continuum example used
by both CPU and CUDA runs. `quickstart-clumps.txt` contains the same complete
catalogue of 685 cloud centers for either backend, in Cartesian cm.

| Physical setting | Value | Configuration entry |
| --- | --- | --- |
| Cloud-placement bounds | 100–950 pc | `[grid] cloud_rin`, `cloud_rout` |
| Cloud radius | 50 pc | `[cloud1] rmax` and `size` |
| Cloud filling factor | 0.1 requested | `[grid] cloud_filling_factors` |
| Radial ground-level C II column, `N_1 = n_1 R_cl` | 5 × 10¹⁴ cm⁻² | `[cloud1] hydrogen = c 5e14` |
| Cloud temperature | 10,000 K | `[cloud1] temperature` |
| Radial bulk speed | 150 km s⁻¹ | Second `[grid] cloud_motion_params` value |
| Random velocity dispersion | 25 km s⁻¹ per Cartesian component | First `[grid] cloud_motion_params` value |
| Source continuum half-width | 600 km s⁻¹ | `[emission] frequency_param` |
| Source radial exponential scale | 0.001 pc | `[emission] position_param` |
| Primary photons | 100,000 | `[run] nphot` |
| Photon seed | 20261104 | `[run] random_seed` |
| Grid-velocity seed | 31415 | `[grid] random_seed` |
| Geometry seed | 31415 | Generator command below |

The background is empty, dust is absent and the prescribed lower-state
population ratio is `[emission] cii_ratio_21 = 0.1`. The historical
`hydrogen` key supplies the ground-level C II column in this configuration;
the column through a cloud diameter is twice the listed radial column.
Cloud centers have
uniform volume number density. They were selected from a rotated FCC
candidate lattice and relaxed without overlaps. A cloud's outer surface
remains inside 950 pc; the 100 pc inner cutoff applies to cloud centers.
Rounding to 685 clouds gives an actual filling
factor of 0.0999854.

After building a backend, run either command from the source directory:

```sh
python3 peacock.py run --line CII1334 --backend cpu --output run/cii-cpu
python3 peacock.py run --line CII1334 --backend cuda --output run/cii-cuda
```

Both commands select this configuration and catalogue automatically. The
CPU and CUDA random streams are independent, so compare binned spectra
with Monte Carlo uncertainties. The example launches 100,000 photons. Increase
`--nphot` in a new run to check convergence for the spectral features
you want to measure.

For custom settings, copy the configuration, edit it, and supply a complete
catalogue consistent with its cloud radius, shell and filling factor:

```sh
python3 peacock.py run --line CII1334 --backend cpu --config my-cii.cfg --clump-file examples/cii/quickstart-clumps.txt --output run/my-cii
```

The same `--config` and `--clump-file` options work for CUDA. Changing only
velocities, temperature, column density or photon count does not require
new positions. Each run saves the input positions as `clumps.txt`.

## Regenerate the positions

Regeneration requires NumPy and SciPy; CPU transport with the bundled
catalogue does not. From the source directory:

```sh
python3 tools/fcc_clump_geometry.py run/cii-geometry --fv 0.1 --radius-pc 50 --rmin-pc 100 --rmax-pc 950 --volume-beta 0 --seed 31415 --shell-width-pc 100
```

Use the resulting `clumps.txt` as the complete cm catalogue.
