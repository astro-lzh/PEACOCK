/* Multilevel UV scattering and transfer. The packed atom is uploaded once
 * for each CUDA context. Geometry and the photon ABI are shared. */
#define PEACOCK_DUST_TABLE_STORAGE __constant__ const
#include "peacock_dust_table.h"
#define PEACOCK_VOIGT_COEFFICIENTS_STORAGE __constant__ const
#include "peacock_voigt_coefficients.h"

namespace multilevel {
enum { max_lower = 53, max_upper = 3, max_transitions = 53 };
enum { max_sampler_proposals = 1048576, max_scatterings = 2000000,
       max_transport_steps = 10000000, boundary_source_mode = 13 };
enum { invalid_packet = -1, scattering_limit = -2, step_limit = -3,
       absorbed_packet = 0, escaped_packet = 1 };
enum { step_in_cell = 0, cloud_crossing = 100, invalid_step = -1000 };
enum { cartesian_grid = 1, spherical_grid = 2 };
constexpr double light_speed = 29979245800.0;
constexpr double electron_charge = 4.803205e-10;
constexpr double electron_mass = 9.10938e-28;
constexpr double boltzmann_constant = 1.38065e-16;

struct Transition {
  int lower, upper;
  double A, nu, f, w2;
};

struct Atom {
  unsigned int nlower, nupper, nlines, reference;
  double mass_g, reference_hz, reference_gamma;
  double lower_energy[max_lower], population[max_lower], gamma[max_upper];
  Transition lines[max_transitions];
};
static_assert(sizeof(Transition) == 40, "CUDA UV transition layout");
static_assert(sizeof(Atom) == 3032, "CUDA UV atomic table layout");
}  // namespace multilevel

extern "C" {
__constant__ multilevel::Atom peacock_cuda_multilevel_atom;
}

extern "C" __global__ void peacock_multilevel_abi(unsigned long long *out) {
  if (threadIdx.x || blockIdx.x) return;
  using multilevel::Atom;
  using multilevel::Transition;
  out[0] = sizeof(Atom);
  out[1] = alignof(Atom);
  out[2] = offsetof(Atom, nlower);
  out[3] = offsetof(Atom, nupper);
  out[4] = offsetof(Atom, nlines);
  out[5] = offsetof(Atom, reference);
  out[6] = offsetof(Atom, mass_g);
  out[7] = offsetof(Atom, reference_hz);
  out[8] = offsetof(Atom, reference_gamma);
  out[9] = offsetof(Atom, lower_energy);
  out[10] = offsetof(Atom, population);
  out[11] = offsetof(Atom, gamma);
  out[12] = offsetof(Atom, lines);
  out[13] = sizeof(Transition);
  out[14] = alignof(Transition);
  out[15] = offsetof(Transition, lower);
  out[16] = offsetof(Transition, upper);
  out[17] = offsetof(Transition, A);
  out[18] = offsetof(Transition, nu);
  out[19] = offsetof(Transition, f);
  out[20] = offsetof(Transition, w2);
}

namespace multilevel {
struct Complex {
  double real, imag;
};

TLAC_DEVICE Complex product(Complex a, Complex b) {
  return {a.real * b.real - a.imag * b.imag, a.real * b.imag + a.imag * b.real};
}

TLAC_DEVICE Complex quotient(Complex a, Complex b) {
  // Scale the denominator before forming its squared magnitude.
  const double scale = fmax(fabs(b.real), fabs(b.imag));
  b.real /= scale;
  b.imag /= scale;
  const double denominator = b.real * b.real + b.imag * b.imag;
  return {(a.real * b.real + a.imag * b.imag) / denominator / scale,
          (a.imag * b.real - a.real * b.imag) / denominator / scale};
}

// Real part of w(x+ia), using the CPU Weideman coefficients and far-wing expansion.
TLAC_DEVICE double voigt(double a, double x) {
  if (!(a >= 0) || !isfinite(a) || !isfinite(x)) return nan("");
  if (a == 0) return exp(-x * x);
  constexpr double inverse_sqrt_pi = 0.56418958354775628695;
  constexpr double asymptotic_radius = 40;
  constexpr int asymptotic_terms = 8;
  const Complex z = {x, a};
  if (hypot(x, a) > asymptotic_radius) {
    Complex term = {1., 0.}, sum = term;
    const Complex z_squared = product(z, z);
    for (int n = 1; n <= asymptotic_terms; n++) {
      term = product(term, quotient({static_cast<double>(2 * n - 1), 0.},
                                   {2. * z_squared.real, 2. * z_squared.imag}));
      sum.real += term.real;
      sum.imag += term.imag;
    }
    return quotient({-inverse_sqrt_pi * sum.imag, inverse_sqrt_pi * sum.real}, z).real;
  }

  const Complex denominator = {weideman_L + a, -x};
  const Complex argument = quotient({weideman_L - a, x}, denominator);
  Complex polynomial = {weideman_a[0], 0.};
  for (unsigned int i = 1; i < sizeof(weideman_a) / sizeof(weideman_a[0]); i++) {
    polynomial = product(polynomial, argument);
    polynomial.real += weideman_a[i];
  }
  const Complex square = product(denominator, denominator);
  return fmax(0., quotient({2 * polynomial.real, 2 * polynomial.imag}, square).real +
                  quotient({inverse_sqrt_pi, 0.}, denominator).real);
}

struct Dust {
  double extinction, albedo, asymmetry;
};

TLAC_DEVICE bool dust_properties(double frequency, Dust &dust) {
  if (!(frequency > 0) || !isfinite(frequency)) return false;
  const double wavelength = light_speed / frequency * 1e4;  // vacuum microns
  constexpr unsigned int rows = sizeof(dust_table) / sizeof(dust_table[0]);
  if (wavelength < dust_table[0][0] || wavelength > dust_table[rows - 1][0])
    return false;
  unsigned int i = 0;
  while (i < rows - 2 && wavelength > dust_table[i + 1][0]) ++i;
  const double fraction = (wavelength - dust_table[i][0]) /
                          (dust_table[i + 1][0] - dust_table[i][0]);
  dust.extinction = dust_table[i][1] * (1 - fraction) + dust_table[i + 1][1] * fraction;
  dust.albedo = dust_table[i][2] * (1 - fraction) + dust_table[i + 1][2] * fraction;
  dust.asymmetry = dust_table[i][3] * (1 - fraction) + dust_table[i + 1][3] * fraction;
  return true;
}

TLAC_DEVICE double thermal_speed(double temperature) {
  return sqrt(2.0 * boltzmann_constant * temperature / peacock_cuda_multilevel_atom.mass_g);
}

TLAC_DEVICE double doppler_width(double temperature) {
  return peacock_cuda_multilevel_atom.reference_hz * thermal_speed(temperature) / light_speed;
}

TLAC_DEVICE double absolute_frequency(double x, double temperature) {
  return peacock_cuda_multilevel_atom.reference_hz + x * doppler_width(temperature);
}

TLAC_DEVICE double frame_frequency(double frequency, double beta_old, double beta_new) {
  return frequency / (1 - beta_old) * (1 - beta_new);
}

TLAC_DEVICE double line_width(double x, double temperature) {
  return absolute_frequency(x, temperature) * thermal_speed(temperature) / light_speed;
}

TLAC_DEVICE double line_detuning(int line, double x, double temperature) {
  return (absolute_frequency(x, temperature) - peacock_cuda_multilevel_atom.lines[line].nu) /
         line_width(x, temperature);
}

TLAC_DEVICE double cross_sections(double x, double temperature, double *weights) {
  const auto &atom = peacock_cuda_multilevel_atom;
  const double width = line_width(x, temperature);
  if (!(width > 0) || !isfinite(width)) return nan("");
  const double prefactor = sqrt(PI) * electron_charge * electron_charge /
                           (electron_mass * light_speed * width);
  double sum = 0.;
  for (unsigned int i = 0; i < atom.nlines; ++i) {
    const Transition line = atom.lines[i];
    double value = 0.;
    if (atom.population[line.lower] > 0)
      value = atom.population[line.lower] * prefactor * line.f *
        voigt(atom.gamma[line.upper] / (4 * PI * width), line_detuning(i, x, temperature));
    if (weights != nullptr) weights[i] = value;
    sum += value;
  }
  return sum;
}

TLAC_DEVICE double core_wing_boundary(double damping) {
  return 6.9184721 + 81.766279 / (log(damping) - 14.651253);
}

TLAC_DEVICE double parallel_three_piece(GpuRng *rng, double x, double a) {
  const double absolute_detuning = fabs(x);
  const double switch_velocity = 0.97 * absolute_detuning;
  const double switch_weight = exp(-switch_velocity * switch_velocity);
  const double switch_angle = atan((switch_velocity - absolute_detuning) / a);
  const double left_probability = (switch_angle + 0.5 * PI) /
    ((1 - switch_weight) * switch_angle + (1 + switch_weight) * 0.5 * PI);
  if (!isfinite(left_probability)) return nan("");
  for (unsigned int proposal = 0; proposal < max_sampler_proposals; ++proposal) {
    const double region_draw = gpu_rand_uniform(rng);
    const double angle_draw = gpu_rand_uniform(rng);
    const double angle = region_draw > left_probability
      ? switch_angle + (0.5 * PI - switch_angle) * angle_draw
      : -0.5 * PI + (switch_angle + 0.5 * PI) * angle_draw;
    const double velocity = a * tan(angle) + absolute_detuning;
    const double draw = gpu_rand_uniform(rng);
    const double test = region_draw < left_probability
      ? exp(velocity * velocity) * draw
      : switch_weight * exp(velocity * velocity) * draw;
    if (test <= 1) return velocity * (x < 0 ? -1 : 1);
  }
  return nan("");
}

TLAC_DEVICE double parallel_five_piece(GpuRng *rng, double signed_x, double a) {
  const double x = fabs(signed_x);
  const double damping_fit_scale = 0.3;
  const double outer_join = (6.0 + 0.375 * damping_fit_scale * log(a)) *
                            2.0 * atan(sqrt(x)) / PI;
  const double inner_join = 2.25 - (0.55 + 0.025 * damping_fit_scale * log(a)) *
                            atan(3 * (x - 4));
  const double outer_weight = exp(-outer_join * outer_join);
  const double inner_weight = exp(-inner_join * inner_join);
  double area1 = outer_weight / a * atan(a / (outer_join + x));
  double area2 = area1 + inner_weight / a * atan((a * (outer_join - inner_join)) /
                  (a * a + (inner_join + x) * (outer_join + x)));
  double area3 = area2 + 1.0 / a * atan(2.0 * inner_join * a /
                  (x * x + a * a - inner_join * inner_join));
  double area4 = area3 + (inner_weight / a) * atan(a * (outer_join - inner_join) /
                  (a * a + (outer_join - x) * (inner_join - x)));
  const double total_area = area4 + (outer_weight / a) * (atan(a / (outer_join - x)) + PI);
  if (!(total_area > 0.0) || !isfinite(total_area)) return nan("");

  area1 /= total_area;
  area2 /= total_area;
  area3 /= total_area;
  area4 /= total_area;
  const double inverse_total_area = 1.0 / total_area;
  for (unsigned int proposal = 0; proposal < max_sampler_proposals; ++proposal) {
    const double draw = gpu_rand_uniform(rng);
    double velocity, envelope_weight;
    if (draw < area1) {
      double angle = draw * a / (inverse_total_area * outer_weight);
      if (angle == 0.) angle = 1e-12;
      velocity = x + a / tan(angle);
      envelope_weight = outer_weight;
    } else if (draw > area1 && draw < area2) {
      const double angle = a * (draw - area1) / (inverse_total_area * inner_weight);
      const double shift = -1.0 * (outer_join + x) / a;
      velocity = x + a * ((tan(angle) + shift) / (1.0 - shift * tan(angle)));
      envelope_weight = inner_weight;
    } else if (draw > area2 && draw < area3) {
      const double angle = a * (draw - area2) / inverse_total_area;
      const double shift = (inner_join + x) / a;
      velocity = x + a * (tan(angle) - shift) / (1 + shift * tan(angle));
      envelope_weight = 1.;
    } else if (draw > area3 && draw < area4) {
      const double angle = a * (draw - area3) / (inner_weight * inverse_total_area) +
                           atan((inner_join - x) / a);
      velocity = x + a * tan(angle);
      envelope_weight = inner_weight;
    } else {
      const double angle = a * (draw - area4) / (inverse_total_area * outer_weight);
      const double shift = (outer_join - x) / a;
      velocity = x + a * (tan(angle) + shift) / (1 - shift * tan(angle));
      envelope_weight = outer_weight;
    }
    const double edge = sqrt(-1. * log(envelope_weight));
    if (gpu_rand_uniform(rng) <= exp(-1. * (velocity * velocity - edge * edge)))
      return velocity * (signed_x < 0 ? -1 : 1);
  }
  return nan("");
}

TLAC_DEVICE double parallel_velocity(GpuRng *rng, const photon &p, int line) {
  const auto &atom = peacock_cuda_multilevel_atom;
  const double x = line_detuning(line, p.x, p.curr_cell->T);
  const double a = atom.gamma[atom.lines[line].upper] / (4 * PI * line_width(p.x, p.curr_cell->T));
  if (!isfinite(x) || !(a > 0) || !isfinite(a)) return nan("");
  if (fabs(x) > 12.) return doublet::gpu_sct_doublet_far_parallel_velocity(rng, x, a);
  return fabs(x) < 3.5 ? parallel_three_piece(rng, x, a) : parallel_five_piece(rng, x, a);
}

TLAC_DEVICE int select_transition(GpuRng *rng, const photon &p) {
  double weights[max_transitions];
  const double total = cross_sections(p.x, p.curr_cell->T, weights);
  if (!(total > 0) || !isfinite(total)) return -1;
  double draw = gpu_rand_uniform(rng) * total;
  int last = -1;
  for (unsigned int i = 0; i < peacock_cuda_multilevel_atom.nlines; ++i) {
    if (weights[i] > 0) {
      last = i;
      draw -= weights[i];
      if (draw < 0) return i;
    }
  }
  return last;
}

TLAC_DEVICE int decay(GpuRng *rng, int incoming) {
  const auto &atom = peacock_cuda_multilevel_atom;
  const int upper = atom.lines[incoming].upper;
  double draw = gpu_rand_uniform(rng) * atom.gamma[upper];
  int last = -1;
  for (unsigned int i = 0; i < atom.nlines; ++i) {
    if (atom.lines[i].upper == upper) {
      last = i;
      draw -= atom.lines[i].A;
      if (draw < 0) return i;
    }
  }
  return last;
}

TLAC_DEVICE double phase_pdf(double cosine, double weight) {
  return .5 * (1 + weight * .25 * (3 * cosine * cosine - 1));
}

TLAC_DEVICE double angle_cosine(GpuRng *rng, int incoming, int outgoing) {
  const auto &atom = peacock_cuda_multilevel_atom;
  const double weight = atom.lines[incoming].w2 * atom.lines[outgoing].w2;
  const double maximum = fmax(phase_pdf(0, weight), phase_pdf(1, weight));
  for (unsigned int proposal = 0; proposal < max_sampler_proposals; ++proposal) {
    const double cosine = 2 * gpu_rand_uniform(rng) - 1;
    if (gpu_rand_uniform(rng) * maximum <= phase_pdf(cosine, weight)) return cosine;
  }
  return nan("");
}

TLAC_DEVICE double raman_frequency(double frequency, int incoming, int outgoing,
                                   double beta_in, double beta_out) {
  const auto &atom = peacock_cuda_multilevel_atom;
  return (frequency * (1 - beta_in) + light_speed *
          (atom.lower_energy[atom.lines[incoming].lower] -
           atom.lower_energy[atom.lines[outgoing].lower])) / (1 - beta_out);
}

TLAC_DEVICE bool scatter_atom(GpuRng *rng, photon &p) {
  const int incoming = select_transition(rng, p);
  if (incoming < 0) return false;
  const int outgoing = decay(rng, incoming);
  if (outgoing < 0) return false;
  p.u_scatter_last[0] = parallel_velocity(rng, p, incoming);
  if (!isfinite(p.u_scatter_last[0])) return false;
  p.u_scatter_last[1] = gpu_rand_gaussian(rng, 1.0 / sqrt(2.0));
  const double angle = angle_cosine(rng, incoming, outgoing);
  if (!isfinite(angle) || !isfinite(p.u_scatter_last[1])) return false;
  gpu_rotrand3d_angle(rng, p.dir, acos(angle), p.dir);

  const double cosine = fmax(-1., fmin(1., gpu_scalar_product_3d(rng, p.dir_last, p.dir)));
  const double velocity_over_c = thermal_speed(p.curr_cell->T) / light_speed;
  const double beta_in = p.u_scatter_last[0] * velocity_over_c;
  const double beta_out = (p.u_scatter_last[0] * cosine +
    p.u_scatter_last[1] * sqrt(fmax(0., 1 - cosine * cosine))) * velocity_over_c;
  const double width = doppler_width(p.curr_cell->T);
  const double reference = peacock_cuda_multilevel_atom.reference_hz;
  const double frequency = raman_frequency(reference + width * p.x, incoming, outgoing,
                                           beta_in, beta_out);
  p.x = (frequency - reference) / width;
  p.sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p.curr_cell, p.dir, p.pos, p.grid);
  return frequency > 0 && isfinite(frequency) && isfinite(p.x) && isfinite(p.sc_dir_bulk);
}

TLAC_DEVICE int scatter_dust(GpuRng *rng, photon &p, const Dust &dust) {
  if (dust.albedo < 0 || dust.albedo > 1 || !isfinite(dust.albedo))
    return invalid_packet;
  if (!(dust.albedo > gpu_rand_uniform(rng))) {
    p.curr_cell = nullptr;
    p.curr_tau = -1.0;
    return absorbed_packet;
  }
  const double draw = gpu_rand_uniform(rng);
  const double g = dust.asymmetry;
  if (!isfinite(g) || fabs(g) >= 1.0) return invalid_packet;
  const double cosine = fabs(g) < 1e-10 ? 2 * draw - 1 :
    -((g - 1) * (g - 1) + 2 * (g - 1) * (1 + g * g) * draw -
      2 * g * (1 + g * g) * draw * draw) / pow(1 + g * (2 * draw - 1), 2);
  if (!isfinite(cosine)) return invalid_packet;
  gpu_rotrand3d_angle(rng, p.dir, acos(fmax(-1., fmin(1., cosine))), p.dir);
  p.sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p.curr_cell, p.dir, p.pos, p.grid);
  return isfinite(p.sc_dir_bulk) ? 1 : invalid_packet;
}

TLAC_DEVICE bool update_photon_values(GpuRng *rng, photon &p, Dust &dust) {
  const double previous_width = p.Delta_nu_D;
  const double previous_bulk = p.sc_dir_bulk;
  p.Delta_nu_D = doppler_width(p.curr_cell->T);
  p.sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p.curr_cell, p.dir, p.pos, p.grid);
  if (!(previous_width > 0 && isfinite(previous_width) && p.Delta_nu_D > 0 &&
        isfinite(p.Delta_nu_D) && isfinite(p.sc_dir_bulk))) return false;

  const auto &atom = peacock_cuda_multilevel_atom;
  const double frequency = atom.reference_hz + p.x * previous_width;
  const double previous_beta = previous_bulk * previous_width / atom.reference_hz;
  const double current_beta = p.sc_dir_bulk * p.Delta_nu_D / atom.reference_hz;
  p.x = (frame_frequency(frequency, previous_beta, current_beta) - atom.reference_hz) /
        p.Delta_nu_D;
  p.a = (atom.reference_gamma / (2 * PI)) / (2.0 * p.Delta_nu_D);
  p.x_cw = core_wing_boundary(p.a);
  if (!dust_properties(absolute_frequency(p.x, p.curr_cell->T), dust)) return false;
  p.curr_tau = p.curr_cell->n_HI * cross_sections(p.x, p.curr_cell->T, nullptr) +
               p.curr_cell->n_D * dust.extinction;
  return isfinite(p.x) && isfinite(p.curr_tau) && p.curr_tau >= 0;
}

TLAC_DEVICE bool enter_cloud(GpuRng *rng, photon &p, int id) {
  grid_cell *owner = p.curr_cell;
  grid *cloud = owner->cloud_grids[id];
  p.grid_shifted = p.grid;
  p.cell_shifted = owner;
  for (int axis = 0; axis < 3; ++axis) {
    p.pos_shifted[axis] += owner->pos_clouds[id][axis];
    p.vel_shifted[axis] += owner->vel_clouds[id][axis];
    p.pos[axis] -= owner->pos_clouds[id][axis];
  }
  p.grid = cloud;
  p.curr_cell = &cloud->cells[cloud->ncells[0] - 1][0][0];
  Dust dust;
  if (!update_photon_values(rng, p, dust)) return false;

  const double width = p.Delta_nu_D;
  const double reference = peacock_cuda_multilevel_atom.reference_hz;
  const double cloud_beta = gpu_scalar_product_3d(rng, p.vel_shifted, p.dir) * width / reference;
  p.x = (frame_frequency(reference + p.x * width, 0, cloud_beta) - reference) / width;
  return isfinite(p.x);
}

TLAC_DEVICE bool leave_cloud(GpuRng *rng, photon &p) {
  p.curr_cell = p.cell_shifted;
  p.grid = p.grid_shifted;
  p.cell_shifted = nullptr;
  p.grid_shifted = nullptr;
  for (int axis = 0; axis < 3; ++axis) {
    p.pos[axis] += p.pos_shifted[axis];
    p.pos_shifted[axis] = 0;
  }
  const double width = p.Delta_nu_D;
  const double reference = peacock_cuda_multilevel_atom.reference_hz;
  const double cloud_beta = gpu_scalar_product_3d(rng, p.vel_shifted, p.dir) * width / reference;
  p.x = (frame_frequency(reference + p.x * width, cloud_beta, 0) - reference) / width;
  Dust dust;
  if (!update_photon_values(rng, p, dust)) return false;
  for (int axis = 0; axis < 3; ++axis) p.vel_shifted[axis] = 0;
  ++p.nclouds_passed;
  return true;
}

TLAC_DEVICE int advance(GpuRng *rng, photon &p, double requested, double &travelled) {
  double intersection[3];
  const int cloud = gpu_get_cloud_intersection(rng, p.curr_cell, p.pos, p.dir,
                                              intersection, &travelled);
  if (cloud >= 0) {
    if (requested > travelled) {
      for (int axis = 0; axis < 3; ++axis) p.pos[axis] = intersection[axis];
      return enter_cloud(rng, p, cloud) ? cloud_crossing : invalid_step;
    }
  } else {
    if (p.grid->type != cartesian_grid && p.grid->type != spherical_grid) return invalid_step;
    grid_cell *next = nullptr;
    const int wall = p.grid->type == cartesian_grid
      ? gpu_get_next_cell_cart(rng, p.grid, p.curr_cell, p.pos, p.dir, &next,
                               intersection, &travelled, true)
      : gpu_get_next_cell_spherical(rng, p.grid, p.curr_cell, p.pos, p.dir, &next,
                                    intersection, &travelled);
    if (wall == step_in_cell || travelled == DBL_MAX || !isfinite(travelled) || travelled < 0)
      return invalid_step;
    if (requested > travelled) {
      for (int axis = 0; axis < 3; ++axis) p.pos[axis] = intersection[axis];
      p.curr_cell = next;
      return wall;
    }
  }

  if (!(requested >= 0) || !isfinite(requested)) return invalid_step;
  for (int axis = 0; axis < 3; ++axis) p.pos[axis] += requested * p.dir[axis];
  travelled = fabs(requested);
  return step_in_cell;
}

TLAC_DEVICE int propagate(GpuRng *rng, photon &p) {
  const auto &atom = peacock_cuda_multilevel_atom;
  if (atom.nlower == 0 || atom.nlower > max_lower || atom.nupper == 0 ||
      atom.nupper > max_upper || atom.nlines == 0 || atom.nlines > max_transitions ||
      atom.reference >= atom.nlines || !(atom.mass_g > 0 && atom.reference_hz > 0 &&
                                       atom.reference_gamma > 0)) return invalid_packet;
  if (p.emission_cfg->initial_pos_mode == boundary_source_mode) {
    const double coordinate = p.emission_cfg->initial_pos_param;
    if (!(coordinate >= 0 && coordinate <= 2) || coordinate != floor(coordinate))
      return invalid_packet;
    if (p.dir[static_cast<int>(coordinate)] < 0) return escaped_packet;
  }

  unsigned int steps = 0;
  while (p.curr_cell != nullptr) {
    if (++steps > max_transport_steps) return step_limit;
    Dust dust;
    if (!update_photon_values(rng, p, dust)) return invalid_packet;
    if (p.tau < 0) p.tau = gpu_get_new_tau(rng);
    if (!isfinite(p.tau)) return invalid_packet;
    const double extinction = p.curr_tau;
    const double requested = extinction == 0 ? DBL_MAX : p.tau / extinction;
    p.prev_cell = p.curr_cell;
    double travelled = 0.;
    const int step = advance(rng, p, requested, travelled);
    if (step == invalid_step || !isfinite(travelled) || travelled < 0) return invalid_packet;
    p.dist += travelled;
    p.c_HI_total += p.prev_cell->n_HI * travelled;
    p.c_D_total += p.prev_cell->n_D * travelled;
    p.tau -= travelled * extinction;

    if (step != step_in_cell) {
      if (p.tau < 0) p.tau = 0.;
      if (p.curr_cell == nullptr && p.cell_shifted != nullptr && !leave_cloud(rng, p))
        return invalid_packet;
      continue;
    }

    if (p.tau > 0 && travelled > 0) continue;
    if (!(p.curr_tau > 0)) return invalid_packet;
    if (p.nscatter >= max_scatterings) return scattering_limit;
    ++p.nscatter;
    const double draw = gpu_rand_uniform(rng);
    const double dust_fraction = p.curr_cell->n_D * dust.extinction / p.curr_tau;
    if (!isfinite(dust_fraction) || dust_fraction < 0 || dust_fraction > 1)
      return invalid_packet;
    p.x_last = p.x;
    for (int axis = 0; axis < 3; ++axis) p.dir_last[axis] = p.dir[axis];
    if (dust_fraction <= 0 || draw > dust_fraction) {
      if (!scatter_atom(rng, p)) return invalid_packet;
    } else {
      const int outcome = scatter_dust(rng, p, dust);
      if (outcome <= 0) return outcome;
    }
    p.dist = 0.;
    p.tau = -1.;
  }
  if (!isfinite(p.x) || !isfinite(p.sc_dir_bulk) || p.cell_shifted != nullptr)
    return invalid_packet;
  for (int axis = 0; axis < 3; ++axis)
    if (!isfinite(p.pos[axis]) || !isfinite(p.dir[axis])) return invalid_packet;
  return escaped_packet;
}
}  // namespace multilevel
