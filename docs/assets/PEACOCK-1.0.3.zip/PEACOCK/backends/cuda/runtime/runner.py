"""Run a selected atomic table against a shared CUDA transport module."""

import ctypes as C
from dataclasses import dataclass
import json
import math
from pathlib import Path
import re
import struct
import time
from typing import Optional

from .compiler import RUNTIME, sha, source_bundle


LIGHT_SPEED = 29979245800.0
MODEL_OPERATORS = {'lya': 'resonant', 'cii': 'fine_structure', 'civ': 'doublet', 'mgii': 'doublet'}
DECIMAL = re.compile(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?')
ATOM_FORMAT = struct.Struct('<II17d')
# Size, alignment, two uint32 offsets, then 17 double offsets.
ATOM_ABI = (ATOM_FORMAT.size, 8, 0, 4, *range(8, ATOM_FORMAT.size, 8))
MAX_LOWER, MAX_UPPER, MAX_TRANSITIONS = 53, 3, 53
MULTILEVEL_HEADER = struct.Struct(f'<4I3d{2 * MAX_LOWER + MAX_UPPER}d')
MULTILEVEL_TRANSITION = struct.Struct('<ii4d')
MULTILEVEL_ABI = (
    MULTILEVEL_HEADER.size + MAX_TRANSITIONS * MULTILEVEL_TRANSITION.size, 8,
    0, 4, 8, 12, 16, 24, 32, 40, 464, 888, MULTILEVEL_HEADER.size,
    MULTILEVEL_TRANSITION.size, 8, 0, 4, 8, 16, 24, 32,
)
INTEGER = re.compile(r'[+-]?[0-9]+')


@dataclass(frozen=True)
class MultilevelAtom:
    mass_g: float
    reference_hz: float
    reference_gamma: float
    reference: int
    lower_energy: tuple
    gamma: tuple
    transitions: tuple

    def pack(self, populations):
        nlower, nupper, nlines = len(self.lower_energy), len(self.gamma), len(self.transitions)
        if not isinstance(populations, list) or len(populations) != nlower:
            raise ValueError('Prepared multilevel populations do not match the atomic table')
        try:
            valid = all(type(value) in (int, float) and math.isfinite(value) and value >= 0
                        for value in populations)
        except OverflowError:
            valid = False
        if not valid:
            raise ValueError('Prepared multilevel populations must be finite and nonnegative')
        lower_padding = (0.0,) * (MAX_LOWER - nlower)
        header = MULTILEVEL_HEADER.pack(
            nlower, nupper, nlines, self.reference,
            self.mass_g, self.reference_hz, self.reference_gamma,
            *self.lower_energy, *lower_padding, *populations, *lower_padding,
            *self.gamma, *((0.0,) * (MAX_UPPER - nupper)),
        )
        records = b''.join(MULTILEVEL_TRANSITION.pack(*line) for line in self.transitions)
        return header + records + bytes((MAX_TRANSITIONS - nlines) * MULTILEVEL_TRANSITION.size)


@dataclass(frozen=True)
class Atom:
    model: str
    reference_hz: float
    digest: str
    device_bytes: bytes
    multilevel: Optional[MultilevelAtom] = None


def _load_multilevel_atom(model, payload):
    fields = [field.decode('ascii') for field in payload.split()]

    def require(condition, label):
        if not condition:
            raise ValueError(f'Invalid multilevel atomic table for {model}: {label}')

    def integers(tokens):
        require(all(INTEGER.fullmatch(token) for token in tokens), 'integer fields')
        return tuple(map(int, tokens))

    def numbers(tokens):
        require(all(DECIMAL.fullmatch(token) for token in tokens), 'numeric fields')
        values = tuple(map(float, tokens))
        require(all(math.isfinite(value) for value in values), 'nonfinite values')
        return values

    require(len(fields) >= 12 and fields[:3] == ['PEACOCK_ATOM_V1', 'multilevel', model] and
            all(len(field) < 96 for field in fields), 'header')
    nlower, nupper, nlines, reference, atomic_number, ion_stage = integers(fields[3:9])
    require(1 <= nlower <= MAX_LOWER and 1 <= nupper <= MAX_UPPER and
            1 <= nlines <= MAX_TRANSITIONS and 0 <= reference < nlines and
            1 <= atomic_number <= 118 and 1 <= ion_stage <= atomic_number + 1,
            'level counts, reference index or ion')
    require(len(fields) == 12 + nlower + nupper + 6 * nlines, 'record count')
    mass, reference_hz, reference_gamma = numbers(fields[9:12])
    lower_energy = numbers(fields[12:12 + nlower])
    gamma = numbers(fields[12 + nlower:12 + nlower + nupper])
    require(min(mass, reference_hz, reference_gamma, *gamma) > 0, 'mass, reference or widths')

    transitions = []
    upper_sums = [0.0] * nupper
    for i in range(12 + nlower + nupper, len(fields), 6):
        lower, upper = integers(fields[i:i + 2])
        rate, frequency, oscillator, w2 = numbers(fields[i + 2:i + 6])
        require(0 <= lower < nlower and 0 <= upper < nupper and rate > 0 and frequency > 0 and
                oscillator >= 0 and abs(w2) <= 1, 'transition record')
        transitions.append((lower, upper, rate, frequency, oscillator, w2))
        upper_sums[upper] += rate
    require(transitions[reference][3] == reference_hz and
            gamma[transitions[reference][1]] == reference_gamma and
            all(abs(total / width - 1.0) <= 1e-12 for total, width in zip(upper_sums, gamma)),
            'reference transition or decay network')

    atom = MultilevelAtom(mass, reference_hz, reference_gamma, reference,
                          lower_energy, gamma, tuple(transitions))
    # The scalar constant retains its size and identifies the active operator.
    scalar = ATOM_FORMAT.pack(1, 4, mass, reference_hz, 0, 0, 0, 0,
                              reference_gamma, 0, 0, reference_gamma / (2 * math.pi),
                              0, 0, 0, 0, 0, 0, 0)
    return Atom(model, reference_hz, sha(payload), scalar, atom)


def load_atom(profile, atom_file):
    """Read the same external atom used during native preparation."""
    model = profile.get('gpu_model') or profile['id']
    if profile['operator'] == 'multilevel':
        return _load_multilevel_atom(model, Path(atom_file).read_bytes())
    operator = MODEL_OPERATORS.get(model)
    if operator is None or profile['operator'] != operator:
        raise ValueError(f'CUDA does not support the selected transition {model}')
    payload = Path(atom_file).read_bytes()
    fields = payload.decode('ascii').split()
    counts = {'resonant': 4, 'fine_structure': 11, 'doublet': 7}
    if (fields[:3] != ['PEACOCK_ATOM_V1', operator, model] or
            len(fields) != 3 + counts[operator] or
            any(not DECIMAL.fullmatch(field) for field in fields[3:])):
        raise ValueError(f'Atomic table header or fields do not match CUDA transition {model}')
    numbers = [float(field) for field in fields[3:]]
    if not all(math.isfinite(value) for value in numbers):
        raise ValueError('Atomic table values must be finite')

    mass = numbers[0]
    red = f1 = f2 = decay0 = decay1 = decay2 = width = fine = detuning = 0.0
    phases = (0.0, 0.0, 0.0, 0.0)
    if operator == 'resonant':
        operator_id, dust = 1, 0.32
        f0, reference, width = numbers[1:]
        valid = min(numbers) > 0
    elif operator == 'fine_structure':
        operator_id, dust = 2, 0.358
        e1, e2, e3, e4, f0, f1, f2, decay0, decay1, decay2 = numbers[1:]
        reference = LIGHT_SPEED * (e3 - e1)
        nu23 = LIGHT_SPEED * (e3 - e2)
        nu24 = LIGHT_SPEED * (e4 - e2)
        fine = LIGHT_SPEED * (e2 - e1)
        detuning = reference - nu24
        valid = (e1 < e2 < e4 < e3 and reference > nu23 > nu24 > 0 and fine > 0 and
                 min(mass, f0, f1, f2, decay0, decay1, decay2) > 0 and
                 math.isfinite(decay0 + decay1))
        phases = (0.5, 0.32, -0.4, 0.28)
    else:
        operator_id, dust = 3, 0.40
        blue_e, red_e, f0, f1, decay0, decay1 = numbers[1:]
        reference, red = LIGHT_SPEED * blue_e, LIGHT_SPEED * red_e
        valid = min(numbers) > 0 and reference > red
    derived = (mass, reference, red, f0, f1, f2, decay0, decay1, decay2, width,
               fine, detuning, dust, *phases)
    if not valid or not all(math.isfinite(value) for value in derived):
        raise ValueError(f'Atomic table has invalid parameters for {model}')
    return Atom(model, reference, sha(payload), ATOM_FORMAT.pack(1, operator_id, *derived))


def _launch(driver, kernel, arguments, count, threads):
    params = (C.c_void_p * len(arguments))(*(C.addressof(value) for value in arguments))
    driver.call('cuLaunchKernel', kernel, (count + threads - 1) // threads, 1, 1,
                threads, 1, 1, 0, None, params, None)
    driver.call('cuCtxSynchronize')


def _device_abi(driver, name, expected, layout):
    kernel = C.c_void_p()
    driver.call('cuModuleGetFunction', C.byref(kernel), driver.module, name)
    size = 8 * len(expected)
    ptr = driver.alloc(size)
    try:
        _launch(driver, kernel, [C.c_uint64(ptr)], 1, 1)
        actual = struct.unpack(f'<{len(expected)}Q', driver.download(ptr, size))
    finally:
        driver.call('cuMemFree_v2', ptr)
    if actual != tuple(expected):
        raise ValueError(f'Shared CUDA module ABI differs from the {layout} layout')


def _upload_constant(driver, name, data, layout):
    lookup = driver.lib.cuModuleGetGlobal_v2
    lookup.argtypes = [C.POINTER(C.c_uint64), C.POINTER(C.c_size_t), C.c_void_p, C.c_char_p]
    lookup.restype = C.c_int
    pointer, size = C.c_uint64(), C.c_size_t()
    driver.call('cuModuleGetGlobal_v2', C.byref(pointer), C.byref(size),
                driver.module, name)
    if size.value != len(data):
        raise ValueError(f'Shared CUDA module {layout} layout differs from the host layout')
    driver.upload(pointer.value, data)


def _upload_atom(driver, atom):
    _upload_constant(driver, b'peacock_cuda_atom', atom.device_bytes, 'atom')


def _packet_dtype(np, meta, abi):
    photon_size = abi['sizeof.photon']
    fields = {}
    for name in ('pos', 'dir', 'pos_shifted'):
        for i in range(3):
            fields[f'{name}{i}'] = [abi['photon.' + name] + i * 8, '<f8']
    for name in ('dist', 'tau', 'x', 'x_i', 'Delta_nu_D', 'sc_dir_bulk', 'c_HI_total', 'c_D_total'):
        fields[name] = [abi['photon.' + name], '<f8']
    for name in ('nscatter', 'nclouds_passed'):
        fields[name] = [abi['photon.' + name], '<i4']
    if meta['fields'] != fields:
        raise ValueError('Prepared packet fields differ from the CUDA ABI')
    fields = meta['fields']
    return np.dtype({'names': list(fields), 'formats': [value[1] for value in fields.values()],
                     'offsets': [value[0] for value in fields.values()], 'itemsize': photon_size})


def _transport(driver, np, grid, photons, emission, meta, batch):
    count, size = meta['nphot'], meta['photon_size']
    relocations = meta['grid_relocations']
    if (len({field for field, _ in relocations}) != len(relocations) or
            any(not 0 <= field <= len(grid) - 8 or not 0 <= target < len(grid)
                for field, target in relocations)):
        raise ValueError('Prepared grid contains invalid pointer relocations')
    allocations = []

    def alloc(nbytes):
        pointer = driver.alloc(nbytes)
        allocations.append(pointer)
        return pointer

    try:
        grid_ptr = alloc(len(grid))
        for field, target in relocations:
            struct.pack_into('<Q', grid, field, grid_ptr + target)
        driver.upload(grid_ptr, grid)
        for row in range(count):
            for field in meta['pointer_offsets']:
                index = row * size + field
                value, = struct.unpack_from('<Q', photons, index)
                if value:
                    if value - 1 >= len(grid):
                        raise ValueError('Prepared photon contains an invalid grid pointer')
                    struct.pack_into('<Q', photons, index, grid_ptr + value - 1)

        capacity = min(batch, count)
        photon_ptr, status_ptr = alloc(capacity * size), alloc(capacity * 4)
        output, statuses = bytearray(), bytearray()
        seconds = 0.0
        for first in range(0, count, batch):
            n = min(batch, count - first)
            driver.upload(photon_ptr, photons[first * size:(first + n) * size])
            driver.upload(status_ptr, np.full(n, -99, dtype='<i4').tobytes())
            arguments = [C.c_uint64(photon_ptr), C.c_uint64(status_ptr), C.c_int(n),
                         C.create_string_buffer(emission), C.c_uint64(meta['seed']),
                         C.c_uint64(meta['sequence_offset'] + first)]
            started = time.perf_counter()
            _launch(driver, driver.kernel, arguments, n, 128)
            seconds += time.perf_counter() - started
            output.extend(driver.download(photon_ptr, n * size))
            statuses.extend(driver.download(status_ptr, n * 4))
        return output, np.frombuffer(statuses, dtype='<i4'), seconds
    finally:
        for ptr in reversed(allocations):
            driver.call('cuMemFree_v2', ptr)


def _readout(np, atom, output, initial, dtype, status, abi):
    result = np.frombuffer(output, dtype=dtype)
    arrays = {name: result[name].copy() for name in dtype.names}
    if atom.multilevel is not None:
        return _multilevel_readout(np, arrays, result, np.frombuffer(initial, dtype=dtype),
                                   status, atom.reference_hz)
    if atom.model == 'cii':
        return arrays
    reference = atom.reference_hz
    c_kms = LIGHT_SPEED / 1e5
    q = (result['x'] + result['sc_dir_bulk']) * result['Delta_nu_D'] * (c_kms / reference)
    with np.errstate(invalid='ignore', divide='ignore'):
        red_velocity = -q / (1 + q / c_kms)
    if atom.model != 'lya':
        q[status != 1] = np.nan
        red_velocity[status != 1] = np.nan
        first = np.frombuffer(initial, dtype=dtype)
        qi = (first['x'] + first['sc_dir_bulk']) * first['Delta_nu_D'] * (c_kms / reference)
        extra = np.dtype({'names': ['component'], 'formats': ['<f8'],
                          'offsets': [abi['photon.extra_info']], 'itemsize': dtype.itemsize})
        arrays.update(nu_final_Hz=reference * (1 + q / c_kms), q_initial_km_s=qi,
                      nu_initial_Hz=reference * (1 + qi / c_kms),
                      packet_index=np.arange(len(status), dtype=np.int64),
                      last_scattered_component=np.frombuffer(output, dtype=extra)['component'].copy())
    arrays.update(q_lab_km_s=q, red_velocity_km_s=red_velocity)
    return arrays


def _multilevel_readout(np, arrays, final, initial, status, reference):
    def observer_frequency(packets):
        width = packets['Delta_nu_D']
        local_frequency = reference + packets['x'] * width
        bulk_beta = packets['sc_dir_bulk'] * width / reference
        return local_frequency / (1 - bulk_beta)

    c_kms = LIGHT_SPEED / 1e5
    with np.errstate(invalid='ignore', divide='ignore', over='ignore'):
        final_nu = observer_frequency(final)
        initial_nu = observer_frequency(initial)
        observer_x = (final_nu - reference) / final['Delta_nu_D']
        q = (final_nu - reference) * (c_kms / reference)
        qi = (initial_nu - reference) * (c_kms / reference)
        red_velocity = -q / (1 + q / c_kms)
    for field in (final_nu, observer_x, q, red_velocity):
        field[status != 1] = np.nan
    arrays.update(nu_final_Hz=final_nu, nu_initial_Hz=initial_nu, x_observer=observer_x,
                  q_lab_km_s=q, q_initial_km_s=qi, red_velocity_km_s=red_velocity,
                  packet_index=np.arange(len(status), dtype=np.int64),
                  sc_dir_bulk_i=initial['sc_dir_bulk'].copy(), Delta_nu_D_i=initial['Delta_nu_D'].copy())
    for i in range(3):
        arrays[f'pos_i{i}'] = initial[f'pos{i}'].copy()
    return arrays


def execute_bundle(root, profile, atom_file, build_dir, case_dir, batch=1024):
    """Run one prepared case using the shared PTX and its runtime atom."""
    import numpy as np
    from ..shared.portable_driver_reference import Driver

    class RuntimeDriver(Driver):
        def __init__(self, ptx_path):
            try:
                super().__init__(ptx_path)
            except Exception:
                if getattr(self, 'context', None):
                    self.close()
                raise

    started = time.perf_counter()
    directory = Path(root).resolve() / RUNTIME
    case = Path(case_dir).resolve()
    ptx = Path(build_dir).resolve() / 'transport.ptx'
    record = json.loads(ptx.with_suffix('.ptx.json').read_text(encoding='utf8'))
    contract_bytes = (directory / 'abi.json').read_bytes()
    _, _, binding = source_bundle(root)
    if (record.get('format') != 'PEACOCK_CUDA_RUNTIME_V1' or
            any(record.get(key) != value for key, value in binding.items()) or
            record['abi_contract_sha256'] != sha(contract_bytes) or
            record['ptx_sha256'] != sha(ptx.read_bytes())):
        raise ValueError('Shared PTX differs from its recorded source, ABI or compiled bytes')

    atom = load_atom(profile, atom_file)
    prepared_atom = (case / 'atomic.atom').read_bytes()
    receipt = json.loads((case / 'prepare_report.json').read_bytes())
    if (sha(prepared_atom) != atom.digest or receipt.get('line') != atom.model or
            receipt.get('atomic_data_sha256') != atom.digest or
            receipt.get('cpu_transport_executed') is not False):
        raise ValueError('Prepared atomic table or input receipt differs from the selected transition')

    def read_input(filename):
        data = (case / filename).read_bytes()
        if sha(data) != receipt['inputs'].get(filename):
            raise ValueError(f'Prepared input {filename} differs from its receipt')
        return data

    meta = json.loads(read_input('case.json'))
    if (meta.get('peacock_model') != atom.model or meta.get('peacock_atom_sha256') != atom.digest or
            receipt.get('packets') != meta['nphot'] or
            meta.get('peacock_device_source_sha256', record['device_source_sha256']) !=
            record['device_source_sha256'] or
            meta.get('peacock_device_bundle_sha256', record['device_bundle_sha256']) !=
            record['device_bundle_sha256']):
        raise ValueError('Prepared inputs belong to a different transition, atom or CUDA build')
    if ('nu0_Hz' in meta or atom.multilevel is not None) and meta.get('nu0_Hz') != atom.reference_hz:
        raise ValueError('Prepared and active atom reference frequencies differ')
    multilevel_bytes = (atom.multilevel.pack(meta.get('atomic_populations'))
                        if atom.multilevel is not None else None)
    if not 1 <= meta['nphot'] <= 2147483647 or not 1 <= batch <= 2147483647:
        raise ValueError('Photon and CUDA batch counts must be positive signed 32-bit integers')
    result_path = case / f'gpu_output_{batch}.npz'
    report_path = case / 'gpu_run_report.json'
    if result_path.exists() or report_path.exists():
        raise FileExistsError(f'Existing GPU result in {case}; prepare a separate case directory')

    contract = json.loads(contract_bytes)
    abi = dict(zip(contract['labels'], contract['values']))
    native_keys = ('sizeof.photon', 'sizeof.emission_cfg_s', 'sizeof.grid', 'sizeof.grid_cell',
                   'photon.x', 'photon.grid', 'emission_cfg_s.CII_ratio_21')
    pointers = ('grid', 'grid_shifted', 'curr_cell', 'prev_cell', 'cell_shifted')
    if (meta.get('format') != 2 or meta.get('abi') != [abi[key] for key in native_keys] or
            meta['photon_size'] != abi['sizeof.photon'] or meta['emission_size'] != abi['sizeof.emission_cfg_s'] or
            meta['pointer_offsets'] != [abi['photon.' + name] for name in pointers]):
        raise ValueError('Prepared native layout differs from the shared CUDA ABI')
    dtype = _packet_dtype(np, meta, abi)
    grid = bytearray(read_input('case.grid.bin'))
    photons = bytearray(read_input('case.photons.bin'))
    emission = read_input('case.emission.bin')
    if (len(grid) < abi['sizeof.grid'] or len(photons) != meta['nphot'] * dtype.itemsize or
            len(emission) != abi['sizeof.emission_cfg_s']):
        raise ValueError('Prepared binary payload sizes do not match their metadata')

    # The CUDA driver owns the context and each execution uploads its own atom.
    driver = RuntimeDriver(ptx)
    try:
        _device_abi(driver, b'review_full_abi', contract['values'], 'native exporter')
        _device_abi(driver, b'review_atom_abi', ATOM_ABI, 'packed atom')
        _upload_atom(driver, atom)
        if multilevel_bytes is not None:
            _device_abi(driver, b'peacock_multilevel_abi', MULTILEVEL_ABI, 'multilevel atom')
            _upload_constant(driver, b'peacock_cuda_multilevel_atom', multilevel_bytes, 'multilevel atom')
        output, status, seconds = _transport(driver, np, grid, photons, emission, meta, batch)
    finally:
        driver.close()
    arrays = _readout(np, atom, output, photons, dtype, status, abi)
    escaped = status == 1
    finite = bool(all(np.all(np.isfinite(value[escaped])) for value in arrays.values()))
    norms = np.sqrt(sum(arrays[f'dir{i}'][escaped]**2 for i in range(3)))
    physical = bool(np.allclose(norms, 1, rtol=1e-10, atol=1e-10) and
                    all(np.all(arrays[name][escaped] >= 0)
                        for name in ('nscatter', 'c_HI_total', 'c_D_total')))
    codes, counts = np.unique(status, return_counts=True)
    status_counts = {str(int(code)): int(count) for code, count in zip(codes, counts)}
    incomplete = int(np.count_nonzero(~np.isin(status, [0, 1])))
    complete = incomplete == 0 and finite and physical
    report = {
        'case': case.name, 'model': atom.model, 'gpu': driver.name, 'nphot': len(status),
        'batch_size': batch, 'gpu_kernel_seconds': seconds,
        'input_to_device_results_seconds': time.perf_counter() - started,
        'status_counts': status_counts, 'escaped_gpu': status_counts.get('1', 0),
        'absorbed_gpu': status_counts.get('0', 0), 'unfinished_or_bad': incomplete,
        'bad_numerical': status_counts.get('-1', 0), 'scattercap_incomplete': status_counts.get('-2', 0),
        'traversalcap_incomplete': status_counts.get('-3', 0),
        'untouched_status_sentinel': status_counts.get('-99', 0),
        'unexpected_status': int(np.count_nonzero(~np.isin(status, [-3, -2, -1, 0, 1]))),
        'all_escaped_fields_finite': finite, 'escaped_physical_sanity': physical,
        'status': 'COMPLETE' if complete else 'NEEDS_ATTENTION',
        'output_path': str(result_path), 'cpu_transport_executed': False,
        'cpu_reference_validation': 'not_requested', 'abi_values_checked': len(abi),
        'atom_abi_values_checked': len(ATOM_ABI),
        'active_nu0_Hz': atom.reference_hz, 'atom_sha256': atom.digest,
        'device_source_sha256': record['device_source_sha256'], 'ptx_sha256': record['ptx_sha256'],
        'device_bundle_sha256': record['device_bundle_sha256'],
    }
    if multilevel_bytes is not None:
        report['multilevel_atom_abi_values_checked'] = len(MULTILEVEL_ABI)
        report['multilevel_atom_sha256'] = sha(multilevel_bytes)
    with result_path.open('xb') as stream:
        np.savez(stream, status=status, **arrays)
    with report_path.open('x', encoding='utf8') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    if not complete:
        raise RuntimeError(f'GPU packet validity checks failed. See {report_path}')
    return report
