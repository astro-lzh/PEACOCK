/* PEACOCK runtime CUDA transport.
 * Scalar and multilevel operators share one transport entry.
 * Transition data are uploaded per CUDA context and select the
 * scattering operator at execution.
 */
#include <curand_kernel.h>
#define CELL_CLOUDS 1
#define PHOTON_MAX_EXTRA_INFO 1
#define PI 3.14159265358979323846
#define DBL_MAX 1.7976931348623157e308
#define TLAC_DEVICE __device__
using GpuRng = curandStatePhilox4_32_10_t;
struct emission_cfg_s;
typedef struct observer_s observer;
typedef struct grid_s grid;

typedef struct grid_cell_s {
  
  
  double L;                    
  double T;                    
  double n_HI;                 
  double n_D;                  
  double pos[3];               
                               
  double vel[3];               
  double* size;                
  struct grid_cell_s *nbs[6];  
                               
                               
                               

#ifdef CELL_CLOUDS
  unsigned int nclouds;
  double **pos_clouds; 
  double **vel_clouds; 
  double *v_flag_clouds;
  grid **cloud_grids;  
#endif
} grid_cell;

struct grid_s {
  int type;                    
  int uniform;                 
  int ncells[3];               
  double boxsize[3];           
  double L_tot;                
  double center[3];            

  grid_cell ***cells;

  
  int nobservers;
  observer *observers;
};

typedef struct photon_s {
  
  double pos[3]; 
  double dir[3]; 
  double x;      

  double Delta_nu_D;  
  double sc_dir_bulk; 
  double a;           
  double x_cw;        
  double curr_tau;    
  double tau;         

  double dist;   

  double c_HI_total, c_D_total; 

  int nscatter; 

  double x_i; 

  double extra_info[PHOTON_MAX_EXTRA_INFO]; 
                                

#ifdef CELL_CLOUDS
  int nclouds_passed;          
#endif

  
  struct emission_cfg_s *emission_cfg; 
  double x_last; 
  double dir_last[3]; 
  double u_scatter_last[2]; 
                            
  grid_cell *curr_cell, *prev_cell;

  struct grid_s *grid;

#ifdef CELL_CLOUDS
  double pos_shifted[3];      
  double vel_shifted[3];      
  grid_cell *cell_shifted;    
  struct grid_s *grid_shifted;         

#endif
#ifdef DEBUG 
  int ncell;
  int cellcheck[200];
#endif
} photon;

struct emission_cfg_s {
  double CII_ratio_21;
  int initial_pos_mode;        
  double initial_pos_param;
  double p_cloud;             
  int initial_freq_mode;      
                              
  double initial_freq_param;  
};


#ifndef TLAC_GPU_BVH_H
#define TLAC_GPU_BVH_H
// Preorder, stackless BVH. escape is the first node after this subtree.
// The device-only grid copy uses the otherwise unused v_flag_clouds pointer
// for this array. Host placement flags are never modified.
struct GpuBvhNode { double lo[3],hi[3]; int escape,cloud; };
#endif


struct PeacockCudaAtom {
  unsigned int version, operator_id;
  double mass_g;
  double reference_hz;
  double red_hz;
  double f0;
  double f1;
  double f2;
  double decay0;
  double decay1;
  double decay2;
  double natural_width_hz;
  double fine_structure_hz;
  double cii_third_detuning_hz;
  double dust_albedo;
  double cii_phase_13_1;
  double cii_phase_23_2;
  double cii_phase_cross;
  double cii_phase_24;
};
static_assert(sizeof(PeacockCudaAtom) == 144, "CUDA atom layout");
extern "C" {
__constant__ PeacockCudaAtom peacock_cuda_atom;
}
TLAC_DEVICE void gpu_assert_photon_pos(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_assert_photon_values(GpuRng *rng, photon *p);
TLAC_DEVICE int gpu_bvh_ray_hit(GpuRng *rng, GpuBvhNode *node,double pos[],double dir[],double limit);
TLAC_DEVICE void gpu_cart2spherical(GpuRng *rng, double pos_cart[], double pos_spherical[]);
TLAC_DEVICE double gpu_cell_velocity_scalar_product(GpuRng *rng, grid_cell *c, double vec[], double pos[],
                                    grid *g);
TLAC_DEVICE double gpu_cell_velocity_scalar_product_cart(GpuRng *rng, grid_cell *c, double vec[]);
TLAC_DEVICE double gpu_cell_velocity_scalar_product_spherical(GpuRng *rng, grid_cell *c, double vec[],
                                              double pos[]);
TLAC_DEVICE void gpu_cross_product(GpuRng *rng, double u_in[], double v_in[], double res[]);
TLAC_DEVICE double gpu_doppler_freq_shift_hydrogen(GpuRng *rng, double T);
TLAC_DEVICE double gpu_dust_albedo(GpuRng *rng, double x, double T);
TLAC_DEVICE grid_cell* gpu_find_grid_cell(GpuRng *rng, grid *g, double pos[]);
TLAC_DEVICE double gpu_gas_scattering_cs(GpuRng *rng, double x, double T);
TLAC_DEVICE double gpu_gas_scattering_cs_smc(GpuRng *rng, double x, double T);
TLAC_DEVICE int gpu_get_cloud_intersection(GpuRng *rng, grid_cell *c,double pos[],double dir[],
                           double intersection[],double *dist);
TLAC_DEVICE int gpu_get_cloud_intersection_bruteforce(GpuRng *rng, grid_cell *c, double pos[], double dir[],
                           double intersection[], double *dist);
TLAC_DEVICE double gpu_get_new_tau(GpuRng *rng);
TLAC_DEVICE int gpu_get_next_cell(GpuRng *rng, grid *grid, grid_cell *cell, double pos[],
                  double dir[], grid_cell **new_cell,
                  double intersection[], double* dist);
TLAC_DEVICE int gpu_get_next_cell_cart(GpuRng *rng, grid *grid, grid_cell *cell, double pos[],
                   double dir[], grid_cell **new_cell,
                   double intersection[], double* dist, bool crossed_axis_only = false);
TLAC_DEVICE int gpu_get_next_cell_spherical(GpuRng *rng, grid *grid, grid_cell *cell, double pos[],
                  double dir[], grid_cell **new_cell,
                  double intersection[], double* dist);
TLAC_DEVICE int gpu_intersection_ray_sphere(GpuRng *rng, double pos[], double dir[], const double R0,
                            const double pos_sphere[], double lambda[]);
TLAC_DEVICE int gpu_is_pos_in_cell(GpuRng *rng, double *pos, grid_cell *c, grid *g);
TLAC_DEVICE int gpu_is_pos_in_cell_cart(GpuRng *rng, double *pos, grid_cell *c);
TLAC_DEVICE int gpu_is_pos_in_cell_spherical(GpuRng *rng, double *pos, grid_cell *c);
TLAC_DEVICE double gpu_norm3d(GpuRng *rng, double vec[]);
TLAC_DEVICE void gpu_rand_direction_3d(GpuRng *rng, double *ret_vec);
TLAC_DEVICE double gpu_rand_exponential(GpuRng *rng, double mu);
TLAC_DEVICE double gpu_rand_gaussian(GpuRng *rng, double sigma);
TLAC_DEVICE double gpu_rand_uniform(GpuRng *rng);
TLAC_DEVICE void gpu_rot3d_vec_angle(GpuRng *rng, double vec_in[], double n[], const double alpha,
                     double vec_out[]);
TLAC_DEVICE void gpu_rotrand3d_angle(GpuRng *rng, double vec_in[], double angle, double vec_out[]);
TLAC_DEVICE double gpu_scalar_product_3d(GpuRng *rng, double vec1[], double vec2[]);
TLAC_DEVICE double gpu_sct_hyd_get_atom_par_vel_acc_counter(GpuRng *rng, const int mode);
TLAC_DEVICE int gpu_sign(GpuRng *rng, double x);
TLAC_DEVICE double gpu_voigt_function_approx(GpuRng *rng, double a, double x);

TLAC_DEVICE void gpu_assert_photon_pos(GpuRng *rng, photon *p) {
  if(p->curr_cell == nullptr) return;
  ((void)0);
  ((void)0);
}

TLAC_DEVICE void gpu_assert_photon_values(GpuRng *rng, photon *p) {
  }

TLAC_DEVICE int gpu_bvh_ray_hit(GpuRng *rng, GpuBvhNode *node,double pos[],double dir[],double limit) {
  double near_t=0,far_t=limit;
  for(int d=0;d<3;d++) {
    if(dir[d]==0) {
      if(pos[d]<node->lo[d] || pos[d]>node->hi[d]) return 0;
    } else {
      double a=(node->lo[d]-pos[d])/dir[d];
      double b=(node->hi[d]-pos[d])/dir[d];
      near_t=fmax(near_t,fmin(a,b)); far_t=fmin(far_t,fmax(a,b));
      if(near_t>far_t) return 0;
    }
  }
  return 1;
}

TLAC_DEVICE void gpu_cart2spherical(GpuRng *rng, double pos_cart[], double pos_spherical[]) {
  double ret[3];
  ret[0] = gpu_norm3d(rng, pos_cart);
  ret[1] = acos(pos_cart[2] / ret[0]);
  ret[2] = atan2(pos_cart[1], pos_cart[0]);
  if(ret[2] < 0)
    ret[2] += 2 * 3.14159265358979323846;
  for (int i = 0; i < 3; i++) {
    pos_spherical[i] = ret[i];
  }
}

TLAC_DEVICE double gpu_cell_velocity_scalar_product(GpuRng *rng, grid_cell *c, double vec[], double pos[],
                                    grid *g) {
  if(g->type == 2)
    return gpu_cell_velocity_scalar_product_spherical(rng, c, vec, pos);
  else if(g->type == 1)
    return gpu_cell_velocity_scalar_product_cart(rng, c, vec);
  __trap();
}

TLAC_DEVICE double gpu_cell_velocity_scalar_product_cart(GpuRng *rng, grid_cell *c, double vec[]) {
  return c->vel[0] * vec[0] + c->vel[1] * vec[1] + c->vel[2] * vec[2];
}

TLAC_DEVICE double gpu_cell_velocity_scalar_product_spherical(GpuRng *rng, grid_cell *c, double vec[],
                                              double pos[]) {
  double d = gpu_norm3d(rng, pos);
  if(d == 0)
    return 0;
  else
    return c->vel[0] * gpu_scalar_product_3d(rng, vec, pos) / d;
}

TLAC_DEVICE void gpu_cross_product(GpuRng *rng, double u_in[], double v_in[], double res[]) {
  double u[] = {u_in[0], u_in[1], u_in[2]};
  double v[] = {v_in[0], v_in[1], v_in[2]};
  res[0] = u[1] * v[2] - u[2] * v[1];
  res[1] = u[2] * v[0] - u[0] * v[2];
  res[2] = u[0] * v[1] - u[1] * v[0];
}

TLAC_DEVICE double gpu_doppler_freq_shift_hydrogen(GpuRng *rng, double T) {
  return peacock_cuda_atom.reference_hz *
    sqrt(2.0 * 1.38065e-16 * T / peacock_cuda_atom.mass_g) / 29979245800.0;
}

TLAC_DEVICE double gpu_dust_albedo(GpuRng *rng, double x, double T) {
  return peacock_cuda_atom.dust_albedo;
}

TLAC_DEVICE grid_cell* gpu_find_grid_cell(GpuRng *rng, grid *g, double pos[]) {
  int i, j, k;
  int n[3];
  for(i = 0; i < 3; i++) {
    n[i] = pos[i] / g->cells[0][0][0].size[i];
    if((n[i] >= g->ncells[i]) || (n[i] < 0)) {
      n[0] = -1;
      break;
    }
  }
  if((n[0] != -1) && gpu_is_pos_in_cell(rng, pos,&(g->cells[n[0]][n[1]][n[2]]), g))
    return &(g->cells[n[0]][n[1]][n[2]]);
  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0; k < g->ncells[2]; k++) {
        if(gpu_is_pos_in_cell(rng, pos, &(g->cells[i][j][k]), g))
          return &(g->cells[i][j][k]);
      }
    }
  }
  return nullptr;
}

TLAC_DEVICE double gpu_gas_scattering_cs(GpuRng *rng, double x, double T) {
  return gpu_gas_scattering_cs_smc(rng, x, T);
}

TLAC_DEVICE double gpu_gas_scattering_cs_smc(GpuRng *rng, double x, double T) {
  return 4 * 1e-21 * (0.395 + 0 * 1.82e-5 * sqrt(T * 1e-4) * x);
}

TLAC_DEVICE int gpu_get_cloud_intersection(GpuRng *rng, grid_cell *c,double pos[],double dir[],
                           double intersection[],double *dist) {
  if(c->nclouds==0) return -1;
#ifdef TLAC_BVH_HOST_CHECK
  return gpu_get_cloud_intersection_bruteforce(rng, c,pos,dir,intersection,dist);
#endif
  if(c->v_flag_clouds==NULL)
    return gpu_get_cloud_intersection_bruteforce(rng, c,pos,dir,intersection,dist);
  GpuBvhNode *nodes=(GpuBvhNode*)c->v_flag_clouds;
  double best=DBL_MAX;
  int best_id=-1;
  for(int node=0;node<nodes[0].escape;) {
    if(!gpu_bvh_ray_hit(rng, &nodes[node],pos,dir,best)) { node=nodes[node].escape; continue; }
    int i=nodes[node].cloud;
    node++;
    if(i<0) continue;
    double lambda[2]={DBL_MAX,DBL_MAX};
    int n=gpu_intersection_ray_sphere(rng, pos,dir,c->cloud_grids[i]->boxsize[0]*(1.0-1e-10),c->pos_clouds[i],lambda);
    if(n!=2 || lambda[0]<0 || lambda[1]<0) continue;
    double candidate=fmin(lambda[0],lambda[1]);
    if(candidate<best || (candidate==best && i<best_id)) { best=candidate; best_id=i; }
  }
  if(best_id<0) return -1;
  for(int d=0;d<3;d++) intersection[d]=pos[d]+dir[d]*best;
  *dist=best*gpu_norm3d(rng, dir);
  return best_id;
}

TLAC_DEVICE int gpu_get_cloud_intersection_bruteforce(GpuRng *rng, grid_cell *c, double pos[], double dir[],
                           double intersection[], double *dist) {
  if(c->nclouds == 0) return -1;
  int i, n;
  double lambda_min = ((double)1.79769313486231570814527423731704357e+308L), cmin;
  double lambda_tmp[2];
  int min_i = 0;
  const double epsilon = 1e-10;
  for(i = 0; i < c->nclouds; i++) {
    lambda_tmp[0] = ((double)1.79769313486231570814527423731704357e+308L); lambda_tmp[1] = ((double)1.79769313486231570814527423731704357e+308L);
    n = gpu_intersection_ray_sphere(rng, pos, dir,
                                c->cloud_grids[i]->boxsize[0] * (1.0 - epsilon),
                                c->pos_clouds[i],
                                lambda_tmp);
    if(n != 2)
      continue;
    if(lambda_tmp[0] < 0 || lambda_tmp[1] < 0) continue;
    cmin = fmin( lambda_tmp[0], lambda_tmp[1]);
    if(cmin < lambda_min) {
      lambda_min = cmin;
      min_i = i;
    }
  }
  if(lambda_min == ((double)1.79769313486231570814527423731704357e+308L))
    return -1;
  else {
    intersection[0] = pos[0] + dir[0] * lambda_min;
    intersection[1] = pos[1] + dir[1] * lambda_min;
    intersection[2] = pos[2] + dir[2] * lambda_min;
    ((void)0);
    *dist = lambda_min * gpu_norm3d(rng, dir);
    return min_i;
  }
}

TLAC_DEVICE double gpu_get_new_tau(GpuRng *rng) {
  return gpu_rand_exponential(rng, 1);
}

TLAC_DEVICE int gpu_get_next_cell(GpuRng *rng, grid *grid, grid_cell *cell, double pos[],
                  double dir[], grid_cell **new_cell,
                  double intersection[], double* dist) {
  if(grid->type == 2)
    return gpu_get_next_cell_spherical(rng, grid, cell, pos, dir, new_cell,
                                   intersection, dist);
  else if(grid->type == 1)
    return gpu_get_next_cell_cart(rng, grid, cell, pos, dir, new_cell,
                              intersection, dist);
  __trap();
}

TLAC_DEVICE int gpu_get_next_cell_cart(GpuRng *rng, grid *grid, grid_cell *cell, double pos[],
                   double dir[], grid_cell **new_cell,
                   double intersection[], double* dist, bool crossed_axis_only) {
   double S[3][3];
   double W[3];
   int s_dir[3];
   double lambda[3];
   double min_lambda;
   const double epsilon_wall = 0.0;
   const double epsilon_periodic = 1e-15;
   int i, j, iml;
   double dist_wp;
   ((void)0);
  for(i = 0; i < 3; i++) {
    s_dir[i] = gpu_sign(rng, dir[i]);
    if(s_dir[i] == 0) {
      lambda[i] = ((double)1.79769313486231570814527423731704357e+308L);
      continue;
    }
    W[i] = cell->pos[i] + 0.5 * s_dir[i] * cell->size[i] * (1 + epsilon_wall);
    lambda[i] = (W[i] - pos[i]) / (dir[i]);
    for(j = 0; j < 3; j++)
      S[i][j] = pos[j] + lambda[i] * dir[j];
  }
  min_lambda = lambda[0];
  iml = 0;
  if(lambda[1] < min_lambda) {
    iml = 1;
    min_lambda = lambda[1];
  }
  if(lambda[2] < min_lambda) {
    iml = 2;
    min_lambda = lambda[2];
  }
  if(crossed_axis_only && (min_lambda == DBL_MAX || !isfinite(min_lambda)))
    return 0;
  dist_wp = lambda[iml];
  *new_cell = cell->nbs[2 * iml + (s_dir[iml] == 1)];
  for(i = 0; i < 3; i++) {
    intersection[i] = S[iml][i];
    if(*new_cell != nullptr && !crossed_axis_only) {
      if(intersection[i] < epsilon_periodic * grid->boxsize[i])
        intersection[i] = (1. - 0 * epsilon_periodic) * grid->boxsize[i];
      else if(intersection[i] > (1 - epsilon_periodic) * grid->boxsize[i])
        intersection[i] = 0. * epsilon_periodic * grid->boxsize[i];
    }
  }
  if(crossed_axis_only && *new_cell != nullptr) {
    const double box_length = grid->boxsize[iml];
    const double next_center = (*new_cell)->pos[iml];
    if(s_dir[iml] < 0 && next_center >= cell->pos[iml] &&
       intersection[iml] < epsilon_periodic * box_length)
      intersection[iml] = box_length;
    else if(s_dir[iml] > 0 && next_center <= cell->pos[iml] &&
            intersection[iml] > (1 - epsilon_periodic) * box_length)
      intersection[iml] = 0.0;
  }
  *dist = fabs(dist_wp);
  ((void)0);
  return (iml + 1) * s_dir[iml];
}

TLAC_DEVICE int gpu_get_next_cell_spherical(GpuRng *rng, grid *grid, grid_cell *cell, double pos[],
                  double dir[], grid_cell **new_cell,
                  double intersection[], double* dist) {
  double lambda[3], lambda_tmp[2];
  int i, j, iml = 0;
  int s_dir[3];
  double sc_dir_pos = dir[0] * pos[0] + dir[1] * pos[1] + dir[2] * pos[2];
  double possq = pos[0] * pos[0] + pos[1] * pos[1] + pos[2] * pos[2];
  const double epsilon = 1e-15;
  double Rwsq[] = { (cell->pos[0] - (0.5 + epsilon) * cell->size[0]) *
                    (cell->pos[0] - (0.5 + epsilon) * cell->size[0]),
                    (cell->pos[0] + (0.5 + epsilon) * cell->size[0]) *
                    (cell->pos[0] + (0.5 + epsilon) * cell->size[0]) };
  double ha, hb;
  double tmp[3];
  ((void)0);
  ((void)0);
  if(Rwsq[0] >= possq)
    Rwsq[0] = possq * (1 - epsilon);
  if(Rwsq[1] <= possq)
    Rwsq[1] = possq * (1 + epsilon);
  ((void)0);
  ((void)0);
  ((void)0);
  ha = sc_dir_pos * sc_dir_pos - possq;
  for(i = 0; i < 2; i++) {
    if(Rwsq[i] == possq) {
      Rwsq[i] += (2 * i - 1) * epsilon * cell->size[0];
    }
    if(Rwsq[i] + ha > 0) {
      hb = sqrt(Rwsq[i] + ha);
      if( -sc_dir_pos - hb > 0)
        lambda_tmp[i] = -sc_dir_pos - hb;
      else if(-sc_dir_pos + hb > 0)
        lambda_tmp[i] = -sc_dir_pos + hb;
      else {
        lambda_tmp[i] = ((double)1.79769313486231570814527423731704357e+308L);
      }
    } else {
      lambda_tmp[i] = ((double)1.79769313486231570814527423731704357e+308L);
    }
  }
  if(lambda_tmp[0] < lambda_tmp[1]) {
    lambda[0] = lambda_tmp[0];
    s_dir[0] = -1;
  } else {
    lambda[0] = lambda_tmp[1];
    s_dir[0] = 1;
  }
  ((void)0);
  ((void)0);
  for(i = 0; i < 3; i++)
    tmp[i] = pos[i] + lambda[0] * dir[i];
  ha = tmp[0] * tmp[0] + tmp[1] * tmp[1] + tmp[2] * tmp[2];
  ((void)0);
  ((void)0);
  ((void)0);
  *dist = lambda[iml];
  *new_cell = cell->nbs[2 * iml + (s_dir[iml] == 1)];
  ((void)0);
  for(i = 0; i < 3; i++) {
    intersection[i] = pos[i] + (lambda[iml]) * dir[i];
    ((void)0);
  }
  return (iml + 11) * s_dir[iml];
}

TLAC_DEVICE int gpu_intersection_ray_sphere(GpuRng *rng, double pos[], double dir[], const double R0,
                            const double pos_sphere[], double lambda[]) {
  double Delta_pos[] = { pos[0] - pos_sphere[0], pos[1] - pos_sphere[1],
                         pos[2] - pos_sphere[2] };
  double dir_sc_deltapos = gpu_scalar_product_3d(rng, dir, Delta_pos);
  double det = dir_sc_deltapos * dir_sc_deltapos -
    gpu_scalar_product_3d(rng, Delta_pos, Delta_pos) + R0 * R0;
  if(det < 0) return 0;
  lambda[0] = - dir_sc_deltapos + sqrt(det);
  if(det == 0) return 1;
  lambda[1] = - dir_sc_deltapos - sqrt(det);
  return 2;
}

TLAC_DEVICE int gpu_is_pos_in_cell(GpuRng *rng, double *pos, grid_cell *c, grid *g) {
  if(g->type == 2)
    return gpu_is_pos_in_cell_spherical(rng, pos, c);
  else if(g->type == 1)
    return gpu_is_pos_in_cell_cart(rng, pos, c);
  __trap();
}

TLAC_DEVICE int gpu_is_pos_in_cell_cart(GpuRng *rng, double *pos, grid_cell *c) {
   const double epsilon = 1e-5;
   if(pos[0] > c->pos[0] + (0.5 + epsilon) * c->size[0]) return 0;
   if(pos[0] < c->pos[0] - (0.5 + epsilon) * c->size[0]) return 0;
   if(pos[1] > c->pos[1] + (0.5 + epsilon) * c->size[1]) return 0;
   if(pos[1] < c->pos[1] - (0.5 + epsilon) * c->size[1]) return 0;
   if(pos[2] > c->pos[2] + (0.5 + epsilon) * c->size[2]) return 0;
   if(pos[2] < c->pos[2] - (0.5 + epsilon) * c->size[2]) return 0;
   return 1;
 }

TLAC_DEVICE int gpu_is_pos_in_cell_spherical(GpuRng *rng, double *pos, grid_cell *c) {
  double pos_spherical[3];
  int i;
  double const epsilon = 1e-5;
  gpu_cart2spherical(rng, pos, pos_spherical);
  for(i = 0; i < 3; i++)
    if(pos_spherical[i] > c->pos[i] + (0.5 + epsilon) * c->size[i]
       || pos_spherical[i] < c->pos[i] - (0.5 + epsilon) * c->size[i]) {
      return 0;
    }
  return 1;
}

TLAC_DEVICE double gpu_norm3d(GpuRng *rng, double vec[]) {
  return sqrt(vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2]);
}

TLAC_DEVICE void gpu_rand_direction_3d(GpuRng *rng, double *ret_vec) {
  double z = 2.0 * gpu_rand_uniform(rng) - 1.0;
  double phi = 2.0 * PI * gpu_rand_uniform(rng);
  double r = sqrt(fmax(0.0, 1.0-z*z));
  ret_vec[0] = r*cos(phi);
  ret_vec[1] = r*sin(phi);
  ret_vec[2] = z;
}

TLAC_DEVICE double gpu_rand_exponential(GpuRng *rng, double mu) {
  return -mu * log(gpu_rand_uniform(rng));
}

TLAC_DEVICE double gpu_rand_gaussian(GpuRng *rng, double sigma) {
  return sigma * curand_normal_double(rng);
}

TLAC_DEVICE double gpu_rand_uniform(GpuRng *rng) {
  
  double u;
  do { u = curand_uniform_double(rng); } while(u >= 1.0);
  return u;
}

TLAC_DEVICE void gpu_rot3d_vec_angle(GpuRng *rng, double vec_in[], double n[], const double alpha,
                     double vec_out[]) {
  int i;
  double vec_in_orig[] = {vec_in[0], vec_in[1], vec_in[2]};
  double ca = cos(alpha);
  double sa = sin(alpha);
  double R[][3] = { {
      n[0] * n[0] * (1. - ca) + ca,
      n[0] * n[1] * (1. - ca) - n[2] * sa,
      n[0] * n[2] * (1. - ca) + n[1] * sa
    },{
      n[1] * n[0] * (1. - ca) + n[2] * sa,
      n[1] * n[1] * (1. - ca) + ca,
      n[1] * n[2] * (1. - ca) - n[0] * sa
    }, {
      n[2] * n[0] * (1. - ca) - n[1] * sa,
      n[2] * n[1] * (1. - ca) + n[0] * sa,
      n[2] * n[2] * (1. - ca) + ca
    }
  };
  for(i = 0; i < 3; i++)
    vec_out[i] = R[i][0] * vec_in_orig[0] +
      R[i][1] * vec_in_orig[1] + R[i][2] * vec_in_orig[2];
}

TLAC_DEVICE void gpu_rotrand3d_angle(GpuRng *rng, double vec_in[], double angle, double vec_out[]) {
  int i;
  double r[3], b[3], norm_b;
  double input_norm = gpu_norm3d(rng, vec_in);
  if (!(input_norm > 0.0) || !isfinite(input_norm) || !isfinite(angle)) {
    do { __trap() ; return ; } while (0);
  }
  do {
    gpu_rand_direction_3d(rng, r);
    gpu_cross_product(rng, vec_in, r, b);
    norm_b = gpu_norm3d(rng, b);
  } while (norm_b == 0.0);
  for(i = 0; i < 3; i++)
    b[i] = b[i] / norm_b;
  gpu_rot3d_vec_angle(rng, vec_in, b, angle, vec_out);
}

TLAC_DEVICE double gpu_scalar_product_3d(GpuRng *rng, double vec1[], double vec2[]) {
  return (vec1[0] * vec2[0] + vec1[1] * vec2[1] + vec1[2] * vec2[2]);
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_par_vel_acc_counter(GpuRng *rng, const int mode) {
  return 0.0;
}

TLAC_DEVICE int gpu_sign(GpuRng *rng, double x) {
  return (x > 0) - (x < 0);
}

TLAC_DEVICE double gpu_voigt_function_approx(GpuRng *rng, double a, double x) {
  double P, q;
  double xsq = x * x;
  double z = (xsq - 0.855) / (xsq + 3.42);
  double zsq = z * z;
  if(z > 0) {
    P = 5.674 * zsq * zsq - 9.207 * zsq * z + 4.421 * zsq + 0.1117 * z;
    q = (1.0 + 21.0/xsq) * a / (3.14159265358979323846 * (xsq + 1.0)) * P;
  } else {
    q = 0.0;
  }
  return (q * sqrt(3.14159265358979323846) + exp(-xsq));
}

namespace lya {
TLAC_DEVICE double gpu_HG_asymmetry_parameter(GpuRng *rng, double x, double T);
TLAC_DEVICE double gpu_hydrogen_scattering_cross_section(GpuRng *rng, double x, double T);
TLAC_DEVICE void gpu_interact_dust(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_interact_hydrogen(GpuRng *rng, photon* p);
TLAC_DEVICE int gpu_propagate_photon(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_scatter_dust(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_scatter_hydrogen(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_hyd_core_get_angle_2p32(GpuRng *rng);
TLAC_DEVICE void gpu_sct_hyd_core_set_dir(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_hyd_get_atom_orthogonal_velocity(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_3piece(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_5piece(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_velocity(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_hyd_get_final_frequency(GpuRng *rng, photon* p, double old_dir[],
                                   double new_dir[]);
TLAC_DEVICE void gpu_sct_hyd_wing_set_dir(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_shift_to_cloud(GpuRng *rng, photon *p, grid_cell *mother_cell, int cloud_id,
                    const int find_new_cell);
TLAC_DEVICE void gpu_unshift_from_cloud(GpuRng *rng, photon *p);
TLAC_DEVICE int gpu_update_photon_pos(GpuRng *rng, photon *p, double r, double *dist_old);
TLAC_DEVICE void gpu_update_photon_values(GpuRng *rng, photon *p);

TLAC_DEVICE double gpu_HG_asymmetry_parameter(GpuRng *rng, double x, double T) {
  return 0.73;
}

TLAC_DEVICE double gpu_hydrogen_scattering_cross_section(GpuRng *rng, double x, double T) {
  const double c1 = peacock_cuda_atom.f0 * sqrt(3.14159265358979323846) *
    4.803205e-10 * 4.803205e-10 / (9.10938e-28 * 29979245800.0);
  const double Delta_nu_D = gpu_doppler_freq_shift_hydrogen(rng, T);
  const double a = peacock_cuda_atom.natural_width_hz/(2.0 * Delta_nu_D);
  return c1 / Delta_nu_D * gpu_voigt_function_approx(rng, a, x);
}

TLAC_DEVICE void gpu_interact_dust(GpuRng *rng, photon *p) {
  double u = gpu_rand_uniform(rng);
  double eta = gpu_dust_albedo(rng, p->x, p->curr_cell->T);
  if(eta > u) {
    gpu_scatter_dust(rng, p);
  } else {
    p->curr_cell = nullptr;
    p->curr_tau = -1;
  }
}

TLAC_DEVICE void gpu_interact_hydrogen(GpuRng *rng, photon* p) {
  gpu_scatter_hydrogen(rng, p);
}

TLAC_DEVICE int gpu_propagate_photon(GpuRng *rng, photon *p) {
  int steps=0;
  if(p->emission_cfg->initial_pos_mode==13) return -1;
  while(p->curr_cell!=NULL) {
    if(++steps>10000000) return -3;
    gpu_update_photon_values(rng, p);
    if(!isfinite(p->x)||!isfinite(p->curr_tau)||p->curr_tau<0) return -1;
    if(p->tau<=0) p->tau=gpu_get_new_tau(rng);
    if(!isfinite(p->tau)||p->tau<=0) return -1;
    double sigma_D=gpu_gas_scattering_cs(rng, p->x,p->curr_cell->T);
    double r=p->curr_tau==0?DBL_MAX:p->tau/p->curr_tau;
    p->prev_cell=p->curr_cell;
    double prev_tau=p->curr_tau,dist;
    gpu_update_photon_pos(rng, p,r,&dist);
    if(!isfinite(dist)||dist<0) return -1;
    p->dist+=dist;
    p->c_HI_total+=p->prev_cell->n_HI*dist;
    p->c_D_total+=p->prev_cell->n_D*dist;
    p->tau-=dist*prev_tau;
    if(p->tau<=0) {
      if(p->curr_cell==NULL||p->curr_tau<=0) return -1;
      if(p->nscatter>=2000000) return -2;
      p->nscatter++;
      r=gpu_rand_uniform(rng);
      double rho=p->curr_cell->n_D*sigma_D/p->curr_tau;
      if(!isfinite(rho)||rho<0||rho>1) return -1;
      p->x_last=p->x;
      for(int i=0;i<3;i++)p->dir_last[i]=p->dir[i];
      if(r>rho)gpu_interact_hydrogen(rng, p);else gpu_interact_dust(rng, p);
      if(p->curr_tau<0)return 0;
      if(!isfinite(p->x)||!isfinite(p->sc_dir_bulk))return -1;
      for(int i=0;i<3;i++)if(!isfinite(p->dir[i]))return -1;
      p->dist=0;p->tau=-1;
    } else if(p->curr_cell==NULL&&p->cell_shifted!=NULL)gpu_unshift_from_cloud(rng, p);
  }
  if(!isfinite(p->x)||!isfinite(p->sc_dir_bulk)||p->cell_shifted!=NULL)return -1;
  for(int i=0;i<3;i++)if(!isfinite(p->pos[i])||!isfinite(p->dir[i]))return -1;
  return 1;
}

TLAC_DEVICE void gpu_scatter_dust(GpuRng *rng, photon *p) {
  double u = gpu_rand_uniform(rng);
  double mu;
  double g[] = {gpu_HG_asymmetry_parameter(rng, p->x, p->curr_cell->T)};
  mu = -((g[0] - 1) * (g[0] - 1) +
         2 * (g[0] - 1) * (1 + g[0] * g[0]) * u - 2 * g[0]
         * (1 + g[0] * g[0]) * u * u) / pow(1 + g[0] * (2 * u - 1), 2);
  gpu_rotrand3d_angle(rng, p->dir, acos(mu), p->dir);
}

TLAC_DEVICE void gpu_scatter_hydrogen(GpuRng *rng, photon *p) {
  int i;
  double old_dir[3];
  for(i = 0; i < 3; i++)
    old_dir[i] = p->dir[i];
  if(fabs(p->x) < p->x_cw)
    gpu_sct_hyd_core_set_dir(rng, p);
  else
    gpu_sct_hyd_wing_set_dir(rng, p);
  p->sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p->curr_cell, p->dir, p->pos,
                                                p->grid);
  p->x = gpu_sct_hyd_get_final_frequency(rng, p, old_dir, p->dir);
}

TLAC_DEVICE double gpu_sct_hyd_core_get_angle_2p32(GpuRng *rng) {
  const double u = gpu_rand_uniform(rng);
  const double sqr = sqrt(2325.0 + 5184.0 * (u - 1) * u);
  const double p13 = pow(36.0 - 72.0 * u + sqr , 1.0/3.0);
  const double tpot = 1.4422495703074083;
  const double nom = 7.0 * tpot * tpot - tpot * p13 * p13;
  const double denom = 3.0 * p13;
  const double mu = nom / denom;
  return acos(mu);
}

TLAC_DEVICE void gpu_sct_hyd_core_set_dir(GpuRng *rng, photon *p) {
  double u = gpu_rand_uniform(rng);
  double alpha;
  const double prob = 0.3333333333;
  if(u > prob) {
    alpha = gpu_sct_hyd_core_get_angle_2p32(rng);
    gpu_rotrand3d_angle(rng, p->dir, alpha, p->dir);
  } else {
    gpu_rand_direction_3d(rng, p->dir);
  }
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_orthogonal_velocity(GpuRng *rng, photon *p) {
  const double xcrit = 0;
  const double xcw = 0;
  if(fabs(p->x) < xcw) {
    double uniform;
    do { uniform = gpu_rand_uniform(rng); } while (uniform == 0.0);
    return sqrt(xcrit * xcrit - log(uniform)) * cos(2 * 3.14159265358979323846 * gpu_rand_uniform(rng));
  } else {
    return gpu_rand_gaussian(rng, 1./sqrt(2.0));
  }
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_3piece(GpuRng *rng, photon *p) {
  float u0, atan_tmp, rnd1, rnd2, rnd3, upar_prop, prob, sgnx, expu0sq;
  float xabs = fabs(p->x);
  u0 = 0.97 * xabs;
  expu0sq = exp(- u0* u0);
  atan_tmp = atan((u0 - xabs) / p->a);
  prob = (atan_tmp + 0.5 * 3.14159265358979323846) /
    ((1 - expu0sq) * atan_tmp + (1 + expu0sq) * 0.5 * 3.14159265358979323846);
  do {
    rnd1 = gpu_rand_uniform(rng);
    if(rnd1 > prob)
      rnd2 = atan_tmp + (0.5 * 3.14159265358979323846 - atan_tmp) * gpu_rand_uniform(rng);
    else
      rnd2 = -0.5 * 3.14159265358979323846 + (atan_tmp + 0.5 * 3.14159265358979323846) * gpu_rand_uniform(rng);
    upar_prop = p->a * tan(rnd2) + xabs;
    if(rnd1 < prob)
      rnd3 = exp(upar_prop * upar_prop) * gpu_rand_uniform(rng);
    else
      rnd3 = expu0sq * exp(upar_prop * upar_prop) * gpu_rand_uniform(rng);
    gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 1);
  } while(rnd3 > 1);
  gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 2);
  sgnx = ((p->x < 0) ? -1 : 1);
  return upar_prop * sgnx;
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_5piece(GpuRng *rng, photon *p) {
  double rnd1, rnd3, upar_prop, sgnx;
  double fac1, fac2, funcval, zz, ratio;
  double x = fabs(p->x);
  double a = p->a;
  double d = (6.0 + 0.375 * 0.3 * log(a)) * 2.0 * atan(sqrt(x))/3.14159265358979323846;
  double f = 2.25 - (0.55 + 0.025 * 0.3 * log(a)) * atan(3 * (x - 4));
  if(!(isfinite(d) && isfinite(f) && 0.0 < f && f < d && d < x))
    return gpu_sct_hyd_get_atom_parallel_vel_3piece(rng, p);
  double ed = exp(-d * d);
  double ef = exp(-f * f);
  double A1 = ed / a * atan(a / (d + x));
  double A2 = A1 + ef / a * atan((a * (d - f))/(a * a +(f + x) * (d + x)));
  double A3 = A2 + 1.0/a * atan(2.0*f*a/(x*x+a*a-f*f));
  double A4 = A3 + (ef/a) * atan(a*(d-f)/(a*a+(d-x)*(f-x)));
  double A5 = A4 + (ed/a)*(atan(a/(d-x)) + 3.14159265358979323846);
  if(!(isfinite(A1) && isfinite(A2) && isfinite(A3) &&
       isfinite(A4) && isfinite(A5) && 0.0 < A1 &&
       A1 < A2 && A2 < A3 && A3 < A4 && A4 < A5))
    return gpu_sct_hyd_get_atom_parallel_vel_3piece(rng, p);
  double norm = A5;
  A1 /= norm;
  A2 /= norm;
  A3 /= norm;
  A4 /= norm;
  A5 /= norm;
  norm = 1.0 / norm;
  do {
    rnd1 = gpu_rand_uniform(rng);
    if(rnd1 < A1) {
      fac1 = rnd1 * a / (norm * ed);
      if(fac1 == 0.0)
        fac1 = 1e-12;
      upar_prop = x + a / tan(fac1);
      funcval = ed;
    } else if(rnd1 > A1 && rnd1 < A2) {
      fac1 = a*(rnd1-A1)/(norm*ef);
      fac2 = -1.0 * (d+x)/a;
      upar_prop = x+a*((tan(fac1)+fac2)/(1.0-fac2*tan(fac1)));
      funcval = ef;
    } else if(rnd1 > A2 && rnd1 < A3) {
      fac1 = a*(rnd1-A2)/norm;
      fac2 = (f+x)/a;
      upar_prop=x+a*(tan(fac1)-fac2)/(1.0+fac2*tan(fac1));
      funcval=1.0;
      fac1=a*(rnd1-A2)/(norm);
      fac2=(f+x)/a;
      upar_prop=x+a*(tan(fac1)-fac2)/(1+fac2*tan(fac1));
      funcval=1.0;
    } else if(rnd1 > A3 && rnd1 < A4) {
      fac1=a*(rnd1-A3)/(ef*norm)+atan((f-x)/a);
      upar_prop=x+a*tan(fac1);
      funcval=ef;
    } else {
      fac1=a*(rnd1-A4)/(norm*ed);
      fac2=(d-x)/a;
      upar_prop=x+a*(tan(fac1)+fac2)/(1-fac2*tan(fac1));
      funcval=ed;
    }
    zz = sqrt(-1. * log(funcval));
    ratio = exp(-1. * (upar_prop * upar_prop - zz * zz));
    rnd3 = gpu_rand_uniform(rng);
    gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 1);
  } while(rnd3 > ratio);
  gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 2);
  sgnx = ((p->x < 0) ? -1 : 1);
  return upar_prop * sgnx;
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_velocity(GpuRng *rng, photon *p) {
  if(p == nullptr)
    return gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 3);
  if(fabs(p->x) < 3.5)
    return gpu_sct_hyd_get_atom_parallel_vel_3piece(rng, p);
  else
    return gpu_sct_hyd_get_atom_parallel_vel_5piece(rng, p);
}

TLAC_DEVICE double gpu_sct_hyd_get_final_frequency(GpuRng *rng, photon* p, double old_dir[],
                                   double new_dir[]) {
  double dir_sc;
  p->u_scatter_last[0] = gpu_sct_hyd_get_atom_parallel_velocity(rng, p);
  p->u_scatter_last[1] = gpu_sct_hyd_get_atom_orthogonal_velocity(rng, p);
  dir_sc = gpu_scalar_product_3d(rng, old_dir, new_dir);
  return p->x - p->u_scatter_last[0] + p->u_scatter_last[0] * dir_sc + p->u_scatter_last[1] * sqrt(1 - dir_sc * dir_sc);
}

TLAC_DEVICE void gpu_sct_hyd_wing_set_dir(GpuRng *rng, photon *p) {
  double u = gpu_rand_uniform(rng);
  double sqr = sqrt(5 + 16 * u * (u - 1));
  double p13 = pow(2 - 4 * u + sqr, 1./3.);
  double mu = (1 - p13 * p13)/p13;
  gpu_rotrand3d_angle(rng, p->dir, acos(mu), p->dir);
}

TLAC_DEVICE void gpu_shift_to_cloud(GpuRng *rng, photon *p, grid_cell *mother_cell, int cloud_id,
                    const int find_new_cell) {
  int i;
  grid *cloud = mother_cell->cloud_grids[cloud_id];
  ((void)0);
  ((void)0);
  p->grid_shifted = p->grid;
  p->cell_shifted = mother_cell;
  for(i = 0; i < 3; i++) {
    p->pos_shifted[i] += mother_cell->pos_clouds[cloud_id][i];
    p->vel_shifted[i] += mother_cell->vel_clouds[cloud_id][i];
    p->pos[i] -= mother_cell->pos_clouds[cloud_id][i];
  }
  p->grid = cloud;
  if(find_new_cell == 0)
    p->curr_cell = &(cloud->cells[cloud->ncells[0] - 1][0][0]);
  else if(find_new_cell == 1)
    p->curr_cell = gpu_find_grid_cell(rng, p->grid, p->pos);
  else
    do { printf( "[Error] " "Unknown `find_new_cell` (=%d)", find_new_cell); printf( " -- %s:%d:%s()\n", "clouds.c", 2226, __func__); } while (0);
  gpu_update_photon_values(rng, p);
  p->x -= gpu_scalar_product_3d(rng, p->vel_shifted, p->dir);
  ((void)0);
  gpu_assert_photon_pos(rng, p);
}

TLAC_DEVICE void gpu_unshift_from_cloud(GpuRng *rng, photon *p) {
  int i;
  ((void)0);
  ((void)0);
  p->curr_cell = p->cell_shifted;
  for(i = 0; i < 3; i++) {
    p->pos[i] += p->pos_shifted[i];
    p->pos_shifted[i] = 0;
  }
  p->grid = p->grid_shifted;
  p->grid_shifted = nullptr;
  p->cell_shifted = nullptr;
  double old_Delta_nu_D = p->Delta_nu_D;
  gpu_update_photon_values(rng, p);
  p->x += gpu_scalar_product_3d(rng, p->vel_shifted, p->dir) * old_Delta_nu_D / p->Delta_nu_D;
  for(i = 0; i < 3; i++)
    p->vel_shifted[i] = 0;
  p->nclouds_passed++;
  ((void)0);
  ((void)0);
}

TLAC_DEVICE int gpu_update_photon_pos(GpuRng *rng, photon *p, double r, double *dist_old) {
  grid_cell *next_cell;
  double intersection[3];
  int i;
  int ret;
  const double epsilon = 0;
  ret = gpu_get_cloud_intersection(rng, p->curr_cell, p->pos, p->dir,
                               intersection, dist_old);
  if(ret != -1) {
    if(r > *dist_old) {
      p->pos[0] = intersection[0];
      p->pos[1] = intersection[1];
      p->pos[2] = intersection[2];
      gpu_shift_to_cloud(rng, p, p->curr_cell, ret, 0);
      gpu_assert_photon_pos(rng, p);
      return 100;
    } else {
      for(i = 0; i < 3; i++)
        p->pos[i] += r * p->dir[i];
      *dist_old = fabs(r);
      gpu_assert_photon_pos(rng, p);
      return 0;
    }
  }
  ret = gpu_get_next_cell(rng, p->grid, p->curr_cell, p->pos,
                      p->dir, &(next_cell),
                      intersection, dist_old);
  if(r > *dist_old) {
    for(i = 0; i < 3; i++) {
      p->pos[i] = intersection[i] + p->curr_cell->size[0] * epsilon * p->dir[i];
      *dist_old += p->curr_cell->size[0] * epsilon * p->dir[i];
    }
    p->curr_cell = next_cell;
  } else {
    for(i = 0; i < 3; i++)
      p->pos[i] += r * p->dir[i];
    *dist_old = fabs(r);
    ret = 0;
  }
  return ret;
}

TLAC_DEVICE void gpu_update_photon_values(GpuRng *rng, photon *p) {
  gpu_assert_photon_values(rng, p);
  ((void)0);
  double sigma_HI, sigma_D;
  double old_Delta_nu_D = p->Delta_nu_D;
  double old_sc_dir_bulk = p->sc_dir_bulk;
  ((void)0);
  p->Delta_nu_D = gpu_doppler_freq_shift_hydrogen(rng, p->curr_cell->T);
  ((void)0);
  p->sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p->curr_cell, p->dir, p->pos,
                                                p->grid);
  ((void)0);
  double tmpvel[] = {
    p->vel_shifted[0] / old_Delta_nu_D * peacock_cuda_atom.reference_hz / 29979245800.0,
    p->vel_shifted[1] / old_Delta_nu_D * peacock_cuda_atom.reference_hz / 29979245800.0,
    p->vel_shifted[2] / old_Delta_nu_D * peacock_cuda_atom.reference_hz / 29979245800.0
  };
  ((void)0);
  p->x = (p->x + old_sc_dir_bulk) * old_Delta_nu_D / p->Delta_nu_D - p->sc_dir_bulk;
  p->a = peacock_cuda_atom.natural_width_hz / (2.0 * p->Delta_nu_D);
  p->x_cw = 6.9184721 + 81.766279 / (log(p->a) - 14.651253);
  sigma_HI = gpu_hydrogen_scattering_cross_section(rng, p->x, p->curr_cell->T);
  sigma_D = gpu_gas_scattering_cs(rng, p->x, p->curr_cell->T);
  p->curr_tau = p->curr_cell->n_HI * sigma_HI + p->curr_cell->n_D * sigma_D;
  gpu_assert_photon_values(rng, p);
}
}

namespace cii {
enum cii_transition { CII_13, CII_23, CII_24 };
struct cii_event { cii_transition line; int lower_out; };
TLAC_DEVICE double gpu_HG_asymmetry_parameter(GpuRng *rng, double x, double T);
TLAC_DEVICE double gpu_cii_population_cross_section(GpuRng *rng, double x, double T, double ratio21);
TLAC_DEVICE void gpu_cii_population_cross_sections(GpuRng *rng, double x, double T, double ratio21, double sigma[3]);
TLAC_DEVICE void gpu_interact_dust(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_interact_hydrogen(GpuRng *rng, photon* p);
TLAC_DEVICE int gpu_propagate_photon(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_scatter_dust(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_scatter_hydrogen(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_cii_frequency_from_sample(GpuRng *rng, photon *p, cii_event e,
                                           double old_dir[], double new_dir[]);
TLAC_DEVICE double gpu_sct_cii_parallel_velocity(GpuRng *rng, photon *p, cii_transition line);
TLAC_DEVICE double gpu_sct_cii_path_w2(GpuRng *rng, cii_event e);
TLAC_DEVICE cii_event gpu_sct_cii_sample_event(GpuRng *rng, photon *p);
TLAC_DEVICE cii_transition gpu_sct_cii_select_transition(GpuRng *rng, const photon *p);
TLAC_DEVICE void gpu_sct_cii_set_direction(GpuRng *rng, photon *p, cii_event e);
TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_3piece(GpuRng *rng, photon *p, double a);
TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_5piece(GpuRng *rng, photon *p, double a);
TLAC_DEVICE void gpu_shift_to_cloud(GpuRng *rng, photon *p, grid_cell *mother_cell, int cloud_id,
                    const int find_new_cell);
TLAC_DEVICE void gpu_unshift_from_cloud(GpuRng *rng, photon *p);
TLAC_DEVICE int gpu_update_photon_pos(GpuRng *rng, photon *p, double r, double *dist_old);
TLAC_DEVICE void gpu_update_photon_values(GpuRng *rng, photon *p);

TLAC_DEVICE double gpu_HG_asymmetry_parameter(GpuRng *rng, double x, double T) {
  return 0.586;
}

TLAC_DEVICE double gpu_cii_population_cross_section(GpuRng *rng, double x, double T, double ratio21) {
  double sigma[3];
  gpu_cii_population_cross_sections(rng, x, T, ratio21, sigma);
  return sigma[0]+sigma[1]+sigma[2];
}

TLAC_DEVICE void gpu_cii_population_cross_sections(GpuRng *rng, double x, double T, double ratio21, double sigma[3]) {
  if(!isfinite(ratio21) || ratio21 < 0.0) {
    printf( "C II requires finite n2/n1 >= 0; got %g\n", ratio21);
    __trap();
  }
  const double D = gpu_doppler_freq_shift_hydrogen(rng, T);
  const double C = sqrt(3.14159265358979323846)*4.803205e-10*4.803205e-10 /
                   (9.10938e-28*29979245800.0*D);
  sigma[0] = C*peacock_cuda_atom.f0*gpu_voigt_function_approx(rng, ((peacock_cuda_atom.decay0 +peacock_cuda_atom.decay1)/(2.0*3.14159265358979323846))/(2*D), x);
  sigma[1] = ratio21*C*peacock_cuda_atom.f1*gpu_voigt_function_approx(rng, ((peacock_cuda_atom.decay0 +peacock_cuda_atom.decay1)/(2.0*3.14159265358979323846))/(2*D), x+peacock_cuda_atom.fine_structure_hz/D);
  sigma[2] = ratio21*C*peacock_cuda_atom.f2*gpu_voigt_function_approx(rng, (peacock_cuda_atom.decay2/(2.0*3.14159265358979323846))/(2*D), x+peacock_cuda_atom.cii_third_detuning_hz/D);
}

TLAC_DEVICE void gpu_interact_dust(GpuRng *rng, photon *p) {
  double u = gpu_rand_uniform(rng);
  double eta = gpu_dust_albedo(rng, p->x, p->curr_cell->T);
  if(eta > u) {
    gpu_scatter_dust(rng, p);
  } else {
    p->curr_cell = nullptr;
    p->curr_tau = -1;
  }
}

TLAC_DEVICE void gpu_interact_hydrogen(GpuRng *rng, photon* p) {
  gpu_scatter_hydrogen(rng, p);
}

TLAC_DEVICE int gpu_propagate_photon(GpuRng *rng, photon *p) {
  if(p->emission_cfg->initial_pos_mode == 13 &&
     p->dir[(int)p->emission_cfg->initial_pos_param] < 0) return 1;
  while(p->curr_cell != NULL) {
    gpu_update_photon_values(rng, p);
    if(!isfinite(p->x) || !isfinite(p->curr_tau) || p->curr_tau < 0) return -1;
    if(p->tau <= 0) p->tau = gpu_get_new_tau(rng);
    double sigma_D = gpu_gas_scattering_cs(rng, p->x, p->curr_cell->T);
    double r = p->curr_tau == 0 ? DBL_MAX : p->tau/p->curr_tau;
    p->prev_cell = p->curr_cell;
    double prev_tau = p->curr_tau, dist;
    gpu_update_photon_pos(rng, p, r, &dist);
    if(!isfinite(dist) || dist < 0) return -1;
    p->dist += dist;
    p->c_HI_total += p->prev_cell->n_HI*dist;
    p->c_D_total += p->prev_cell->n_D*dist;
    p->tau -= dist*prev_tau;
    if(p->tau <= 0) {
      if(p->curr_cell == NULL) return -1;
      p->nscatter++;
      r = gpu_rand_uniform(rng);
      double rho = p->curr_cell->n_D*sigma_D/p->curr_tau;
      p->x_last = p->x;
      for(int i=0;i<3;i++) p->dir_last[i]=p->dir[i];
      if(r > rho) gpu_interact_hydrogen(rng, p);
      else gpu_interact_dust(rng, p);
      if(p->curr_tau < 0) return 0;
      p->dist = 0;
      p->tau = -1;
    } else if(p->curr_cell == NULL && p->cell_shifted != NULL) {
      gpu_unshift_from_cloud(rng, p);
    }
  }
  return isfinite(p->x) ? 1 : -1;
}

TLAC_DEVICE void gpu_scatter_dust(GpuRng *rng, photon *p) {
  double u = gpu_rand_uniform(rng);
  double mu;
  double g[] = {gpu_HG_asymmetry_parameter(rng, p->x, p->curr_cell->T)};
  mu = -((g[0] - 1) * (g[0] - 1) +
         2 * (g[0] - 1) * (1 + g[0] * g[0]) * u - 2 * g[0]
         * (1 + g[0] * g[0]) * u * u) / pow(1 + g[0] * (2 * u - 1), 2);
  mu = fmax(-1.0, fmin(1.0, mu));
  gpu_rotrand3d_angle(rng, p->dir, acos(mu), p->dir);
  p->sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p->curr_cell, p->dir, p->pos, p->grid);
}

TLAC_DEVICE void gpu_scatter_hydrogen(GpuRng *rng, photon *p) {
  double old_dir[3];
  for(int i=0; i<3; i++) old_dir[i] = p->dir[i];
  const cii_event e = gpu_sct_cii_sample_event(rng, p);
  gpu_sct_cii_set_direction(rng, p, e);
  p->sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p->curr_cell, p->dir, p->pos, p->grid);
  p->x = gpu_sct_cii_frequency_from_sample(rng, p, e, old_dir, p->dir);
}

TLAC_DEVICE double gpu_sct_cii_frequency_from_sample(GpuRng *rng, photon *p, cii_event e,
                                           double old_dir[], double new_dir[]) {
  const double mu = fmax(-1.0, fmin(1.0, gpu_scalar_product_3d(rng, old_dir, new_dir)));
  const int lower_in = e.line == CII_13 ? 1 : 2;
  const double shift = (lower_in-e.lower_out)*peacock_cuda_atom.fine_structure_hz /
                       gpu_doppler_freq_shift_hydrogen(rng, p->curr_cell->T);
  return p->x + shift + p->u_scatter_last[0]*(mu-1.0)
    + p->u_scatter_last[1]*sqrt(fmax(0.0, 1.0-mu*mu));
}

TLAC_DEVICE double gpu_sct_cii_parallel_velocity(GpuRng *rng, photon *p, cii_transition line) {
  photon local = *p;
  const double D = gpu_doppler_freq_shift_hydrogen(rng, p->curr_cell->T);
  const double offsets[] = {0.0, peacock_cuda_atom.fine_structure_hz/D, peacock_cuda_atom.cii_third_detuning_hz/D};
  const double widths[] = {((peacock_cuda_atom.decay0 +peacock_cuda_atom.decay1)/(2.0*3.14159265358979323846)), ((peacock_cuda_atom.decay0 +peacock_cuda_atom.decay1)/(2.0*3.14159265358979323846)), (peacock_cuda_atom.decay2/(2.0*3.14159265358979323846))};
  local.x += offsets[line];
  local.a = widths[line]/(2*D);
  local.x_cw = 6.9184721 + 81.766279/(log(local.a)-14.651253);
  return fabs(local.x) < 3.5 ? gpu_sct_hyd_get_atom_parallel_vel_3piece(rng, &local, local.a)
                            : gpu_sct_hyd_get_atom_parallel_vel_5piece(rng, &local, local.a);
}

TLAC_DEVICE double gpu_sct_cii_path_w2(GpuRng *rng, cii_event e) {
  if(e.line == CII_24) return peacock_cuda_atom.cii_phase_24;
  if(e.line == CII_13) return e.lower_out == 1 ? peacock_cuda_atom.cii_phase_13_1 : peacock_cuda_atom.cii_phase_cross;
  return e.lower_out == 2 ? peacock_cuda_atom.cii_phase_23_2 : peacock_cuda_atom.cii_phase_cross;
}

TLAC_DEVICE cii_event gpu_sct_cii_sample_event(GpuRng *rng, photon *p) {
  cii_event e;
  e.line = gpu_sct_cii_select_transition(rng, p);
  p->u_scatter_last[0] = gpu_sct_cii_parallel_velocity(rng, p, e.line);
  p->u_scatter_last[1] = gpu_rand_gaussian(rng, 1.0/sqrt(2.0));
  e.lower_out = e.line == CII_24 ? 2 :
    (gpu_rand_uniform(rng) < peacock_cuda_atom.decay0/(peacock_cuda_atom.decay0 +peacock_cuda_atom.decay1) ? 1 : 2);
  return e;
}

TLAC_DEVICE cii_transition gpu_sct_cii_select_transition(GpuRng *rng, const photon *p) {
  double w[3];
  gpu_cii_population_cross_sections(rng, p->x, p->curr_cell->T,
                               p->emission_cfg->CII_ratio_21, w);
  const double total = w[0]+w[1]+w[2];
  if(!(total > 0.0) || !isfinite(total)) {
    do { printf( "[Error] " "C II gas event has invalid total absorption cross section."); printf( " -- %s:%d:%s()\n", "interact_hydrogen.c", 60, __func__); } while (0);
    __trap();
  }
  const double q = gpu_rand_uniform(rng)*total;
  if(q < w[0]) return CII_13;
  if(q < w[0]+w[1]) return CII_23;
  return CII_24;
}

TLAC_DEVICE void gpu_sct_cii_set_direction(GpuRng *rng, photon *p, cii_event e) {
  const double W2 = gpu_sct_cii_path_w2(rng, e);
  const double max_pdf = fmax(0.5-W2/8.0, 0.5+W2/4.0);
  double mu;
  do {
    mu = 2*gpu_rand_uniform(rng)-1;
  } while(gpu_rand_uniform(rng)*max_pdf > 0.5+W2*(3*mu*mu-1)/8.0);
  gpu_rotrand3d_angle(rng, p->dir, acos(mu), p->dir);
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_3piece(GpuRng *rng, photon *p, double a) {
  float u0, atan_tmp, rnd1, rnd2, rnd3, upar_prop, prob, sgnx, expu0sq;
  float xabs = fabs(p->x);
  u0 = 0.97 * xabs;
  expu0sq = exp(- u0* u0);
  atan_tmp = atan((u0 - xabs) / a);
  prob = (atan_tmp + 0.5 * 3.14159265358979323846) /
    ((1 - expu0sq) * atan_tmp + (1 + expu0sq) * 0.5 * 3.14159265358979323846);
  do {
    rnd1 = gpu_rand_uniform(rng);
    if(rnd1 > prob)
      rnd2 = atan_tmp + (0.5 * 3.14159265358979323846 - atan_tmp) * gpu_rand_uniform(rng);
    else
      rnd2 = -0.5 * 3.14159265358979323846 + (atan_tmp + 0.5 * 3.14159265358979323846) * gpu_rand_uniform(rng);
    upar_prop = a * tan(rnd2) + xabs;
    if(rnd1 < prob)
      rnd3 = exp(upar_prop * upar_prop) * gpu_rand_uniform(rng);
    else
      rnd3 = expu0sq * exp(upar_prop * upar_prop) * gpu_rand_uniform(rng);
    gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 1);
  } while(rnd3 > 1);
  gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 2);
  sgnx = ((p->x < 0) ? -1 : 1);
  return upar_prop * sgnx;
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_5piece(GpuRng *rng, photon *p, double a) {
  double rnd1, rnd3, upar_prop, sgnx;
  double fac1, fac2, funcval, zz, ratio;
  double x = fabs(p->x);
  double d = (6.0 + 0.375 * 0.3 * log(a)) * 2.0 * atan(sqrt(x))/3.14159265358979323846;
  double f = 2.25 - (0.55 + 0.025 * 0.3 * log(a)) * atan(3 * (x - 4));
  double ed = exp(-d * d);
  double ef = exp(-f * f);
  double A1 = ed / a * atan(a / (d + x));
  double A2 = A1 + ef / a * atan((a * (d - f))/(a * a +(f + x) * (d + x)));
  double A3 = A2 + 1.0/a * atan(2.0*f*a/(x*x+a*a-f*f));
  double A4 = A3 + (ef/a) * atan(a*(d-f)/(a*a+(d-x)*(f-x)));
  double A5 = A4 + (ed/a)*(atan(a/(d-x)) + 3.14159265358979323846);
  double norm = A5;
  A1 /= norm;
  A2 /= norm;
  A3 /= norm;
  A4 /= norm;
  A5 /= norm;
  norm = 1.0 / norm;
  do {
    rnd1 = gpu_rand_uniform(rng);
    if(rnd1 < A1) {
      fac1 = rnd1 * a / (norm * ed);
      if(fac1 == 0.0)
        fac1 = 1e-12;
      upar_prop = x + a / tan(fac1);
      funcval = ed;
    } else if(rnd1 > A1 && rnd1 < A2) {
      fac1 = a*(rnd1-A1)/(norm*ef);
      fac2 = -1.0 * (d+x)/a;
      upar_prop = x+a*((tan(fac1)+fac2)/(1.0-fac2*tan(fac1)));
      funcval = ef;
    } else if(rnd1 > A2 && rnd1 < A3) {
      fac1 = a*(rnd1-A2)/norm;
      fac2 = (f+x)/a;
      upar_prop=x+a*(tan(fac1)-fac2)/(1.0+fac2*tan(fac1));
      funcval=1.0;
      fac1=a*(rnd1-A2)/(norm);
      fac2=(f+x)/a;
      upar_prop=x+a*(tan(fac1)-fac2)/(1+fac2*tan(fac1));
      funcval=1.0;
    } else if(rnd1 > A3 && rnd1 < A4) {
      fac1=a*(rnd1-A3)/(ef*norm)+atan((f-x)/a);
      upar_prop=x+a*tan(fac1);
      funcval=ef;
    } else {
      fac1=a*(rnd1-A4)/(norm*ed);
      fac2=(d-x)/a;
      upar_prop=x+a*(tan(fac1)+fac2)/(1-fac2*tan(fac1));
      funcval=ed;
    }
    zz = sqrt(-1. * log(funcval));
    ratio = exp(-1. * (upar_prop * upar_prop - zz * zz));
    rnd3 = gpu_rand_uniform(rng);
    gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 1);
  } while(rnd3 > ratio);
  gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 2);
  sgnx = ((p->x < 0) ? -1 : 1);
  return upar_prop * sgnx;
}

TLAC_DEVICE void gpu_shift_to_cloud(GpuRng *rng, photon *p, grid_cell *mother_cell, int cloud_id,
                    const int find_new_cell) {
  int i;
  grid *cloud = mother_cell->cloud_grids[cloud_id];
  ((void)0);
  ((void)0);
  p->grid_shifted = p->grid;
  p->cell_shifted = mother_cell;
  for(i = 0; i < 3; i++) {
    p->pos_shifted[i] += mother_cell->pos_clouds[cloud_id][i];
    p->vel_shifted[i] += mother_cell->vel_clouds[cloud_id][i];
    p->pos[i] -= mother_cell->pos_clouds[cloud_id][i];
  }
  p->grid = cloud;
  if(find_new_cell == 0)
    p->curr_cell = &(cloud->cells[cloud->ncells[0] - 1][0][0]);
  else if(find_new_cell == 1)
    p->curr_cell = gpu_find_grid_cell(rng, p->grid, p->pos);
  else
    do { printf( "[Error] " "Unknown `find_new_cell` (=%d)", find_new_cell); printf( " -- %s:%d:%s()\n", "clouds.c", 2226, __func__); } while (0);
  gpu_update_photon_values(rng, p);
  p->x -= gpu_scalar_product_3d(rng, p->vel_shifted, p->dir);
  ((void)0);
  gpu_assert_photon_pos(rng, p);
}

TLAC_DEVICE void gpu_unshift_from_cloud(GpuRng *rng, photon *p) {
  int i;
  ((void)0);
  ((void)0);
  p->curr_cell = p->cell_shifted;
  for(i = 0; i < 3; i++) {
    p->pos[i] += p->pos_shifted[i];
    p->pos_shifted[i] = 0;
  }
  p->grid = p->grid_shifted;
  p->grid_shifted = nullptr;
  p->cell_shifted = nullptr;
  double old_Delta_nu_D = p->Delta_nu_D;
  gpu_update_photon_values(rng, p);
  p->x += gpu_scalar_product_3d(rng, p->vel_shifted, p->dir) * old_Delta_nu_D / p->Delta_nu_D;
  for(i = 0; i < 3; i++)
    p->vel_shifted[i] = 0;
  p->nclouds_passed++;
  ((void)0);
  ((void)0);
}

TLAC_DEVICE int gpu_update_photon_pos(GpuRng *rng, photon *p, double r, double *dist_old) {
  grid_cell *next_cell;
  double intersection[3];
  int i;
  int ret;
  const double epsilon = 0;
  ret = gpu_get_cloud_intersection(rng, p->curr_cell, p->pos, p->dir,
                               intersection, dist_old);
  if(ret != -1) {
    if(r > *dist_old) {
      p->pos[0] = intersection[0];
      p->pos[1] = intersection[1];
      p->pos[2] = intersection[2];
      gpu_shift_to_cloud(rng, p, p->curr_cell, ret, 0);
      gpu_assert_photon_pos(rng, p);
      return 100;
    } else {
      for(i = 0; i < 3; i++)
        p->pos[i] += r * p->dir[i];
      *dist_old = fabs(r);
      gpu_assert_photon_pos(rng, p);
      return 0;
    }
  }
  ret = gpu_get_next_cell(rng, p->grid, p->curr_cell, p->pos,
                      p->dir, &(next_cell),
                      intersection, dist_old);
  if(r > *dist_old) {
    for(i = 0; i < 3; i++) {
      p->pos[i] = intersection[i] + p->curr_cell->size[0] * epsilon * p->dir[i];
      *dist_old += p->curr_cell->size[0] * epsilon * p->dir[i];
    }
    p->curr_cell = next_cell;
  } else {
    for(i = 0; i < 3; i++)
      p->pos[i] += r * p->dir[i];
    *dist_old = fabs(r);
    ret = 0;
  }
  return ret;
}

TLAC_DEVICE void gpu_update_photon_values(GpuRng *rng, photon *p) {
  gpu_assert_photon_values(rng, p);
  ((void)0);
  double sigma_HI, sigma_D;
  double old_Delta_nu_D = p->Delta_nu_D;
  double old_sc_dir_bulk = p->sc_dir_bulk;
  ((void)0);
  p->Delta_nu_D = gpu_doppler_freq_shift_hydrogen(rng, p->curr_cell->T);
  ((void)0);
  p->sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p->curr_cell, p->dir, p->pos,
                                                p->grid);
  ((void)0);
  double tmpvel[] = {
    p->vel_shifted[0] / old_Delta_nu_D * peacock_cuda_atom.reference_hz / 29979245800.0,
    p->vel_shifted[1] / old_Delta_nu_D * peacock_cuda_atom.reference_hz / 29979245800.0,
    p->vel_shifted[2] / old_Delta_nu_D * peacock_cuda_atom.reference_hz / 29979245800.0
  };
  ((void)0);
  p->x = (p->x + old_sc_dir_bulk) * old_Delta_nu_D / p->Delta_nu_D - p->sc_dir_bulk;
  p->a = ((peacock_cuda_atom.decay0 +peacock_cuda_atom.decay1)/(2.0*3.14159265358979323846)) / (2.0 * p->Delta_nu_D);
  p->x_cw = 6.9184721 + 81.766279 / (log(p->a) - 14.651253);
  sigma_HI = gpu_cii_population_cross_section(rng, p->x, p->curr_cell->T,
                                          p->emission_cfg->CII_ratio_21);
  sigma_D = gpu_gas_scattering_cs(rng, p->x, p->curr_cell->T);
  p->curr_tau = p->curr_cell->n_HI*sigma_HI + p->curr_cell->n_D*sigma_D;
  gpu_assert_photon_values(rng, p);
}
}

namespace doublet {
enum doublet_transition { LINE_BLUE, LINE_RED };
TLAC_DEVICE double gpu_HG_asymmetry_parameter(GpuRng *rng, double x, double T);
TLAC_DEVICE void gpu_doublet_component_cross_sections(GpuRng *rng, double x,double T,double sigma[2]);
TLAC_DEVICE double gpu_hydrogen_scattering_cross_section_double_line(GpuRng *rng, double x,double T);
TLAC_DEVICE void gpu_interact_dust(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_interact_hydrogen(GpuRng *rng, photon* p);
TLAC_DEVICE int gpu_propagate_photon(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_scatter_dust(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_scatter_hydrogen(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_doublet_far_parallel_velocity(GpuRng *rng, double signed_x,double a);
TLAC_DEVICE double gpu_sct_doublet_frequency_from_sample(GpuRng *rng, photon *p,
                                            double old_dir[], double new_dir[], doublet_transition line);
TLAC_DEVICE double gpu_sct_doublet_parallel_velocity(GpuRng *rng, photon *p,doublet_transition line);
TLAC_DEVICE doublet_transition gpu_sct_doublet_select_transition(GpuRng *rng, const photon *p);
TLAC_DEVICE void gpu_sct_doublet_set_direction(GpuRng *rng, photon *p, doublet_transition line);
TLAC_DEVICE double gpu_sct_hyd_core_get_angle_2p32(GpuRng *rng);
TLAC_DEVICE double gpu_sct_hyd_get_atom_orthogonal_velocity(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_3piece(GpuRng *rng, photon *p);
TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_5piece(GpuRng *rng, photon *p);
TLAC_DEVICE void gpu_shift_to_cloud(GpuRng *rng, photon *p, grid_cell *mother_cell, int cloud_id,
                    const int find_new_cell);
TLAC_DEVICE void gpu_unshift_from_cloud(GpuRng *rng, photon *p);
TLAC_DEVICE int gpu_update_photon_pos(GpuRng *rng, photon *p, double r, double *dist_old);
TLAC_DEVICE void gpu_update_photon_values(GpuRng *rng, photon *p);

TLAC_DEVICE double gpu_HG_asymmetry_parameter(GpuRng *rng, double x, double T) {
  return 0.65;
}

TLAC_DEVICE void gpu_doublet_component_cross_sections(GpuRng *rng, double x,double T,double sigma[2]) {
  const double D=gpu_doppler_freq_shift_hydrogen(rng, T);
  const double Dr=D*(peacock_cuda_atom.red_hz/peacock_cuda_atom.reference_hz);
  const double pref=sqrt(3.14159265358979323846)*4.803205e-10*4.803205e-10/(9.10938e-28*29979245800.0);
  const double xr=(D*x+(peacock_cuda_atom.reference_hz-peacock_cuda_atom.red_hz))/Dr;
  sigma[0]=(pref/D)*peacock_cuda_atom.f0*gpu_voigt_function_approx(rng, peacock_cuda_atom.decay0/(4*3.14159265358979323846*D),x);
  sigma[1]=(pref/Dr)*peacock_cuda_atom.f1*gpu_voigt_function_approx(rng, peacock_cuda_atom.decay1/(4*3.14159265358979323846*Dr),xr);
}

TLAC_DEVICE double gpu_hydrogen_scattering_cross_section_double_line(GpuRng *rng, double x,double T) {
  double sigma[2];gpu_doublet_component_cross_sections(rng, x,T,sigma);return sigma[0]+sigma[1];
}

TLAC_DEVICE void gpu_interact_dust(GpuRng *rng, photon *p) {
  double u = gpu_rand_uniform(rng);
  double eta = gpu_dust_albedo(rng, p->x, p->curr_cell->T);
  if(eta > u) {
    gpu_scatter_dust(rng, p);
  } else {
    p->curr_cell = nullptr;
    p->curr_tau = -1;
  }
}

TLAC_DEVICE void gpu_interact_hydrogen(GpuRng *rng, photon* p) {
  gpu_scatter_hydrogen(rng, p);
}

TLAC_DEVICE int gpu_propagate_photon(GpuRng *rng, photon *p) {
  int steps=0;
  if(p->emission_cfg->initial_pos_mode==13) return -1;
  while(p->curr_cell!=NULL) {
    if(++steps>10000000) return -3;
    gpu_update_photon_values(rng, p);
    if(!isfinite(p->x)||!isfinite(p->curr_tau)||p->curr_tau<0) return -1;
    if(p->tau<=0) p->tau=gpu_get_new_tau(rng);
    if(!isfinite(p->tau)||p->tau<=0) return -1;
    double sigma_D=gpu_gas_scattering_cs(rng, p->x,p->curr_cell->T);
    double r=p->curr_tau==0?DBL_MAX:p->tau/p->curr_tau;
    p->prev_cell=p->curr_cell;
    double prev_tau=p->curr_tau,dist;
    gpu_update_photon_pos(rng, p,r,&dist);
    if(!isfinite(dist)||dist<0) return -1;
    p->dist+=dist;
    p->c_HI_total+=p->prev_cell->n_HI*dist;
    p->c_D_total+=p->prev_cell->n_D*dist;
    p->tau-=dist*prev_tau;
    if(p->tau<=0) {
      if(p->curr_cell==NULL||p->curr_tau<=0) return -1;
      if(p->nscatter>=2000000) return -2;
      p->nscatter++;
      r=gpu_rand_uniform(rng);
      double rho=p->curr_cell->n_D*sigma_D/p->curr_tau;
      if(!isfinite(rho)||rho<0||rho>1) return -1;
      p->x_last=p->x;
      for(int i=0;i<3;i++)p->dir_last[i]=p->dir[i];
      if(r>rho)gpu_interact_hydrogen(rng, p);else gpu_interact_dust(rng, p);
      if(p->curr_tau<0)return 0;
      if(!isfinite(p->x)||!isfinite(p->sc_dir_bulk))return -1;
      for(int i=0;i<3;i++)if(!isfinite(p->dir[i]))return -1;
      p->dist=0;p->tau=-1;
    } else if(p->curr_cell==NULL&&p->cell_shifted!=NULL)gpu_unshift_from_cloud(rng, p);
  }
  if(!isfinite(p->x)||!isfinite(p->sc_dir_bulk)||p->cell_shifted!=NULL)return -1;
  for(int i=0;i<3;i++)if(!isfinite(p->pos[i])||!isfinite(p->dir[i]))return -1;
  return 1;
}

TLAC_DEVICE void gpu_scatter_dust(GpuRng *rng, photon *p) {
  double u = gpu_rand_uniform(rng);
  double mu;
  double g[] = {gpu_HG_asymmetry_parameter(rng, p->x, p->curr_cell->T)};
  mu = -((g[0] - 1) * (g[0] - 1) +
         2 * (g[0] - 1) * (1 + g[0] * g[0]) * u - 2 * g[0]
         * (1 + g[0] * g[0]) * u * u) / pow(1 + g[0] * (2 * u - 1), 2);
  gpu_rotrand3d_angle(rng, p->dir, acos(mu), p->dir);
}

TLAC_DEVICE void gpu_scatter_hydrogen(GpuRng *rng, photon *p) {
  double old_dir[3];
  for(int i = 0; i < 3; i++) old_dir[i] = p->dir[i];
  const doublet_transition line = gpu_sct_doublet_select_transition(rng, p);
  p->extra_info[0]=(double)line;
  p->u_scatter_last[0] = gpu_sct_doublet_parallel_velocity(rng, p, line);
  p->u_scatter_last[1] = gpu_sct_hyd_get_atom_orthogonal_velocity(rng, p);
  gpu_sct_doublet_set_direction(rng, p, line);
  p->sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p->curr_cell, p->dir,
                                                p->pos, p->grid);
  p->x = gpu_sct_doublet_frequency_from_sample(rng, p, old_dir, p->dir,line);
}

TLAC_DEVICE double gpu_sct_doublet_far_parallel_velocity(GpuRng *rng, double signed_x,double a) {
  if (!isfinite(signed_x) || !isfinite(a) || !(a > 0)) return nan("");
  const double x=fabs(signed_x),h=fmin(12.,x*.5),bound=(x-h)*(x-h)+a*a;
  const double left=atan2(a,x+h),right=atan2(a,h-x);
  const double core=sqrt(3.14159265358979323846)*erf(h)/bound,tail=exp(-h*h)*(left+right)/a;
  if (!isfinite(bound) || !(bound > 0) || !isfinite(core) || core < 0 ||
      !isfinite(tail) || tail < 0 || !isfinite(core+tail) || !(core+tail > 0)) return nan("");
  const unsigned int max_operations=1048576u;
  unsigned int operations=0;
  while(operations<max_operations) {
    ++operations;
    double u;
    if(gpu_rand_uniform(rng)*(core+tail)<core) {
      do {
        if(operations>=max_operations)return nan("");
        ++operations;
        u=gpu_rand_gaussian(rng, 1/sqrt(2.));
      }while(fabs(u)>h);
      if(gpu_rand_uniform(rng)<=bound/((x-u)*(x-u)+a*a))return signed_x<0?-u:u;
    }else {
      double q=gpu_rand_uniform(rng)*(left+right);
      if(q<=0)continue;
      if(q<left)u=x-a/tan(q);
      else {q-=left;if(q<=0)continue;u=x+a/tan(q);}
      if(isfinite(u) && fabs(u)>=h && gpu_rand_uniform(rng)<=exp(h*h-u*u))return signed_x<0?-u:u;
    }
  }
  return nan("");
}

TLAC_DEVICE double gpu_sct_doublet_frequency_from_sample(GpuRng *rng, photon *p,
                                            double old_dir[], double new_dir[], doublet_transition line) {
  const double mu = fmax(-1.0,fmin(1.0,gpu_scalar_product_3d(rng, old_dir, new_dir)));
  const double Dj_over_Dblue=line==LINE_BLUE?1.0:peacock_cuda_atom.red_hz/peacock_cuda_atom.reference_hz;
  return p->x + Dj_over_Dblue * (p->u_scatter_last[0] * (mu-1.0)
    + p->u_scatter_last[1] * sqrt(fmax(0.0, 1.0 - mu * mu)));
}

TLAC_DEVICE double gpu_sct_doublet_parallel_velocity(GpuRng *rng, photon *p,doublet_transition line) {
  photon local=*p;
  const double Dblue=gpu_doppler_freq_shift_hydrogen(rng, p->curr_cell->T);
  const double ratio=line==LINE_BLUE?1.0:peacock_cuda_atom.red_hz/peacock_cuda_atom.reference_hz;
  const double Dj=Dblue*ratio;
  local.x=line==LINE_BLUE?p->x:(Dblue*p->x+(peacock_cuda_atom.reference_hz-peacock_cuda_atom.red_hz))/Dj;
  local.a=(line==LINE_BLUE?peacock_cuda_atom.decay0:peacock_cuda_atom.decay1)/(4*3.14159265358979323846*Dj);
  local.x_cw=6.9184721+81.766279/(log(local.a)-14.651253);
  if(fabs(local.x)>12)return gpu_sct_doublet_far_parallel_velocity(rng, local.x,local.a);
  return fabs(local.x)<3.5 ? gpu_sct_hyd_get_atom_parallel_vel_3piece(rng, &local) : gpu_sct_hyd_get_atom_parallel_vel_5piece(rng, &local);
}

TLAC_DEVICE doublet_transition gpu_sct_doublet_select_transition(GpuRng *rng, const photon *p) {
  double sigma[2];gpu_doublet_component_cross_sections(rng, p->x,p->curr_cell->T,sigma);
  const double total=sigma[0]+sigma[1];
  if(!(total>0) || !isfinite(total)){do { printf( "[Error] " "Invalid doublet opacity"); printf( " -- %s:%d:%s()\n", "interact_hydrogen.c", 41, __func__); } while (0);__trap();}
  return gpu_rand_uniform(rng)*total<sigma[0] ? LINE_BLUE : LINE_RED;
}

TLAC_DEVICE void gpu_sct_doublet_set_direction(GpuRng *rng, photon *p, doublet_transition line) {
  if(line == LINE_BLUE) {
    const double theta = gpu_sct_hyd_core_get_angle_2p32(rng);
    gpu_rotrand3d_angle(rng, p->dir, theta, p->dir);
  } else {
    gpu_rand_direction_3d(rng, p->dir);
  }
}

TLAC_DEVICE double gpu_sct_hyd_core_get_angle_2p32(GpuRng *rng) {
  const double u = gpu_rand_uniform(rng);
  const double sqr = sqrt(2325.0 + 5184.0 * (u - 1) * u);
  const double p13 = pow(36.0 - 72.0 * u + sqr , 1.0/3.0);
  const double tpot = 1.4422495703074083;
  const double nom = 7.0 * tpot * tpot - tpot * p13 * p13;
  const double denom = 3.0 * p13;
  const double mu = nom / denom;
  return acos(mu);
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_orthogonal_velocity(GpuRng *rng, photon *p) {
  const double xcrit = 0;
  const double xcw = 0;
  if(fabs(p->x) < xcw) {
    double ret = sqrt(xcrit * xcrit - log(gpu_rand_uniform(rng))) * cos(2 * 3.14159265358979323846 * gpu_rand_uniform(rng));
    if(!isfinite(ret)) {
      return gpu_sct_hyd_get_atom_orthogonal_velocity(rng, p);
    }
    return ret;
  } else {
    return gpu_rand_gaussian(rng, 1./sqrt(2.0));
  }
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_3piece(GpuRng *rng, photon *p) {
  float u0, atan_tmp, rnd1, rnd2, rnd3, upar_prop, prob, sgnx, expu0sq;
  float xabs = fabs(p->x);
  u0 = 0.97 * xabs;
  expu0sq = exp(- u0* u0);
  atan_tmp = atan((u0 - xabs) / p->a);
  prob = (atan_tmp + 0.5 * 3.14159265358979323846) /
    ((1 - expu0sq) * atan_tmp + (1 + expu0sq) * 0.5 * 3.14159265358979323846);
  do {
    rnd1 = gpu_rand_uniform(rng);
    if(rnd1 > prob)
      rnd2 = atan_tmp + (0.5 * 3.14159265358979323846 - atan_tmp) * gpu_rand_uniform(rng);
    else
      rnd2 = -0.5 * 3.14159265358979323846 + (atan_tmp + 0.5 * 3.14159265358979323846) * gpu_rand_uniform(rng);
    upar_prop = p->a * tan(rnd2) + xabs;
    if(rnd1 < prob)
      rnd3 = exp(upar_prop * upar_prop) * gpu_rand_uniform(rng);
    else
      rnd3 = expu0sq * exp(upar_prop * upar_prop) * gpu_rand_uniform(rng);
    gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 1);
  } while(rnd3 > 1);
  gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 2);
  sgnx = ((p->x < 0) ? -1 : 1);
  return upar_prop * sgnx;
}

TLAC_DEVICE double gpu_sct_hyd_get_atom_parallel_vel_5piece(GpuRng *rng, photon *p) {
  double rnd1, rnd3, upar_prop, sgnx;
  double fac1, fac2, funcval, zz, ratio;
  double x = fabs(p->x);
  double a = p->a;
  double d = (6.0 + 0.375 * 0.3 * log(a)) * 2.0 * atan(sqrt(x))/3.14159265358979323846;
  double f = 2.25 - (0.55 + 0.025 * 0.3 * log(a)) * atan(3 * (x - 4));
  if(!(isfinite(d) && isfinite(f) && 0.0 < f && f < d && d < x))
    return gpu_sct_hyd_get_atom_parallel_vel_3piece(rng, p);
  double ed = exp(-d * d);
  double ef = exp(-f * f);
  double A1 = ed / a * atan(a / (d + x));
  double A2 = A1 + ef / a * atan((a * (d - f))/(a * a +(f + x) * (d + x)));
  double A3 = A2 + 1.0/a * atan(2.0*f*a/(x*x+a*a-f*f));
  double A4 = A3 + (ef/a) * atan(a*(d-f)/(a*a+(d-x)*(f-x)));
  double A5 = A4 + (ed/a)*(atan(a/(d-x)) + 3.14159265358979323846);
  if(!(isfinite(A1) && isfinite(A2) && isfinite(A3) && isfinite(A4) && isfinite(A5) &&
       0.0 < A1 && A1 < A2 && A2 < A3 && A3 < A4 && A4 < A5))
    return gpu_sct_hyd_get_atom_parallel_vel_3piece(rng, p);
  double norm = A5;
  A1 /= norm;
  A2 /= norm;
  A3 /= norm;
  A4 /= norm;
  A5 /= norm;
  norm = 1.0 / norm;
  do {
    rnd1 = gpu_rand_uniform(rng);
    if(rnd1 < A1) {
      fac1 = rnd1 * a / (norm * ed);
      if(fac1 == 0.0)
        fac1 = 1e-12;
      upar_prop = x + a / tan(fac1);
      funcval = ed;
    } else if(rnd1 > A1 && rnd1 < A2) {
      fac1 = a*(rnd1-A1)/(norm*ef);
      fac2 = -1.0 * (d+x)/a;
      upar_prop = x+a*((tan(fac1)+fac2)/(1.0-fac2*tan(fac1)));
      funcval = ef;
    } else if(rnd1 > A2 && rnd1 < A3) {
      fac1 = a*(rnd1-A2)/norm;
      fac2 = (f+x)/a;
      upar_prop=x+a*(tan(fac1)-fac2)/(1.0+fac2*tan(fac1));
      funcval=1.0;
      fac1=a*(rnd1-A2)/(norm);
      fac2=(f+x)/a;
      upar_prop=x+a*(tan(fac1)-fac2)/(1+fac2*tan(fac1));
      funcval=1.0;
    } else if(rnd1 > A3 && rnd1 < A4) {
      fac1=a*(rnd1-A3)/(ef*norm)+atan((f-x)/a);
      upar_prop=x+a*tan(fac1);
      funcval=ef;
    } else {
      fac1=a*(rnd1-A4)/(norm*ed);
      fac2=(d-x)/a;
      upar_prop=x+a*(tan(fac1)+fac2)/(1-fac2*tan(fac1));
      funcval=ed;
    }
    zz = sqrt(-1. * log(funcval));
    ratio = exp(-1. * (upar_prop * upar_prop - zz * zz));
    rnd3 = gpu_rand_uniform(rng);
    gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 1);
  } while(rnd3 > ratio);
  gpu_sct_hyd_get_atom_par_vel_acc_counter(rng, 2);
  sgnx = ((p->x < 0) ? -1 : 1);
  return upar_prop * sgnx;
}

TLAC_DEVICE void gpu_shift_to_cloud(GpuRng *rng, photon *p, grid_cell *mother_cell, int cloud_id,
                    const int find_new_cell) {
  int i;
  grid *cloud = mother_cell->cloud_grids[cloud_id];
  ((void)0);
  ((void)0);
  p->grid_shifted = p->grid;
  p->cell_shifted = mother_cell;
  for(i = 0; i < 3; i++) {
    p->pos_shifted[i] += mother_cell->pos_clouds[cloud_id][i];
    p->vel_shifted[i] += mother_cell->vel_clouds[cloud_id][i];
    p->pos[i] -= mother_cell->pos_clouds[cloud_id][i];
  }
  p->grid = cloud;
  if(find_new_cell == 0)
    p->curr_cell = &(cloud->cells[cloud->ncells[0] - 1][0][0]);
  else if(find_new_cell == 1)
    p->curr_cell = gpu_find_grid_cell(rng, p->grid, p->pos);
  else
    do { printf( "[Error] " "Unknown `find_new_cell` (=%d)", find_new_cell); printf( " -- %s:%d:%s()\n", "clouds.c", 2226, __func__); } while (0);
  gpu_update_photon_values(rng, p);
  p->x -= gpu_scalar_product_3d(rng, p->vel_shifted, p->dir);
  ((void)0);
  gpu_assert_photon_pos(rng, p);
}

TLAC_DEVICE void gpu_unshift_from_cloud(GpuRng *rng, photon *p) {
  int i;
  ((void)0);
  ((void)0);
  p->curr_cell = p->cell_shifted;
  for(i = 0; i < 3; i++) {
    p->pos[i] += p->pos_shifted[i];
    p->pos_shifted[i] = 0;
  }
  p->grid = p->grid_shifted;
  p->grid_shifted = nullptr;
  p->cell_shifted = nullptr;
  double old_Delta_nu_D = p->Delta_nu_D;
  gpu_update_photon_values(rng, p);
  p->x += gpu_scalar_product_3d(rng, p->vel_shifted, p->dir) * old_Delta_nu_D / p->Delta_nu_D;
  for(i = 0; i < 3; i++)
    p->vel_shifted[i] = 0;
  p->nclouds_passed++;
  ((void)0);
  ((void)0);
}

TLAC_DEVICE int gpu_update_photon_pos(GpuRng *rng, photon *p, double r, double *dist_old) {
  grid_cell *next_cell;
  double intersection[3];
  int i;
  int ret;
  const double epsilon = 0;
  ret = gpu_get_cloud_intersection(rng, p->curr_cell, p->pos, p->dir,
                               intersection, dist_old);
  if(ret != -1) {
    if(r > *dist_old) {
      p->pos[0] = intersection[0];
      p->pos[1] = intersection[1];
      p->pos[2] = intersection[2];
      gpu_shift_to_cloud(rng, p, p->curr_cell, ret, 0);
      gpu_assert_photon_pos(rng, p);
      return 100;
    } else {
      for(i = 0; i < 3; i++)
        p->pos[i] += r * p->dir[i];
      *dist_old = fabs(r);
      gpu_assert_photon_pos(rng, p);
      return 0;
    }
  }
  ret = gpu_get_next_cell(rng, p->grid, p->curr_cell, p->pos,
                      p->dir, &(next_cell),
                      intersection, dist_old);
  if(r > *dist_old) {
    for(i = 0; i < 3; i++) {
      p->pos[i] = intersection[i] + p->curr_cell->size[0] * epsilon * p->dir[i];
      *dist_old += p->curr_cell->size[0] * epsilon * p->dir[i];
    }
    p->curr_cell = next_cell;
  } else {
    for(i = 0; i < 3; i++)
      p->pos[i] += r * p->dir[i];
    *dist_old = fabs(r);
    ret = 0;
  }
  return ret;
}

TLAC_DEVICE void gpu_update_photon_values(GpuRng *rng, photon *p) {
  gpu_assert_photon_values(rng, p);
  ((void)0);
  double sigma_HI, sigma_D;
  double old_Delta_nu_D = p->Delta_nu_D;
  double old_sc_dir_bulk = p->sc_dir_bulk;
  ((void)0);
  p->Delta_nu_D = gpu_doppler_freq_shift_hydrogen(rng, p->curr_cell->T);
  ((void)0);
  p->sc_dir_bulk = gpu_cell_velocity_scalar_product(rng, p->curr_cell, p->dir, p->pos,
                                                p->grid);
  ((void)0);
  double tmpvel[] = {
    p->vel_shifted[0] / old_Delta_nu_D * peacock_cuda_atom.reference_hz / 29979245800.0,
    p->vel_shifted[1] / old_Delta_nu_D * peacock_cuda_atom.reference_hz / 29979245800.0,
    p->vel_shifted[2] / old_Delta_nu_D * peacock_cuda_atom.reference_hz / 29979245800.0
  };
  ((void)0);
  p->x = (p->x + old_sc_dir_bulk) * old_Delta_nu_D / p->Delta_nu_D - p->sc_dir_bulk;
  p->a = (peacock_cuda_atom.decay0/(2.0*3.14159265358979323846)) / (2.0 * p->Delta_nu_D);
  p->x_cw = 6.9184721 + 81.766279 / (log(p->a) - 14.651253);
  sigma_HI = gpu_hydrogen_scattering_cross_section_double_line(rng, p->x, p->curr_cell->T);
  sigma_D = gpu_gas_scattering_cs(rng, p->x, p->curr_cell->T);
  p->curr_tau = p->curr_cell->n_HI * sigma_HI + p->curr_cell->n_D * sigma_D;
  gpu_assert_photon_values(rng, p);
}
}

#include "peacock_multilevel.cuh"

extern "C" __global__ void tlac_transport(photon *photons, int *status, int count,
                                         emission_cfg_s emission, unsigned long long seed,
                                         unsigned long long offset) {
  int index = blockIdx.x * blockDim.x + threadIdx.x;
  if (index >= count) return;
  GpuRng rng;
  curand_init(seed, offset + index, 0, &rng);
  photon packet = photons[index];
  packet.emission_cfg = &emission;
  int fate = -1;
  if (peacock_cuda_atom.version == 1) {
    switch (peacock_cuda_atom.operator_id) {
    case 1: fate = lya::gpu_propagate_photon(&rng, &packet); break;
    case 2: fate = cii::gpu_propagate_photon(&rng, &packet); break;
    case 3: fate = doublet::gpu_propagate_photon(&rng, &packet); break;
    case 4: fate = multilevel::propagate(&rng, packet); break;
    }
  }
  packet.emission_cfg = nullptr;
  photons[index] = packet;
  status[index] = fate;
}
extern "C" __global__ void review_full_abi(unsigned long long *out){if(threadIdx.x||blockIdx.x)return;
out[0]=sizeof(photon);
out[1]=alignof(photon);
out[2]=offsetof(photon,pos);
out[3]=offsetof(photon,dir);
out[4]=offsetof(photon,x);
out[5]=offsetof(photon,Delta_nu_D);
out[6]=offsetof(photon,sc_dir_bulk);
out[7]=offsetof(photon,a);
out[8]=offsetof(photon,x_cw);
out[9]=offsetof(photon,curr_tau);
out[10]=offsetof(photon,tau);
out[11]=offsetof(photon,dist);
out[12]=offsetof(photon,c_HI_total);
out[13]=offsetof(photon,c_D_total);
out[14]=offsetof(photon,nscatter);
out[15]=offsetof(photon,x_i);
out[16]=offsetof(photon,extra_info);
out[17]=offsetof(photon,nclouds_passed);
out[18]=offsetof(photon,emission_cfg);
out[19]=offsetof(photon,x_last);
out[20]=offsetof(photon,dir_last);
out[21]=offsetof(photon,u_scatter_last);
out[22]=offsetof(photon,curr_cell);
out[23]=offsetof(photon,prev_cell);
out[24]=offsetof(photon,grid);
out[25]=offsetof(photon,pos_shifted);
out[26]=offsetof(photon,vel_shifted);
out[27]=offsetof(photon,cell_shifted);
out[28]=offsetof(photon,grid_shifted);
out[29]=sizeof(grid);
out[30]=alignof(grid);
out[31]=offsetof(grid,type);
out[32]=offsetof(grid,uniform);
out[33]=offsetof(grid,ncells);
out[34]=offsetof(grid,boxsize);
out[35]=offsetof(grid,L_tot);
out[36]=offsetof(grid,center);
out[37]=offsetof(grid,cells);
out[38]=offsetof(grid,nobservers);
out[39]=offsetof(grid,observers);
out[40]=sizeof(grid_cell);
out[41]=alignof(grid_cell);
out[42]=offsetof(grid_cell,L);
out[43]=offsetof(grid_cell,T);
out[44]=offsetof(grid_cell,n_HI);
out[45]=offsetof(grid_cell,n_D);
out[46]=offsetof(grid_cell,pos);
out[47]=offsetof(grid_cell,vel);
out[48]=offsetof(grid_cell,size);
out[49]=offsetof(grid_cell,nbs);
out[50]=offsetof(grid_cell,nclouds);
out[51]=offsetof(grid_cell,pos_clouds);
out[52]=offsetof(grid_cell,vel_clouds);
out[53]=offsetof(grid_cell,v_flag_clouds);
out[54]=offsetof(grid_cell,cloud_grids);
out[55]=sizeof(emission_cfg_s);
out[56]=alignof(emission_cfg_s);
out[57]=offsetof(emission_cfg_s,CII_ratio_21);
out[58]=offsetof(emission_cfg_s,initial_pos_mode);
out[59]=offsetof(emission_cfg_s,initial_pos_param);
out[60]=offsetof(emission_cfg_s,p_cloud);
out[61]=offsetof(emission_cfg_s,initial_freq_mode);
out[62]=offsetof(emission_cfg_s,initial_freq_param);
out[63]=sizeof(GpuBvhNode);
out[64]=alignof(GpuBvhNode);
out[65]=offsetof(GpuBvhNode,lo);
out[66]=offsetof(GpuBvhNode,hi);
out[67]=offsetof(GpuBvhNode,escape);
out[68]=offsetof(GpuBvhNode,cloud);
}

extern "C" __global__ void review_atom_abi(unsigned long long *out) {
  if (threadIdx.x || blockIdx.x) return;
  out[0] = sizeof(PeacockCudaAtom);
  out[1] = alignof(PeacockCudaAtom);
  out[2] = offsetof(PeacockCudaAtom, version);
  out[3] = offsetof(PeacockCudaAtom, operator_id);
  out[4] = offsetof(PeacockCudaAtom, mass_g);
  out[5] = offsetof(PeacockCudaAtom, reference_hz);
  out[6] = offsetof(PeacockCudaAtom, red_hz);
  out[7] = offsetof(PeacockCudaAtom, f0);
  out[8] = offsetof(PeacockCudaAtom, f1);
  out[9] = offsetof(PeacockCudaAtom, f2);
  out[10] = offsetof(PeacockCudaAtom, decay0);
  out[11] = offsetof(PeacockCudaAtom, decay1);
  out[12] = offsetof(PeacockCudaAtom, decay2);
  out[13] = offsetof(PeacockCudaAtom, natural_width_hz);
  out[14] = offsetof(PeacockCudaAtom, fine_structure_hz);
  out[15] = offsetof(PeacockCudaAtom, cii_third_detuning_hz);
  out[16] = offsetof(PeacockCudaAtom, dust_albedo);
  out[17] = offsetof(PeacockCudaAtom, cii_phase_13_1);
  out[18] = offsetof(PeacockCudaAtom, cii_phase_23_2);
  out[19] = offsetof(PeacockCudaAtom, cii_phase_cross);
  out[20] = offsetof(PeacockCudaAtom, cii_phase_24);
}
