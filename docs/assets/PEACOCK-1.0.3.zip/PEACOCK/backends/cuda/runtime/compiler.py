"""Compile the shared CUDA translation unit once with NVRTC."""

from contextlib import ExitStack
import ctypes as C
import ctypes.util
import hashlib
import json
import os
from pathlib import Path
import re
import site


RUNTIME = Path('backends/cuda/runtime')
DEVICE_HEADERS = {
    'peacock_multilevel.cuh': RUNTIME / 'multilevel.cuh',
    'peacock_dust_table.h': Path('src/physics/dust_table.h'),
    'peacock_voigt_coefficients.h': Path('src/physics/voigt_coefficients.h'),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def source_bundle(root):
    root = Path(root).resolve()
    source = (root / RUNTIME / 'transport.cu').read_bytes()
    headers = {name: (root / path).read_bytes() for name, path in DEVICE_HEADERS.items()}
    source_sha = sha(source)
    dependencies = {path.as_posix(): sha(headers[name]) for name, path in DEVICE_HEADERS.items()}
    identity = {'transport.cu': source_sha, 'virtual_headers': {
        name: [path.as_posix(), dependencies[path.as_posix()]] for name, path in DEVICE_HEADERS.items()
    }}
    binding = {
        'device_source_sha256': source_sha,
        'device_dependencies_sha256': dependencies,
        'device_bundle_sha256': sha(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode('ascii')),
    }
    return source, headers, binding


def _nvidia_directory(nvidia_root):
    if nvidia_root is not None:
        return Path(nvidia_root).resolve()
    candidates = [Path(entry) / 'nvidia' for entry in site.getsitepackages()]
    candidates.append(Path(site.getusersitepackages()) / 'nvidia')
    return next((path for path in candidates if (path / 'cuda_nvrtc').is_dir()), None)


def _library(dll_paths, nvidia, library):
    if os.name == 'nt':
        directory = nvidia / 'cuda_nvrtc/bin' if nvidia is not None else None
        if library is None and directory is not None:
            library = next((str(path) for path in sorted(directory.glob('nvrtc64_*.dll'))
                            if re.fullmatch(r'nvrtc64_\d+_\d+\.dll', path.name)), None)
        if library is None:
            raise FileNotFoundError('Set --nvidia-root or --nvrtc-library for NVRTC on Windows')
        explicit = Path(library)
        if explicit.is_file():
            library = str(explicit.resolve())
            directory = explicit.resolve().parent
        builtins = []
        if directory is not None and directory.is_dir():
            dll_paths.enter_context(os.add_dll_directory(str(directory)))
            builtins = [C.WinDLL(str(path)) for path in sorted(directory.glob('nvrtc-builtins*.dll'))]
        lib = C.WinDLL(str(library))
        lib._peacock_builtin_libraries = builtins
        return lib
    if library is None and nvidia is not None:
        directory = nvidia / 'cuda_nvrtc/lib'
        library = next((str(path) for path in sorted(directory.glob('libnvrtc.so*'))
                        if re.fullmatch(r'libnvrtc\.so(?:\.\d+)*', path.name)), None)
    return C.CDLL(str(library or C.util.find_library('nvrtc') or 'libnvrtc.so'))


def compile_bundle(root, output, arch='compute_120', nvidia_root=None,
                   nvrtc_library=None, includes=()):
    """Write one line-independent PTX artifact and its source binding."""
    directory = Path(root).resolve() / RUNTIME
    output = Path(output).resolve()
    record_path = output.with_suffix(output.suffix + '.json')
    if output.exists() or record_path.exists():
        raise FileExistsError(f'Existing CUDA build artifact: {output}')
    source, headers, binding = source_bundle(root)
    abi = (directory / 'abi.json').read_bytes()
    nvidia = _nvidia_directory(nvidia_root)
    include_dirs = [Path(path).resolve() for path in includes]
    if nvidia is not None:
        for name in ('cuda_runtime', 'curand', 'cuda_cccl'):
            path = nvidia / name / 'include'
            if path.is_dir():
                include_dirs.append(path)
    options = [f'--gpu-architecture={arch}', '--std=c++17',
               '--device-as-default-execution-space', '--fmad=false']
    options.extend(f'--include-path={path}' for path in include_dirs)
    option_array = (C.c_char_p * len(options))(*(option.encode() for option in options))
    header_names = (C.c_char_p * len(headers))(*(name.encode('ascii') for name in headers))
    header_sources = (C.c_char_p * len(headers))(*headers.values())
    output.parent.mkdir(parents=True, exist_ok=True)
    log_path = output.with_suffix('.compile.log')

    with ExitStack() as dll_paths:
        lib = _library(dll_paths, nvidia, nvrtc_library)
        ptr, size, integer, string = C.c_void_p, C.c_size_t, C.c_int, C.c_char_p
        declarations = {
            'nvrtcCreateProgram': [C.POINTER(ptr), string, string, integer,
                                   C.POINTER(string), C.POINTER(string)],
            'nvrtcCompileProgram': [ptr, integer, C.POINTER(string)],
            'nvrtcGetProgramLogSize': [ptr, C.POINTER(size)],
            'nvrtcGetProgramLog': [ptr, ptr],
            'nvrtcGetPTXSize': [ptr, C.POINTER(size)],
            'nvrtcGetPTX': [ptr, ptr],
            'nvrtcDestroyProgram': [C.POINTER(ptr)],
            'nvrtcVersion': [C.POINTER(integer), C.POINTER(integer)],
        }
        for name, arguments in declarations.items():
            function = getattr(lib, name)
            function.argtypes = arguments
            function.restype = integer

        def check(code, operation):
            if code:
                raise RuntimeError(f'{operation} failed with NVRTC error {code}. See {log_path}')

        program = ptr()
        check(lib.nvrtcCreateProgram(C.byref(program), source, b'peacock_transport.cu',
                                     len(headers), header_sources, header_names), 'Creating the CUDA program')
        try:
            status = lib.nvrtcCompileProgram(program, len(options), option_array)
            count = size()
            check(lib.nvrtcGetProgramLogSize(program, C.byref(count)), 'Reading the compiler log size')
            log = C.create_string_buffer(count.value)
            check(lib.nvrtcGetProgramLog(program, log), 'Reading the compiler log')
            log_path.write_bytes(log.value)
            check(status, 'Compiling the shared CUDA module')
            check(lib.nvrtcGetPTXSize(program, C.byref(count)), 'Reading the compiled PTX size')
            ptx = C.create_string_buffer(count.value)
            check(lib.nvrtcGetPTX(program, ptx), 'Reading the compiled PTX')
            major, minor = integer(), integer()
            check(lib.nvrtcVersion(C.byref(major), C.byref(minor)), 'Reading the compiler version')
        finally:
            lib.nvrtcDestroyProgram(C.byref(program))

    payload = ptx.value
    if not payload:
        raise RuntimeError('NVRTC returned empty PTX')
    record = {
        'format': 'PEACOCK_CUDA_RUNTIME_V1',
        **binding,
        'abi_contract_sha256': sha(abi),
        'ptx_sha256': sha(payload),
        'architecture': arch,
        'nvrtc_version': [major.value, minor.value],
        'compile_options': options,
    }
    output.write_bytes(payload)
    record_path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
    return record
