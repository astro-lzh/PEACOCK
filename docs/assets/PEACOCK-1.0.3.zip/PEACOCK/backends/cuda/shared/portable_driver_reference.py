#!/usr/bin/env python3
"""Run the exact exported CUDA kernel using only NVIDIA's installed driver.

Supports Windows and Linux, requires Python/numpy but no local Toolkit.
The exported PTX and data originate from this project's C/CUDA build.
"""
import argparse
import ctypes as C
import json
import os
from pathlib import Path
import struct
import time
import numpy as np

def ks_distance(a,b):
    a=np.sort(a); b=np.sort(b); points=np.sort(np.concatenate([a,b]))
    return float(np.max(np.abs(np.searchsorted(a,points,side='right')/len(a)-
                               np.searchsorted(b,points,side='right')/len(b))))

class Driver:
    def __init__(self,ptx):
        self.lib=C.WinDLL('nvcuda.dll') if os.name=='nt' else C.CDLL('libcuda.so.1')
        u=C.c_uint; i=C.c_int; p=C.c_void_p; z=C.c_size_t; d=C.c_uint64
        signatures={
          'cuInit':[u], 'cuDeviceGet':[C.POINTER(i),i],
          'cuDeviceGetName':[p,i,i], 'cuCtxCreate_v2':[C.POINTER(p),u,i],
          'cuCtxDestroy_v2':[p], 'cuModuleLoadData':[C.POINTER(p),p],
          'cuModuleGetFunction':[C.POINTER(p),p,C.c_char_p],
          'cuMemAlloc_v2':[C.POINTER(d),z], 'cuMemFree_v2':[d],
          'cuMemcpyHtoD_v2':[d,p,z], 'cuMemcpyDtoH_v2':[p,d,z],
          'cuLaunchKernel':[p,u,u,u,u,u,u,u,p,C.POINTER(p),C.POINTER(p)],
          'cuCtxSynchronize':[], 'cuGetErrorString':[i,C.POINTER(C.c_char_p)]}
        for name,args in signatures.items():
            f=getattr(self.lib,name); f.argtypes=args; f.restype=i
        self.call('cuInit',0); device=i(); self.call('cuDeviceGet',C.byref(device),0)
        name=C.create_string_buffer(256); self.call('cuDeviceGetName',name,256,device)
        self.name=name.value.decode(); self.context=p()
        self.call('cuCtxCreate_v2',C.byref(self.context),0,device)
        self.module=p(); code=C.create_string_buffer(Path(ptx).read_bytes()+b'\0')
        self.call('cuModuleLoadData',C.byref(self.module),code)
        self.kernel=p(); self.call('cuModuleGetFunction',C.byref(self.kernel),self.module,b'tlac_transport')
    def call(self,name,*args):
        rc=getattr(self.lib,name)(*args)
        if rc:
            msg=C.c_char_p(); self.lib.cuGetErrorString(rc,C.byref(msg))
            raise RuntimeError(f'{name}: CUDA error {rc}: {msg.value.decode() if msg.value else "unknown"}')
    def alloc(self,n):
        ptr=C.c_uint64(); self.call('cuMemAlloc_v2',C.byref(ptr),n); return ptr.value
    def upload(self,ptr,data):
        buf=C.create_string_buffer(bytes(data)); self.call('cuMemcpyHtoD_v2',ptr,buf,len(data))
    def download(self,ptr,n):
        buf=C.create_string_buffer(n); self.call('cuMemcpyDtoH_v2',buf,ptr,n); return buf.raw
    def close(self): self.call('cuCtxDestroy_v2',self.context)

def execute(driver,prefix,batch,no_bvh=False,limit=None,timing=None,validate_reference=True):
    loaded_start=time.perf_counter()
    meta=json.loads(prefix.with_suffix('.json').read_text())
    n,size=meta['nphot'],meta['photon_size']
    grid=bytearray(prefix.with_suffix('.grid.bin').read_bytes())
    photons=bytearray(prefix.with_suffix('.photons.bin').read_bytes())
    emission=prefix.with_suffix('.emission.bin').read_bytes()
    assert len(photons)==n*size and len(emission)==meta['emission_size']
    if limit is not None:
        n=min(n,limit); photons=photons[:n*size]
    allocations=[]
    try:
        gp=driver.alloc(len(grid)); allocations.append(gp)
        for field,target in meta['grid_relocations']:
            assert 0<=field<=len(grid)-8 and 0<=target<len(grid)
            struct.pack_into('<Q',grid,field,gp+target)
        if no_bvh:
            for field in meta.get('bvh_pointer_fields',[]): struct.pack_into('<Q',grid,field,0)
        driver.upload(gp,grid)
        for i in range(n):
            for field in meta['pointer_offsets']:
                at=i*size+field; value=struct.unpack_from('<Q',photons,at)[0]
                if value:
                    assert value-1<len(grid)
                    struct.pack_into('<Q',photons,at,gp+value-1)
        pp=driver.alloc(min(batch,n)*size); allocations.append(pp)
        sp=driver.alloc(min(batch,n)*4); allocations.append(sp)
        output=bytearray(); statuses=bytearray(); kernel_seconds=0
        for first in range(0,n,batch):
            count=min(batch,n-first)
            driver.upload(pp,photons[first*size:(first+count)*size])
            args=[C.c_uint64(pp),C.c_uint64(sp),C.c_int(count),
                  C.create_string_buffer(emission),C.c_uint64(meta['seed']),
                  C.c_uint64(meta['sequence_offset']+first)]
            params=(C.c_void_p*len(args))(*(C.cast(C.byref(v),C.c_void_p).value for v in args))
            t=time.perf_counter()
            driver.call('cuLaunchKernel',driver.kernel,(count+127)//128,1,1,128,1,1,0,None,params,None)
            driver.call('cuCtxSynchronize')
            kernel_seconds+=time.perf_counter()-t
            output.extend(driver.download(pp,count*size)); statuses.extend(driver.download(sp,count*4))
        fields=meta['fields']
        if timing is not None:
            # Ends after the last result download, before comparison and NPZ I/O.
            timing['input_to_device_results_seconds']=time.perf_counter()-loaded_start
            timing['gpu_kernel_seconds']=kernel_seconds
        dtype=np.dtype({'names':list(fields),'formats':[v[1] for v in fields.values()],
                        'offsets':[v[0] for v in fields.values()],'itemsize':size})
        result=np.frombuffer(output,dtype=dtype)
        status=np.frombuffer(statuses,dtype='<i4')
        assert np.all((status==0)|(status==1)), 'Invalid or unfinished GPU photon'
        escaped=result[status==1]
        for field in fields: assert np.all(np.isfinite(escaped[field])),field+' is not finite'
        assert np.all(escaped['nscatter']>=0)
        assert np.all(escaped['c_HI_total']>=0) and np.all(escaped['c_D_total']>=0)
        norms=np.sqrt(sum(escaped['dir'+str(i)]**2 for i in range(3)))
        assert np.allclose(norms,1,rtol=1e-10,atol=1e-10)
        stats={}; ks_limit=None; cpu_count=None
        if validate_reference:
            cpu=np.fromfile(prefix.with_suffix('.cpu.bin'),dtype=dtype)[:n]
            cs=np.fromfile(prefix.with_suffix('.cpu_status.bin'),dtype='<i4')[:n]; cpu=cpu[cs==1]
            cpu_count=len(cpu)
            pool=(len(cpu)+len(escaped))/(2*n)
            escape_limit=6*np.sqrt(max(pool*(1-pool),1/n)*2/n)+2/n
            assert abs(len(cpu)-len(escaped))/n<escape_limit,'Escape fractions disagree'
            ks_limit=np.sqrt(-0.5*np.log(0.0001/2)*(len(cpu)+len(escaped))/(len(cpu)*len(escaped)))
            xc=(cpu['x']+cpu['sc_dir_bulk'])*cpu['Delta_nu_D']
            xg=(escaped['x']+escaped['sc_dir_bulk'])*escaped['Delta_nu_D']
            for key,a,b in [('frequency',xc,xg),('scatter_count',cpu['nscatter'],escaped['nscatter']),
                            ('cloud_crossings',cpu['nclouds_passed'],escaped['nclouds_passed'])]:
                value=ks_distance(a,b); stats[key]=value
                assert value<ks_limit,(prefix.parent.name,key,value,ks_limit)
        if prefix.parent.name=='vacuum':
            assert len(escaped)==n and np.all(escaped['nscatter']==0)
            assert np.allclose(escaped['x'],escaped['x_i'],rtol=1e-12,atol=1e-12)
        report={'case':prefix.parent.name,'nphot':n,'escaped_cpu':cpu_count,'escaped_gpu':len(escaped),
          'gpu':driver.name,'batch_size':batch,'gpu_kernel_seconds':kernel_seconds,
          'cpu_transport_seconds':meta['cpu_transport_seconds'] if validate_reference else None,
          'ks':stats,'ks_limit':ks_limit,'status':'PASS' if validate_reference else 'COMPLETE',
          'cpu_reference_validation':'passed' if validate_reference else 'not_requested'}
        # Save portable numerical fields without meaningless device addresses.
        tag=('bruteforce_' if no_bvh else '')+str(batch)+('_subset' if limit else '')
        np.savez(prefix.parent/('gpu_output_'+tag+'.npz'),status=status,
                 **{name:result[name] for name in fields})
        return report,{name:result[name].copy() for name in fields},status.copy()
    finally:
        for ptr in allocations: driver.call('cuMemFree_v2',ptr)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('directory',type=Path)
    ap.add_argument('--ptx',type=Path,default=Path(__file__).with_name('transport.ptx'))
    ap.add_argument('--batch',type=int,default=65536)
    ap.add_argument('--no-reference',action='store_true',help='Run without CPU reference files; retain physical sanity checks')
    args=ap.parse_args(); assert 1<=args.batch<=1048576
    driver=Driver(args.ptx); reports=[]
    print('Executing real CUDA kernel on '+driver.name,flush=True)
    try:
        cases=sorted(args.directory.glob('*/case.json')); assert cases,'No exported cases found'
        for path in cases:
            prefix=path.with_suffix('')
            r,a,s=execute(driver,prefix,args.batch,validate_reference=not args.no_reference); reports.append(r)
            print(json.dumps(r),flush=True)
            if not args.no_reference and path.parent.name in ['clouds','t15_current']:
                _,b,t=execute(driver,prefix,args.batch+37)
                assert np.array_equal(s,t),'Batch changes photon fates'
                for field in a: assert np.array_equal(a[field],b[field]),('Batch changes output',field)
                r['batch_reproducibility']='exact for all recorded photon fields and fates'
                limit=64 if path.parent.name=='t15_current' else len(s)
                _,brute,bs=execute(driver,prefix,args.batch,no_bvh=True,limit=limit)
                assert np.array_equal(s[:limit],bs),'BVH changes photon fates'
                for field in a: assert np.array_equal(a[field][:limit],brute[field]),('BVH changes output',field)
                r['bvh_equivalence_photons']=limit
        report={'status':'COMPLETE' if args.no_reference else 'PASS','execution':'Real CUDA on local GPU; grid/emission exported from Rockfish',
                'timing_note':'Kernel timing excludes input preparation, network transfer and output; CPU reference thread count is recorded in each input metadata file.',
                'cases':reports}
        filename='gpu_run_report.json' if args.no_reference else 'gpu_validation_report.json'
        (args.directory/filename).write_text(json.dumps(report,indent=2)+'\n')
        print(report['status']+': '+str(args.directory/filename),flush=True)
    finally: driver.close()

if __name__=='__main__': main()
