#ifndef TLAC_GPU_INPUT_BVH_H
#define TLAC_GPU_INPUT_BVH_H
#include <algorithm>
#include <cfloat>
#include <climits>
#include <vector>
extern "C" {
#include "../grid.h"
// Declare only the grid distance function needed alongside CUDA math.
double distance_3d(double pos1[],double pos2[]);
}
#include "bvh.h"

namespace tlac_input {
// Shared construction for GPU ray traversal and host emission point queries.
// Conservative bounds enclose the spheres, with deterministic split ties.
inline int build(grid_cell *c,std::vector<int> &ids,int begin,int end,
                 std::vector<GpuBvhNode> &nodes) {
  int index=static_cast<int>(nodes.size()); nodes.emplace_back();
  GpuBvhNode b{}; b.cloud=-1;
  for(int d=0;d<3;d++) { b.lo[d]=DBL_MAX; b.hi[d]=-DBL_MAX; }
  for(int j=begin;j<end;j++) {
    int i=ids[j]; double radius=c->cloud_grids[i]->boxsize[0]*(1.0+1e-12);
    for(int d=0;d<3;d++) {
      b.lo[d]=std::min(b.lo[d],c->pos_clouds[i][d]-radius);
      b.hi[d]=std::max(b.hi[d],c->pos_clouds[i][d]+radius);
    }
  }
  if(end-begin==1) b.cloud=ids[begin];
  else {
    int axis=0; for(int d=1;d<3;d++) if(b.hi[d]-b.lo[d]>b.hi[axis]-b.lo[axis]) axis=d;
    int mid=begin+(end-begin)/2;
    std::nth_element(ids.begin()+begin,ids.begin()+mid,ids.begin()+end,[&](int a,int z) {
      double x=c->pos_clouds[a][axis],y=c->pos_clouds[z][axis]; return x==y?a<z:x<y;
    });
    build(c,ids,begin,mid,nodes); build(c,ids,mid,end,nodes);
  }
  b.escape=static_cast<int>(nodes.size()); nodes[index]=b; return index;
}

inline int find_cloud(grid_cell *c,double pos[],const std::vector<GpuBvhNode> &nodes) {
  int best=INT_MAX;
  for(int node=0;node<static_cast<int>(nodes.size());) {
    const GpuBvhNode &b=nodes[node];
    bool inside=true;
    for(int d=0;d<3;d++) if(pos[d]<b.lo[d]||pos[d]>b.hi[d]) inside=false;
    if(!inside) { node=b.escape; continue; }
    node++;
    // Broad-phase bounds prune candidates. Strict distance-to-center testing
    // excludes the sphere boundary. When clouds overlap, choose the
    // smallest cloud index.
    if(b.cloud>=0 && b.cloud<best &&
       distance_3d(pos,c->pos_clouds[b.cloud])<c->cloud_grids[b.cloud]->boxsize[0])
      best=b.cloud;
  }
  return best==INT_MAX?-1:best;
}
}
#endif
