#ifndef TLAC_GPU_BVH_H
#define TLAC_GPU_BVH_H
// Preorder, stackless BVH. escape is the first node after this subtree.
// The device-only grid copy uses the otherwise unused v_flag_clouds pointer
// for this array. Host placement flags are never modified.
struct GpuBvhNode { double lo[3],hi[3]; int escape,cloud; };
#endif
