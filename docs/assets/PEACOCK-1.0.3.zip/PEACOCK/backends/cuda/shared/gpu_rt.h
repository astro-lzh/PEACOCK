#ifndef TLAC_GPU_RT_H
#define TLAC_GPU_RT_H
#include "../emission.h"
#ifdef __cplusplus
extern "C" {
#endif
void run_photons_cuda(grid *g, int nphot, struct emission_cfg_s emission,
                      unsigned long long seed, unsigned long long offset);
// Used only by the CUDA build's host emission; retains the C/GSL RNG sequence.
int cuda_emission_cloud_id(grid_cell *c, double pos[]);
#ifdef __cplusplus
}
#endif
#endif
