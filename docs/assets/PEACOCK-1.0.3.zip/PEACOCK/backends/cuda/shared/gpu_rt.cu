#ifndef TLAC_HOST_EXPORT
#include <cuda_runtime.h>
#include <curand_kernel.h>
#endif
#include <algorithm>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cfloat>
#include <cmath>
#include <map>
#include <fstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
#include <unistd.h>
extern "C" {
#include "gpu_rt.h"
#include "../physical_properties.h"
#include "../io/o_photon.h"
#include "../propagation.h"
#include "../clouds.h"
}
#define PI 3.14159265358979323846
#include "bvh.h"
#include "input_bvh.h"

#ifndef TLAC_HOST_EXPORT
using GpuRng = curandStatePhilox4_32_10_t;
#define TLAC_DEVICE __device__
#include "device_physics.cuh"

static void check(cudaError_t e, const char *what) {
  if(e != cudaSuccess) throw std::runtime_error(std::string(what)+": "+cudaGetErrorString(e));
}

#endif

// Serialize the complete grid graph into one device allocation. Relocate
// each pointer explicitly, preserving shared cloud templates independently
// of the host row layout.
class GridArena {
  std::vector<unsigned char> data;
  std::vector<std::pair<size_t,size_t>> relocations;
  std::vector<size_t> bvh_fields;
  std::vector<size_t> inactive_spherical_velocity_fields;
  std::unordered_map<const void*,size_t> offsets;
  std::unordered_map<size_t,void*> originals;
  std::unordered_map<const grid*,int> visited;
  std::unordered_map<const grid_cell*,std::vector<GpuBvhNode>> input_bvh;
  unsigned char *device = nullptr;

  size_t alloc(size_t n) {
    size_t p=(data.size()+15)&~size_t(15);
    data.resize(p+n, 0);
    return p;
  }
  template<class T> void put(size_t p, const T &v) {
    std::memcpy(data.data()+p,&v,sizeof(v));
  }
  void pointer(size_t field, size_t target) { relocations.emplace_back(field,target); }
  size_t blob(const void *src,size_t n) {
    size_t p=alloc(n); std::memcpy(data.data()+p,src,n); return p;
  }
  void record(const void *host,size_t p) { offsets[host]=p; originals[p]=const_cast<void*>(host); }

  size_t add_grid(grid *g,int depth) {
    auto found=offsets.find(g);
    if(found!=offsets.end()) {
      if(visited[g]==1) throw std::runtime_error("Cyclic cloud grid graph is unsupported");
      return found->second;
    }
    if(depth>1) throw std::runtime_error("Nested clouds beyond one level are unsupported (CPU photon has one parent slot)");
    if(g->nobservers!=0) throw std::runtime_error("CUDA backend does not support observers; use the CPU executable for observer runs");
    if(g->type!=GRID_CARTESIAN && g->type!=GRID_SPHERICAL) throw std::runtime_error("Invalid grid type");
    size_t nx=g->ncells[0],ny=g->ncells[1],nz=g->ncells[2];
    if(nx==0||ny==0||nz==0||nx>10000000/ny||nx*ny>10000000/nz)
      throw std::runtime_error("Invalid or excessively large grid dimensions");
    size_t gp=alloc(sizeof(grid)); record(g,gp); visited[g]=1;
    grid copy=*g; copy.cells=nullptr; copy.observers=nullptr; put(gp,copy);
    size_t rows=alloc(nx*sizeof(grid_cell**));
    size_t planes=alloc(nx*ny*sizeof(grid_cell*));
    size_t cells=alloc(nx*ny*nz*sizeof(grid_cell));
    pointer(gp+offsetof(grid,cells),rows);
    for(size_t i=0;i<nx;i++) {
      pointer(rows+i*sizeof(void*),planes+i*ny*sizeof(void*));
      for(size_t j=0;j<ny;j++) {
        pointer(planes+(i*ny+j)*sizeof(void*),cells+(i*ny+j)*nz*sizeof(grid_cell));
        for(size_t k=0;k<nz;k++) record(&g->cells[i][j][k],cells+((i*ny+j)*nz+k)*sizeof(grid_cell));
      }
    }
    for(size_t i=0;i<nx;i++) for(size_t j=0;j<ny;j++) for(size_t k=0;k<nz;k++) {
      grid_cell *c=&g->cells[i][j][k]; size_t cp=offsets.at(c);
      if(!std::isfinite(c->T)||c->T<=0||!std::isfinite(c->n_HI)||c->n_HI<0||
         !std::isfinite(c->n_D)||c->n_D<0) throw std::runtime_error("Invalid grid temperature/density");
      grid_cell cc=*c;
      // Spherical transport reads the radial velocity component vel[0].
      // Serialize the unused components as zero for deterministic
      // device inputs.
      if(g->type==GRID_SPHERICAL) {
        cc.vel[1]=cc.vel[2]=0;
        for(int d=1;d<3;d++) inactive_spherical_velocity_fields.push_back(cp+offsetof(grid_cell,vel)+d*sizeof(double));
      }
      cc.size=nullptr; std::fill(cc.nbs,cc.nbs+6,nullptr);
      cc.pos_clouds=nullptr; cc.vel_clouds=nullptr; cc.cloud_grids=nullptr;
      // The host placement flags are not part of the serialized input.
      cc.v_flag_clouds=nullptr;
      put(cp,cc);
      pointer(cp+offsetof(grid_cell,size),blob(c->size,3*sizeof(double)));
      for(int q=0;q<6;q++) if(c->nbs[q]) pointer(cp+offsetof(grid_cell,nbs)+q*sizeof(void*),offsets.at(c->nbs[q]));
      if(!c->nclouds) continue;
      if(depth==1) throw std::runtime_error("Nested clouds beyond one level are unsupported");
      size_t n=c->nclouds;
      size_t pp=alloc(n*sizeof(double*)),vp=alloc(n*sizeof(double*)),gg=alloc(n*sizeof(grid*));
      size_t positions=alloc(3*n*sizeof(double)),velocities=alloc(3*n*sizeof(double));
      pointer(cp+offsetof(grid_cell,pos_clouds),pp);
      pointer(cp+offsetof(grid_cell,vel_clouds),vp);
      pointer(cp+offsetof(grid_cell,cloud_grids),gg);
      for(size_t q=0;q<n;q++) {
        if(c->cloud_grids[q]->type!=GRID_SPHERICAL) throw std::runtime_error("Clouds must be spherical");
        for(int d=0;d<3;d++) {
          put(positions+(3*q+d)*sizeof(double),c->pos_clouds[q][d]);
          put(velocities+(3*q+d)*sizeof(double),c->vel_clouds[q][d]);
        }
        pointer(pp+q*sizeof(void*),positions+3*q*sizeof(double));
        pointer(vp+q*sizeof(void*),velocities+3*q*sizeof(double));
        pointer(gg+q*sizeof(void*),add_grid(c->cloud_grids[q],depth+1));
      }
      if(n>=8) {
        std::vector<int> ids(n); for(size_t q=0;q<n;q++) ids[q]=static_cast<int>(q);
        std::vector<GpuBvhNode> nodes; nodes.reserve(2*n-1);
        tlac_input::build(c,ids,0,static_cast<int>(n),nodes);
        size_t bp=blob(nodes.data(),nodes.size()*sizeof(GpuBvhNode));
        size_t field=cp+offsetof(grid_cell,v_flag_clouds);
        pointer(field,bp); bvh_fields.push_back(field);
        input_bvh.emplace(c,std::move(nodes));
      }
    }
    visited[g]=2; return gp;
  }
public:
  int emission_cloud_id(grid_cell *c,double pos[]) const {
    const auto found=input_bvh.find(c);
    if(found==input_bvh.end()) return get_cloud_id(c,pos);
    return tlac_input::find_cloud(c,pos,found->second);
  }
  explicit GridArena(grid *g, bool upload=true) {
    add_grid(g,0);
    if(!upload) return;
#ifndef TLAC_HOST_EXPORT
    check(cudaMalloc(reinterpret_cast<void**>(&device),data.size()),"Allocate grid");
    for(auto r:relocations) { void *p=device+r.second; put(r.first,p); }
    check(cudaMemcpy(device,data.data(),data.size(),cudaMemcpyHostToDevice),"Upload grid");
    std::printf("CUDA grid: %.2f MiB, %zu shared grid templates\n",data.size()/1048576.0,visited.size());
#endif
  }
  ~GridArena() {
#ifndef TLAC_HOST_EXPORT
    if(device) cudaFree(device);
#endif
  }
  void export_grid(const std::string &prefix, FILE *meta) const {
    std::ofstream out(prefix+".grid.bin",std::ios::binary);
    out.write(reinterpret_cast<const char*>(data.data()),data.size());
    if(!out) throw std::runtime_error("Cannot write portable grid");
    std::fprintf(meta,"\"grid_relocations\":[");
    for(size_t i=0;i<relocations.size();i++) {
      if(i) std::fprintf(meta,",");
      std::fprintf(meta,"[%zu,%zu]",relocations[i].first,relocations[i].second);
    }
    std::fprintf(meta,"],\n");
    std::fprintf(meta,"\"bvh_pointer_fields\":[");
    for(size_t i=0;i<bvh_fields.size();i++) std::fprintf(meta,"%s%zu",i?",":"",bvh_fields[i]);
    std::fprintf(meta,"],\n");
    std::fprintf(meta,"\"inactive_spherical_velocity_offsets\":[");
    for(size_t i=0;i<inactive_spherical_velocity_fields.size();i++)
      std::fprintf(meta,"%s%zu",i?",":"",inactive_spherical_velocity_fields[i]);
    std::fprintf(meta,"],\n");
  }
  void encode_photon(photon &p) const {
    // Offset+1 reserves zero for null, including the root grid at offset 0.
    #define ENCODE(field) p.field=p.field?reinterpret_cast<decltype(p.field)>(offsets.at(p.field)+1):nullptr
    ENCODE(grid); ENCODE(grid_shifted); ENCODE(curr_cell); ENCODE(prev_cell); ENCODE(cell_shifted);
    #undef ENCODE
    p.emission_cfg=nullptr;
  }
  template<class T> T *to_device(T *p) const {
    return p?reinterpret_cast<T*>(device+offsets.at(p)):nullptr;
  }
  template<class T> T *to_host(T *p) const {
    if(!p) return nullptr;
    auto offset=reinterpret_cast<uintptr_t>(p)-reinterpret_cast<uintptr_t>(device);
    return static_cast<T*>(originals.at(offset));
  }
  void map_photon(photon &p, bool upload) const {
    if(upload) {
      p.grid=to_device(p.grid); p.grid_shifted=to_device(p.grid_shifted);
      p.curr_cell=to_device(p.curr_cell); p.prev_cell=to_device(p.prev_cell); p.cell_shifted=to_device(p.cell_shifted);
    } else {
      p.grid=to_host(p.grid); p.grid_shifted=to_host(p.grid_shifted);
      p.curr_cell=to_host(p.curr_cell); p.prev_cell=to_host(p.prev_cell); p.cell_shifted=to_host(p.cell_shifted);
    }
    p.emission_cfg=nullptr;
  }
};

// Host emission uses a serial GSL stream. The lookup scope begins after
// grid construction and ends before the BVH is destroyed.
static const GridArena *emission_arena=nullptr;
static int emission_lookup_mode=0; // 0 indexed, 1 linear, 2 indexed + exact check
class EmissionLookupScope {
  const GridArena *previous;
  int previous_mode;
public:
  explicit EmissionLookupScope(const GridArena &arena):previous(emission_arena),previous_mode(emission_lookup_mode) {
    const char *s=std::getenv("TLAC_GPU_INPUT_LOOKUP");
    int mode=0;
    if(s && std::strcmp(s,"bvh")!=0) {
      if(std::strcmp(s,"linear")==0) mode=1;
      else if(std::strcmp(s,"check")==0) mode=2;
      else throw std::runtime_error("TLAC_GPU_INPUT_LOOKUP must be bvh, linear or check");
    }
    emission_arena=&arena; emission_lookup_mode=mode;
  }
  ~EmissionLookupScope() { emission_arena=previous; emission_lookup_mode=previous_mode; }
};
extern "C" int cuda_emission_cloud_id(grid_cell *c,double pos[]) {
  if(!emission_arena || emission_lookup_mode==1) return get_cloud_id(c,pos);
  int answer=emission_arena->emission_cloud_id(c,pos);
  if(emission_lookup_mode==2 && answer!=get_cloud_id(c,pos)) {
    std::fprintf(stderr,"CUDA input spatial lookup disagrees with original cloud membership\n");
    std::abort();
  }
  return answer;
}

#ifndef TLAC_HOST_EXPORT
extern "C" __global__ void tlac_transport(photon *photons,int *status,int n,
                          emission_cfg_s emission,unsigned long long seed,
                          unsigned long long offset) {
  int id=blockIdx.x*blockDim.x+threadIdx.x;
  if(id>=n) return;
  GpuRng rng;
  curand_init(seed,offset+id,0,&rng);
  photon p=photons[id]; p.emission_cfg=&emission;
  status[id]=gpu_propagate_photon(&rng,&p);
  p.emission_cfg=nullptr;
  photons[id]=p;
}

extern "C" __global__ void cii_abi(unsigned long long *out) {
  if(threadIdx.x || blockIdx.x) return;
  out[0]=sizeof(photon);out[1]=sizeof(emission_cfg_s);out[2]=sizeof(grid);out[3]=sizeof(grid_cell);
  out[4]=offsetof(photon,x);out[5]=offsetof(photon,grid);out[6]=offsetof(emission_cfg_s,CII_ratio_21);
}
extern "C" __global__ void cii_opacity(const double *input,double *out,int n) {
  int i=blockIdx.x*blockDim.x+threadIdx.x;if(i>=n)return;
  GpuRng rng;curand_init(91,i,0,&rng);
  double w[3];gpu_cii_population_cross_sections(&rng,input[3*i],input[3*i+1],input[3*i+2],w);
  for(int j=0;j<3;j++)out[3*i+j]=w[j];
}
extern "C" __global__ void cii_events(double *out,int n) {
  int i=blockIdx.x*blockDim.x+threadIdx.x;if(i>=n)return;
  GpuRng rng;curand_init(81403,i,0,&rng);
  grid g={};g.type=1;grid_cell cell={};cell.T=1e5;cell.n_HI=1;
  emission_cfg_s ec={};ec.CII_ratio_21=.6;
  photon p={};p.grid=&g;p.curr_cell=&cell;p.emission_cfg=&ec;
  p.Delta_nu_D=gpu_doppler_freq_shift_hydrogen(&rng,cell.T);p.dir[2]=1;
  double off[3]={0,29979245800.0*63.42/p.Delta_nu_D,29979245800.0*(74932.62-74930.10+63.42)/p.Delta_nu_D};
  p.x=-off[i%3];double old_dir[3]={0,0,1};
  cii_event e=gpu_sct_cii_sample_event(&rng,&p);
  gpu_sct_cii_set_direction(&rng,&p,e);
  out[7*i]=e.line;out[7*i+1]=e.lower_out;out[7*i+2]=p.dir[2];
  double xout=gpu_sct_cii_frequency_from_sample(&rng,&p,e,old_dir,p.dir);
  out[7*i+3]=xout-p.x-p.u_scatter_last[0]*(p.dir[2]-1)-p.u_scatter_last[1]*sqrt(fmax(0.,1-p.dir[2]*p.dir[2]));
  p.x=2.37;p.curr_tau=1;p.dir[0]=p.dir[1]=0;p.dir[2]=1;
  cell.vel[0]=3.1;cell.vel[1]=-.7;cell.vel[2]=2.2;p.sc_dir_bulk=2.2;
  gpu_interact_dust(&rng,&p);
  out[7*i+4]=p.curr_cell ? 1 : 0;out[7*i+5]=p.dir[2];
  out[7*i+6]=p.curr_cell ? fabs(p.x-2.37)+fabs(p.sc_dir_bulk-(cell.vel[0]*p.dir[0]+cell.vel[1]*p.dir[1]+cell.vel[2]*p.dir[2])) : 0;
}

#endif

static void write_bytes(const std::string &path,const void *p,size_t n) {
  std::ofstream f(path,std::ios::binary); f.write(static_cast<const char*>(p),n);
  if(!f) throw std::runtime_error("Cannot write "+path);
}

static void export_portable(const std::string &prefix,grid *g,int nphot,
                            emission_cfg_s emission,unsigned long long seed,
                            unsigned long long offset) {
  const auto input_start=std::chrono::steady_clock::now();
  GridArena arena(g,false);
  EmissionLookupScope lookup(arena);
  const auto grid_ready=std::chrono::steady_clock::now();
  std::vector<photon> initial(nphot),encoded(nphot),reference(nphot);
  std::vector<int> status(nphot);
  for(int i=0;i<nphot;i++) {
    initial[i]=photon{}; initial[i].emission_cfg=&emission;
    start_photon(&initial[i],g);
    encoded[i]=initial[i]; arena.encode_photon(encoded[i]);
  }
  const auto photons_ready=std::chrono::steady_clock::now();
  write_bytes(prefix+".photons.bin",encoded.data(),encoded.size()*sizeof(photon));
  // Serialize the ABI fields explicitly so stack padding does not enter the case.
  unsigned char emission_bytes[sizeof(emission_cfg_s)]{};
#define COPY_EMISSION_FIELD(field) \
  std::memcpy(emission_bytes + offsetof(emission_cfg_s, field), &emission.field, sizeof(emission.field))
  COPY_EMISSION_FIELD(CII_ratio_21);
  COPY_EMISSION_FIELD(initial_pos_mode);
  COPY_EMISSION_FIELD(initial_pos_param);
  COPY_EMISSION_FIELD(p_cloud);
  COPY_EMISSION_FIELD(initial_freq_mode);
  COPY_EMISSION_FIELD(initial_freq_param);
#undef COPY_EMISSION_FIELD
  write_bytes(prefix+".emission.bin",emission_bytes,sizeof(emission_bytes));
  auto start=std::chrono::steady_clock::now();
  bool skip_reference=std::getenv("TLAC_GPU_SKIP_REFERENCE")!=nullptr;
  double cpu_seconds=0;
  if(!skip_reference) {
    for(int i=0;i<nphot;i++) {
      reference[i]=initial[i];
      status[i]=propagate_photon(&reference[i],nullptr);
      reference[i].grid=nullptr; reference[i].grid_shifted=nullptr;
      reference[i].curr_cell=nullptr; reference[i].prev_cell=nullptr;
      reference[i].cell_shifted=nullptr; reference[i].emission_cfg=nullptr;
    }
    cpu_seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    write_bytes(prefix+".cpu.bin",reference.data(),reference.size()*sizeof(photon));
    write_bytes(prefix+".cpu_status.bin",status.data(),status.size()*sizeof(int));
  }
  FILE *meta=std::fopen((prefix+".json").c_str(),"w");
  if(!meta) throw std::runtime_error("Cannot write portable metadata");
  std::fprintf(meta,"{\"format\":2,\"nphot\":%d,\"photon_size\":%zu,\"emission_size\":%zu,\"seed\":%llu,\"sequence_offset\":%llu,\"cpu_transport_seconds\":%.9f,\n",
               nphot,sizeof(photon),sizeof(emission),seed,offset,cpu_seconds);
  // Record the native sizes and offsets checked by the device ABI kernel.
  std::fprintf(meta,"\"abi\":[%zu,%zu,%zu,%zu,%zu,%zu,%zu],\n",
               sizeof(photon),sizeof(emission_cfg_s),sizeof(grid),sizeof(grid_cell),
               offsetof(photon,x),offsetof(photon,grid),offsetof(emission_cfg_s,CII_ratio_21));
#ifdef PEACOCK_MULTILEVEL
  std::fprintf(meta, "\"nu0_Hz\":%.17g,\n\"atomic_populations\":[", RT_NU0);
  for (int i = 0; i < RT_NLOWER; ++i)
    std::fprintf(meta, "%s%.17g", i ? "," : "", rt_pop[i]);
  std::fputs("],\n", meta);
#endif
  arena.export_grid(prefix,meta);
  std::fprintf(meta,"\"pointer_offsets\":[%zu,%zu,%zu,%zu,%zu],\n",offsetof(photon,grid),offsetof(photon,grid_shifted),offsetof(photon,curr_cell),offsetof(photon,prev_cell),offsetof(photon,cell_shifted));
  std::fprintf(meta,"\"fields\":{");
  for(int i=0;i<3;i++) std::fprintf(meta,"\"pos%d\":[%zu,\"<f8\"],\"dir%d\":[%zu,\"<f8\"],",i,offsetof(photon,pos)+i*sizeof(double),i,offsetof(photon,dir)+i*sizeof(double));
  #define FIELD(name,type) std::fprintf(meta,"\"" #name "\":[%zu,\"" type "\"],",offsetof(photon,name))
  for(int i=0;i<3;i++) std::fprintf(meta,"\"pos_shifted%d\":[%zu,\"<f8\"],",i,offsetof(photon,pos_shifted)+i*sizeof(double));
  FIELD(dist,"<f8"); FIELD(tau,"<f8");
  FIELD(x,"<f8"); FIELD(x_i,"<f8"); FIELD(Delta_nu_D,"<f8"); FIELD(sc_dir_bulk,"<f8");
  FIELD(c_HI_total,"<f8"); FIELD(c_D_total,"<f8"); FIELD(nscatter,"<i4");
  #undef FIELD
  std::fprintf(meta,"\"nclouds_passed\":[%zu,\"<i4\"]}}\n",offsetof(photon,nclouds_passed));
  std::fclose(meta);
  const auto input_end=std::chrono::steady_clock::now();
  const double grid_seconds=std::chrono::duration<double>(grid_ready-input_start).count();
  const double emission_seconds=std::chrono::duration<double>(photons_ready-grid_ready).count();
  const double total_seconds=std::chrono::duration<double>(input_end-input_start).count();
  FILE *timing=std::fopen((prefix+".input_timing.json").c_str(),"w");
  if(!timing) throw std::runtime_error("Cannot write input timings");
  std::fprintf(timing,"{\"nphot\":%d,\"lookup\":\"%s\",\"grid_pack_and_bvh_seconds\":%.9f,\"emission_and_encoding_seconds\":%.9f,\"serialization_and_io_seconds\":%.9f,\"cpu_reference_seconds\":%.9f,\"input_export_seconds\":%.9f}\n",
               nphot,emission_lookup_mode==1?"linear":emission_lookup_mode==2?"check":"bvh",grid_seconds,emission_seconds,
               total_seconds-grid_seconds-emission_seconds-cpu_seconds,cpu_seconds,total_seconds);
  std::fclose(timing);
  std::printf("CUDA input: pack/BVH %.6fs, emission %.6fs, export total %.6fs (%s lookup)\n",
              grid_seconds,emission_seconds,total_seconds,emission_lookup_mode==1?"linear":emission_lookup_mode==2?"check":"bvh");
  std::printf("Portable CUDA test exported: %s.json (%d photons, CPU transport %.6fs)\n",prefix.c_str(),nphot,cpu_seconds);
}

static int batch_size() {
  const char *value=std::getenv("TLAC_GPU_BATCH");
  if(!value) return 65536;
  char *end=nullptr; long n=std::strtol(value,&end,10);
  if(*end||n<1||n>1048576) throw std::runtime_error("TLAC_GPU_BATCH must be an integer from 1 to 1048576");
  return static_cast<int>(n);
}

extern "C" void run_photons_cuda(grid *g,int nphot,emission_cfg_s emission,
                                  unsigned long long seed,unsigned long long offset) {
  try {
    if(nphot<0) throw std::runtime_error("Negative photon count");
    if(access("track_photons.dat",F_OK)==0) throw std::runtime_error("CUDA backend does not support track_photons.dat; use the CPU executable for trajectory tracking");
    if(const char *prefix=std::getenv("TLAC_GPU_EXPORT")) {
      export_portable(prefix,g,nphot,emission,seed,offset);
      // Export is deliberately not reported as a completed RT/HDF5 run.
      std::puts("Export-only process completed; the normal HDF5 run is not finalized.");
      std::exit(EXIT_SUCCESS);
    }
#ifdef TLAC_HOST_EXPORT
    throw std::runtime_error("Input exporter requires TLAC_GPU_EXPORT; no CPU RT fallback is enabled");
#else
    int count=0; check(cudaGetDeviceCount(&count),"Detect CUDA devices");
    if(count==0) throw std::runtime_error("No GPU is visible; run inside a Slurm GPU allocation");
    cudaDeviceProp info; check(cudaGetDeviceProperties(&info,0),"Read CUDA device");
    std::printf("CUDA RT: %s; %d photons; seed=%llu; sequence offset=%llu\n",info.name,nphot,seed,offset);
    if(!nphot) return;
    auto start=std::chrono::steady_clock::now();
    GridArena arena(g);
    EmissionLookupScope lookup(arena);
    int batch=std::min(nphot,batch_size());
    std::vector<photon> photons(batch);
    std::vector<int> status(batch);
    photon *device_photons=nullptr; int *device_status=nullptr;
    check(cudaMalloc(reinterpret_cast<void**>(&device_photons),batch*sizeof(photon)),"Allocate photons");
    check(cudaMalloc(reinterpret_cast<void**>(&device_status),batch*sizeof(int)),"Allocate statuses");
    unsigned long long escaped=0,absorbed=0;
    double emission_seconds=0,transport_seconds=0,output_seconds=0;
    for(int first=0;first<nphot;first+=std::min(batch,nphot-first)) {
      int n=std::min(batch,nphot-first);
      auto t=std::chrono::steady_clock::now();
      // Use the host emission model and configured GSL seed.
      // Value-initialize the packet before generating its emission state.
      for(int i=0;i<n;i++) {
        photons[i]=photon{}; photons[i].emission_cfg=&emission;
        start_photon(&photons[i],g); arena.map_photon(photons[i],true);
      }
      emission_seconds+=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();
      t=std::chrono::steady_clock::now();
      check(cudaMemcpy(device_photons,photons.data(),n*sizeof(photon),cudaMemcpyHostToDevice),"Upload photons");
      tlac_transport<<<(n+127)/128,128>>>(device_photons,device_status,n,emission,seed,offset+first);
      check(cudaGetLastError(),"Launch photon transport");
      check(cudaDeviceSynchronize(),"Complete photon transport");
      check(cudaMemcpy(photons.data(),device_photons,n*sizeof(photon),cudaMemcpyDeviceToHost),"Download photons");
      check(cudaMemcpy(status.data(),device_status,n*sizeof(int),cudaMemcpyDeviceToHost),"Download statuses");
      transport_seconds+=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();
      t=std::chrono::steady_clock::now();
      for(int i=0;i<n;i++) {
        if(status[i]<0) throw std::runtime_error("Numerically invalid photon "+std::to_string(first+i)+"; this run is invalid");
        if(status[i]==0) { absorbed++; continue; }
        arena.map_photon(photons[i],false); photons[i].emission_cfg=&emission;
        o_photon(0,&photons[i]); escaped++;
      }
      output_seconds+=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();
      std::printf("CUDA progress: %d/%d; escaped=%llu absorbed=%llu\n",first+n,nphot,escaped,absorbed);
    }
    check(cudaFree(device_photons),"Free photons"); check(cudaFree(device_status),"Free statuses");
    double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    std::printf("CUDA timing: total=%.6fs emission=%.6fs transport=%.6fs output=%.6fs\n",elapsed,emission_seconds,transport_seconds,output_seconds);
    if(escaped+absorbed!=static_cast<unsigned long long>(nphot)) throw std::runtime_error("Photon accounting failed");
#endif
  } catch(const std::exception &e) {
    std::fprintf(stderr,"CUDA RT failed: %s\n",e.what());
    std::exit(EXIT_FAILURE);
  }
}
