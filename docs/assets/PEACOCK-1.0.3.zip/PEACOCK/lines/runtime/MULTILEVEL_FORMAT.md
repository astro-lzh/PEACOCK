# Multilevel runtime atom tables

A multilevel profile loads its atom file before reading the run configuration.
The fields are separated by whitespace and appear in this order:

1. `PEACOCK_ATOM_V1 multilevel LINE_ID`
2. `nlower nupper nlines reference Z ion_stage`
3. Atomic mass in grams, reference frequency in Hz and reference damping
   rate in s⁻¹.
4. `nlower` lower-level energies in cm⁻¹.
5. `nupper` upper-level damping rates in s⁻¹.
6. `nlines` records of `lower upper A nu f w2`. Here `A` is the decay
   rate in s⁻¹, `nu` is the frequency in Hz, `f` is the oscillator
   strength and `w2` is the scalar angular coefficient.

All indices are zero-based. The supplied network limits are 53 lower
levels, 3 upper levels and 53 transitions. The reference frequency and
damping rate must match the reference transition, and the sum of the
decay rates for each upper level must match its damping rate. Preserve
transition order to reproduce seeded absorption and decay sampling.

The loader starts with population 1 in the first lower level and zero in
the other lower levels. The run configuration then
sets the requested `population_ratio_2` and subsequent ratios. Loading a
new atom resets those populations.

`python3 tools/export_multilevel_atoms.py --check` verifies that the supplied
files contain the reference header values and transition order.
