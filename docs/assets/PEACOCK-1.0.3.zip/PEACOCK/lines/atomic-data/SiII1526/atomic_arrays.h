/* Generated from atomic_model.json. Energies in cm^-1, rates s^-1. */
const double rt_lower_E[RT_NLOWER]={0,287.24000000000001};
const double rt_gamma[RT_NUPPER]={1135900000};
double rt_pop[RT_NLOWER]={1.};
const rt_transition rt_lines[RT_NLINES]={
{0,0,381500000,1963654690145526,0.13331016136182694,0},
{1,0,754400000,1955043451581934,0.13297126670152468,-0}
};
