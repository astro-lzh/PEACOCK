/* C IV atomic parameters.
 * Common ground S1/2; blue upper P3/2 W2=.5, red upper P1/2 W2=0.
 * Strict per-transition Doppler width. Independent levels, no J interference,
 * recoil OFF; first-order bulk v/c inherited from native TLAC transport.
 */
#ifndef PEACOCK_PRIVATE_ATOMIC_PARAMETERS_H
#define PEACOCK_PRIVATE_ATOMIC_PARAMETERS_H
#define LINE_ION_NAME "CIV"
#define LINE_LIGHT_SPEED 29979245800.0
#define LINE_BOLTZMANN 1.38065e-16
#define LINE_ATOM_MASS 1.9926000000000001e-23
#define LINE_E_BLUE 64591.699999999997
#define LINE_E_RED 64484
#define LINE_NU_BLUE (LINE_LIGHT_SPEED*LINE_E_BLUE)
#define LINE_NU_RED (LINE_LIGHT_SPEED*LINE_E_RED)
#define LINE_DELTA_NU (LINE_NU_BLUE-LINE_NU_RED)
#define LINE_F_BLUE 0.1905
#define LINE_F_RED 0.095000000000000001
#define LINE_GAMMA_BLUE 265000000
#define LINE_GAMMA_RED 264000000
/* TLAC-compatible identifiers alias the doublet parameters. */
#define HYDROGEN_MASS LINE_ATOM_MASS
#define LYA_NU0 LINE_NU_BLUE
#define LYA_NU0_F_H LINE_NU_RED
#define DELTA_NU_H_K LINE_DELTA_NU
#define LYA_F12 LINE_F_BLUE
#define LYA_F_H LINE_F_RED
#define LYA_DELTA_NU_L (LINE_GAMMA_BLUE/(2.0*3.14159265358979323846))
#endif
