const double rt_lower_E[RT_NLOWER]={0};
const double rt_gamma[RT_NUPPER]={1460000000};
double rt_pop[RT_NLOWER]={1};
const rt_transition rt_lines[RT_NLINES]={{0,0,1460000000,1794317114684646.5,1.8330514783907874,1}};
