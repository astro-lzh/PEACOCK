/***********************************
 * Physical constants defined here *
 *                                 *
 * (in cgs)                        *
 ***********************************/
#define LIGHT_SPEED   29979245800.0
#define ELECTRON_MASS 9.10938e-28
#define GRAVITATIONAL_CONSTANT 6.67e-8
#define ELECTRON_CHARGE 4.803205e-10
#define PLANCK_CONSTANT 6.62607e-27
#define BOLTZMANN_CONSTANT 1.38065e-16
#define HYDROGEN_MASS 1.67372e-24
#define PROTON_MASS 1.672622e-24

#define PARSEC 3.085677581467192e18 // in cm

/* Lyman alpha constants */
#define LYA_F12        0.4162
#define LYA_NU0        2.466e15     // Line center frequency
#define LYA_DELTA_NU_L 9.936e7      // Natural line width

