/***********************************
 * Physical constants defined here *
 *                                 *
 * (in cgs)                        *
 ***********************************/
#define LIGHT_SPEED   29979245800.0
#define ELECTRON_MASS 9.10938e-28
#define GRAVITATIONAL_CONSTANT 6.67e-8

#define ELECTRON_CHARGE 4.803205e-10
#define PLANCK_CONSTANT 6.62607e-27
#define BOLTZMANN_CONSTANT 1.38065e-16
#define HYDROGEN_MASS 1.9926e-23 
#define PROTON_MASS 1.672622e-24

#define PARSEC 3.085677581467192e18 // in cm

/* C II: NIST Wiese & Fuhr 2007, JPCRD 36, 1287, Table 8, multiplet 2.
 * https://www.nist.gov/document/jpcrd3620071287ppdf
 * Level IDs are quantum-state labels, NOT increasing energy:
 * 1=2P_1/2, 2=2P_3/2, 3=2D_3/2, 4=2D_5/2; E3 > E4.
 * Array/profile order: 13 (1334.53), 23 (1335.66), 24 (1335.71).
 * Wavenumber levels (cm^-1) define a self-consistent frequency scale.
 * See also the NIST Handbook level energies (MG93):
 * https://physics.nist.gov/PhysRefData/Handbook/Tables/carbontable6.htm
 * Vacuum frequencies use the exact speed of light in CGS units.
 */
#define CII_E1 0.0
#define CII_E2 63.42
#define CII_E3 74932.62
#define CII_E4 74930.10
#define CII_NU13 (LIGHT_SPEED*(CII_E3-CII_E1))
#define CII_NU23 (LIGHT_SPEED*(CII_E3-CII_E2))
#define CII_NU24 (LIGHT_SPEED*(CII_E4-CII_E2))
#define CII_FINE_STRUCTURE_NU (LIGHT_SPEED*(CII_E2-CII_E1))
/* Derived vacuum wavelengths, in Angstrom. */
#define CII_LAMBDA13_A (1e8*LIGHT_SPEED/CII_NU13)
#define CII_LAMBDA23_A (1e8*LIGHT_SPEED/CII_NU23)
#define CII_LAMBDA24_A (1e8*LIGHT_SPEED/CII_NU24)
#define LYA_NU0 CII_NU13
#define LYA_F1 0.129
#define LYA_F2 0.0127
#define LYA_F3 0.115
#define CII_A31 2.41e8
#define CII_A32 4.76e7
#define CII_A42 2.88e8
/* Upper-state total radiative widths within this four-level E1 model.
 * Stored widths are Gamma/(2*pi); a = Gamma/(4*pi*Delta_nu_D).
 */
#define LYA_DELTA_NU_L_1 ((CII_A31+CII_A32)/(2.0*3.14159265358979323846))
#define LYA_DELTA_NU_L_2 LYA_DELTA_NU_L_1
#define LYA_DELTA_NU_L_3 (CII_A42/(2.0*3.14159265358979323846))
/* The frequency separations refer to the ordered profiles. */
#define DELTA_NU_12 CII_FINE_STRUCTURE_NU
#define DELTA_NU_13 (CII_NU13-CII_NU24)

