/* Mg II atomic parameters.
 * Common ground S1/2; blue upper P3/2 W2=.5, red upper P1/2 W2=0.
 * Strict per-transition Doppler width. Independent levels, no J interference,
 * recoil OFF; first-order bulk v/c inherited from native TLAC transport.
 */
#ifndef PEACOCK_PRIVATE_ATOMIC_PARAMETERS_H
#define PEACOCK_PRIVATE_ATOMIC_PARAMETERS_H
#define LINE_ION_NAME "MgII"
#define LINE_LIGHT_SPEED 29979245800.0
#define LINE_BOLTZMANN 1.38065e-16
#define LINE_ATOM_MASS 4.0359402070100601e-23
#define LINE_E_BLUE 35760.898000000001
#define LINE_E_RED 35669.300999999999
#define LINE_NU_BLUE (LINE_LIGHT_SPEED*LINE_E_BLUE)
#define LINE_NU_RED (LINE_LIGHT_SPEED*LINE_E_RED)
#define LINE_DELTA_NU (LINE_NU_BLUE-LINE_NU_RED)
#define LINE_F_BLUE 0.63649999999999995
#define LINE_F_RED 0.31724999999999998
#define LINE_GAMMA_BLUE 252000000
#define LINE_GAMMA_RED 251000000
/* TLAC-compatible identifiers alias the doublet parameters. */
#define HYDROGEN_MASS LINE_ATOM_MASS
#define LYA_NU0 LINE_NU_BLUE
#define LYA_NU0_F_H LINE_NU_RED
#define DELTA_NU_H_K LINE_DELTA_NU
#define LYA_F12 LINE_F_BLUE
#define LYA_F_H LINE_F_RED
#define LYA_DELTA_NU_L (LINE_GAMMA_BLUE/(2.0*3.14159265358979323846))
#endif
