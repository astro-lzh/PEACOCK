/* Generated from atomic_model.json. Energies in cm^-1, rates s^-1. */
const double rt_lower_E[RT_NLOWER]={0};
const double rt_gamma[RT_NUPPER]={337000000,340000000};
double rt_pop[RT_NLOWER]={1.};
const rt_transition rt_lines[RT_NLINES]={
{0,0,337000000,2412226050654560,0.078035612691728415,0},
{0,1,340000000,2419981681543020,0.15645293180773256,0.70710678118654735}
};
