"""Materialize a private compiler view of PEACOCK's shared source tree."""

import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def line_profiles():
    return json.loads((ROOT / 'lines/catalog.json').read_text(encoding='utf8'))['lines']


def package_path(relative):
    path = PurePosixPath(relative)
    if not path.parts or path.is_absolute() or '..' in path.parts or '\\' in relative or ':' in relative:
        raise ValueError(f'Invalid path in source layout: {relative}')
    return Path(*path.parts)


def source_view():
    layout = (ROOT / 'lines/source-layout.json').read_bytes()
    sources = {}
    payload = {}
    identity = hashlib.sha256(layout)

    def read(relative):
        if relative not in sources:
            sources[relative] = (ROOT / package_path(relative)).read_bytes()
        return sources[relative]

    for destination, source in sorted(json.loads(layout)['files'].items()):
        data = read(source)
        payload[package_path(destination)] = data
        identity.update(hashlib.sha256(data).digest())

    digest = identity.hexdigest()
    cache = ROOT / 'build' / 'sources'
    cache.mkdir(parents=True, exist_ok=True)
    target = cache / digest[:16]

    def verify():
        if (target / '.source-id').read_text(encoding='ascii').strip() != digest:
            raise ValueError(f'Compiler view identity differs: {target}')
        for relative, data in payload.items():
            path = target / relative
            if path.is_symlink() or not path.is_file() or path.read_bytes() != data:
                raise ValueError(f'Generated source view has been modified: {path}. Move that build directory aside and retry.')

    if target.exists():
        verify()
        return target

    staging = Path(tempfile.mkdtemp(prefix='.source-', dir=cache))
    try:
        for relative, data in payload.items():
            destination = staging / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        (staging / '.source-id').write_text(digest + '\n', encoding='ascii')
        try:
            staging.rename(target)
        except OSError:
            if not target.is_dir():
                raise
            verify()
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return target


if __name__ == '__main__':
    print(source_view())
