"""Turn PEACOCK escape packets into a spectrum, a CSV table and a PNG figure."""

from __future__ import annotations

import argparse
import configparser
import json
from pathlib import Path
import sys
import warnings

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backends.cuda.runtime.runner import LIGHT_SPEED, load_atom
from tools.engine_layout import line_profiles

PC_CM = 3.08567758e18
C_KMS = LIGHT_SPEED / 1e5


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_configuration(case):
    config = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=(";", "#"))
    path = case / "resolved.cfg"
    if not path.is_file():
        raise ValueError("The run directory needs its resolved.cfg and atomic.atom files.")
    config.read(path, encoding="utf-8")
    return config


def selected_profile(case, metadata):
    name = metadata.get("line") or metadata.get("peacock_model") or metadata.get("model")
    if not name:
        name = (case / "atomic.atom").read_text(encoding="utf-8").split()[2]
    for profile in line_profiles():
        if str(name).casefold() in (profile["id"].casefold(), profile["name"].casefold()):
            return profile
    raise ValueError(f"Unknown line in the run metadata: {name!r}.")


def cpu_packets(case, reference):
    paths = sorted(case.glob("packets_*.dat"))
    if len(paths) != 1:
        raise ValueError("Expected one primary packets_*.dat ASCII file. Use the tutorial's ASCII output settings.")
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="loadtxt: input contained no data")
        packets = np.loadtxt(paths[0], ndmin=2)
    if not packets.size:
        return np.empty(0), np.empty((0, 3)), np.empty((0, 3)), paths[0]
    if packets.shape[1] != 19:
        raise ValueError("Expected the 19-column primary ASCII escape-packet format.")
    # Column 7 is already in the observer frame; column 9 is its width in Hz.
    frequency = reference + packets[:, 6] * packets[:, 8]
    return frequency, packets[:, :3], packets[:, 3:6], paths[0]


def cuda_packets(case, atom):
    report = read_json(case / "gpu_run_report.json")
    if report.get("status") != "COMPLETE" or report.get("unfinished_or_bad", 0):
        raise ValueError("The GPU run is incomplete. Resolve gpu_run_report.json before making a spectrum.")
    name = str(report.get("output_path", "")).replace("\\", "/").rsplit("/", 1)[-1]
    path = case / name
    if not name or not path.is_file():
        paths = sorted(case.glob("gpu_output_*.npz"))
        if len(paths) != 1:
            raise ValueError("Expected one GPU packet archive, or the archive named by gpu_run_report.json.")
        path = paths[0]
    with np.load(path, allow_pickle=False) as archive:
        status = archive["status"]
        if status.ndim != 1 or np.any(~np.isin(status, (0, 1))):
            raise ValueError("The GPU archive contains incomplete or invalid photon histories.")
        escaped = status == 1
        if "nu_final_Hz" in archive:
            frequency = archive["nu_final_Hz"][escaped]
        elif atom.multilevel is not None:
            width = archive["Delta_nu_D"][escaped]
            beta = archive["sc_dir_bulk"][escaped] * width / atom.reference_hz
            frequency = (atom.reference_hz + archive["x"][escaped] * width) / (1 - beta)
        else:
            frequency = atom.reference_hz + (
                archive["x"][escaped] + archive["sc_dir_bulk"][escaped]
            ) * archive["Delta_nu_D"][escaped]
        position = np.column_stack([archive[f"pos{i}"][escaped] for i in range(3)])
        direction = np.column_stack([archive[f"dir{i}"][escaped] for i in range(3)])
    return frequency, position, direction, path, len(status)


def spectrum(case, *, bins=60, velocity_range=None, aperture_pc=None, normalization="continuum"):
    """Read a completed run and bin its equal-weight, angle-averaged escapes."""
    case = Path(case).resolve()
    config = read_configuration(case)
    gpu = (case / "gpu_run_report.json").is_file()
    metadata = read_json(case / ("prepare_report.json" if gpu else "run.json"))
    profile = selected_profile(case, metadata)
    atom = load_atom(profile, case / "atomic.atom")
    launched = config.getint("run", "nphot")
    if launched <= 0:
        raise ValueError("The resolved configuration needs a positive nphot count.")
    if bins < 1:
        raise ValueError("Use at least one spectral bin.")
    if aperture_pc is not None and (not np.isfinite(aperture_pc) or aperture_pc <= 0):
        raise ValueError("The aperture radius must be finite and positive, in pc.")

    if gpu:
        frequency, position, direction, packet_path, initial_count = cuda_packets(case, atom)
        if initial_count != launched:
            raise ValueError("GPU packet count differs from the resolved configuration.")
    else:
        frequency, position, direction, packet_path = cpu_packets(case, atom.reference_hz)
    if len(frequency) > launched:
        raise ValueError("More escapes than launched photons: select the primary packet stream.")
    norms = np.linalg.norm(direction, axis=1)
    if (np.any(~np.isfinite(frequency)) or np.any(frequency <= 0) or
            np.any(~np.isfinite(position)) or np.any(~np.isfinite(direction)) or np.any(norms <= 0)):
        raise ValueError("Escaped packets have invalid frequencies, positions or directions.")

    # Use the same linear Doppler convention for both backends. Positive is red.
    velocity = -C_KMS * (frequency - atom.reference_hz) / atom.reference_hz
    direction = direction / norms[:, None]
    selected = np.ones(len(frequency), dtype=bool)
    if aperture_pc is not None:
        impact_pc = np.linalg.norm(np.cross(position, direction), axis=1) / PC_CM
        selected &= impact_pc <= aperture_pc

    mode = config.getint("emission", "frequency_mode", fallback=-1)
    halfwidth = config.getfloat("emission", "frequency_param", fallback=0)
    uniform_continuum = mode == 3 and np.isfinite(halfwidth) and halfwidth > 0
    limits = velocity_range or ((-halfwidth, halfwidth) if uniform_continuum else (-600.0, 600.0))
    if len(limits) != 2 or not np.all(np.isfinite(limits)) or limits[0] >= limits[1]:
        raise ValueError("Give an increasing, finite velocity range in km/s.")
    edges = np.linspace(*limits, bins + 1)
    counts = np.histogram(velocity[selected], bins=edges)[0]
    widths = np.diff(edges)
    if normalization == "continuum":
        if not uniform_continuum:
            raise ValueError("Continuum normalization needs frequency_mode=3 with a positive half-width; use --normalization probability for a line source.")
        denominator = launched * widths / (2 * halfwidth)
        ylabel = "Flux / injected continuum"
    elif normalization == "probability":
        if not counts.sum():
            raise ValueError("No escaping packets fall inside the selected aperture and velocity range.")
        denominator = counts.sum() * widths
        ylabel = "Normalized profile (km/s)$^{-1}$"
    else:
        raise ValueError(f"Unknown normalization: {normalization}")
    flux = counts / denominator
    uncertainty = np.sqrt(counts) / denominator
    summary = {
        "line": profile["name"], "line_label": profile["label"],
        "backend": "cuda" if gpu else "cpu",
        "packet_file": packet_path.name, "launched_packets": launched,
        "escaped_packets": len(frequency), "aperture_packets": int(selected.sum()),
        "binned_packets": int(counts.sum()), "reference_frequency_hz": atom.reference_hz,
        "reference_wavelength_angstrom": LIGHT_SPEED / atom.reference_hz * 1e8,
        "velocity_convention": "-c * (nu_observer - nu_reference) / nu_reference; positive is red",
        "normalization": normalization, "velocity_range_km_s": list(map(float, limits)),
        "bins": bins, "aperture_pc": aperture_pc,
        "continuum_halfwidth_km_s": halfwidth if uniform_continuum else None,
        "photon_seed": config.get("run", "random_seed", fallback=None),
        "grid_seed": config.get("grid", "random_seed", fallback=None),
        "spectrum_estimator": "equal-weight escapes, averaged over outgoing directions",
        "uncertainty": "sqrt(bin count) divided by the same normalization; approximate Monte Carlo sampling error",
    }
    return edges, counts, flux, uncertainty, ylabel, summary


def write_spectrum(output, edges, counts, flux, uncertainty, ylabel, summary):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    centres = (edges[:-1] + edges[1:]) / 2
    csv_path, json_path = output.with_suffix(".csv"), output.with_suffix(".json")
    np.savetxt(csv_path, np.column_stack((centres, flux, uncertainty, counts, edges[:-1], edges[1:])),
               delimiter=",", comments="", header="velocity_km_s,flux,mc_sigma,escaped_packets,bin_left_km_s,bin_right_km_s")
    json_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    with plt.rc_context({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False}):
        fig, ax = plt.subplots(figsize=(8, 4.6), constrained_layout=True)
        ax.stairs(flux, edges, baseline=None, color="#176776", linewidth=1.7,
                  label=summary["line_label"])
        ax.fill_between(centres, np.maximum(0, flux - uncertainty), flux + uncertainty,
                        color="#176776", alpha=0.15, step="mid", linewidth=0)
        if summary["normalization"] == "continuum":
            ax.axhline(1, color="#8b989e", linestyle="--", linewidth=1)
        ax.axvline(0, color="#8b989e", linestyle=":", linewidth=1)
        ax.set(xlabel="Velocity relative to the reference transition (km/s)", ylabel=ylabel,
               xlim=(edges[0], edges[-1]), ylim=(0, None))
        ax.legend(frameon=False)
        fig.savefig(output, dpi=180)
        plt.close(fig)
    return csv_path, json_path


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", type=Path, help="A completed CPU or CUDA run directory")
    parser.add_argument("--output", type=Path, required=True, help="Output PNG path; CSV and JSON use the same stem")
    parser.add_argument("--bins", type=int, default=60)
    parser.add_argument("--velocity-range", nargs=2, type=float, metavar=("MIN", "MAX"))
    parser.add_argument("--aperture-pc", type=float, help="Projected aperture radius in pc; default includes every escape")
    parser.add_argument("--normalization", choices=("continuum", "probability"), default="continuum")
    args = parser.parse_args(argv)
    try:
        result = spectrum(args.case, bins=args.bins, velocity_range=args.velocity_range,
                          aperture_pc=args.aperture_pc, normalization=args.normalization)
        csv_path, json_path = write_spectrum(args.output, *result)
    except (ValueError, OSError, KeyError, configparser.Error) as error:
        parser.exit(2, f"PEACOCK spectrum: {error}\n")
    summary = result[-1]
    print(f"{summary['binned_packets']} packets in {args.bins} bins; {summary['line']}, {summary['backend']}.")
    print(f"Figure: {args.output}\nTable: {csv_path}\nSettings: {json_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
