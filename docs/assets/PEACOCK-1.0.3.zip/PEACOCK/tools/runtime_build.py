"""Build one linked native executable for a complete PEACOCK backend."""

import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

from tools.engine_layout import ROOT, line_profiles, source_view


OPERATORS = {
    'cpu': {'resonant':'models/lya', 'fine_structure':'models/cii', 'multilevel':'models/uv/src'},
    'cuda': {'resonant':'models/gpu_lya/src', 'fine_structure':'models/cii', 'doublet':'models/gpu_civ/src',
             'multilevel':'models/uv/src'},
}
SOURCE_DIRS = ('', 'config', 'config/iniparser', 'grids', 'io', 'misc', 'observer')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(value):
    return [value] if Path(value).is_file() else shlex.split(value)


def native_source_identity(view):
    return {
        'compiler_view': (view/'.source-id').read_text().strip(),
        'line_registry_sha256': sha(ROOT/'lines/catalog.json'),
        'build_recipe_sha256': sha(Path(__file__)),
        'runtime': {p.name: sha(p) for p in sorted((ROOT/'src/runtime').glob('*')) if p.is_file()},
    }


def build_record(backend, directory, view):
    directory = directory.resolve()
    path = directory/'build.json'
    if not path.is_file():
        raise ValueError(f'Build this backend first with `python3 peacock.py build --backend {backend}`.')
    record = json.loads(path.read_text(encoding='utf8'))
    if record['format'] != 1 or record['backend'] != backend:
        raise ValueError('This build belongs to another backend or build format.')
    if record['source'] != native_source_identity(view):
        raise ValueError(f'Native source changed. Build {backend} in a new directory.')
    exe = directory/record['executable']
    if exe.parent != directory or sha(exe) != record['executable_sha256']:
        raise ValueError('Native executable checksum differs from its build record.')
    return record, exe


def runtime_environment(record):
    env = os.environ.copy()
    if record['runtime_directories']:
        env['PATH'] = os.pathsep.join([*record['runtime_directories'], env.get('PATH','')])
    return env


def configuration(args):
    suffix = '.exe' if os.name=='nt' else ''
    prefix = Path(args.compiler_prefix).resolve() if args.compiler_prefix else None
    def tool(explicit, variable, fallback, prefixed):
        default = str(prefix/'bin'/(prefixed+suffix)) if prefix else fallback
        return command(explicit or os.environ.get(variable, default))
    cc = tool(args.cc,'CC','cc','gcc')
    cxx = tool(args.cxx,'CXX','c++','g++')
    nm = tool(args.nm,'NM','nm','nm')
    runtime = [str(prefix/'bin')] if prefix else []
    env = runtime_environment({'runtime_directories':runtime})
    includes = [Path(p).resolve() for p in args.include_dir]
    libraries = [Path(p).resolve() for p in args.library_dir]
    if prefix:
        includes.append(prefix/'include')
        libraries.append(prefix/'lib')
    cppflags = ['-I'+str(p) for p in includes] + shlex.split(os.environ.get('CPPFLAGS',''))
    ldflags = ['-L'+str(p) for p in libraries] + shlex.split(os.environ.get('LDFLAGS',''))
    libs = shlex.split(args.libs or os.environ.get('LDLIBS','-lgsl -lgslcblas -lm'))
    gsl = os.environ.get('GSL_CONFIG') or (None if prefix else shutil.which('gsl-config'))
    if gsl:
        cppflags += shlex.split(subprocess.check_output([gsl,'--cflags'],text=True,env=env))
        if not args.libs and 'LDLIBS' not in os.environ:
            libs = shlex.split(subprocess.check_output([gsl,'--libs'],text=True,env=env))
    flags = ['-O3','-DNDEBUG','-DMAKEFILE_GRID=GRID_VARIABLE']
    if args.backend=='cuda':
        flags += ['-DTLAC_CUDA=1','-DTLAC_HOST_EXPORT=1']
    else:
        flags += ['-fno-builtin']
    if args.openmp:
        cppflags += ['-DUSE_OMP=1']
        flags += shlex.split(os.environ.get('OPENMP_CFLAGS','-fopenmp'))
        ldflags += shlex.split(os.environ.get('OPENMP_LIBS','-fopenmp'))
    if args.hdf5:
        cppflags += ['-DUSE_HDF5=1'] + shlex.split(subprocess.check_output(['pkg-config','--cflags','hdf5'],text=True,env=env))
        libs += shlex.split(subprocess.check_output(['pkg-config','--libs','hdf5'],text=True,env=env))
    return cc,cxx,nm,flags+cppflags,ldflags,libs,env,runtime


def symbols(nm, objects, env):
    output = subprocess.check_output([*nm,'-g','--defined-only','-j',*map(str,objects)],text=True,env=env)
    result = set()
    for raw in output.splitlines():
        name = raw.strip()
        if sys.platform=='darwin' and name.startswith('_'):
            name = name[1:]
        if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',name):
            result.add(name)
    return result


def build_native(args, stage, view):
    cc,cxx,nm,flags,ldflags,libs,env,runtime = configuration(args)
    cflags = ['-std=gnu99',*shlex.split(os.environ.get('CFLAGS',''))]
    cxxflags = ['-std=c++14',*shlex.split(os.environ.get('CXXFLAGS',''))]
    scalar = ROOT/'src/runtime/scalar_atom.c'
    exporter = args.backend=='cuda'
    declared = json.loads((ROOT/'lines/source-layout.json').read_text(encoding='utf8'))['files']
    final_objects = []
    for operator, relative in OPERATORS[args.backend].items():
        root = view/relative
        source = sorted(view/name for name in declared if name.endswith('.c') and
                        name.startswith(relative+'/') and
                        Path(name).parent in {Path(relative)/folder for folder in SOURCE_DIRS})
        operator_flags = [*flags,'-I'+str(root)]
        if operator!='multilevel':
            source.append(scalar)
            operator_flags += ['-DPEACOCK_ATOM_'+operator.upper(),'-include',str(scalar.with_suffix('.h'))]
        else:
            operator_flags += ['-DPEACOCK_MULTILEVEL=1']
        folder = stage/'objects'/operator
        folder.mkdir(parents=True)

        def compile_c(item, prefix_header=None):
            index,path = item
            obj = folder/f'{index}.o'
            prefix = ['-include',str(prefix_header)] if prefix_header else []
            subprocess.run([*cc,*prefix,*operator_flags,*cflags,'-c',str(path),'-o',str(obj)],check=True,env=env)
            return obj

        # Probe this operator's public C symbols with the actual platform flags.
        # The link pass namespaces those symbols so layouts can remain private.
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
            probe = list(pool.map(compile_c,enumerate(source)))
            names = symbols(nm,probe,env)
            if not {'main','peacock_load_atom'} <= names:
                raise RuntimeError(f'Could not identify the native entry points for {operator}.')
            if exporter:
                names.update(('run_photons_cuda','cuda_emission_cloud_id'))
            prefix_header = folder/'namespace.h'
            prefix_header.write_text(''.join(f'#define {n} pc_{operator}_{n}\n' for n in sorted(names)))
            objects = list(pool.map(lambda item:compile_c(item,prefix_header),enumerate(source)))
        final_objects.extend(objects)

        if exporter:
            host = root/'gpu/gpu_rt.cu'
            text = host.read_text(encoding='utf8')
            anchor = '#include "input_bvh.h"\n'
            if text.count(anchor)!=1:
                raise ValueError('GPU exporter namespace anchor changed.')
            adapter = folder/'exporter.cc'
            adapter.write_text(text.replace(anchor,anchor+f'\nnamespace pc_{operator}_export {{\n')+'\n}\n')
            obj = folder/'exporter.o'
            subprocess.run([*cxx,'-include',str(prefix_header),*operator_flags,*cxxflags,
                            '-I'+str(root/'gpu'),'-c',str(adapter),'-o',str(obj)],check=True,env=env)
            final_objects.append(obj)

    entry = stage/'main.o'
    export_flag = ['-DPEACOCK_EXPORTER=1'] if exporter else []
    rows = [p for p in line_profiles() if args.backend in p['backends']]
    registry = stage/'line_registry.inc'
    if len({p['id'] for p in rows}) != len(rows) or any(
            not re.fullmatch(r'[A-Za-z0-9_]+',p['id']) or p['operator'] not in OPERATORS[args.backend]
            for p in rows):
        raise ValueError('The line registry contains an invalid native profile.')
    registry.write_text(''.join(f'{{"{p["id"]}", "{p["operator"]}"}},\n' for p in rows),encoding='ascii')
    subprocess.run([*cc,*export_flag,'-std=c99','-O2','-I'+str(stage),'-c',
                    str(ROOT/'src/runtime/main.c'),'-o',str(entry)],check=True,env=env)
    name = 'peacock-export' if exporter else 'peacock-cpu'
    exe = stage/(name+('.exe' if os.name=='nt' else ''))
    subprocess.run([*(cxx if exporter else cc),str(entry),*map(str,final_objects),*ldflags,*libs,'-o',str(exe)],check=True,env=env)
    shutil.rmtree(stage/'objects')
    entry.unlink()
    registry.unlink()
    return {'format':1,'backend':args.backend,'operators':list(OPERATORS[args.backend]),
            'executable':exe.name,'executable_sha256':sha(exe),'source':native_source_identity(view),
            'runtime_directories':runtime,'openmp':args.openmp,'hdf5':args.hdf5}


def build(args):
    view = source_view()
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(f'Choose a new build directory: {output}')
    if args.backend=='cuda' and (args.openmp or args.hdf5):
        raise ValueError('OpenMP and HDF5 apply to the CPU backend.')
    if args.backend=='cpu' and args.host_only:
        raise ValueError('--host-only applies to CUDA input preparation.')
    output.parent.mkdir(parents=True,exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.peacock-',dir=output.parent))
    try:
        record = build_native(args,stage,view)
        if args.backend=='cuda' and not args.host_only:
            from backends.cuda.runtime import compile_bundle
            record['device'] = compile_bundle(ROOT,stage/'transport.ptx',args.arch,args.nvidia_root,
                                              args.nvrtc_library,args.cuda_include)
        (stage/'build.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
        stage.rename(output)
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    print(output/record['executable'])
