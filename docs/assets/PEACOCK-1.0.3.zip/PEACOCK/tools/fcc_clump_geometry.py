"""Generate reproducible, nonoverlapping FCC cloud geometries.

``volume_beta`` always means the *volume* number-density exponent:
    n_cl(r) proportional to r**(-volume_beta).
Integer cloud counts match the analytic integral in each radial shell.  This
does not assert a pointwise density law or an equilibrium random hard-sphere
process.  Dense shells can retain FCC packing correlations after relaxation.

The generated catalogue contains cloud-center coordinates.
PEACOCK applies velocities and photon transport separately.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import time
from typing import Any, Mapping

import numpy as np
from scipy.spatial import cKDTree


GENERATOR_VERSION = "fcc-shell-quota-1.0.0"
DEFAULT_PARSEC_CM = 3.085677581467192e18
NATIVE_REQUIRED_BORDER = 1.000001


class GeometryFeasibilityError(ValueError):
    """The requested geometry cannot be populated by this FCC seed pool."""


@dataclass(frozen=True)
class GeometrySettings:
    radius_pc: float = 50.0
    rmin_pc: float = 1000.0
    rmax_pc: float = 10000.0
    volume_beta: float = 2.0
    seed: int = 10
    n_clouds: int | None = None
    fv: float | None = 0.02
    shell_width_pc: float | None = None
    relax_sweeps: int = 3
    workers: int = 1
    safety_border: float = 1.000002
    parsec_cm: float = DEFAULT_PARSEC_CM
    max_pool_points: int = 8_000_000


def _sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _integer(value: Any, name: str, minimum: int) -> int:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
        raise ValueError(f"{name} must be an integer")
    if int(value) < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    return int(value)


def _resolved_settings(settings: GeometrySettings | Mapping[str, Any]) -> dict[str, Any]:
    if isinstance(settings, GeometrySettings):
        raw = asdict(settings)
    elif isinstance(settings, Mapping):
        supplied = dict(settings)
        # Specifying an exact N alone should not inherit the default Fv.
        if "n_clouds" in supplied and "fv" not in supplied:
            supplied["fv"] = None
        raw = asdict(GeometrySettings(**supplied))
    else:
        raise TypeError("settings must be GeometrySettings or a mapping")
    for field in ("radius_pc", "rmin_pc", "rmax_pc", "volume_beta", "safety_border", "parsec_cm"):
        if isinstance(raw[field], (bool, np.bool_)):
            raise ValueError(f"{field} must be a finite number")
        raw[field] = float(raw[field])
        if not math.isfinite(raw[field]):
            raise ValueError(f"{field} must be finite")
    if raw["radius_pc"] <= 0 or raw["rmin_pc"] < 0 or raw["rmax_pc"] <= raw["rmin_pc"]:
        raise ValueError("Require radius_pc > 0 and 0 <= rmin_pc < rmax_pc")
    if raw["safety_border"] <= NATIVE_REQUIRED_BORDER:
        raise ValueError(f"safety_border must exceed the native placement margin {NATIVE_REQUIRED_BORDER}")
    if raw["parsec_cm"] <= 0:
        raise ValueError("parsec_cm must be positive")
    raw["seed"] = _integer(raw["seed"], "seed", 0)
    raw["relax_sweeps"] = _integer(raw["relax_sweeps"], "relax_sweeps", 0)
    raw["max_pool_points"] = _integer(raw["max_pool_points"], "max_pool_points", 1)
    raw["workers"] = _integer(raw["workers"], "workers", -1)
    if raw["workers"] == 0:
        raise ValueError("workers must be -1 or a positive integer")
    center_max = raw["rmax_pc"] - raw["radius_pc"] * raw["safety_border"]
    if center_max <= raw["rmin_pc"]:
        raise GeometryFeasibilityError("No cloud-center radial interval remains after the outer containment margin")
    if raw["rmin_pc"] == 0 and raw["volume_beta"] >= 3:
        raise ValueError("A volume density exponent >= 3 is not normalizable with rmin_pc = 0")
    if raw["shell_width_pc"] is None:
        raw["shell_width_pc"] = 2 * raw["radius_pc"]
    raw["shell_width_pc"] = float(raw["shell_width_pc"])
    if not math.isfinite(raw["shell_width_pc"]) or raw["shell_width_pc"] <= 0:
        raise ValueError("shell_width_pc must be positive and finite")
    if raw["fv"] is not None:
        if isinstance(raw["fv"], (bool, np.bool_)):
            raise ValueError("fv must be a finite positive number")
        raw["fv"] = float(raw["fv"])
        if not math.isfinite(raw["fv"]) or not 0 < raw["fv"] < 1:
            raise ValueError("fv must lie strictly between 0 and 1")
    if raw["n_clouds"] is not None:
        raw["n_clouds"] = _integer(raw["n_clouds"], "n_clouds", 1)
    if raw["n_clouds"] is None and raw["fv"] is None:
        raise ValueError("Supply n_clouds or fv")
    shell_volume_factor = raw["rmax_pc"] ** 3 - raw["rmin_pc"] ** 3
    requested_real_n = None if raw["fv"] is None else raw["fv"] * shell_volume_factor / raw["radius_pc"] ** 3
    # Match positive C round(), including the half-integer case.
    derived_n = None if requested_real_n is None else int(math.floor(requested_real_n + 0.5))
    if raw["n_clouds"] is None:
        if derived_n < 1:
            raise GeometryFeasibilityError("Requested Fv rounds to fewer than one cloud")
        raw["n_clouds"] = derived_n
    elif derived_n is not None and derived_n != raw["n_clouds"]:
        raise ValueError(f"n_clouds={raw['n_clouds']} conflicts with fv={raw['fv']} (native rounded N={derived_n})")
    raw["center_rmax_pc"] = center_max
    raw["requested_unrounded_n_clouds"] = requested_real_n
    raw["actual_fv"] = raw["n_clouds"] * raw["radius_pc"] ** 3 / shell_volume_factor
    return raw


def _cdf(r: np.ndarray, settings: Mapping[str, Any]) -> np.ndarray:
    r = np.asarray(r, dtype=np.float64)
    lo, hi = settings["rmin_pc"], settings["center_rmax_pc"]
    exponent = 3.0 - settings["volume_beta"]
    if lo == 0:
        return np.clip((r / hi) ** exponent, 0, 1)
    logs = np.log(r / lo)
    span = math.log(hi / lo)
    if abs(exponent) < 1e-10:
        result = logs / span
    elif exponent > 0:
        # Scale by hi**exponent to avoid overflow for general finite beta.
        result = (np.exp(exponent * (logs - span)) - math.exp(-exponent * span)) / (-math.expm1(-exponent * span))
    else:
        result = np.expm1(exponent * logs) / math.expm1(exponent * span)
    result = np.clip(result, 0, 1)
    result = np.where(r <= lo, 0.0, np.where(r >= hi, 1.0, result))
    return result


def _shell_targets(settings: Mapping[str, Any]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    lo, hi, width = settings["rmin_pc"], settings["center_rmax_pc"], settings["shell_width_pc"]
    n_shells = int(math.ceil((hi - lo) / width))
    if n_shells > 1_000_000:
        raise GeometryFeasibilityError("Requested shell width produces over one million shells; increase shell_width_pc explicitly")
    edges = np.r_[lo + np.arange(n_shells, dtype=np.float64) * width, hi]
    cumulative = settings["n_clouds"] * _cdf(edges, settings)
    cumulative[0], cumulative[-1] = 0.0, float(settings["n_clouds"])
    quotas = np.diff(np.floor(cumulative + 0.5).astype(np.int64))
    if np.any(quotas < 0) or int(quotas.sum()) != settings["n_clouds"]:
        raise ArithmeticError("Invalid analytic shell quotas")
    return edges, quotas, np.diff(cumulative)


def _seed_streams(seed: int) -> tuple[list[np.random.Generator], dict[str, Any]]:
    children = np.random.SeedSequence(seed).spawn(3)
    names = ("fcc_rotation_translation", "shell_selection", "angular_relaxation")
    return [np.random.default_rng(child) for child in children], {
        "root_seed": seed, "derivation": "numpy.random.SeedSequence(seed).spawn(3), PCG64",
        "streams": {name: {"spawn_key": list(child.spawn_key)} for name, child in zip(names, children)},
    }


def _fcc_pool(settings: Mapping[str, Any], edges: np.ndarray, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    started = time.perf_counter()
    nearest = 2 * settings["radius_pc"] * settings["safety_border"]
    lattice = nearest * math.sqrt(2)
    density = 4 / lattice ** 3
    estimated_points = density * 4 * math.pi / 3 * (settings["center_rmax_pc"] ** 3 - settings["rmin_pc"] ** 3)
    # A guard, not a physical packing test: the generator never silently changes
    # the requested radius/count/law to fit an allocation or a shell quota.
    if estimated_points > settings["max_pool_points"]:
        raise GeometryFeasibilityError(
            f"FCC pool would contain approximately {estimated_points:,.0f} points; "
            f"exceeds max_pool_points={settings['max_pool_points']:,}. Increase the explicit memory limit only if intended.")
    if settings["n_clouds"] > estimated_points * 1.05 + 64:
        raise GeometryFeasibilityError("Requested cloud count exceeds the estimated total FCC candidate capacity")
    translation = rng.uniform(0, lattice, 3)
    rotation, _ = np.linalg.qr(rng.normal(size=(3, 3)))
    if np.linalg.det(rotation) < 0:
        rotation[:, -1] *= -1
    bound = int(math.ceil((settings["center_rmax_pc"] + np.linalg.norm(translation)) / lattice)) + 1
    enumeration_count = 4 * (2 * bound + 1) ** 3
    enumeration_limit = 4 * settings["max_pool_points"]
    if enumeration_count > enumeration_limit:
        raise GeometryFeasibilityError(
            f"FCC enclosing cube requires enumerating {enumeration_count:,} points; "
            f"exceeds the explicit memory/work guard {enumeration_limit:,}. "
            "Increase max_pool_points explicitly only if this geometry is intended.")
    ids = np.arange(-bound, bound + 1, dtype=np.int64)
    xx, yy = np.meshgrid(ids, ids, indexing="ij")
    xy = np.column_stack((xx.ravel(), yy.ravel()))
    basis = np.array([[0, 0, 0], [0, .5, .5], [.5, 0, .5], [.5, .5, 0]], dtype=np.float64)
    chunks, count = [], 0
    for z in ids:
        cells = np.column_stack((xy, np.full(len(xy), z)))
        points = (cells[:, None, :] + basis[None, :, :]).reshape(-1, 3) * lattice + translation
        radii2 = np.einsum("ij,ij->i", points, points)
        keep = (radii2 >= settings["rmin_pc"] ** 2) & (radii2 <= settings["center_rmax_pc"] ** 2)
        if np.any(keep):
            # The radial cut precedes rotation.  Post-rotation bounds are audited.
            chunk = points[keep] @ rotation.T
            count += len(chunk)
            if count > settings["max_pool_points"]:
                raise GeometryFeasibilityError("Actual FCC pool exceeds the explicit max_pool_points memory guard")
            chunks.append(chunk)
    if not chunks:
        raise GeometryFeasibilityError("No FCC candidates lie in the requested cloud-center shell")
    points = np.concatenate(chunks)
    radii = np.linalg.norm(points, axis=1)
    # Float roundoff at a rotation boundary must never admit a native-invalid point.
    keep = (radii >= settings["rmin_pc"]) & (radii <= settings["center_rmax_pc"])
    points, radii = points[keep], radii[keep]
    shells = np.searchsorted(edges, radii, side="right") - 1
    shells[radii == edges[-1]] = len(edges) - 2
    available = np.bincount(shells, minlength=len(edges) - 1)
    return points, shells, {
        "candidate_count": len(points), "estimated_candidate_count": estimated_points,
        "enumerated_cube_point_count": enumeration_count, "enumerated_cube_point_limit": enumeration_limit,
        "candidate_shell_counts": available.tolist(), "nearest_seed_distance_pc": nearest,
        "conventional_cell_length_pc": lattice, "translation_pc": translation.tolist(),
        "rotation_matrix": rotation.tolist(), "maximum_uniform_seed_density_per_pc3": density,
        "candidate_positions_sha256": _sha_bytes(points.astype("<f8", copy=False).tobytes()),
        "seconds": time.perf_counter() - started,
    }


def _unit_directions(rng: np.random.Generator, n: int) -> np.ndarray:
    mu, phi = rng.uniform(-1, 1, n), rng.uniform(0, 2 * math.pi, n)
    radial = np.sqrt(np.maximum(0, 1 - mu * mu))
    return np.column_stack((radial * np.cos(phi), radial * np.sin(phi), mu))


def _relax_angles(positions: np.ndarray, settings: Mapping[str, Any], rng: np.random.Generator) -> tuple[np.ndarray, dict[str, Any]]:
    radii = np.linalg.norm(positions, axis=1)
    moved = np.zeros(len(positions), dtype=bool)
    separation = 2 * settings["radius_pc"] * settings["safety_border"]
    sweeps = []
    for sweep in range(settings["relax_sweeps"]):
        started = time.perf_counter()
        candidates = radii[:, None] * _unit_directions(rng, len(positions))
        conflicts = cKDTree(positions).query_ball_point(candidates, separation, return_length=True, workers=settings["workers"])
        own = np.linalg.norm(candidates - positions, axis=1) <= separation
        other_conflicts = conflicts - own.astype(conflicts.dtype)
        eligible = other_conflicts == 0
        candidate_indices = np.flatnonzero(eligible)
        collisions = cKDTree(candidates[candidate_indices]).query_pairs(separation, output_type="ndarray")
        if len(collisions):
            eligible[candidate_indices[np.unique(collisions)]] = False
        accepted = np.flatnonzero(eligible)
        positions[accepted] = candidates[accepted]
        moved[accepted] = True
        sweeps.append({"sweep": sweep + 1, "accepted_moves": len(accepted),
            "existing_conflict_rejections": int(np.count_nonzero(other_conflicts)),
            "eligible_candidate_pair_collisions": len(collisions), "seconds": time.perf_counter() - started})
    if not np.allclose(np.linalg.norm(positions, axis=1), radii, rtol=3e-15, atol=3e-11):
        raise ArithmeticError("Angular relaxation changed a cloud's radial location")
    coarse_edges = np.linspace(settings["rmin_pc"], settings["center_rmax_pc"], 11)
    total = np.histogram(radii, coarse_edges)[0]
    changed = np.histogram(radii[moved], coarse_edges)[0]
    fractions = np.divide(changed, total, out=np.zeros(10, dtype=float), where=total > 0)
    return positions, {"sweeps": sweeps, "all_center_radii_preserved": True,
        "fraction_ever_relocated": float(np.mean(moved)), "coarse_shell_edges_pc": coarse_edges.tolist(),
        "relocation_fraction_by_coarse_shell": fractions.tolist(),
        "equilibrium_hard_sphere_sampling_claimed": False,
        "packing_correlation_caveat": "Dense shells can retain FCC and hard-sphere packing correlations; shell matching does not define a unique random point process."}


def _audit_positions(positions: np.ndarray, settings: Mapping[str, Any], edges: np.ndarray, quotas: np.ndarray) -> dict[str, Any]:
    if positions.shape != (settings["n_clouds"], 3) or not np.all(np.isfinite(positions)):
        raise ArithmeticError("Generated position shape, cloud count, or finite-value check failed")
    radii = np.linalg.norm(positions, axis=1)
    if np.any(radii < settings["rmin_pc"]) or np.any(radii > settings["center_rmax_pc"]):
        raise ArithmeticError("Generated cloud center violates the requested radial interval")
    achieved = np.histogram(radii, edges)[0]
    if not np.array_equal(achieved, quotas):
        raise ArithmeticError("Achieved shell counts differ from the exact integer quotas")
    if len(positions) > 1:
        nearest = cKDTree(positions).query(positions, k=2, workers=settings["workers"])[0][:, 1]
        minimum = float(np.min(nearest))
        native_minimum = 2 * settings["radius_pc"] * NATIVE_REQUIRED_BORDER
        if minimum <= native_minimum:
            raise ArithmeticError("Generated cloud separation fails the native nonoverlap safety margin")
    else:
        minimum = None
    ordered_radii = np.sort(radii)
    cdf = _cdf(ordered_radii, settings)
    n = len(positions)
    ks = float(max(np.max(np.arange(1, n + 1) / n - cdf), np.max(cdf - np.arange(n) / n)))
    return {"exact_cloud_count": n, "minimum_center_separation_pc": minimum,
        "native_required_minimum_center_separation_pc": 2 * settings["radius_pc"] * NATIVE_REQUIRED_BORDER,
        "nonoverlap_passed": True, "outer_containment_passed": True,
        "center_radius_range_pc": [float(radii.min()), float(radii.max())],
        "maximum_outer_surface_pc": float(radii.max() + settings["radius_pc"]),
        "achieved_shell_counts": achieved.tolist(), "integer_shell_quotas_match_exactly": True,
        "radial_cdf_maximum_absolute_deviation": ks,
        "positions_pc_sha256": _sha_bytes(positions.astype("<f8", copy=False).tobytes())}


def geometry_identity(settings: GeometrySettings | Mapping[str, Any]) -> tuple[dict[str, Any], str]:
    """Return normalized settings and the complete, content-bound cache key."""
    resolved = _resolved_settings(settings)
    identity = {"generator_version": GENERATOR_VERSION, "generator_sha256": _sha_file(Path(__file__)), "settings": resolved}
    encoded = json.dumps(identity, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return identity, _sha_bytes(encoded)


def generate_positions(settings: GeometrySettings | Mapping[str, Any]) -> tuple[np.ndarray, dict[str, Any]]:
    """Generate exact-N positions in pc, with a full geometry-only audit.

    A shell-capacity failure raises GeometryFeasibilityError.  No fallback,
    density-law flattening, radius adjustment, or Fv adjustment occurs.
    Worker count affects runtime only; identical seeds/settings otherwise give
    identical positions in single- and multithreaded nearest-neighbor queries.
    """
    started = time.perf_counter()
    identity, cache_key = geometry_identity(settings)
    resolved = identity["settings"]
    edges, quotas, expected = _shell_targets(resolved)
    streams, seed_audit = _seed_streams(resolved["seed"])
    points, shell_indices, pool_audit = _fcc_pool(resolved, edges, streams[0])
    available = np.asarray(pool_audit["candidate_shell_counts"], dtype=np.int64)
    shortage = np.flatnonzero(quotas > available)
    if len(shortage):
        detail = [{"shell": int(j), "radius_range_pc": edges[j:j + 2].tolist(),
                   "requested": int(quotas[j]), "available": int(available[j])} for j in shortage]
        raise GeometryFeasibilityError("FCC shell quotas exceed candidate packing capacity; science settings were not changed: " + json.dumps(detail))
    order = np.argsort(shell_indices, kind="stable")
    offsets = np.r_[0, np.cumsum(available)]
    chosen = np.concatenate([streams[1].choice(order[offsets[j]:offsets[j + 1]], size=int(count), replace=False)
                             for j, count in enumerate(quotas)])
    positions = points[chosen].copy()
    del points, shell_indices, order, chosen
    positions, relaxation = _relax_angles(positions, resolved, streams[2])
    validation = _audit_positions(positions, resolved, edges, quotas)
    audit = {"status": "PASS", **identity, "cache_key": cache_key,
        "method": "randomly rotated/translated FCC seed pool, exact radial-shell quotas, overlap-safe angular relaxation",
        "density_definition": "volume number density n_cl(r) proportional to r^-volume_beta",
        "radial_probability_definition": "p(r) dr proportional to r^(2-volume_beta) dr",
        "fv_definition": "N a^3 / (rmax^3 - rmin^3), legacy shell-volume convention",
        "inner_boundary_definition": "cloud centers at or beyond rmin; cloud surfaces may extend below rmin",
        "requested_fv": resolved["fv"], "actual_fv": resolved["actual_fv"],
        "fv_integer_rounding_error": None if resolved["fv"] is None else resolved["actual_fv"] - resolved["fv"],
        "n_rounding_rule": "floor(requested_unrounded_N + 0.5), matching positive C round()",
        "shell_edges_pc": edges.tolist(), "expected_shell_counts": expected.tolist(),
        "integer_shell_quotas": quotas.tolist(), "maximum_shell_integer_rounding_error": float(np.max(np.abs(quotas - expected))),
        "pointwise_density_or_subshell_law_claimed": False,
        "seed_streams": seed_audit, "fcc_seed_pool": pool_audit, "angular_relaxation": relaxation,
        "validation": validation, "transport_executed": False, "existing_studies_modified": False,
        "elapsed_seconds": time.perf_counter() - started}
    return positions, audit


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def prepare_geometry(output_dir: str | Path, *, fv: float | None = None, n_clouds: int | None = None,
                     radius_pc: float = 50., rmin_pc: float = 1000., rmax_pc: float = 10000.,
                     volume_beta: float = 2., seed: int = 10, shell_width_pc: float | None = None,
                     relax_sweeps: int = 3, workers: int = 1, safety_border: float = 1.000002,
                     parsec_cm: float = DEFAULT_PARSEC_CM, max_pool_points: int = 8_000_000) -> dict[str, Any]:
    """Create or validate an exact-N cache; return native cm-text file metadata.

    Caches are per complete setting set and generator content hash.  Taking a
    first-N prefix from a different cloud-count cache is never permitted.
    On infeasibility a failure JSON is written and the exception is reraised.
    """
    if fv is None and n_clouds is None:
        fv = 0.02
    settings = GeometrySettings(radius_pc, rmin_pc, rmax_pc, volume_beta, seed, n_clouds, fv,
                                shell_width_pc, relax_sweeps, workers, safety_border, parsec_cm, max_pool_points)
    identity, key = geometry_identity(settings)
    resolved = identity["settings"]
    directory = Path(output_dir).expanduser().resolve() / ("fcc_" + key)
    directory.mkdir(parents=True, exist_ok=True)
    manifest_path = directory / "geometry_manifest.json"
    positions_path = directory / f"clump_pos_Ncl1_{resolved['n_clouds']}.txt"
    arrays_path = directory / "geometry_arrays.npz"
    audit_path = directory / "geometry_audit.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("cache_key") != key or manifest.get("identity") != identity:
            raise ArithmeticError("Existing cache identity does not match the requested settings")
        for path, field in ((positions_path, "positions_file_sha256"), (arrays_path, "arrays_file_sha256"), (audit_path, "audit_file_sha256")):
            if not path.is_file() or _sha_file(path) != manifest[field]:
                raise ArithmeticError(f"Existing FCC cache failed its hash check: {path}")
        with np.load(arrays_path, allow_pickle=False) as arrays:
            positions = arrays["positions_pc"]
        edges, quotas, _ = _shell_targets(resolved)
        _audit_positions(positions, resolved, edges, quotas)
        native_positions = np.loadtxt(positions_path, dtype=np.float64, ndmin=2)
        if native_positions.shape != positions.shape or not np.array_equal(native_positions, positions * parsec_cm):
            raise ArithmeticError("Existing native cm-text positions do not exactly match the audited arrays")
        return {**manifest, "cache_reused": True}
    if any(path.exists() for path in (positions_path, arrays_path, audit_path)):
        raise ArithmeticError("Incomplete FCC cache contains output files; preserve/inspect it before retrying")
    try:
        positions, audit = generate_positions(settings)
    except Exception as exc:
        _atomic_json(directory / "preparation_failure.json", {"status": "FAILED", "identity": identity,
                     "cache_key": key, "error_type": type(exc).__name__, "error": str(exc),
                     "science_settings_changed": False, "transport_executed": False})
        raise
    positions_cm = positions * parsec_cm
    temporary_text = positions_path.with_name(positions_path.name + f".tmp.{os.getpid()}")
    np.savetxt(temporary_text, positions_cm, fmt="%.17e")
    readback = np.loadtxt(temporary_text, dtype=np.float64, ndmin=2)
    if not np.array_equal(readback, positions_cm):
        raise ArithmeticError("17-digit native cm-text roundtrip failed")
    os.replace(temporary_text, positions_path)
    temporary_arrays = arrays_path.with_name(arrays_path.name + f".tmp.{os.getpid()}")
    with temporary_arrays.open("wb") as stream:
        np.savez_compressed(stream, positions_pc=positions, positions_cm=positions_cm,
                            center_radii_pc=np.linalg.norm(positions, axis=1))
    os.replace(temporary_arrays, arrays_path)
    audit["native_text_roundtrip_exact"] = True
    audit["native_text_units"] = "cm"
    audit["parsec_cm"] = parsec_cm
    _atomic_json(audit_path, audit)
    manifest = {"status": "PASS", "identity": identity, "cache_key": key,
        "generator_version": GENERATOR_VERSION, "generator_sha256": identity["generator_sha256"],
        "n_clouds": resolved["n_clouds"], "volume_beta": volume_beta,
        "radius_pc": radius_pc, "fv": resolved["actual_fv"],
        "positions_file": positions_path.as_posix(), "clump_position_file": positions_path.as_posix(),
        "arrays_file": arrays_path.as_posix(), "audit_file": audit_path.as_posix(),
        "manifest_file": manifest_path.as_posix(), "positions_file_units": "cm",
        "positions_file_sha256": _sha_file(positions_path), "arrays_file_sha256": _sha_file(arrays_path),
        "audit_file_sha256": _sha_file(audit_path), "exact_count_required": True,
        "prefix_reuse_permitted": False, "cache_reused": False}
    _atomic_json(manifest_path, manifest)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--fv", type=float)
    group.add_argument("--n-clouds", type=int)
    parser.add_argument("--radius-pc", type=float, default=50.)
    parser.add_argument("--rmin-pc", type=float, default=1000.)
    parser.add_argument("--rmax-pc", type=float, default=10000.)
    parser.add_argument("--volume-beta", type=float, default=2.)
    parser.add_argument("--seed", type=int, default=10)
    parser.add_argument("--shell-width-pc", type=float)
    parser.add_argument("--relax-sweeps", type=int, default=3)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--parsec-cm", type=float, default=DEFAULT_PARSEC_CM)
    parser.add_argument("--safety-border", type=float, default=1.000002)
    parser.add_argument("--max-pool-points", type=int, default=8_000_000)
    args = vars(parser.parse_args())
    output_dir = args.pop("output_dir")
    print(json.dumps(prepare_geometry(output_dir, **args), indent=2))


if __name__ == "__main__":
    main()
