"""Export lossless runtime tables from PEACOCK's reference UV atom headers."""

import argparse
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
ATOM_DATA = ROOT / "lines/atomic-data"
SHARED_ARRAYS = {
    "NV1243": "NV1239",
    "SII1254": "SII1250",
    "SII1259": "SII1250",
    "SiII1193": "SiII1190",
}
NUMBER = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?")


def numbers(text, count):
    tokens = [part.strip() for part in text.split(",")]
    if len(tokens) != count or any(NUMBER.fullmatch(t) is None for t in tokens):
        raise ValueError(f"Expected {count} numeric tokens in {text!r}")
    # The source token -0 is a C integer zero, promoted to positive double
    # zero. A textual floating-point parser would treat it as negative zero.
    return " ".join("0" if token == "-0" else token for token in tokens)


def render(data_path):
    line = data_path.parent.name
    data = dict(re.findall(r"^#define (RT_\w+)\s+([^\r\n]+)", data_path.read_text(), re.M))
    if data["RT_NAME"] != '"' + line + '"':
        raise ValueError(f"Line name differs from its reference header: {data_path}")
    arrays_path = ATOM_DATA / SHARED_ARRAYS.get(line, line) / "atomic_arrays.h"
    arrays = arrays_path.read_text()
    nlower, nupper, nlines = (int(data[key]) for key in ("RT_NLOWER", "RT_NUPPER", "RT_NLINES"))
    lower = re.search(r"rt_lower_E\[RT_NLOWER\]\s*=\s*\{([^{}]+)\}", arrays).group(1)
    gamma = re.search(r"rt_gamma\[RT_NUPPER\]\s*=\s*\{([^{}]+)\}", arrays).group(1)
    transitions = arrays.split("const rt_transition rt_lines[RT_NLINES]", 1)[1]
    rows = re.findall(r"\{([^{}]+)\}", transitions)
    if len(rows) != nlines:
        raise ValueError(f"Wrong transition count in {arrays_path}")
    return "\n".join([
        f"PEACOCK_ATOM_V1 multilevel {line}",
        " ".join(data[key] for key in
                 ("RT_NLOWER", "RT_NUPPER", "RT_NLINES", "RT_REFERENCE", "RT_Z", "RT_STAGE")),
        " ".join(data[key] for key in ("RT_MASS", "RT_NU0", "RT_REFERENCE_GAMMA")),
        numbers(lower, nlower),
        numbers(gamma, nupper),
        *(numbers(row, 6) for row in rows),
        "",
    ])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Verify the shipped atom files")
    args = parser.parse_args()
    files = sorted(ATOM_DATA.glob("*/atomic_data.h"))
    if len(files) != 10:
        raise SystemExit("Expected ten reference multilevel headers")
    for path in files:
        target = ROOT / "lines/runtime" / (path.parent.name + ".atom")
        expected = render(path).encode("ascii")
        if args.check:
            if target.read_bytes() != expected:
                raise SystemExit(f"Runtime data differs from the reference headers: {target}")
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(expected)
    print(f"Verified {len(files)} multilevel runtime tables" if args.check
          else f"Exported {len(files)} multilevel runtime tables")


if __name__ == "__main__":
    main()
