import numpy as np
import os
import time
from scipy.spatial import cKDTree
from scipy.spatial.distance import pdist
from multiprocessing import Pool, cpu_count

PARSEC = 3.08567758e18
PI = np.pi

def compute_nclumps(Fv, Rin_pc, Rout_pc, Rcloud_pc):
    shell_vol = (4.0 / 3.0) * PI * (Rout_pc**3 - Rin_pc**3)
    clump_vol = (4.0 / 3.0) * PI * (Rcloud_pc**3)
    return int(round(Fv * shell_vol / clump_vol))

def filter_candidates_kdtree(tree, candidates, r, threshold=2000):
    if len(candidates) == 0:
        return candidates
    idxs = tree.query_ball_point(candidates, r)
    mask = np.array([len(x) == 0 for x in idxs], dtype=bool)
    return candidates[mask]

def generate_clumps_kdtree_batchsafe(n_clumps, Rin_pc, Rout_pc, Rcloud_pc, alpha,
                                     external_clumps=None, external_Rcloud_pc=None,
                                     seed=10, batch_size=1000, max_attempts=1e7):
    Rcloud = Rcloud_pc * PARSEC
    Rcloud_ext = external_Rcloud_pc * PARSEC if (external_clumps is not None and external_Rcloud_pc is not None) else None

    Rin = Rin_pc * PARSEC
    Rout = Rout_pc * PARSEC
    min_dist = 2 * Rcloud  # for self-to-self
    buffer = 1e-6 * Rcloud

    alpha_factor = 1.0 - alpha
    norm_factor = Rout_pc**alpha_factor - Rin_pc**alpha_factor

    rng = np.random.default_rng(seed)
    ext_tree = cKDTree(external_clumps) if external_clumps is not None and len(external_clumps) > 0 else None
    external_min_dist = Rcloud + Rcloud_ext if Rcloud_ext is not None else None

    clumps = []
    attempts = 0

    while len(clumps) < n_clumps and attempts < max_attempts:
        us = rng.random(batch_size)
        r_pc = (us * norm_factor + Rin_pc**alpha_factor)**(1 / alpha_factor)
        rs = r_pc * PARSEC

        costheta = 2.0 * rng.random(batch_size) - 1.0
        sintheta = np.sqrt(1.0 - costheta**2)
        phi = 2.0 * PI * rng.random(batch_size)

        xs = rs * sintheta * np.cos(phi)
        ys = rs * sintheta * np.sin(phi)
        zs = rs * costheta

        candidates = np.stack([xs, ys, zs], axis=1)

        # 边界：球心不能越出外边界 Rcloud
        mask = (rs > Rin) & (rs < Rout - Rcloud)
        candidates = candidates[mask]

        # 与当前 clumps 比较
        if clumps:
            clump_tree = cKDTree(np.array(clumps))
            candidates = filter_candidates_kdtree(clump_tree, candidates, r=min_dist - buffer)

        # 与 external_clumps 比较
        if ext_tree and external_min_dist is not None:
            candidates = filter_candidates_kdtree(ext_tree, candidates, r=external_min_dist - buffer)

        # 与 batch 自己互检
        if len(candidates) > 1:
            batch_tree = cKDTree(candidates)
            conflict_pairs = batch_tree.query_pairs(r=min_dist - buffer)
            conflicted = set(i for i, j in conflict_pairs) | set(j for i, j in conflict_pairs)
            candidates = [p for i, p in enumerate(candidates) if i not in conflicted]

        clumps.extend(candidates[: n_clumps - len(clumps)])
        attempts += batch_size

        if attempts % (batch_size * 10) == 0:
            print(f"[INFO] Accepted {len(clumps)} / {n_clumps} after {attempts} attempts")

    if len(clumps) < n_clumps:
        raise RuntimeError(f"Only generated {len(clumps)} clumps after {attempts} attempts.")

    # 后验去重（保险）
    clumps = np.array(clumps)
    tree = cKDTree(clumps)
    final_conflicts = tree.query_pairs(r=min_dist - buffer)
    if final_conflicts:
        print(f"[WARN] Found {len(final_conflicts)} final overlap pairs. Removing one per pair...")
        to_remove = set(i for i, _ in final_conflicts)
        mask = np.ones(len(clumps), dtype=bool)
        mask[list(to_remove)] = False
        clumps = clumps[mask]

    return clumps

# ========= 新增：按 r^-alpha 把 [Rin,Rout] 切成“等测度薄壳” =========
def _split_shells_by_measure(alpha, Rin_pc, Rout_pc_effective, M):
    """
    将 [Rin, Rout_effective] 按 ∫ r^{-alpha}dr 的测度等分为 M 个薄壳。
    注意：Rout_pc_effective 已应考虑球心外缘收缩（Rout - Rcloud_pc）。
    """
    af = 1.0 - alpha
    m0 = Rin_pc**af
    m1 = Rout_pc_effective**af
    ms = np.linspace(m0, m1, M+1)
    return ms**(1.0/af)  # 长度 M+1 的壳层边界（pc）

# ========= 重写：两组同范围(1–10 kpc)、同半径(50pc)，分壳按比例着色 =========
def generate_two_clump_groups_from_filling_factor(Fv_1, Fv_2, alpha, seed=12345):
    """
    新逻辑：
    1) 在 1–10 kpc 内一次性生成 (Fv1+Fv2) 对应数量、半径=50pc 的全集，不重叠，整体遵从 r^-alpha。
    2) 用“等测度薄壳 + 每壳固定比例”的方式给全集着色：
       每个薄壳内，按 p1 = n1/(n1+n2) 的比例分给 Group1（余下给 Group2），
       确保两组在每个半径段的占比一致 → 两组都保持 r^-alpha 形状。
    3) 保存时按 clumps1 在前、clumps2 在后，写入一个文件。
    """
    # 统一范围 & 半径
    Rin_pc, Rout_pc = 1000.0, 10000.0
    Rcloud_pc = 50.0

    # 数量由 Fv 转换
    n1 = compute_nclumps(Fv_1, Rin_pc, Rout_pc, Rcloud_pc)
    n2 = compute_nclumps(Fv_2, Rin_pc, Rout_pc, Rcloud_pc)
    n_total = n1 + n2
    print(f"[Groups] n1={n1}, n2={n2}, total={n_total}, Rin={Rin_pc} pc, Rout={Rout_pc} pc, Rcl={Rcloud_pc} pc")

    # 若已有文件，直接跳过
    outdir = "clump_pos_CGM_ISM"

    os.makedirs(outdir, exist_ok=True)
    fname = f"{outdir}/clump_pos_Ncl1_{n1}_Ncl2_{n2}.txt"
    if os.path.exists(fname):
        print(f"✅ File already exists: {fname}, skipping generation.")
        return

    # ---- 先生成全集 ----
    clumps_all = generate_clumps_kdtree_batchsafe(
        n_clumps=n_total,
        Rin_pc=Rin_pc,
        Rout_pc=Rout_pc,
        Rcloud_pc=Rcloud_pc,
        alpha=alpha,
        external_clumps=None,
        external_Rcloud_pc=None,
        seed=seed,
        batch_size=2000  # 可根据机器略微调大
    )

    # ---- 分壳按比例着色（关键）----
    rng = np.random.default_rng(seed + 999)
    p1 = n1 / float(n_total)

    # 外缘要与生成一致：球心有效外半径为 (Rout - Rcloud)
    edges = _split_shells_by_measure(alpha, Rin_pc, Rout_pc - Rcloud_pc, M=max(64, min(256, n_total // 1500)))
    r_pc_all = np.linalg.norm(clumps_all, axis=1) / PARSEC

    labels = np.zeros(n_total, dtype=np.int8)  # 1=Group1, 2=Group2（0=未分配）
    left1 = n1

    for i in range(len(edges) - 1):
        r_lo, r_hi = edges[i], edges[i+1]
        idx = np.where((r_pc_all >= r_lo) & (r_pc_all < r_hi))[0]
        if idx.size == 0:
            continue
        want = p1 * idx.size
        base = int(np.floor(want))
        frac = want - base
        give = base + (1 if (frac > 0 and rng.random() < frac) else 0)
        give = min(give, left1, idx.size)
        if give > 0:
            pick = rng.choice(idx, size=give, replace=False)
            labels[pick] = 1
            left1 -= give

    if left1 > 0:
        pool = np.where(labels == 0)[0]
        extra = rng.choice(pool, size=left1, replace=False)
        labels[extra] = 1
    labels[labels == 0] = 2

    clumps1 = clumps_all[labels == 1]
    clumps2 = clumps_all[labels == 2]

    # （可选）最小距离抽查/打印
    tree_all = cKDTree(clumps_all)
    dists, _ = tree_all.query(clumps_all, k=2)
    dmin_pc = (dists[:, 1].min()) / PARSEC
    print(f"✅ Minimum clump-clump distance: {dmin_pc:.3f} pc")

    # ---- 保存（先 clumps1 后 clumps2）----
    all_clumps = np.vstack([clumps1, clumps2])
    np.savetxt(fname, all_clumps, fmt="%.8e")
    print(f" Saved total {len(all_clumps)} clumps to '{fname}'")

def generate_one_clump_group_from_filling_factor(Fv_1,  alpha, seed=12345):
    Rcloud_pc = 50
    Rin1, Rout1 = 1000, 10000
    n1 = compute_nclumps(Fv_1, Rin1, Rout1, Rcloud_pc)
    print(f"[Group 1] Fv={Fv_1:.5f}, n={n1}, Rin={Rin1} pc, Rout={Rout1} pc")

    os.makedirs("clump_pos", exist_ok=True)
    fname = f"clump_pos/clump_pos_Ncl1_{n1}.txt"
    if os.path.exists(fname):
        print(f"✅ File already exists: {fname}, skipping generation.")
        return

    clumps1 = generate_clumps_kdtree_batchsafe(
        n_clumps=n1,
        Rin_pc=Rin1,
        Rout_pc=Rout1,
        Rcloud_pc=Rcloud_pc,
        alpha=alpha,
        external_clumps=None,
        external_Rcloud_pc=0,
        seed=seed
    )

    tree1 = cKDTree(clumps1)
    dists1, _ = tree1.query(clumps1, k=2)
    dmin1_pc = (dists1[:, 1].min()) / PARSEC
    print(f"📘 [Group 1] Min internal clump distance: {dmin1_pc:.3f} pc")
    if dmin1_pc < 99.9:
        raise RuntimeError(f"❌ Group 1 clumps too close: min={dmin1_pc:.6f} pc < 99.9 pc")

    np.savetxt(fname, clumps1, fmt="%.8e")
    print(f" Saved total {len(clumps1)} clumps to '{fname}'")
