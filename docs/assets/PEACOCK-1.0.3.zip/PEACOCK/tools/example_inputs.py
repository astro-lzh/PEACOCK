"""Resolve the configuration and cloud catalogue for a bundled example."""

from pathlib import Path

from tools.engine_layout import ROOT


def bundled_inputs(profile, config=None, clump_file=None):
    """Associate a named example with its complete, fixed cloud catalogue.

    A copied or independently supplied configuration remains a custom input;
    it never silently inherits the bundled example's geometry.
    """
    relative = profile.get("example_config")
    example = (ROOT / relative).resolve() if relative else None
    selected = Path(config).resolve() if config is not None else example
    catalogue = Path(clump_file).resolve() if clump_file is not None else None
    if selected is not None and selected == example and catalogue is None:
        relative = profile.get("example_clumps")
        if relative:
            catalogue = (ROOT / relative).resolve()
    return selected, catalogue
