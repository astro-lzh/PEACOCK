# Choosing a line profile

Run `python3 peacock.py lines` from the source directory to list the exact
line IDs and supported backends. A profile supplies an atomic network, a
reference transition for frequency or velocity, and a scattering operator.
The reference wavelength in each name is in ångströms. A multiplet still
uses its full network. The aliases `lya`, `cii`, `civ` and `mgii` select
`HI1216`, `CII1334`, `CIV1548` and `MgII2796`, respectively.

| Line ID or group | Physical model | Backends |
| --- | --- | --- |
| `HI1216` | Resonant H I Lyα transfer | CPU, CUDA |
| `CII1334` | Coupled four-level C II network with prescribed lower-level populations and fluorescence | CPU, CUDA |
| `CIV1548`, `MgII2796` | Common resonance doublet operator with species-specific atomic data | CUDA |
| `AlII1670`, `FeII1608` | UV multilevel transfer | CPU, CUDA |
| `NV1239`, `NV1243` | Coupled N V doublet with two reference wavelengths | CPU, CUDA |
| `SII1250`, `SII1254`, `SII1259` | S II network with three reference wavelengths | CPU, CUDA |
| `SiII1190`, `SiII1193`, `SiII1526` | Si II multilevel transfer | CPU, CUDA |

Each profile uses its full atomic network. For example, N V 1239 and 1243
use the same coupled doublet with different velocity zero points. Si II 1526
includes a different set of transitions from Si II 1190 and 1193.

## Build the backend

```sh
python3 peacock.py build --backend cpu
python3 peacock.py build --backend cuda --arch compute_120
```

The CPU build produces one `peacock-cpu` executable. A full CUDA build
produces one `peacock-export` executable and one `transport.ptx`. On
Windows the executables have an `.exe` suffix. The CUDA module supports all 14 profiles. Line selection happens when
you run or prepare a case.

`compute_120` is the RTX 5090 example target. Use a target compatible with
your GPU and NVRTC; see the [CUDA guide](gpu-workflow.md).

The default build directories are `build/cpu` and `build/cuda`. Use
`build --output` for a different build directory and supply the same
directory as `--build-dir` to later commands. Choose a new build directory
when changing the compiler, optional CPU features or the CUDA architecture.
For CPU builds, `--openmp` enables threaded transport and `--hdf5` enables
HDF5 I/O. OpenMP requires a compatible compiler and runtime. HDF5 requires
its development libraries to be available through `pkg-config`.

## Select a line and run

```sh
python3 peacock.py run --line HI1216 --backend cpu --output run/lya
python3 peacock.py run --line SiII1190 --backend cpu --output run/si1190
python3 peacock.py run --line CIV1548 --backend cuda --output run/civ
```

`run` uses an existing backend build. When `--backend` is omitted, it
uses the first backend listed for the profile. Pass it explicitly when
choosing CUDA for a profile that also supports CPU.

Use a fresh output directory for each run. For a custom configuration,
pass `--config file.cfg`. Its line, reference units, lower-level
populations and cloud catalogue should match the selected profile.
`--nphot` sets the primary packet count. For CPU configurations with
native `<N>` placeholders, pass `--template` once per value in index
order, starting at 0. Custom CPU configurations read relative input paths from the
working directory where you invoke PEACOCK. The [cloud model
guide](cloud-model.md) describes catalogue inputs and cloud schema 2.

`CII1334` uses the same [quickstart wind](../examples/cii/README.md) on
CPU and CUDA: `examples/cii/quickstart.cfg` and its bundled complete cloud
catalogue. Physical settings and positions are shared; packet histories
need not match individually. Use `--clump-file` with a copied custom
configuration when it selects catalogue placement.

To inspect the CUDA inputs or reuse a build with a separate execution
step, follow the [CUDA workflow](gpu-workflow.md). Both `prepare` and
`execute` select the line with `--line`.

## Emission position

Set `position_mode` in the `[emission]` section.

| Mode | Position and initial direction |
| --- | --- |
| 1 | Luminosity-weighted cell, with emission near its center or spherical shell mid-radius |
| 2 | Luminosity-weighted cell, sampled uniformly in volume |
| 3 | Radial exponential source, with `position_param` as its scale in pc |
| 4 | Cartesian midplane, with a random initial direction |
| 5 | Cartesian boundary plane, with a random initial direction |
| 6 | Cartesian boundary plane, directed along the positive axis |
| 7 | Cartesian midplane, directed along the positive axis |

For a plane, `position_param` selects its normal axis with 0 for x, 1 for y
and 2 for z.

In spherical cells, mode 1 samples the cell's solid angle in spherical
coordinates. Mode 2 samples radius cubed uniformly between the two radial
faces.

The frequency modes are 0 for thermal and natural broadening, 1 for a
fixed Doppler offset, 2 for a Gaussian width in km/s, and 3 for a uniform
velocity half-width in km/s. Doublet mode 4 uses Gaussian components
with a 2:1 blue-to-red mixture. Widths and exponential source scales
must be finite and nonnegative.

## Source and data

The shared transport source is under `src/core/`. All four host scattering
operators use `src/physics/interact_hydrogen.c` and
`src/physics/physical_properties.c`. They share velocity sampling and
physical-property calculations while retaining their transition and
redistribution rules. Host I/O, grids and configuration also live under
`src/core/`.
The common CUDA module is under `backends/cuda/runtime/`. The line
catalog maps each profile to an operator and a runtime table in
`lines/runtime/<name>.atom`. Its atomic reference directory is
`lines/atomic-data/<name>/`.

Keep `atomic.atom` and the resolved configuration with each run. The
recorded line ID and SHA-256 checksums identify the data and executables
used for that case.
