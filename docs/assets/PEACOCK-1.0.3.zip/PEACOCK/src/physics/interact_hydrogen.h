#ifndef PEACOCK_INTERACT_HYDROGEN_H
#define PEACOCK_INTERACT_HYDROGEN_H

#include "photon.h"

/* Update the photon in its current cell after one gas scattering. */
void interact_hydrogen(photon *p);

#ifdef PEACOCK_ATOM_FINE_STRUCTURE
/* Direct one-piece probe for the C II sampling regression. Invalid input returns NaN. */
double sct_hyd_get_atom_parallel_vel_1piece(photon *p);
#endif

#endif
