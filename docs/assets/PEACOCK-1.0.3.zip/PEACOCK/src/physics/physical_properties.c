#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "physical_properties.h"

#ifdef PEACOCK_MULTILEVEL
#include <complex.h>
#include "dust_table.h"
#include "voigt_coefficients.h"
#else
#include "tlac_defs.h"
#include "misc/my_math.h"
#endif

inline double thermal_velocity_hydrogen(double T) {
  return sqrt(2.0 * BOLTZMANN_CONSTANT * T / HYDROGEN_MASS);
}

inline double doppler_freq_shift_hydrogen(double T) {
  return LYA_NU0 * thermal_velocity_hydrogen(T) / LIGHT_SPEED;
}

static void check_voigt_input(double damping, double detuning) {
  if (damping < 0.0 || !isfinite(damping) || !isfinite(detuning)) {
    fprintf(stderr, "Invalid Voigt input: damping=%g, detuning=%g.\n", damping, detuning);
    exit(EXIT_FAILURE);
  }
}

#ifdef PEACOCK_MULTILEVEL

/* H(a,x) = Re w(x+ia). The 40-term Weideman (1994) approximation uses
 * an asymptotic expansion in the far wings to avoid cancellation. */
double voigt_function_approx(double a, double x) {
  check_voigt_input(a, x);
  if (a == 0)
    return exp(-x * x);

  const double inverse_sqrt_pi = 0.56418958354775628695;
  const double asymptotic_radius = 40;
  const int asymptotic_terms = 8;
  double complex z = x + I * a;
  if (cabs(z) > asymptotic_radius) {
    double complex term = 1., sum = term, z_squared = z * z;
    for (int n = 1; n <= asymptotic_terms; n++) {
      term *= (2 * n - 1) / (2. * z_squared);
      sum += term;
    }
    return creal(I * inverse_sqrt_pi * sum / z);
  }

  const double complex denominator = weideman_L - I * z;
  const double complex argument = (weideman_L + I * z) / denominator;
  double complex polynomial = weideman_a[0];
  for (size_t i = 1; i < sizeof(weideman_a) / sizeof(weideman_a[0]); i++)
    polynomial = polynomial * argument + weideman_a[i];
  return fmax(0., creal(2 * polynomial / (denominator * denominator) +
                        inverse_sqrt_pi / denominator));
}

enum dust_column {
  DUST_WAVELENGTH,
  DUST_EXTINCTION,
  DUST_ALBEDO,
  DUST_ASYMMETRY
};

/* Linearly interpolate the supplied Draine table on its wavelength grid. */
static double dust_value(double x, double T, enum dust_column column) {
  const double microns_per_cm = 1e4;
  const double frequency = LYA_NU0 + x * doppler_freq_shift_hydrogen(T);
  if (!(frequency > 0.0) || !isfinite(frequency)) {
    fprintf(stderr, "Invalid frequency %g Hz for dust interpolation at x=%g and T=%g K.\n",
            frequency, x, T);
    exit(EXIT_FAILURE);
  }
  const double wavelength = LIGHT_SPEED / frequency * microns_per_cm;
  const size_t rows = sizeof(dust_table) / sizeof(dust_table[0]);
  if (wavelength < dust_table[0][DUST_WAVELENGTH] ||
      wavelength > dust_table[rows - 1][DUST_WAVELENGTH]) {
    fprintf(stderr, "Dust wavelength %.9g micron outside supplied Draine table\n", wavelength);
    exit(2);
  }
  size_t i = 0;
  while (i < rows - 2 && wavelength > dust_table[i + 1][DUST_WAVELENGTH])
    i++;
  const double fraction = (wavelength - dust_table[i][DUST_WAVELENGTH]) /
    (dust_table[i + 1][DUST_WAVELENGTH] - dust_table[i][DUST_WAVELENGTH]);
  return dust_table[i][column] * (1 - fraction) + dust_table[i + 1][column] * fraction;
}

double gas_scattering_cs(double x, double T) {
  return dust_value(x, T, DUST_EXTINCTION);
}

double dust_albedo(double x, double T) {
  return dust_value(x, T, DUST_ALBEDO);
}

double HG_asymmetry_parameter(double x, double T) {
  return dust_value(x, T, DUST_ASYMMETRY);
}

#else

/* Tasitsiomi (2006) fit for H(a,x), as given by Laursen (2010), §7.2.2.
 * The numerical coefficients below define the fit, valid above 2 K. */
double voigt_function_approx(double a, double x) {
  check_voigt_input(a, x);
  const double core_boundary_squared = 0.855;
  const double detuning_offset_squared = 3.42;
  const double wing_correction_scale = 21.0;
  const double x_squared = x * x;
  const double z = (x_squared - core_boundary_squared) / (x_squared + detuning_offset_squared);
  const double z_squared = z * z;
  double correction = 0.0;
  if (z > 0) {
    const double polynomial = 5.674 * z_squared * z_squared - 9.207 * z_squared * z +
      4.421 * z_squared + 0.1117 * z;
    correction = (1.0 + wing_correction_scale / x_squared) * a /
      (PI * (x_squared + 1.0)) * polynomial;
  }
  return correction * sqrt(PI) + exp(-x_squared);
}

inline double gas_scattering_cs(double x, double T) {
#ifdef SIMPLE_DUST
  /* Unit extinction for builds that explicitly select SIMPLE_DUST. */
  return 1.0;
#else
  /* Pei (1992) SMC extinction law. The effective dust density uses the
   * gas density scaled by metallicity relative to solar. */
  const double extinction_scale_cm2 = 4 * 1e-21;
  const double reference_extinction = 0.395;
  const double detuning_slope = 1.82e-5;
  const double inverse_reference_temperature = 1e-4;
  return extinction_scale_cm2 * (reference_extinction + DUST_FREQUENCY_DEPENDENT *
    detuning_slope * sqrt(T * inverse_reference_temperature) * x);
#endif
}

inline double dust_albedo(double x, double T) {
  return TLAC_DUST_ALBEDO;
}

inline double HG_asymmetry_parameter(double x, double T) {
  return TLAC_DUST_HG_G;
}

/* Reference component cross section. The weighted totals below include
 * the other components of the fine-structure multiplet or doublet. */
inline double hydrogen_scattering_cross_section(double x, double T) {
#if defined(PEACOCK_ATOM_FINE_STRUCTURE)
  const double oscillator_strength = LYA_F1;
  const double natural_width = LYA_DELTA_NU_L_1;
#else
  const double oscillator_strength = LYA_F12;
  const double natural_width = LYA_DELTA_NU_L;
#endif
  const double prefactor = oscillator_strength * sqrt(PI) *
    ELECTRON_CHARGE * ELECTRON_CHARGE / (ELECTRON_MASS * LIGHT_SPEED);
  const double doppler_width = doppler_freq_shift_hydrogen(T);
  const double a = natural_width / (2.0 * doppler_width);
  return prefactor / doppler_width * voigt_function_approx(a, x);
}

#if defined(PEACOCK_ATOM_FINE_STRUCTURE)

/* C II component order is 13, 23, 24. The last two originate in level 2. */
void cii_population_cross_sections(double x, double T, double ratio21, double sigma[3]) {
  if (!isfinite(ratio21) || ratio21 < 0.0) {
    fprintf(stderr, "C II requires finite n2/n1 >= 0; got %g\n", ratio21);
    exit(EXIT_FAILURE);
  }
  const double width = doppler_freq_shift_hydrogen(T);
  const double prefactor = sqrt(PI) * ELECTRON_CHARGE * ELECTRON_CHARGE /
    (ELECTRON_MASS * LIGHT_SPEED * width);
  sigma[0] = prefactor * LYA_F1 * voigt_function_approx(LYA_DELTA_NU_L_1 / (2 * width), x);
  sigma[1] = ratio21 * prefactor * LYA_F2 *
    voigt_function_approx(LYA_DELTA_NU_L_2 / (2 * width), x + DELTA_NU_12 / width);
  sigma[2] = ratio21 * prefactor * LYA_F3 *
    voigt_function_approx(LYA_DELTA_NU_L_3 / (2 * width), x + DELTA_NU_13 / width);
}

double cii_population_cross_section(double x, double T, double ratio21) {
  double sigma[3];
  cii_population_cross_sections(x, T, ratio21, sigma);
  return sigma[0] + sigma[1] + sigma[2];
}

#elif defined(PEACOCK_ATOM_DOUBLET)

/* The input detuning uses the blue component's Doppler width. */
void doublet_component_cross_sections(double x, double T, double sigma[2]) {
  const double blue_width = doppler_freq_shift_hydrogen(T);
  const double red_width = blue_width * (LINE_NU_RED / LINE_NU_BLUE);
  const double prefactor = sqrt(PI) * ELECTRON_CHARGE * ELECTRON_CHARGE /
    (ELECTRON_MASS * LIGHT_SPEED);
  const double red_x = (blue_width * x + LINE_DELTA_NU) / red_width;
  sigma[0] = (prefactor / blue_width) * LINE_F_BLUE *
    voigt_function_approx(LINE_GAMMA_BLUE / (4 * PI * blue_width), x);
  sigma[1] = (prefactor / red_width) * LINE_F_RED *
    voigt_function_approx(LINE_GAMMA_RED / (4 * PI * red_width), red_x);
}

inline double hydrogen_scattering_cross_section_double_line(double x, double T) {
  double sigma[2];
  doublet_component_cross_sections(x, T, sigma);
  return sigma[0] + sigma[1];
}

#endif
#endif
