#ifndef ATOMIC_NETWORK_H
#define ATOMIC_NETWORK_H
/* Storage limits for the supplied atom files. Each calculation uses only
 * the loaded counts, never the unused capacity. */
enum { RT_MAX_LOWER = 53, RT_MAX_UPPER = 3, RT_MAX_LINES = 53 };

typedef struct {
  int lower, upper;
  double A, nu, f, w2;
} rt_transition;

typedef struct {
  char name[32];
  int nlower, nupper, nlines, reference, atomic_number, ion_stage;
  double mass, reference_frequency, reference_gamma;
  double lower_energy[RT_MAX_LOWER], gamma[RT_MAX_UPPER];
  rt_transition lines[RT_MAX_LINES];
} rt_atom_data;

/* Select and validate an atom before parsing configuration. The selected
 * data and initialized population ratios are read-only during transport. */
int peacock_load_atom(const char *path);
extern const rt_atom_data *const rt_atom;
extern double rt_pop[RT_MAX_LOWER];

/* Atomic fields used by transport and output. */
#define RT_NAME (rt_atom->name)
#define RT_NLOWER (rt_atom->nlower)
#define RT_NUPPER (rt_atom->nupper)
#define RT_NLINES (rt_atom->nlines)
#define RT_REFERENCE (rt_atom->reference)
#define RT_Z (rt_atom->atomic_number)
#define RT_STAGE (rt_atom->ion_stage)
#define RT_MASS (rt_atom->mass)
#define RT_NU0 (rt_atom->reference_frequency)
#define RT_REFERENCE_GAMMA (rt_atom->reference_gamma)
#define rt_lines (rt_atom->lines)
#define rt_lower_E (rt_atom->lower_energy)
#define rt_gamma (rt_atom->gamma)

double rt_cross_sections(double x,double T,double *weights);
double rt_line_width(double x,double T);
double rt_line_detuning(int line,double x,double T);
double rt_phase_pdf(double mu,double W2);
double rt_raman_frequency(double nu,int in,int out,double beta_in,double beta_out);
double rt_frame_frequency(double nu,double beta_old,double beta_new);
void rt_validate_atom(void);
#endif
