#ifndef _PHYSICAL_PROPERTIES_H_
#define _PHYSICAL_PROPERTIES_H_

#if (defined(PEACOCK_ATOM_RESONANT) + defined(PEACOCK_ATOM_FINE_STRUCTURE) + \
     defined(PEACOCK_ATOM_DOUBLET) + defined(PEACOCK_MULTILEVEL)) != 1
#error Select one PEACOCK scattering operator.
#endif

#if defined(PEACOCK_ATOM_RESONANT) || defined(PEACOCK_ATOM_FINE_STRUCTURE)
#include "line_constants.h"
#else
/* CGS constants shared by the doublet and multilevel operators. The
 * resonant and fine-structure reference headers provide the same values. */
#define LIGHT_SPEED 29979245800.0
#define ELECTRON_MASS 9.10938e-28
#define GRAVITATIONAL_CONSTANT 6.67e-8
#define ELECTRON_CHARGE 4.803205e-10
#define PLANCK_CONSTANT 6.62607e-27
#define BOLTZMANN_CONSTANT 1.38065e-16
#define PROTON_MASS 1.672622e-24
#define PARSEC 3.085677581467192e18

#ifdef PEACOCK_ATOM_DOUBLET
#include "atomic_parameters.h"
#else
#include "atomic_network.h"
#define HYDROGEN_MASS RT_MASS
#define LYA_NU0 RT_NU0
#define LYA_F1 (rt_lines[RT_REFERENCE].f)
#define LYA_DELTA_NU_L_1 (RT_REFERENCE_GAMMA / (2 * 3.14159265358979323846))
#endif
#endif

/* Thermal Doppler speed (cm/s) and reference Doppler width (Hz). */
double thermal_velocity_hydrogen(double T);
double doppler_freq_shift_hydrogen(double T);

/* Dimensionless Voigt profile H(a, x) for finite detuning and damping >= 0. */
double voigt_function_approx(double a, double x);

/* Total dust extinction in cm^2, scattering albedo and phase asymmetry. */
double gas_scattering_cs(double x, double T);
double dust_albedo(double x, double T);
double HG_asymmetry_parameter(double x, double T);

#ifndef PEACOCK_MULTILEVEL
double hydrogen_scattering_cross_section(double x, double T);
#endif

#if defined(PEACOCK_ATOM_FINE_STRUCTURE)
/* Contributions are ordered 1->3, 2->3, 2->4 and weighted relative to n1. */
void cii_population_cross_sections(double x, double T, double ratio21, double sigma[3]);
double cii_population_cross_section(double x, double T, double ratio21);
#elif defined(PEACOCK_ATOM_DOUBLET)
/* Blue and red components evaluated at the same physical frequency. */
void doublet_component_cross_sections(double x, double T, double sigma[2]);
double hydrogen_scattering_cross_section_double_line(double x, double T);
#endif

#endif
