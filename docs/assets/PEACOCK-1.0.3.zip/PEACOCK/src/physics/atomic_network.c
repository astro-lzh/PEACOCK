#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "physical_properties.h"
#include "atomic_network.h"

static rt_atom_data loaded_atom;
const rt_atom_data *const rt_atom = &loaded_atom;
double rt_pop[RT_MAX_LOWER];

enum { ATOM_TOKEN_SIZE = 96, MAX_ATOMIC_NUMBER = 118 };
static const double decay_rate_relative_tolerance = 1e-12;

/* Return 1 for a complete token, 0 for EOF and -1 for invalid input. */
static int atom_token(FILE *file, char token[ATOM_TOKEN_SIZE]) {
  int ch;
  do {
    ch = fgetc(file);
  } while (ch != EOF && isspace(ch));
  if (ch == EOF) return ferror(file) ? -1 : 0;
  size_t n = 0;
  do {
    if (ch == 0 || n + 1 == ATOM_TOKEN_SIZE) return -1;
    token[n++] = (char)ch;
    ch = fgetc(file);
  } while (ch != EOF && !isspace(ch));
  token[n] = '\0';
  return ferror(file) ? -1 : 1;
}

static int atom_integer(FILE *file, int min, int max, int *value) {
  char token[ATOM_TOKEN_SIZE], *end;
  if (atom_token(file, token) != 1) return 0;
  errno = 0;
  long parsed = strtol(token, &end, 10);
  if (errno || end == token || *end || parsed < min || parsed > max) return 0;
  *value = (int)parsed;
  return 1;
}

static int atom_number(FILE *file, double *value) {
  char token[ATOM_TOKEN_SIZE], *end;
  if (atom_token(file, token) != 1) return 0;
  errno = 0;
  double parsed = strtod(token, &end);
  if (errno || end == token || *end || !isfinite(parsed)) return 0;
  *value = parsed;
  return 1;
}

static int decay_network_closed(const rt_atom_data *atom) {
  for (int upper = 0; upper < atom->nupper; upper++) {
    double sum = 0.0;
    for (int line = 0; line < atom->nlines; line++)
      if (atom->lines[line].upper == upper) sum += atom->lines[line].A;
    if (fabs(sum / atom->gamma[upper] - 1.0) > decay_rate_relative_tolerance) return 0;
  }
  return 1;
}

int peacock_load_atom(const char *path) {
  if (path == NULL) return 1;
  FILE *file = fopen(path, "r");
  if (file == NULL) {
    fprintf(stderr, "Cannot open multilevel atom %s: %s\n", path, strerror(errno));
    return 1;
  }
  rt_atom_data next = {0};
  char token[ATOM_TOKEN_SIZE];
  const char *field = "header";
  if (atom_token(file, token) != 1 || strcmp(token, "PEACOCK_ATOM_V1") ||
      atom_token(file, token) != 1 || strcmp(token, "multilevel") ||
      atom_token(file, token) != 1 || strlen(token) >= sizeof(next.name) ||
      token[strspn(token, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_")])
    goto invalid;
  strcpy(next.name, token);

  field = "level and transition counts or reference index";
  if (!atom_integer(file, 1, RT_MAX_LOWER, &next.nlower) ||
      !atom_integer(file, 1, RT_MAX_UPPER, &next.nupper) ||
      !atom_integer(file, 1, RT_MAX_LINES, &next.nlines) ||
      !atom_integer(file, 0, next.nlines - 1, &next.reference) ||
      !atom_integer(file, 1, MAX_ATOMIC_NUMBER, &next.atomic_number) ||
      !atom_integer(file, 1, next.atomic_number + 1, &next.ion_stage))
    goto invalid;
  field = "mass, reference frequency or reference width";
  if (!atom_number(file, &next.mass) || !(next.mass > 0) ||
      !atom_number(file, &next.reference_frequency) || !(next.reference_frequency > 0) ||
      !atom_number(file, &next.reference_gamma) || !(next.reference_gamma > 0))
    goto invalid;
  field = "lower-level energies";
  for (int i = 0; i < next.nlower; i++)
    if (!atom_number(file, &next.lower_energy[i])) goto invalid;
  field = "upper-level widths";
  for (int i = 0; i < next.nupper; i++)
    if (!atom_number(file, &next.gamma[i]) || !(next.gamma[i] > 0)) goto invalid;
  field = "transition records";
  for (int i = 0; i < next.nlines; i++) {
    rt_transition *line = &next.lines[i];
    if (!atom_integer(file, 0, next.nlower - 1, &line->lower) ||
        !atom_integer(file, 0, next.nupper - 1, &line->upper) ||
        !atom_number(file, &line->A) || !(line->A > 0) ||
        !atom_number(file, &line->nu) || !(line->nu > 0) ||
        !atom_number(file, &line->f) || line->f < 0 ||
        !atom_number(file, &line->w2) || fabs(line->w2) > 1)
      goto invalid;
  }
  field = "reference transition or decay network";
  if (next.reference_frequency != next.lines[next.reference].nu ||
      next.reference_gamma != next.gamma[next.lines[next.reference].upper] ||
      !decay_network_closed(&next))
    goto invalid;
  field = "trailing data";
  if (atom_token(file, token) != 0) goto invalid;
  if (fclose(file) != 0) {
    fprintf(stderr, "Cannot finish reading multilevel atom %s\n", path);
    return 1;
  }

  loaded_atom = next;
  memset(rt_pop, 0, sizeof(rt_pop));
  rt_pop[0] = 1.0;
  return 0;

invalid:
  fprintf(stderr, "Invalid multilevel atom %s (%s)\n", path, field);
  fclose(file);
  return 1;
}

/* Population ratios are initialized once before grid construction and become
 * read-only during OpenMP transport. The grid field n_HI stores n(lower 1). */
double rt_line_width(double x, double T) {
  return (LYA_NU0 + x * doppler_freq_shift_hydrogen(T)) *
    thermal_velocity_hydrogen(T) / LIGHT_SPEED;
}

double rt_line_detuning(int line, double x, double T) {
  return (LYA_NU0 + x * doppler_freq_shift_hydrogen(T) - rt_lines[line].nu) /
    rt_line_width(x, T);
}

double rt_cross_sections(double x, double T, double *weights) {
  const double D = rt_line_width(x, T), pi = 3.14159265358979323846;
  if(!(D > 0) || !isfinite(D)) {
    fprintf(stderr, "Invalid photon frequency/temperature\n");
    exit(2);
  }
  const double pref = sqrt(pi) * ELECTRON_CHARGE * ELECTRON_CHARGE /
    (ELECTRON_MASS * LIGHT_SPEED * D);
  double sum = 0;
  for(int j = 0; j < RT_NLINES; j++) {
    const rt_transition *l = &rt_lines[j];
    double s = 0;
    if(rt_pop[l->lower] > 0)
      s = rt_pop[l->lower] * pref * l->f *
        voigt_function_approx(rt_gamma[l->upper] / (4 * pi * D),
                              rt_line_detuning(j, x, T));
    if(weights)
      weights[j] = s;
    sum += s;
  }
  return sum;
}

double rt_phase_pdf(double mu, double W2) {
  return .5 * (1 + W2 * .25 * (3 * mu * mu - 1));
}

double rt_raman_frequency(double nu, int in, int out,
                          double beta_in, double beta_out) {
  return (nu * (1 - beta_in) + LIGHT_SPEED *
          (rt_lower_E[rt_lines[in].lower] - rt_lower_E[rt_lines[out].lower])) /
    (1 - beta_out);
}

double rt_frame_frequency(double nu, double beta_old, double beta_new) {
  return nu / (1 - beta_old) * (1 - beta_new);
}

void rt_validate_atom(void) {
  for(int i = 0; i < RT_NLOWER; i++)
    if(!isfinite(rt_pop[i]) || rt_pop[i] < 0) {
      fprintf(stderr, "Invalid lower-level population %d\n", i + 1);
      exit(2);
    }
  if (!decay_network_closed(rt_atom)) {
    fprintf(stderr, "Nonclosing decay network\n");
    exit(2);
  }
}
