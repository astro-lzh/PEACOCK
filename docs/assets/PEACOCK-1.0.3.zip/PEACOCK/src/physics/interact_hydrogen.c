/* Scalar scattering operators for Lyalpha, C II, resonance doublets and
 * multilevel UV atoms. Geometry and transfer call the same entry point. */
#include <assert.h>
#include <math.h>
#include <stdlib.h>

#include "tlac_defs.h"

#ifdef TWO_PHOTON_DESTRUCTION
#include <gsl/gsl_sf_erf.h>
#endif

#include "emission.h"
#include "grid.h"
#include "interact_hydrogen.h"
#include "misc/messages.h"
#include "misc/my_math.h"
#include "misc/rand_tools.h"
#include "physical_properties.h"
#include "scattering_fit.h"

#if (defined(PEACOCK_ATOM_RESONANT) + defined(PEACOCK_ATOM_FINE_STRUCTURE) + \
     defined(PEACOCK_ATOM_DOUBLET) + defined(PEACOCK_MULTILEVEL)) != 1
#error Select one PEACOCK scattering operator.
#endif

/* Values accepted by the tlac_defs.h compile-time switches. */
#define PARALLEL_SAMPLER_ONE_PIECE 0
#define PARALLEL_SAMPLER_LAURSEN 1
#define PARALLEL_SAMPLER_FIVE_PIECE 2
#define SIMPLE_SCATTER_ISOTROPIC 1
#define SIMPLE_SCATTER_ORTHOGONAL 2

#if defined(PEACOCK_ATOM_FINE_STRUCTURE)
#if TLAC_XCRIT != 0
#error C II fluorescence requires TLAC_XCRIT=0.
#endif
#ifdef TWO_PHOTON_DESTRUCTION
#error Lyalpha two-photon destruction is not a C II channel.
#endif
#endif

static double sample_maxwellian_transverse_velocity(void) {
  return rand_gaussian(1.0 / sqrt(2.0));
}

/* Unit-vector dot products and analytic phase inversions can round past
 * the endpoints. Leave nonfinite values visible to the caller. */
#if defined(PEACOCK_ATOM_RESONANT) || \
    (defined(PEACOCK_ATOM_DOUBLET) && !defined(SIMPLE_HYDROGEN_SCATTER))
static double clamp_direction_cosine(double cosine) {
  if (!isfinite(cosine)) return cosine;
  if (cosine > 1.0) return 1.0;
  if (cosine < -1.0) return -1.0;
  return cosine;
}
#endif

static int valid_parallel_input(double x, double damping) {
  return isfinite(x) && isfinite(damping) && damping > 0.0;
}

#if !defined(PEACOCK_ATOM_DOUBLET) || !defined(TLAC_GPU_BUILD)
static double checked_parallel_velocity(double velocity, const char *model) {
  if (!isfinite(velocity)) {
    print_error("Invalid %s parallel velocity sample.", model);
    exit(EXIT_FAILURE);
  }
  return velocity;
}
#endif

#if defined(PEACOCK_ATOM_FINE_STRUCTURE) || \
    (!defined(PEACOCK_MULTILEVEL) && \
     SCT_HYD_GET_ATOM_PARALLEL_VELOCITY_ALG == PARALLEL_SAMPLER_ONE_PIECE)
/* One Lorentzian envelope, accepted with its Gaussian weight. */
static double sample_parallel_one_piece(const photon *p) {
  const double absolute_detuning = fabs(p->x);
  double velocity, acceptance_draw;
  do {
    const double proposal_draw = rand_uniform();
    velocity = absolute_detuning + p->a * tan(proposal_draw * PI * sign(p->a) + 0.5 * PI);
    acceptance_draw = rand_uniform();
  } while (!isfinite(velocity) || !(acceptance_draw <= exp((-1.0) * velocity * velocity)));

#ifdef PEACOCK_ATOM_RESONANT
  return (p->x < 0 ? -1 : 1) * velocity;
#else
  return p->x < 0 ? -velocity : velocity;
#endif
}
#endif

#ifdef PEACOCK_ATOM_FINE_STRUCTURE
double sct_hyd_get_atom_parallel_vel_1piece(photon *p) {
  if (!valid_parallel_input(p->x, p->a)) return NAN;
  return sample_parallel_one_piece(p);
}
#endif

#if defined(PEACOCK_MULTILEVEL) || \
    SCT_HYD_GET_ATOM_PARALLEL_VELOCITY_ALG != PARALLEL_SAMPLER_ONE_PIECE
#ifdef PEACOCK_MULTILEVEL
typedef double three_piece_real;
#else
typedef float three_piece_real;
#endif

/* Zheng & Miralda-Escudé (2002), as used by Laursen (2010).
 * Multilevel UV uses double precision; the scalar operators use float. */
static double sample_parallel_three_piece(const photon *p, double damping) {
  const three_piece_real absolute_detuning = fabs(p->x);
  if (!isfinite(absolute_detuning)) return NAN;
  three_piece_real switch_velocity;

#if SCT_HYD_GET_ATOM_PARALLEL_VELOCITY_ALG == PARALLEL_SAMPLER_LAURSEN
  const double small_detuning = 0.2;
  const double envelope_correction = 0.01;
  const double detuning_slope = 1.2;
  const double wing_switch_velocity = 4.5;
  /* Apply the interior fit strictly between the two detuning joins. */
  switch_velocity = 0;
  if (absolute_detuning >= small_detuning) {
    if (small_detuning < absolute_detuning && absolute_detuning < p->x_cw)
      switch_velocity = absolute_detuning -
        envelope_correction * pow(damping, 1. / 6.) * exp(detuning_slope * absolute_detuning);
    else if (absolute_detuning > p->x_cw)
      switch_velocity = wing_switch_velocity;
  }
#else
  const double switch_fraction = 0.97;
  switch_velocity = switch_fraction * absolute_detuning;
#endif

  const three_piece_real switch_weight = exp(-switch_velocity * switch_velocity);
  const three_piece_real switch_angle = atan((switch_velocity - absolute_detuning) / damping);
  const three_piece_real left_probability = (switch_angle + 0.5 * PI) /
    ((1 - switch_weight) * switch_angle + (1 + switch_weight) * 0.5 * PI);
  if (!isfinite(left_probability)) return NAN;
  three_piece_real velocity, acceptance_test;
  do {
    const three_piece_real region_draw = rand_uniform();
    three_piece_real proposal_angle;
    if (region_draw > left_probability)
      proposal_angle = switch_angle + (0.5 * PI - switch_angle) * rand_uniform();
    else
      proposal_angle = -0.5 * PI + (switch_angle + 0.5 * PI) * rand_uniform();

    velocity = damping * tan(proposal_angle) + absolute_detuning;
    /* At equality, use the left proposal and the right-side weight. */
    if (region_draw < left_probability)
      acceptance_test = exp(velocity * velocity) * rand_uniform();
    else
      acceptance_test = switch_weight * exp(velocity * velocity) * rand_uniform();
  } while (!(acceptance_test <= 1));

  const three_piece_real detuning_sign = p->x < 0 ? -1 : 1;
  return velocity * detuning_sign;
}
#endif

#if defined(PEACOCK_MULTILEVEL) || \
    SCT_HYD_GET_ATOM_PARALLEL_VELOCITY_ALG == PARALLEL_SAMPLER_FIVE_PIECE
/* Dijkstra's five-region proposal uses Gaussian envelope plateaus with
 * joins at +/-inner_join and +/-outer_join. */
static double sample_parallel_five_piece(const photon *p, double a) {
  const double x = fabs(p->x);
  const double damping_fit_scale = 0.3;
  const double outer_base = 6.0, outer_log_coefficient = 0.375;
  const double inner_base = 2.25, inner_turn_coefficient = 0.55;
  const double inner_log_coefficient = 0.025;
  const int inner_turn_scale = 3, inner_turn_center = 4;
  const double outer_join = (outer_base + outer_log_coefficient * damping_fit_scale * log(a))
    * 2.0 * atan(sqrt(x)) / PI;
  const double inner_join = inner_base -
    (inner_turn_coefficient + inner_log_coefficient * damping_fit_scale * log(a))
    * atan(inner_turn_scale * (x - inner_turn_center));

#if defined(PEACOCK_ATOM_RESONANT) || defined(PEACOCK_ATOM_DOUBLET)
  /* The resonant and doublet operators select the three-region sampler
   * before drawing if the five-region joins fail their ordering test. */
  if (!(isfinite(outer_join) && isfinite(inner_join) &&
        0.0 < inner_join && inner_join < outer_join && outer_join < x))
    return sample_parallel_three_piece(p, a);
#endif

  const double outer_weight = exp(-outer_join * outer_join);
  const double inner_weight = exp(-inner_join * inner_join);
  double area1 = outer_weight / a * atan(a / (outer_join + x));
  double area2 = area1 + inner_weight / a *
    atan((a * (outer_join - inner_join)) /
         (a * a + (inner_join + x) * (outer_join + x)));
  double area3 = area2 + 1.0 / a *
    atan(2.0 * inner_join * a / (x * x + a * a - inner_join * inner_join));
  double area4 = area3 + (inner_weight / a) *
    atan(a * (outer_join - inner_join) / (a * a + (outer_join - x) * (inner_join - x)));
  const double total_area = area4 + (outer_weight / a) * (atan(a / (outer_join - x)) + PI);

#if defined(PEACOCK_ATOM_RESONANT) || defined(PEACOCK_ATOM_DOUBLET)
  if (!(isfinite(area1) && isfinite(area2) && isfinite(area3) &&
        isfinite(area4) && isfinite(total_area) &&
        0.0 < area1 && area1 < area2 && area2 < area3 && area3 < area4 && area4 < total_area))
    return sample_parallel_three_piece(p, a);
#else
  if (!(total_area > 0.0) || !isfinite(total_area)) return NAN;
#endif

  area1 /= total_area;
  area2 /= total_area;
  area3 /= total_area;
  area4 /= total_area;
  const double inverse_total_area = 1.0 / total_area;
  const double minimum_tail_angle = 1e-12;

  double velocity, acceptance_draw, acceptance_ratio;
  do {
    const double region_draw = rand_uniform();
    double envelope_weight;
    if (region_draw < area1) {
      double proposal_angle = region_draw * a / (inverse_total_area * outer_weight);
      if (proposal_angle == 0.0)
        proposal_angle = minimum_tail_angle;
      velocity = x + a / tan(proposal_angle);
      envelope_weight = outer_weight;
    } else if (region_draw > area1 && region_draw < area2) {
      const double proposal_angle = a * (region_draw - area1) /
        (inverse_total_area * inner_weight);
      const double tangent_shift = -1.0 * (outer_join + x) / a;
      velocity = x + a * ((tan(proposal_angle) + tangent_shift) /
                           (1.0 - tangent_shift * tan(proposal_angle)));
      envelope_weight = inner_weight;
    } else if (region_draw > area2 && region_draw < area3) {
      const double proposal_angle = a * (region_draw - area2) / inverse_total_area;
      const double tangent_shift = (inner_join + x) / a;
      velocity = x + a * (tan(proposal_angle) - tangent_shift) /
        (1 + tangent_shift * tan(proposal_angle));
      envelope_weight = 1.0;
    } else if (region_draw > area3 && region_draw < area4) {
      const double proposal_angle = a * (region_draw - area3) /
        (inner_weight * inverse_total_area) + atan((inner_join - x) / a);
      velocity = x + a * tan(proposal_angle);
      envelope_weight = inner_weight;
    } else {
      const double proposal_angle = a * (region_draw - area4) /
        (inverse_total_area * outer_weight);
      const double tangent_shift = (outer_join - x) / a;
      velocity = x + a * (tan(proposal_angle) + tangent_shift) /
        (1 - tangent_shift * tan(proposal_angle));
      envelope_weight = outer_weight;
    }

    const double envelope_edge = sqrt(-1. * log(envelope_weight));
    acceptance_ratio = exp(-1. * (velocity * velocity - envelope_edge * envelope_edge));
    acceptance_draw = rand_uniform();
  } while (!(acceptance_draw <= acceptance_ratio));

  const double detuning_sign = p->x < 0 ? -1 : 1;
  return velocity * detuning_sign;
}
#endif

static double sample_parallel_velocity(const photon *p) {
  if (!valid_parallel_input(p->x, p->a)) return NAN;
#if defined(PEACOCK_MULTILEVEL) || \
    SCT_HYD_GET_ATOM_PARALLEL_VELOCITY_ALG == PARALLEL_SAMPLER_FIVE_PIECE
  const double five_piece_threshold = 3.5;
  return fabs(p->x) < five_piece_threshold
    ? sample_parallel_three_piece(p, p->a)
    : sample_parallel_five_piece(p, p->a);
#elif SCT_HYD_GET_ATOM_PARALLEL_VELOCITY_ALG == PARALLEL_SAMPLER_ONE_PIECE
  return sample_parallel_one_piece(p);
#elif SCT_HYD_GET_ATOM_PARALLEL_VELOCITY_ALG == PARALLEL_SAMPLER_LAURSEN
  return sample_parallel_three_piece(p, p->a);
#else
#error Unsupported atom parallel velocity algorithm.
#endif
}

#if defined(PEACOCK_ATOM_DOUBLET) || defined(PEACOCK_MULTILEVEL)
/* The Gaussian core and Cauchy tails together cover the real line. */
static const double far_wing_threshold = 12.0;

static double sample_far_parallel_velocity(double signed_x, double a) {
  if (!valid_parallel_input(signed_x, a)) return NAN;
  const double max_core_half_width = 12.0;
  const double x = fabs(signed_x);
  const double h = fmin(max_core_half_width, x * .5);
  const double bound = (x - h) * (x - h) + a * a;
  const double left = atan2(a, x + h);
  const double right = atan2(a, h - x);
  const double core = sqrt(PI) * erf(h) / bound;
  const double tail = exp(-h * h) * (left + right) / a;
  if (!isfinite(bound) || !(bound > 0) || !isfinite(core) || core < 0 ||
      !isfinite(tail) || tail < 0 || !isfinite(core + tail) || !(core + tail > 0))
    return NAN;
  /* The attempt budget counts both envelope attempts and the nested
   * Gaussian proposals without consuming random draws. Exhaustion
   * signals a numerical failure. */
  const unsigned int max_operations = 1048576u;
  unsigned int operations = 0;
  for (;;) {
    if (operations >= max_operations) return NAN;
    ++operations;
    double u;
    if (rand_uniform() * (core + tail) < core) {
      do {
        if (operations >= max_operations) return NAN;
        ++operations;
        u = rand_gaussian(1 / sqrt(2.));
      } while (fabs(u) > h);
      if (rand_uniform() <= bound / ((x - u) * (x - u) + a * a))
        return signed_x < 0 ? -u : u;
    } else {
      double q = rand_uniform() * (left + right);
      if (q <= 0) continue;
      if (q < left) {
        u = x - a / tan(q);
      } else {
        q -= left;
        if (q <= 0) continue;
        u = x + a / tan(q);
      }
      if (isfinite(u) && fabs(u) >= h && rand_uniform() <= exp(h * h - u * u))
        return signed_x < 0 ? -u : u;
    }
  }
}
#endif

#if defined(PEACOCK_ATOM_RESONANT) || defined(PEACOCK_ATOM_DOUBLET)
#ifdef TWO_PHOTON_DESTRUCTION
static double mean_core_scatterings(double xcrit) {
  const double core_probability = gsl_sf_erf(xcrit);
  return 1.0 / (1 - core_probability);
}

static double two_photon_destruction_probability(const photon *p) {
  const double n_p = TWO_PHOTON_DESTRUCTION * p->curr_cell->n_HI;
  const double q2p2s = 1.8e-4; // weak temperature dependence
  const double A_alpha = 6.25e8; // Einstein A coefficient
  return n_p * q2p2s / (n_p * q2p2s + A_alpha);
}
#endif

/* The ordinary perpendicular velocity is Maxwellian. Core skipping, when
 * configured, draws from a truncated Gaussian. */
static double sample_orthogonal_velocity(photon *p) {
#if TLAC_XCRIT < 0
  const double activation_optical_depth = 1.0;
  const double core_skip_scale = 5.;
  double xcrit;
  const double atau0 = p->a * get_dist_to_wall(p->grid, p->curr_cell, p->pos) *
    hydrogen_scattering_cross_section(0, p->curr_cell->T) * p->curr_cell->n_HI;
  const double xcw = p->x_cw;
  if (atau0 > activation_optical_depth)
    xcrit = fmin(pow(atau0, 1. / 3.) / core_skip_scale, -TLAC_XCRIT);
  else
    xcrit = 0.0;
#else
  const double xcrit = TLAC_XCRIT;
  const double xcw = TLAC_XCRIT;
#endif

  if (!(fabs(p->x) < xcw))
    return sample_maxwellian_transverse_velocity();

  for (;;) {
#ifdef TWO_PHOTON_DESTRUCTION
    const double single_probability = two_photon_destruction_probability(p);
    if (single_probability >= 1.0) {
      p->curr_tau = -1.0;
      return 0.0;
    }
    const double destruction_probability = 1 - pow(1.0 - single_probability,
                                                    mean_core_scatterings(xcrit));
    assert(destruction_probability >= 0);
    assert(destruction_probability <= 1);
    assert(isfinite(destruction_probability));
    if (rand_uniform() < destruction_probability) {
      p->curr_tau = -1.0;
      return 0.0;
    }
#endif

#ifdef PEACOCK_ATOM_RESONANT
    double uniform;
    do { uniform = rand_uniform(); } while (uniform == 0.0);
    return sqrt(xcrit * xcrit - log(uniform)) * cos(2 * PI * rand_uniform());
#else
    const double velocity = sqrt(xcrit * xcrit - log(rand_uniform())) *
      cos(2 * PI * rand_uniform());
    if (isfinite(velocity)) return velocity;
#ifdef DEBUG
    print_error("Retrying nonfinite perpendicular velocity: xcrit=%e, x=%e, xcw=%e",
                xcrit, p->x, p->x_cw);
#endif
#endif
  }
}
#endif

#if !defined(SIMPLE_HYDROGEN_SCATTER) && \
    (defined(PEACOCK_ATOM_RESONANT) || defined(PEACOCK_ATOM_DOUBLET))
/* Invert the blue-component phase distribution from Laursen (2010), Eq. 3.27. */
static double sample_blue_scattering_angle(void) {
  const double u = rand_uniform();
  const double discriminant_root = sqrt(2325.0 + 5184.0 * (u - 1) * u);
  const double cubic_root = pow(36.0 - 72.0 * u + discriminant_root, 1.0 / 3.0);
  const double cube_root_three = 1.4422495703074083;
  const double numerator = 7.0 * cube_root_three * cube_root_three -
    cube_root_three * cubic_root * cubic_root;
  const double denominator = 3.0 * cubic_root;
  const double mu = numerator / denominator;
  return acos(clamp_direction_cosine(mu));
}
#endif

#if defined(SIMPLE_HYDROGEN_SCATTER) && !defined(PEACOCK_MULTILEVEL)
static void sample_simple_scattering_direction(photon *p) {
#if SIMPLE_HYDROGEN_SCATTER == SIMPLE_SCATTER_ISOTROPIC
  rand_direction_3d(p->dir);
#elif SIMPLE_HYDROGEN_SCATTER == SIMPLE_SCATTER_ORTHOGONAL
  rotrand3d_angle(p->dir, 0.5 * PI, p->dir);
#else
#error SIMPLE_HYDROGEN_SCATTER must be 1 (isotropic) or 2 (orthogonal).
#endif
}
#endif

#if defined(PEACOCK_ATOM_RESONANT)
#ifndef SIMPLE_HYDROGEN_SCATTER
/* The core mixes isotropic and blue-component dipole scattering.
 * The far wing uses the Rayleigh phase function (Laursen 2010, Eq. 3.28). */
static void sample_resonant_direction(photon *p) {
  const int in_core = fabs(p->x) < p->x_cw;
  const double draw = rand_uniform();
#ifdef DEBUG
  double previous[] = {p->dir[0], p->dir[1], p->dir[2]};
#endif
  double angle;
  if (in_core) {
    const double isotropic_probability = 0.3333333333;
    if (draw > isotropic_probability) {
      angle = sample_blue_scattering_angle();
    } else {
      rand_direction_3d(p->dir);
      return;
    }
  } else {
    const double discriminant_root = sqrt(5 + 16 * draw * (draw - 1));
    const double cubic_root = pow(2 - 4 * draw + discriminant_root, 1. / 3.);
    const double mu = (1 - cubic_root * cubic_root) / cubic_root;
    angle = acos(clamp_direction_cosine(mu));
  }
  rotrand3d_angle(p->dir, angle, p->dir);
#ifdef DEBUG
  if (!approx_equal(angle_vec3d(previous, p->dir), angle))
    print_error("Scattering angle differs from the requested angle.");
#endif
}
#endif

static void scatter_atom(photon *p) {
  double old_dir[] = {p->dir[0], p->dir[1], p->dir[2]};
#ifdef SIMPLE_HYDROGEN_SCATTER
  sample_simple_scattering_direction(p);
#else
  sample_resonant_direction(p);
#endif
  p->sc_dir_bulk = cell_velocity_scalar_product(p->curr_cell, p->dir, p->pos, p->grid);

  /* The resonant operator samples velocities after the outgoing direction. */
  p->u_scatter_last[0] = checked_parallel_velocity(sample_parallel_velocity(p), "Ly-alpha");
#ifdef TWO_PHOTON_DESTRUCTION
  if (p->curr_tau < 0) return;
#endif
  p->u_scatter_last[1] = sample_orthogonal_velocity(p);
  const double mu = clamp_direction_cosine(scalar_product_3d(old_dir, p->dir));
  p->x = p->x - p->u_scatter_last[0] + p->u_scatter_last[0] * mu +
    p->u_scatter_last[1] * sqrt(1 - mu * mu);
}
#elif defined(PEACOCK_ATOM_FINE_STRUCTURE)
/* Scalar unpolarized C II, independent upper levels, fixed populations.
 * No upper-J interference or Stokes-vector transport is included.
 * Keep one absorption channel throughout velocity, decay and direction draws.
 */
typedef enum { CII_13=0, CII_23=1, CII_24=2 } cii_transition;
enum { CII_LOWER_GROUND = 1, CII_LOWER_FINE_STRUCTURE = 2 };
typedef struct { cii_transition line; int lower_out; } cii_event;

static cii_transition sct_cii_select_transition(const photon *p) {
  double w[3];
  cii_population_cross_sections(p->x, p->curr_cell->T,
                               p->emission_cfg->CII_ratio_21, w);
  const double total = w[0]+w[1]+w[2];
  if(!(total > 0.0) || !isfinite(total)) {
    print_error("C II gas event has invalid total absorption cross section.");
    exit(EXIT_FAILURE);
  }
  const double q = rand_uniform()*total;
  if(q < w[0]) return CII_13;
  if(q < w[0]+w[1]) return CII_23;
  return CII_24;
}

static double sct_cii_parallel_velocity(const photon *p, cii_transition line) {
  /* The single-line rejection sampler needs the selected line's detuning. */
  photon local = *p;
  const double D = doppler_freq_shift_hydrogen(p->curr_cell->T);
  const double offsets[] = {0.0, DELTA_NU_12/D, DELTA_NU_13/D};
  const double widths[] = {LYA_DELTA_NU_L_1, LYA_DELTA_NU_L_2, LYA_DELTA_NU_L_3};
  local.x += offsets[line];
  local.a = widths[line]/(2*D);
  local.x_cw = core_wing_boundary(local.a);
  return sample_parallel_velocity(&local);
}

static cii_event sct_cii_sample_event(photon *p) {
  cii_event e;
  e.line = sct_cii_select_transition(p);
  p->u_scatter_last[0] = checked_parallel_velocity(sct_cii_parallel_velocity(p, e.line), "C II");
  /* Ordinary Maxwellian transverse velocity; Ly-alpha core skipping is
   * not valid for this multilevel fluorescence problem. */
  p->u_scatter_last[1] = sample_maxwellian_transverse_velocity();
  e.lower_out = e.line == CII_24 ? CII_LOWER_FINE_STRUCTURE :
    (rand_uniform() < CII_A31 / (CII_A31 + CII_A32) ?
     CII_LOWER_GROUND : CII_LOWER_FINE_STRUCTURE);
  return e;
}

#ifndef SIMPLE_HYDROGEN_SCATTER
static double sct_cii_path_w2(cii_event e) {
  /* W2 = w^(2)(Ju,Ji)*w^(2)(Ju,Jf), electric-dipole 6-j factors.
   * p(mu) = 1/2 + W2*(3*mu^2-1)/8; uniform azimuth.
   */
  const double w2_ground_resonance = 0.5;        /* 1 -> 3 -> 1 */
  const double w2_fine_structure_resonance = 0.32; /* 2 -> 3 -> 2 */
  const double w2_upper_four_resonance = 0.28;    /* 2 -> 4 -> 2 */
  const double w2_fluorescent_branch = -0.4;       /* 1 -> 3 -> 2 or reverse */
  if (e.line == CII_24) return w2_upper_four_resonance;
  if (e.line == CII_13)
    return e.lower_out == CII_LOWER_GROUND ? w2_ground_resonance : w2_fluorescent_branch;
  return e.lower_out == CII_LOWER_FINE_STRUCTURE ?
    w2_fine_structure_resonance : w2_fluorescent_branch;
}

static void sct_cii_set_direction(photon *p, cii_event e) {
  const double W2 = sct_cii_path_w2(e);
  const double max_pdf = fmax(0.5-W2/8.0, 0.5+W2/4.0);
  double mu;
  do {
    mu = 2*rand_uniform()-1;
  } while(rand_uniform()*max_pdf > 0.5+W2*(3*mu*mu-1)/8.0);
  rotrand3d_angle(p->dir, acos(mu), p->dir);
}

#endif

static double sct_cii_frequency_from_sample(photon *p, cii_event e,
                                           double old_dir[], double new_dir[]) {
  const double mu = fmax(-1.0, fmin(1.0, scalar_product_3d(old_dir, new_dir)));
  const int lower_in = e.line == CII_13 ? CII_LOWER_GROUND : CII_LOWER_FINE_STRUCTURE;
  const double shift = (lower_in-e.lower_out)*CII_FINE_STRUCTURE_NU /
                       doppler_freq_shift_hydrogen(p->curr_cell->T);
  /* Coherent Raman: nu_out(atom) = nu_in(atom)+(E_i-E_f)/h.
   * Common blue-line x and common Doppler width, first-order Doppler
   * approximation nu_in ~ nu_out ~ nu0 in velocity factors, no recoil.
   * BOTH conversion directions require the incoming -u_parallel term.
   */
  return p->x + shift + p->u_scatter_last[0]*(mu-1.0)
    + p->u_scatter_last[1]*sqrt(fmax(0.0, 1.0-mu*mu));
}

static void scatter_atom(photon *p) {
  double old_dir[3];
  for(int i=0; i<3; i++) old_dir[i] = p->dir[i];
  const cii_event e = sct_cii_sample_event(p);
#ifdef SIMPLE_HYDROGEN_SCATTER
  sample_simple_scattering_direction(p);
#else
  sct_cii_set_direction(p, e);
#endif
  p->sc_dir_bulk = cell_velocity_scalar_product(p->curr_cell, p->dir, p->pos, p->grid);
  p->x = sct_cii_frequency_from_sample(p, e, old_dir, p->dir);
}
#elif defined(PEACOCK_ATOM_DOUBLET)
/* Independent fine-structure transitions in scalar, unpolarized RT.
 * Line identity belongs to one scattering event, not to the photon history.
 * The two amplitudes are not interfered in this approximation.
 */
typedef enum { LINE_BLUE, LINE_RED } doublet_transition;

static doublet_transition sct_doublet_select_transition(const photon *p) {
  double sigma[2];
  doublet_component_cross_sections(p->x, p->curr_cell->T, sigma);
  const double total = sigma[0] + sigma[1];
  if (!(total > 0) || !isfinite(total)) {
    print_error("Invalid %s doublet opacity", LINE_ION_NAME);
    exit(EXIT_FAILURE);
  }
  return rand_uniform() * total < sigma[0] ? LINE_BLUE : LINE_RED;
}

static double sct_doublet_parallel_velocity(const photon *p, doublet_transition line) {
  photon local = *p;
  const int blue = line == LINE_BLUE;
  const double blue_width = doppler_freq_shift_hydrogen(p->curr_cell->T);
  const double width_ratio = blue ? 1.0 : LINE_NU_RED / LINE_NU_BLUE;
  const double component_width = blue_width * width_ratio;
  local.x = blue ? p->x : (blue_width * p->x + LINE_DELTA_NU) / component_width;
  local.a = (blue ? LINE_GAMMA_BLUE : LINE_GAMMA_RED) / (4 * PI * component_width);
  local.x_cw = core_wing_boundary(local.a);
  const double absolute_detuning = fabs(local.x);
  /* Stable exact two-envelope rejection for distant wings. */
  if (absolute_detuning > far_wing_threshold)
    return sample_far_parallel_velocity(local.x, local.a);
  return sample_parallel_velocity(&local);
}

#ifndef SIMPLE_HYDROGEN_SCATTER
static void sct_doublet_set_direction(photon *p, doublet_transition line) {
  if (line == LINE_BLUE) {
    /* p(mu) = 7/16 + 3 mu^2/16 for S_1/2 -> P_3/2. */
    const double angle = sample_blue_scattering_angle();
    rotrand3d_angle(p->dir, angle, p->dir);
  } else {
    /* S_1/2 -> P_1/2: isotropic, p(mu) = 1/2. */
    rand_direction_3d(p->dir);
  }
}
#endif

static double sct_doublet_frequency_from_sample(const photon *p,
                                               double old_dir[], double new_dir[],
                                               doublet_transition line) {
  const double mu = fmax(-1.0, fmin(1.0, scalar_product_3d(old_dir, new_dir)));
  const double width_ratio = line == LINE_BLUE ? 1.0 : LINE_NU_RED / LINE_NU_BLUE;
  return p->x + width_ratio * (p->u_scatter_last[0] * (mu - 1.0)
    + p->u_scatter_last[1] * sqrt(fmax(0.0, 1.0 - mu * mu)));
}

static void scatter_atom(photon *p) {
  double old_dir[3];
  for (int i = 0; i < 3; i++)
    old_dir[i] = p->dir[i];

  /* Draw the transition and velocities once, before changing direction. */
  const doublet_transition line = sct_doublet_select_transition(p);
  p->extra_info[0] = (double)line;
  p->u_scatter_last[0] = sct_doublet_parallel_velocity(p, line);
#ifndef TLAC_GPU_BUILD
  p->u_scatter_last[0] = checked_parallel_velocity(p->u_scatter_last[0], LINE_ION_NAME);
#endif
  p->u_scatter_last[1] = sample_orthogonal_velocity(p);
#ifdef TWO_PHOTON_DESTRUCTION
  if (p->curr_tau < 0) return;
#endif

#ifdef SIMPLE_HYDROGEN_SCATTER
  sample_simple_scattering_direction(p);
#else
  sct_doublet_set_direction(p, line);
#endif

  p->sc_dir_bulk = cell_velocity_scalar_product(p->curr_cell, p->dir,
                                                p->pos, p->grid);
  /* Frequencies remain in the common blue-line coordinate. */
  p->x = sct_doublet_frequency_from_sample(p, old_dir, p->dir, line);
}
#else
/* Independent populated transitions. Keep the same absorption channel
 * for the velocity draw and the decay-dependent Raman redistribution. */
typedef struct { int in, out; } rt_event;

static int rt_select_transition(const photon *p) {
  double weights[RT_MAX_LINES];
  const double total = rt_cross_sections(p->x, p->curr_cell->T, weights);
  if (!(total > 0) || !isfinite(total)) {
    print_error("Invalid %s gas opacity at x=%g and T=%g K.", RT_NAME, p->x, p->curr_cell->T);
    exit(EXIT_FAILURE);
  }
  double draw = rand_uniform() * total;
  int last = -1;
  for (int i = 0; i < RT_NLINES; i++) {
    if (weights[i] > 0) {
      last = i;
      draw -= weights[i];
      if (draw < 0) return i;
    }
  }
  return last;
}

static double rt_parallel_velocity(const photon *p, int line) {
  photon local = *p;
  local.x = rt_line_detuning(line, p->x, p->curr_cell->T);
  local.a = rt_gamma[rt_lines[line].upper] / (4 * PI * rt_line_width(p->x, p->curr_cell->T));
  local.x_cw = core_wing_boundary(local.a);
  if (fabs(local.x) > far_wing_threshold)
    return sample_far_parallel_velocity(local.x, local.a);
  return sample_parallel_velocity(&local);
}

static int rt_decay(int in) {
  const int upper = rt_lines[in].upper;
  double draw = rand_uniform() * rt_gamma[upper];
  int last = -1;
  for (int j = 0; j < RT_NLINES; j++) {
    if (rt_lines[j].upper == upper) {
      last = j;
      draw -= rt_lines[j].A;
      if (draw < 0) return j;
    }
  }
  return last;
}

static double rt_angle_mu(rt_event e) {
  const double phase_weight = rt_lines[e.in].w2 * rt_lines[e.out].w2;
  const double max_pdf = fmax(rt_phase_pdf(0, phase_weight), rt_phase_pdf(1, phase_weight));
  double mu;
  do {
    mu = 2 * rand_uniform() - 1;
  } while (rand_uniform() * max_pdf > rt_phase_pdf(mu, phase_weight));
  return mu;
}

static rt_event rt_sample_event(photon *p) {
  rt_event e;
  e.in = rt_select_transition(p);
  e.out = rt_decay(e.in);
  p->u_scatter_last[0] = checked_parallel_velocity(rt_parallel_velocity(p, e.in), RT_NAME);
  p->u_scatter_last[1] = sample_maxwellian_transverse_velocity();
  return e;
}

static double rt_frequency_from_sample(photon *p, rt_event e, double old_dir[], double new_dir[]) {
  const double mu = fmax(-1., fmin(1., scalar_product_3d(old_dir, new_dir)));
  const double velocity_over_c = thermal_velocity_hydrogen(p->curr_cell->T) / LIGHT_SPEED;
  const double beta_in = p->u_scatter_last[0] * velocity_over_c;
  const double beta_out = (p->u_scatter_last[0] * mu +
    p->u_scatter_last[1] * sqrt(fmax(0., 1 - mu * mu))) * velocity_over_c;
  const double width = doppler_freq_shift_hydrogen(p->curr_cell->T);
  return (rt_raman_frequency(LYA_NU0 + width * p->x, e.in, e.out, beta_in, beta_out) -
          LYA_NU0) / width;
}

static void scatter_atom(photon *p) {
  double old_dir[] = {p->dir[0], p->dir[1], p->dir[2]};
  const rt_event e = rt_sample_event(p);
  rotrand3d_angle(p->dir, acos(rt_angle_mu(e)), p->dir);
  p->x = rt_frequency_from_sample(p, e, old_dir, p->dir);
  p->sc_dir_bulk = cell_velocity_scalar_product(p->curr_cell, p->dir, p->pos, p->grid);
}
#endif

void interact_hydrogen(photon *p) {
  scatter_atom(p);
}
