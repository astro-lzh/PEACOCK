#ifndef PEACOCK_EMISSION_MODES_H
#define PEACOCK_EMISSION_MODES_H

/* Prepared CUDA cases store these codes. The configuration parser maps
 * consecutive position choices onto them. */
enum emission_position_mode {
  EMISSION_POS_CELL_CENTER = 1,
  EMISSION_POS_CELL_RANDOM = 2,
  EMISSION_POS_EXPONENTIAL = 11,
  EMISSION_POS_MIDPLANE = 12,
  EMISSION_POS_BOUNDARY = 13,
  EMISSION_POS_BOUNDARY_DIRECTED = 14,
  EMISSION_POS_MIDPLANE_DIRECTED = 15
};

enum emission_frequency_mode {
  EMISSION_FREQ_THERMAL = 0,
  EMISSION_FREQ_FIXED,
  EMISSION_FREQ_GAUSSIAN,
  EMISSION_FREQ_UNIFORM,
  EMISSION_FREQ_DOUBLET
};

static inline int emission_position_from_config(int mode) {
  switch (mode) {
    case 3: return EMISSION_POS_EXPONENTIAL;
    case 4: return EMISSION_POS_MIDPLANE;
    case 5: return EMISSION_POS_BOUNDARY;
    case 6: return EMISSION_POS_BOUNDARY_DIRECTED;
    case 7: return EMISSION_POS_MIDPLANE_DIRECTED;
    default: return mode;
  }
}

static inline int emission_position_uses_luminosity(int mode) {
  return mode == EMISSION_POS_CELL_CENTER || mode == EMISSION_POS_CELL_RANDOM;
}

static inline int emission_position_is_plane(int mode) {
  return mode == EMISSION_POS_MIDPLANE || mode == EMISSION_POS_BOUNDARY ||
         mode == EMISSION_POS_BOUNDARY_DIRECTED || mode == EMISSION_POS_MIDPLANE_DIRECTED;
}

#endif
