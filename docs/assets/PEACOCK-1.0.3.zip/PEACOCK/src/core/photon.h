
#ifndef _PHOTON_H_
#define _PHOTON_H_

struct emission_cfg_s; // defined in emission.h

#include "grid.h"

#ifdef EXTRA_PHOTON_INFORMATION
#if  EXTRA_PHOTON_INFORMATION == 1 // Additional intrinsic values
#define PHOTON_MAX_EXTRA_INFO 7
#endif
#else
#define PHOTON_MAX_EXTRA_INFO 1 // Default value
#endif

typedef struct photon_s {
  /* -- Stuff that is stored -- */
  double pos[3]; ///< Position
  double dir[3]; ///< Direction, unit vector
  double x;      ///< Dimensionless frequency

  double Delta_nu_D;  ///< Doppler frequency shift
  double sc_dir_bulk; ///< dir.v_bulk
  double a;           ///< Damping width
  double x_cw;        ///< Distinction of wing or core
  double curr_tau;    ///< Optical depth in cell for current x
  double tau;         ///< tau that gets drawn to obtain the distance to travel

  double dist;   ///< distance travelled without scatter

  double c_HI_total, c_D_total; ///< total column densities

  int nscatter; ///< how many times it has been scattered

  double x_i; ///< Initial frequqency

  double extra_info[PHOTON_MAX_EXTRA_INFO]; ///< Can be used to store
                                /// additional output information

#ifdef CELL_CLOUDS
  int nclouds_passed;          ///< Went through how many clouds
#endif

  /* -- Stuff that is not stored -- */
  struct emission_cfg_s *emission_cfg; ///< see emission.h for details
  double x_last; ///< Frequency before last scatter
  double dir_last[3]; ///< Direction before last scatter
  double u_scatter_last[2]; ///< Parallel & orthogonal direction of last
                            ///< scattered atom.
  grid_cell *curr_cell, *prev_cell;

  struct grid_s *grid;

#ifdef CELL_CLOUDS
  double pos_shifted[3];      ///< Shifted of position when entering cloud
  double vel_shifted[3];      ///< Shifted bulk velocity (due to cloud vel.)
  grid_cell *cell_shifted;    ///< Shifted from cell
  struct grid_s *grid_shifted;         ///< Shifted from grid

#endif
} photon;

#include "emission.h"

/**********************************************************//**
 * create_photon
 *                                                        
 * Creates a photon and initializes all variables to zero.
 *                                                        
 * Returns pointer to newly created photon.
 **************************************************************/
photon* create_photon(void);

/***************************************************************//**
 * update_photon_values
 *                                                             
 * Update propertie values of photon according to current cell.
 *                                                             
 * Updates: x, sc_dir_bulk, x_cw, a, Delta_nu_D, curr_tau
 *******************************************************************/
void update_photon_values(photon *p);

#ifdef FIX_FREQUENCY
/* Restore the initial detuning and refresh opacity for that detuning. */
void fix_photon_frequency(photon *p);
#endif

/*************************************************//**
 * free_photon
 *                                               
 * Frees the memory allocated by a photon struct.
 *****************************************************/
void free_photon(photon *p);

/***************************************************************//**
 * assert_photon_pos
 *                                                             
 * Calls assert to check if photon is on grid and in right cell
 *******************************************************************/
#ifdef DEBUG
#define assert_photon_pos(p) _assert_photon_pos((p), __FILE__, __LINE__)
void _assert_photon_pos(photon *p, const char* function_caller,
                        int caller_line);
#else
void assert_photon_pos(photon *p);
#endif

/*************************************//**
 * assert_photon_values
 *                                   
 * Checks if photon values make sense
 *****************************************/
#ifdef DEBUG
#define assert_photon_values(p) _assert_photon_values((p), __FILE__, __LINE__)
void _assert_photon_values(photon *p, const char* function_caller,
                             int caller_line);
#else
void assert_photon_values(photon *p);
#endif

/* ------------------------------------------------------------ */
/**
   Prints all information of a photon sctructure.
**/
void print_photon(photon *p);

#endif // PHOTON_H

