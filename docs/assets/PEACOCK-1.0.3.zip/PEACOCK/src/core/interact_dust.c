#include <math.h>
#include <stdlib.h>

#include "interact_dust.h"
#include "misc/messages.h"
#include "misc/my_math.h"
#include "misc/rand_tools.h"
#include "physical_properties.h"

static void scatter_dust(photon *p) {
  const double draw = rand_uniform();
  const double asymmetry = HG_asymmetry_parameter(p->x, p->curr_cell->T);
  if (!isfinite(asymmetry) || fabs(asymmetry) >= 1.0) {
    print_error("Invalid dust phase asymmetry %g. Expected -1 < g < 1.", asymmetry);
    exit(EXIT_FAILURE);
  }
  double mu;

#ifdef PEACOCK_MULTILEVEL
  const double isotropic_asymmetry_limit = 1e-10;
  if (fabs(asymmetry) < isotropic_asymmetry_limit) {
    mu = 2 * draw - 1;
  } else
#endif
  {
    /* Henyey–Greenstein inverse CDF, Laursen (2010), Eq. 4.9. */
    const double g = asymmetry;
    mu = -((g - 1) * (g - 1) +
           2 * (g - 1) * (1 + g * g) * draw -
           2 * g * (1 + g * g) * draw * draw) / pow(1 + g * (2 * draw - 1), 2);
  }
  if (!isfinite(mu)) {
    print_error("Dust scattering produced a nonfinite direction cosine.");
    exit(EXIT_FAILURE);
  }
  /* Inverse-CDF arithmetic can round just beyond a physical endpoint. */
  mu = fmax(-1.0, fmin(1.0, mu));
  rotrand3d_angle(p->dir, acos(mu), p->dir);
#if defined(PEACOCK_ATOM_FINE_STRUCTURE) || defined(PEACOCK_MULTILEVEL)
  /* Preserve cell-frame frequency while updating the direction projection. */
  p->sc_dir_bulk = cell_velocity_scalar_product(p->curr_cell, p->dir, p->pos, p->grid);
#endif
}

void interact_dust(photon *p) {
  const double draw = rand_uniform();
  const double albedo = dust_albedo(p->x, p->curr_cell->T);
  if (!isfinite(albedo) || albedo < 0.0 || albedo > 1.0) {
    print_error("Invalid dust albedo %g. Expected a probability in [0, 1].", albedo);
    exit(EXIT_FAILURE);
  }
  if (albedo > draw) {
    scatter_dust(p);
  } else {
    p->curr_cell = NULL;
    p->curr_tau = -1.0; /* Negative optical depth marks an absorbed packet. */
  }
}
