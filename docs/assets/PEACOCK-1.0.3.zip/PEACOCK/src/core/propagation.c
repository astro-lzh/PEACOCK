#include <assert.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "propagation.h"
#include "clouds.h"
#include "grid.h"
#include "interact_dust.h"
#include "interact_hydrogen.h"
#include "io/o_photon_ascii.h"
#include "misc/messages.h"
#include "misc/rand_tools.h"
#include "observer/observer.h"
#include "physical_properties.h"

/* These status values are part of the ASCII tracking format. Grid wall
 * codes are supplied by the Cartesian and spherical intersection routines. */
enum {
  STEP_IN_CELL = 0,
  STEP_INTO_CLOUD = 100,
  TRACK_CLOUD_EXIT_OFFSET = 1000,
  TRACK_TERMINAL_OFFSET = 2000
};

int propagate_photon(photon *p, FILE *tracking) {
  static unsigned long long tracked_packets = 0;
  unsigned long long tracking_id = 0;
  int step = STEP_IN_CELL;

  assert_photon_pos(p);
  assert_photon_values(p);
  assert(p->curr_cell != NULL);
  if (tracking != NULL) {
#ifdef USE_OMP
#pragma omp atomic capture
#endif
    tracking_id = ++tracked_packets;
  }

  /* The source is the first event for the virtual observers. */
  assert(p->dist == 0);
  process_observers_scatter(p, NULL, NULL);

  const struct emission_cfg_s *emission = p->emission_cfg;
  const int outward_source = emission->initial_pos_mode == EMISSION_POS_BOUNDARY &&
    p->dir[(int)emission->initial_pos_param] < 0;
  while (p->curr_cell != NULL && !outward_source) {
    assert_photon_pos(p);
    if (tracking != NULL && (TRACK_PHOTON_DAT_MODE == 0 || step == STEP_IN_CELL))
      o_photon_ascii_simple(tracking, tracking_id, step, p);

    update_photon_values(p);
#ifdef FIX_FREQUENCY
    fix_photon_frequency(p);
#endif
    if (p->tau < 0)
      p->tau = get_new_tau();

    /* A transparent cell advances to its next geometric boundary. */
#ifdef NO_SCATTER_MODE
    const double requested_distance = HUGE_VAL;
#else
    const double extinction = p->curr_tau;
    const double requested_distance = extinction == 0 ? HUGE_VAL : p->tau / extinction;
#endif
    p->prev_cell = p->curr_cell;
    double distance;
    step = update_photon_pos(p, requested_distance, &distance);
    p->dist += distance;
    p->c_HI_total += p->prev_cell->n_HI * distance;
    p->c_D_total += p->prev_cell->n_D * distance;
#ifndef NO_SCATTER_MODE
    p->tau -= distance * extinction;
#endif

    if (step != STEP_IN_CELL) {
      /* A boundary can leave a zero or slightly negative residual through
       * rounding. Finish the crossing before testing for an interaction. */
      if (p->tau < 0)
        p->tau = 0;
#ifdef CELL_CLOUDS
      if (p->curr_cell == NULL && p->cell_shifted != NULL) {
        unshift_from_cloud(p);
        step += TRACK_CLOUD_EXIT_OFFSET;
      }
#endif
      continue;
    }

    /* A positive residual from rounding can take another in-cell step.
     * A zero-length move cannot consume it, so handle that tie here. */
    if (p->tau > 0 && distance > 0)
      continue;
    p->tau = 0;
    if (p->nscatter == INT_MAX) {
      print_error("Photon scattering count exceeds the supported integer range.");
      exit(EXIT_FAILURE);
    }
    p->nscatter++;
    const double draw = rand_uniform();
    const double dust_cross_section = gas_scattering_cs(p->x, p->curr_cell->T);
    const double dust_fraction = p->curr_cell->n_D * dust_cross_section / p->curr_tau;
    p->x_last = p->x;
    for (int axis = 0; axis < 3; axis++)
      p->dir_last[axis] = p->dir[axis];

    if (dust_fraction <= 0 || draw > dust_fraction)
      interact_hydrogen(p);
    else
      interact_dust(p);

    if (p->curr_tau < 0) {
      if (tracking != NULL)
        o_photon_ascii_simple(tracking, tracking_id, step - TRACK_TERMINAL_OFFSET, p);
      return 0;
    }

    p->dist = 0;
    p->tau = PHOTON_TAU_UNSAMPLED;
    process_observers_scatter(p, NULL, NULL);
  }

  process_observers_exit(p);
  if (tracking != NULL)
    o_photon_ascii_simple(tracking, tracking_id, step + TRACK_TERMINAL_OFFSET, p);
  return 1;
}

double get_new_tau(void) {
#ifdef NO_SCATTER_MODE
  /* A finite value keeps diagnostic state well defined in no-scatter runs. */
  return DBL_MAX;
#else
  return rand_exponential(1.0);
#endif
}

int update_photon_pos(photon *p, double distance, double *travelled) {
  double intersection[3];
#ifdef DEBUG
  assert(!isnan(distance));
  assert_photon_pos(p);
  assert_photon_values(p);
  assert(p->curr_cell != NULL);
#endif

#ifdef CELL_CLOUDS
  /* Cloud membership uses the catalogue attached to the current cell. */
  const int cloud_id = get_cloud_intersection(p->curr_cell, p->pos, p->dir,
                                             intersection, travelled);
  if (cloud_id >= 0) {
    if (distance > *travelled) {
      for (int axis = 0; axis < 3; axis++)
        p->pos[axis] = intersection[axis];
      shift_to_cloud(p, p->curr_cell, cloud_id, 0);
      assert_photon_pos(p);
      return STEP_INTO_CLOUD;
    }
  } else
#endif
  {
    grid_cell *next_cell;
    const int wall = get_next_cell(p->grid, p->curr_cell, p->pos, p->dir,
                                   &next_cell, intersection, travelled);
    if (distance > *travelled) {
      /* The grid routine has already placed the intersection past the wall. */
      for (int axis = 0; axis < 3; axis++)
        p->pos[axis] = intersection[axis];
      p->curr_cell = next_cell;
      assert_photon_pos(p);
      return wall;
    }
  }

  if (!isfinite(distance) || distance < 0) {
    print_error("Photon advance requires a finite nonnegative in-cell distance.");
    exit(EXIT_FAILURE);
  }
  for (int axis = 0; axis < 3; axis++)
    p->pos[axis] += distance * p->dir[axis];
  *travelled = fabs(distance);
  assert_photon_pos(p);
  return STEP_IN_CELL;
}
