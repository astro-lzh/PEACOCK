#include <stdint.h>
#include <limits.h>
#include <assert.h>

#include <math.h>
#include <float.h>
#include <stdio.h>
#include <stdlib.h>

#include "grid.h"
#include "clouds.h"
#include "grids/grid_cart.h"
#include "grids/grid_spherical.h"
#include "misc/messages.h"
#include "misc/mem.h"
#include "misc/my_math.h"
#include "misc/rand_tools.h"
#include "physical_properties.h"

/* Allocate a contiguous 3-D cell array without overflowing its size or
 * index calculations. The dimensions remain int in the public grid ABI. */
grid_cell ***allocate_grid_cells(int nx, int ny, int nz) {
  if (nx <= 0 || ny <= 0 || nz <= 0) {
    print_error("Every grid dimension must have a positive number of cells.");
    exit(EXIT_FAILURE);
  }
  const size_t x = (size_t)nx, y = (size_t)ny, z = (size_t)nz;
  if (x > SIZE_MAX / y || x * y > SIZE_MAX / z) {
    print_error("Grid cell count exceeds the addressable range.");
    exit(EXIT_FAILURE);
  }
  const size_t xy = x * y, xyz = xy * z;
  if (x > SIZE_MAX / sizeof(grid_cell **) ||
      xy > SIZE_MAX / sizeof(grid_cell *) ||
      xyz > SIZE_MAX / sizeof(grid_cell)) {
    print_error("Grid allocation exceeds the addressable range.");
    exit(EXIT_FAILURE);
  }
  const size_t outer_bytes = x * sizeof(grid_cell **);
  const size_t row_bytes = xy * sizeof(grid_cell *);
  const size_t cell_bytes = xyz * sizeof(grid_cell);
  if (outer_bytes > SIZE_MAX - row_bytes ||
      outer_bytes + row_bytes > SIZE_MAX - cell_bytes) {
    print_error("Grid allocation exceeds the addressable range.");
    exit(EXIT_FAILURE);
  }
  const size_t bytes = outer_bytes + row_bytes + cell_bytes;
  grid_cell ***cells = check_realloc(NULL, bytes);
  grid_cell **rows = (grid_cell **)((char *)cells + outer_bytes);
  grid_cell *data = (grid_cell *)((char *)rows + row_bytes);
  for (int i = 0; i < nx; i++) {
    cells[i] = rows + (size_t)i * y;
    for (int j = 0; j < ny; j++)
      cells[i][j] = data + ((size_t)i * y + (size_t)j) * z;
  }
  print_info("\tAllocate %.2fMB of memory.\n", bytes / (1024. * 1024.));
  return cells;
}

/*************************************************************************//**
 * create_grid
 * 
 * Creates grid.
 * 
 * @param grid_type Can be of GRID_SPHERICAL or GRID_CARTESIAN
 * @param size[3/1] Size in cm (array of x,y,z or radius).
 * @param ncells[3] Number of cells in each dimension
 * @param cell_placement_mode   Decides how cells are placed (so far only
 * uniform).
 * 
 * @return Pointer to grid.
 *****************************************************************************/
grid* create_grid(const int grid_type, double* size, int* ncells,
                  int cell_placement_mode) {
  switch(grid_type) {
    
  case GRID_CARTESIAN:
#ifdef _GRID_CART_H_
    return create_uniform_grid(size[0], size[1], size[2],
                               ncells[0], ncells[1], ncells[2]);
#else 
    print_error("Cartesian grid is not defined. Wrong tlac version?");
    exit(-1);
#endif

  case  GRID_SPHERICAL:
#ifdef _GRID_SPHERICAL_H_
    return create_spherical_grid(size[0], ncells[0], ncells[1], ncells[2]);
#else
    print_error("Spherical grid is not defined. Wrong tlac version?");
    exit(-1);
#endif
  default:
    print_error("Unknown grid type '%d'", grid_type);
    return NULL;
  }
  
}

/****************************************//**
 * free_grid
 *                     
 * Frees memory of grid
 ********************************************/
void free_grid(grid *g) {
  int i, j, k;
  pick_random_cell(NULL);
#ifdef CELL_CLOUDS
  free_clouds(g);
#endif

  // Uniform grids only one size
  if(g->uniform)
    free(g->cells[0][0][0].size);
  else {
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        for(k = 0; k < g->ncells[2]; k++) {
          free(g->cells[i][j][k].size);
        }
      }
    }
  }
   
  free(g->observers);
  
  free(g->cells);
  free(g);

}

/*****************************************************//**
 * get_total_luminosity
 *                                                   
 * Calculates sum of luminosities
 *                                                   
 * Returns: Sum over all individual cell luminosities
 *                                                   
 * Arguments: grid struct
 *********************************************************/
double get_total_luminosity(grid* g) {
  int i, j, k;

  g->L_tot = 0;

  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0; k < g->ncells[2]; k++) {
        g->L_tot += g->cells[i][j][k].L;
      }
    }    
  }

  return g->L_tot;
}

static void init_random_cell_generator(grid *g, gsl_rng **ret_rng,
                                       gsl_ran_discrete_t **ret_discrete_ran);

/**********************************************//**
 * pick_random_cell
 * 
 * Returns pointer to random cell
 * Pass NULL to release the calling thread's generator and weights.
 * 
 **************************************************/
grid_cell *pick_random_cell(grid* g) {
  static int rnd_gen_init = 0;
  static gsl_rng * rng;
  static gsl_ran_discrete_t *disc_ran; 
#ifdef USE_OMP
#pragma omp threadprivate(rng,disc_ran,rnd_gen_init)
#endif


  // ---- Free random cell gen ----
  if(g == NULL) {
    if(rnd_gen_init == 1) {
      rnd_gen_init = 0;
      gsl_rng_free(rng);
      gsl_ran_discrete_free(disc_ran);
    }
    return NULL;
  }

  // ---- Initialize random generator ----
  if(!rnd_gen_init) {
    if(!isfinite(g->L_tot) || g->L_tot <= 0) {
      print_error("Trying to initialize random cell generator but L_tot = %e",
                  g->L_tot);
      exit(-1);
    }
    init_random_cell_generator(g, &rng, &disc_ran);
    rnd_gen_init = 1;
  }

  const size_t n = gsl_ran_discrete(rng, disc_ran);
  const size_t ny = (size_t)g->ncells[1], nz = (size_t)g->ncells[2];
  const size_t iz = n % nz;
  const size_t iy = (n / nz) % ny;
  const size_t ix = (n / nz) / ny;
  assert(ix < (size_t)g->ncells[0]);

  return &(g->cells[ix][iy][iz]);

}

/****************************************************************//**
 * init_random_cell_generator
 *                                                              
 * Initializes the GSL routines for the random cell generator
 *                                                              
 * Arguments: Grid struct
 *                                                              
 * Returns: ret_rng & ret_discrete_ran -- pointers to GSL random
 * generator routines normalized to luminosities
 ********************************************************************/
static void init_random_cell_generator(grid *g,
                                gsl_rng **ret_rng, 
                                gsl_ran_discrete_t **ret_discrete_ran) {
  const size_t nx = (size_t)g->ncells[0];
  const size_t ny = (size_t)g->ncells[1];
  const size_t nz = (size_t)g->ncells[2];
  if (g->ncells[0] <= 0 || g->ncells[1] <= 0 || g->ncells[2] <= 0 ||
      nx > SIZE_MAX / ny || nx * ny > SIZE_MAX / nz ||
      nx * ny * nz > SIZE_MAX / sizeof(double)) {
    print_error("Grid is too large for luminosity sampling.");
    exit(EXIT_FAILURE);
  }
  const size_t ntot = nx * ny * nz;
  double *luminosities = check_realloc(NULL, sizeof(*luminosities) * ntot);

  *ret_rng = gsl_rng_alloc(gsl_rng_default);
  if (*ret_rng == NULL) {
    free(luminosities);
    print_error("Error allocating the random cell generator.");
    exit(EXIT_FAILURE);
  }
  /* Seed the cell sampler with a draw from the simulation RNG. */
  gsl_rng_set(*ret_rng, rand_int(999999));

  size_t n = 0;
  for (size_t i = 0; i < nx; i++) {
    for (size_t j = 0; j < ny; j++) {
      for (size_t k = 0; k < nz; k++) {
        double weight = g->cells[i][j][k].L;
        if (!isfinite(weight) || weight < 0.0) {
          print_error("Invalid luminosity at cell (%zu, %zu, %zu): %e.",
                      i, j, k, weight);
          exit(EXIT_FAILURE);
        }
        luminosities[n++] = weight;
      }
    }
  }

  /* ---- Init random generator ---- */
  *ret_discrete_ran = gsl_ran_discrete_preproc(ntot, luminosities);
  if(*ret_discrete_ran == NULL) {
    print_error("Error allocating discrete random generator.");
    exit(-1);
  }

  free(luminosities);

}

/*********************************************************************//**
 * find_grid_cell
 *                                                               
 * Given a grid and a position, the function returns a pointer to the
 * cell containing the position. If nothing is found, NULL is
 * returned.
 *************************************************************************/
grid_cell* find_grid_cell(grid *g, double pos[]) {
  int i, j, k;
  int n[3];

  for (i = 0; i < 3; i++)
    if (!isfinite(pos[i])) return NULL;

  /* Check the candidate coordinate before converting it to an int.
   * Truncating toward zero maps offsets in (-1, 0) to index 0. */
  for (i = 0; i < 3; i++) {
    const double index = pos[i] / g->cells[0][0][0].size[i];
    if (!(index > -1.0 && index < g->ncells[i])) {
      n[0] = -1;
      break;
    }
    n[i] = (int)index;
  }
  if((n[0] != -1) && is_pos_in_cell(pos,&(g->cells[n[0]][n[1]][n[2]]), g))
    return &(g->cells[n[0]][n[1]][n[2]]);

  // Search all cells if the coordinate estimate misses.
  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0; k < g->ncells[2]; k++) {
        if(is_pos_in_cell(pos, &(g->cells[i][j][k]), g))
          return &(g->cells[i][j][k]);
      }
    }
  }

  return NULL;
}

/*********************************************************************//**
 * get_next_cell
 *                                                                
 * Given a cell, a position, a direction and a distance to travel
 * (cell, pos, dir, r), the functon calculates the cell in this
 * directiond and the intersection of the wall and the path. position
 * (new_cell, intersection). Also, the distance to the intersection
 * point `dist` is returned.
 *                                                                
 * Return code is status which wall was crossed: 1 = (0)+ (wall in
 * positive dim0 direction) 2 = (1)+ 3 =(2)+ -1 = (0)- ...
 *************************************************************************/
int get_next_cell(grid *grid, grid_cell *cell, double pos[], 
                  double dir[], grid_cell **new_cell, 
                  double intersection[], double* dist) {
#if TLAC_GRID == GRID_SPHERICAL
  return get_next_cell_spherical(grid, cell, pos, dir, new_cell,
                                 intersection, dist);
#elif TLAC_GRID == GRID_CARTESIAN
  return get_next_cell_cart(grid, cell, pos, dir, new_cell,
                            intersection, dist);
#elif TLAC_GRID == GRID_VARIABLE
  if(grid->type == GRID_SPHERICAL)
    return get_next_cell_spherical(grid, cell, pos, dir, new_cell,
                                   intersection, dist);
  else if(grid->type == GRID_CARTESIAN)
    return get_next_cell_cart(grid, cell, pos, dir, new_cell,
                              intersection, dist);
#endif
  exit(-1);
}

/*********************************************************************//**
 * get_random_pos_in_cell
 *                                                              
 * Given a cell it calculates a random (uniform) position in the cell
 * and returns the result to the pointer given.
 *************************************************************************/
void get_random_pos_in_cell(grid_cell* c, grid* g, double ret_pos[]) {
#if TLAC_GRID == GRID_SPHERICAL
  return get_random_pos_in_cell_spherical(c, g, ret_pos);
#elif TLAC_GRID == GRID_CARTESIAN
  return get_random_pos_in_cell_cart(c, g, ret_pos);
#elif TLAC_GRID == GRID_VARIABLE
  if(g->type == GRID_SPHERICAL)
    return get_random_pos_in_cell_spherical(c, g, ret_pos);
  else if(g->type == GRID_CARTESIAN)
    return get_random_pos_in_cell_cart(c, g, ret_pos);
#endif
}

/****************************************************//**
 * is_pos_in_grid
 *                                                  
 * Checks if position is on grid. Returns 1 if true;
 ********************************************************/
int is_pos_in_grid(double *pos, grid *g) {
#if TLAC_GRID == GRID_SPHERICAL
  return is_pos_in_grid_spherical(pos, g);
#elif TLAC_GRID == GRID_CARTESIAN
  return is_pos_in_grid_cart(pos, g);
#elif TLAC_GRID == GRID_VARIABLE
  if(g->type == GRID_SPHERICAL)
    return is_pos_in_grid_spherical(pos, g);
  else if(g->type == GRID_CARTESIAN)
    return is_pos_in_grid_cart(pos, g);
#endif

  exit(-1);
}

/****************************************************//**
 * is_pos_in_cell
 *                                                  
 * Checks if position is on cell. Returns 1 if true;
 ********************************************************/
int is_pos_in_cell(double *pos, grid_cell *c, grid *g) {
#if TLAC_GRID == GRID_SPHERICAL
  return is_pos_in_cell_spherical(pos, c);
#elif TLAC_GRID == GRID_CARTESIAN
  return is_pos_in_cell_cart(pos, c);
#elif TLAC_GRID == GRID_VARIABLE
  if(g->type == GRID_SPHERICAL)
    return is_pos_in_cell_spherical(pos, c);
  else if(g->type == GRID_CARTESIAN)
    return is_pos_in_cell_cart(pos, c);
#endif

  exit(-1);
}

/********************************************************************//**
 * cell_velocity_scalar_product
 *                                                                  
 * Calculates scalar product between `vec` and velocity of grid cell
 * `c`. Returns result.
 ************************************************************************/
double cell_velocity_scalar_product(grid_cell *c, double vec[], double pos[],
                                    grid *g) {
#if TLAC_GRID == GRID_SPHERICAL
  return cell_velocity_scalar_product_spherical(c, vec, pos);
#elif TLAC_GRID == GRID_CARTESIAN
  return cell_velocity_scalar_product_cart(c, vec);
#elif TLAC_GRID == GRID_VARIABLE
  if(g->type == GRID_SPHERICAL)
    return cell_velocity_scalar_product_spherical(c, vec, pos);
  else if(g->type == GRID_CARTESIAN)
    return cell_velocity_scalar_product_cart(c, vec);
#endif

  exit(-1);
}

/*****************************************************//**
 * set_grid_values
 *                                                   
 * Set values, n_HI, n_D, T,... to all cells in grid.
 *********************************************************/
 void set_grid_values(grid *g, const double n_HI, const double n_D,
                      const double T, const double L) {
   int i, j, k;
   
   for(i = 0; i < g->ncells[0]; i++) {
     for(j = 0; j < g->ncells[1]; j++) {
       for(k = 0; k < g->ncells[2]; k++) {
         g->cells[i][j][k].n_HI = n_HI;
         g->cells[i][j][k].n_D = n_D;
         g->cells[i][j][k].T = T;
         g->cells[i][j][k].L = L;
       }
     }
   }
 }

/*******************************************************************//**
 * set_grid_values_ring
 * 
 * Set grid values n_HI, n_D, ... to all cells with center in Rmin,
 * Rmax from center.
 * Note: A negative value means the parameter is left unchanged
 * (except for v, there nan has the same effect)
 * 
 * @param v  Out- (>0) or inflowing (<0) velocity (spherically symmetric).
 * 
 * @return Number of cells filled.
 ***********************************************************************/
int set_grid_values_ring(grid *g, const double Rin, const double Rout,
                         const double n_HI, const double n_D,
                         const double T, const double L,
                         const double v) {
  assert(Rout >= Rin);
  
#if TLAC_GRID == GRID_SPHERICAL
  return set_grid_values_ring_spherical(g, Rin, Rout, n_HI, n_D, T, L, v);
#elif TLAC_GRID == GRID_CARTESIAN
  return set_grid_values_ring_cart(g, Rin, Rout, n_HI, n_D, T, L, v);
#elif TLAC_GRID == GRID_VARIABLE
  if(g->type == GRID_SPHERICAL)
    return set_grid_values_ring_spherical(g, Rin, Rout, n_HI, n_D, T, L, v);
  else if(g->type == GRID_CARTESIAN)
    return set_grid_values_ring_cart(g, Rin, Rout, n_HI, n_D, T, L, v);
#endif

  return -1;
}

/**********************************************************************//**
 * set_grid_linear_velocity
 * 
 * Sets linear velocity for dimension `dim` between `Rmin` & `Rmax`
 * (from center) Velocity is scaled from `vmin` to `vmax`. Expects all
 * in cgs.
 * 
 * Can be used, e.g., for plane-parallel outflow in slab.
 * 
 * Returns number of cells filled.
 **************************************************************************/
int set_grid_linear_velocity(grid *g, int dim, double Rmin, double Rmax,
                             double vmin, double vmax) {

  int i,j, k;
  int nfilled = 0;
  double vel, R;
  grid_cell *c;
  
  // Error checks
  if((dim < 0) || (dim > 2)) {
    print_error("Wrong dimension %d.", dim);
    exit(-1);
  }

  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        R = c->pos[dim] - g->center[dim]; // can be negative!
        if((fabs(R) < Rmin) || (fabs(R) > Rmax))
          continue;

        vel = sign(R) * (vmax - vmin) * (fabs(R) - Rmin) / (Rmax - Rmin) + vmin;
        c->vel[dim] = vel / thermal_velocity_hydrogen(c->T);
        
        nfilled++;
      }
    }
  }

  return nfilled;
}

/*
  set_grid_values_bicone

  Set values in grid in bicone with half-opening angle alpha
  Return number of cells filled.

  Alpha in radians.
*/
int set_grid_values_bicone(grid *g, double alpha,
                           double n_HI, double n_D, double T, double L,
                           double vz) {
  if((alpha < 0) || (alpha > 2.)) {
    print_error("alpha should be given in radians.");
    exit(-1);
  }
  int i, j, k, l;
  double relpos[3];
  grid_cell *c;
  int nfilled = 0;
  double d;

  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        for(l = 0; l<3; l++)
          relpos[l] = c->pos[l] - g->center[l];
        d = norm3d(relpos);
        if(fabs(d) < 1e-12)
          continue;
        if(fabs(relpos[2]) / d < fabs(cos(alpha))) {
          if(n_HI >= 0)
            c->n_HI = n_HI;
          if(n_D >= 0)
            c->n_D = n_D;
          if(T >= 0)
            c->T = T;
          if(L >= 0)
            c->L = L;
          c->vel[2] = vz;

          nfilled++;
        }
      } // end cell loops
    }
  }
  return nfilled;
}

/********************************************************************//**
 * Checks grid `g` for constistency and throws error if something is
 * fishy...
 ************************************************************************/
void check_grid(grid *g) {
  int i, j, k, l;
  double tmppos[3], d;
  grid_cell *c;
  int fail = 0;
  double vrms = 0, vnorm, vnorm_min = DBL_MAX, vnorm_max = -DBL_MAX,
    Tmin = DBL_MAX, Tmax = -DBL_MAX;
  double n_HImin = DBL_MAX, n_HImax = -DBL_MAX, n_HImean = 0;
  double n_Dmin = DBL_MAX, n_Dmax = -DBL_MAX, n_Dmean = 0;
  double Lmin = DBL_MAX, Lmax = -DBL_MAX;
#ifdef CELL_CLOUDS
  unsigned int nclouds_min = UINT_MAX, nclouds_max = 0;
#else
  const unsigned int nclouds_min = 0, nclouds_max = 0;
#endif
  size_t nclouds = 0;
  double vmin[3], vmax[3], cvel;
  double cloud_vrms = 0;
  const double corner_fraction = 0.49; // Just inside the actual cell corners.
  const double neighbor_gap_tolerance = 1e-5;

  // -- General (grid) checks -- 
  for(i = 0; i < 3; i++) {
    vmin[i] = DBL_MAX;
    vmax[i] = -DBL_MAX;
    if(g->ncells[i] <= 0) {
      print_error("ncells[%d] = %d", i, g->ncells[i]);
      exit(-1);
    }
    if(!isfinite(g->boxsize[i]) || g->boxsize[i] <= 0) {
      print_error("boxsize[%d] = %e", i, g->boxsize[i]);
      exit(-1);
    }
  }
  print_info("\tTotal grid luminosity is %e\n", g->L_tot);
  if(!isfinite(g->L_tot) || g->L_tot < 0) {
    print_error("Total grid luminosity must be finite and nonnegative.");
    exit(-1);
  }

  if(g->type == GRID_SPHERICAL)
    print_warning("Spherical grid check not fully implemented yet!");

  // -- Check per cell --
  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        
        // Cell centers are in native coordinates; the predicates take Cartesian points.
        double *position = c->pos;
        if(g->type == GRID_SPHERICAL) {
          spherical2cart(c->pos, tmppos);
          position = tmppos;
        }
        if(!is_pos_in_grid(position, g) || !is_pos_in_cell(position, c, g)) {
          print_error("General position check failed.");
          fail = 1;
        }

        if(g->type == GRID_CARTESIAN) {
        
          // Check if order of cells is ok
          for(l = 0; l < 3; l++) {
            if(c->nbs[2 * l + 1] != NULL) {
              if(c->pos[l] >= c->nbs[2 * l + 1]->pos[l]) {
                print_error("Failed on cell order dimension=%d! Neighbor is at "
                            "%e (in boxsize units)", 2 * l + 1,
                            c->nbs[2 * l + 1]->pos[l] / g->boxsize[l]);
                fail = 1;
              }
            }
            if(c->nbs[2 * l] != NULL) {
              if(c->pos[l] <= c->nbs[2 * l]->pos[l]) {
                print_error("Failed on cell order dimension=%d! Neighbor is at "
                            "%e (in boxsize units)", 2 * l,
                            c->nbs[2 * l]->pos[l] / g->boxsize[l]);
                fail = 1;
              }
            }
          }

          // Check if corner of cells are still in cell
          for(l = 0; l < 3; l++)
            tmppos[l] = c->pos[l] - corner_fraction * c->size[l];
          if( (is_pos_in_grid(tmppos, g) == 0) ||
              (is_pos_in_cell(tmppos, c, g) == 0)) {
            print_error("Lower corner of cell not in cell.");
            fail = 1;
          }
          for(l = 0; l < 3; l++)
            tmppos[l] = c->pos[l] + corner_fraction * c->size[l];
          if( (is_pos_in_grid(tmppos, g) == 0) ||
              (is_pos_in_cell(tmppos, c, g) == 0)) {
            print_error("Upper corner of cell not in cell.");
            fail = 1;
          }
        
          // Check if neighbors are nearby (no gaps)
          for(l = 0; l < 3; l++) {
            if(c->nbs[2 * l] != NULL) {
              d = fabs((c->pos[l] - 0.5 * c->size[l]) -
                       (c->nbs[2 * l]->pos[l] +
                        0.5 * c->nbs[2 * l]->size[l])) / c->size[l];
              if(d > neighbor_gap_tolerance) {
                print_error("Neighbor %d gap is %e cell widths (maximum %e).",
                            2 * l, d, neighbor_gap_tolerance);
                fail = 1;
              }
            }
            if(c->nbs[2 * l + 1] != NULL) {
              d = fabs((c->pos[l] + 0.5 * c->size[l]) -
                       (c->nbs[2 * l + 1]->pos[l] -
                        0.5 * c->nbs[2 * l + 1]->size[l])) / c->size[l];
              if(d > neighbor_gap_tolerance) {
                print_error("Neighbor %d gap is %e cell widths (maximum %e).",
                            2 * l + 1, d, neighbor_gap_tolerance);
                fail = 1;
              }
            }
          }
        } // only Cartesian end

        // Check for sanity values
        if(!isfinite(c->T) || c->T <= 0.) {
          print_error("Cell temperature must be finite and positive.");
          fail = 1;
        }
        if(!isfinite(c->n_HI) || !isfinite(c->n_D) || !isfinite(c->L) ||
           c->n_HI < 0 || c->n_D < 0 || c->L < 0) {
          print_error("Cell densities and luminosity must be finite and nonnegative.");
          fail = 1;
        }

        for(l = 0; l < 3; l++) {
          if(!isfinite(c->size[l]) || c->size[l] <= 0 || !isfinite(c->vel[l])) {
            print_error("Cell axis %d needs a positive finite size and a finite velocity.", l);
            fail = 1;
          }
        }

        // Record variables
        vnorm = norm3d(c->vel) * thermal_velocity_hydrogen(c->T);
        if(vnorm < vnorm_min)
          vnorm_min = vnorm;
        if(vnorm > vnorm_max)
          vnorm_max = vnorm;
        if(c->T < Tmin)
          Tmin = c->T;
        if(c->T > Tmax)
          Tmax = c->T;
        if(c->n_HI < n_HImin)
          n_HImin = c->n_HI;
        if(c->n_HI > n_HImax)
          n_HImax = c->n_HI;
        if(c->n_D < n_Dmin)
          n_Dmin = c->n_D;
        if(c->n_D > n_Dmax)
          n_Dmax = c->n_D;
        if(c->L < Lmin)
          Lmin = c->L;
        if(c->L > Lmax)
          Lmax = c->L;
        for(l = 0; l < 3; l++) {
          cvel = c->vel[l] * thermal_velocity_hydrogen(c->T);
          if(cvel > vmax[l])
            vmax[l] = cvel;
          if(cvel < vmin[l])
            vmin[l] = cvel;
        }

        n_HImean += c->n_HI;
        n_Dmean += c->n_D;
        vrms += pow(vnorm, 2);

#ifdef CELL_CLOUDS
        if(c->nclouds < nclouds_min)
          nclouds_min = c->nclouds;
        if(c->nclouds > nclouds_max)
          nclouds_max = c->nclouds;
        nclouds += c->nclouds;

        for(unsigned int cloud = 0; cloud < c->nclouds && !fail; cloud++) {
          if(!is_pos_in_cell(c->pos_clouds[cloud], c, g)) {
            print_error("Cloud %u center is outside its cell.", cloud);
            fail = 1;
            break;
          }
          cloud_vrms += pow(thermal_velocity_hydrogen(c->cloud_grids[cloud]->cells[0][0][0].T) *
                           norm3d(c->vel_clouds[cloud]), 2);
          for(unsigned int other = 0; other < cloud; other++) {
            d = distance_3d(c->pos_clouds[cloud], c->pos_clouds[other]) /
              (c->cloud_grids[cloud]->boxsize[0] + c->cloud_grids[other]->boxsize[0]);
            if(d <= 1.0) {
              print_error("Clouds %u and %u overlap (distance / sum of radii = %e).",
                          other, cloud, d);
              fail = 1;
              break;
            }
          }
        } 
#endif // CELL_CLOUDS

        if(fail) {
          print_error("Error check failed!");
          printf("--------------------------------------------\n");
          printf("Failed at cell (%d, %d, %d)\n", i, j, k);
          print_cell(c,g);
          printf("Note: Check cell cannot deal with periodic "
                 "boundaries yet...");
          printf("--------------------------------------------\n");
          exit(-1);
        }
        
      } 
    }
  } // Cell loop ending //

  if(g->type == GRID_CARTESIAN) {
      const size_t ncells = (size_t)g->ncells[0] * g->ncells[1] * g->ncells[2];
      vrms = sqrt(vrms / ncells);
      n_HImean /= ncells;
      n_Dmean /= ncells;
      cloud_vrms = nclouds > 0 ? sqrt(cloud_vrms / nclouds) : 0.0;

      print_info("\t\tChecked %zu cells. vrms = %.3ekm/s.\n\t\t"
                 "vnorm_min = %.3ekm/s, vnorm_max = %.3ekm/s (norm)\n"
                 "\t\tTmin = %.3eK, Tmax = %.3eK\n\t\tn_HImin = %.2ecm^-3, "
                 "n_HImax = %.2e, n_HImean = %.2e\n"
                 "\t\tn_Dmin = %.2e, n_Dmax = %.2e, "
                 "n_Dmean = %.2e\n"
                 "\t\tLmin = %.3e, Lmax = %.3e\n"
                 "\t\tnclouds_min = %u, nclouds_max = %u, nclouds_tot = %zu\n"
                 "\t\tcloud_vrms = %.2ekm/s\n",
                 ncells,
                 vrms / 1e5, vnorm_min / 1e5, vnorm_max / 1e5,
                 Tmin, Tmax, n_HImin, n_HImax, n_HImean,
                 n_Dmin, n_Dmax, n_Dmean, Lmin, Lmax,
                 nclouds_min, nclouds_max, nclouds, cloud_vrms / 1e5);
      for(i = 0; i < 3; i++)
        print_info("\t\t v(dim=%d) min = %.3ekm/s, max = %.3ekm/s\n",
                   i, vmin[i] / 1e5, vmax[i] / 1e5);
    }
  
}

/* ------------------------------------------------------------ */
/**
   Prints info about cell `c` (and neighbors)
**/
void print_cell(grid_cell *c, grid *g) {
  int i;

  printf("Dim(0) Position(1) Pos/boxsize(2) Next_neighbors(3,5) inBS(4,6)\n");
  printf("---------------------------------------------------------------\n");
  for(i = 0; i < 3; i++) {
    printf("(%d) %e %e ", i, c->pos[i], c->pos[i] / g->boxsize[i]);
    if(c->nbs[2 * i] != NULL) {
      printf("%e %e ", c->nbs[2 * i]->pos[i],
             c->nbs[2 * i]->pos[i] / g->boxsize[i]);
    } else {
      printf("NULL NULL ");
    }
    if(c->nbs[2 * i + 1] != NULL) {
      printf("%e %e ", c->nbs[2 * i + 1]->pos[i],
             c->nbs[2 * i + 1]->pos[i] / g->boxsize[i]);
    } else {
      printf("NULL NULL ");
    }

    printf("\n");
  }
}

/* ------------------------------------------------------------ */

/**********************************************************************//**
 * get_pos_dist_from_center
 *                                                          
 * Calculates a random position which is `d` from the center of the
 * grid `g` and returns it to `ret_pos`.
 **************************************************************************/
void get_pos_dist_from_center(grid *g, double d, double ret_pos[]) {
  double rand_dir[3];
  int i;
  
  rand_direction_3d(rand_dir);

  for(i = 0; i < 3; i++)
    ret_pos[i] = g->center[i] + rand_dir[i] * d;

}

/* ------------------------------------------------------------ */
/**
   Returns closest distance to closest wall.

   @param *g    -- Grid of cell
   @param *c    -- Cell
   @param pos[] -- Position from which to calculate.
   
   @return Distance to next wall in cm.
**/
double get_dist_to_wall(grid *g, grid_cell *c, double pos[]) {
#ifdef CELL_CLOUDS
  // If we have clouds here, just return 0 to be sure
  if(c->nclouds)
    return 0.0;
#endif

  if(g->type == GRID_SPHERICAL) {
    double r = norm3d(pos);
    if(r > c->pos[0])
      return c->pos[0] + 0.5 * c->size[0] - r;
    else
      return r - (c->pos[0] - 0.5 * c->size[0]);
#ifdef _GRID_CART_H_
  } else if(g->type == GRID_CARTESIAN) {
    return get_dist_to_wall_cart(c, pos);
#endif
  }
  exit(-1);
}
