#ifndef PEACOCK_SCATTERING_FIT_H
#define PEACOCK_SCATTERING_FIT_H

#include <math.h>

/* Core-to-wing detuning fit from Smith et al. (2014), equation 21. */
static inline double core_wing_boundary(double damping) {
  const double detuning_offset = 6.9184721;
  const double inverse_log_coefficient = 81.766279;
  const double log_damping_offset = 14.651253;
  return detuning_offset + inverse_log_coefficient / (log(damping) - log_damping_offset);
}

#endif
