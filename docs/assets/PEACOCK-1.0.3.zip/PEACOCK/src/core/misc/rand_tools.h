#ifndef _RAND_TOOLS_H_
#define _RAND_TOOLS_H_

#include <stdlib.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

/*********************************************************************
 * init_gsl_rand_gend                                                *
 *                                                                   *
 * Sets seed and rand gen type for GSL random number generators used *
 * in this program                                                   *
 *********************************************************************/
void init_rand_tools(long int seed);

/***************************************
 * rand_uniform                        *
 *                                     *
 * Returns a uniform variable in [0,1) *
 ***************************************/
double rand_uniform(void);

/* ------------------------------------------------------------ */
/**
   Returns an integer in [0, max] (including both)
**/
int rand_int(int max);


/*********************************
 * cleanup_rand_tools            *
 *                               *
 * Frees memory occupied here... *
 *********************************/
void cleanup_rand_tools(void);

/*************************************************************
 * rand_direction_3d                                         *
 *                                                           *
 * Returns a random vector in 3d so that x^2 + y^2 + z^2 = 1 *
 *************************************************************/
void rand_direction_3d(double *ret_vec);

/************************************************************
 * rand_cauchy                                              *
 *                                                          *
 * Returns a random variable drawn from a cauchy/lorentzian *
 * distribution                                             *
 * p(x) dx = {1 \over a\pi (1 + (x/a)^2) } dx               *
 ************************************************************/
double rand_cauchy(double a);

/**********************************************************
 * rand_gaussian                                          *
 *                                                        *
 * Returns a random variable drawn from a gaussian/normal *
 * distribution                                           *
 **********************************************************/
double rand_gaussian(double sigma);

/*******************************************************************
 * rand_exponential                                                *
 *                                                                 *
 * Returns a random variable drawn from a exponential distribution *
 * p(x) dx = {1 \over \mu} \exp(-x/\mu) dx                         *
 *******************************************************************/
double rand_exponential(double mu);

/****************************************************************
 * rand_poisson This function returns a random integer from the *
 * Poisson distribution with mean mu.                           *
 ****************************************************************/
double rand_poisson(double mu);

/********************************************************************
 * rotrand3d_angle                                                  *
 *                                                                  *
 * Rotates a given vector by a random (uniform) angle and the angle *
 * given. Hence, vec_in*vec_out = cos(angle)                        *
 ********************************************************************/
void rotrand3d_angle(double vec_in[], double angle, double vec_out[]);

#endif

