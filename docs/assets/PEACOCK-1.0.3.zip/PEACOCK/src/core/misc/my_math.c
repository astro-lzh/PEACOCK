#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <math.h>

#include "my_math.h"

#include "messages.h"

double array_min(double *arr, int nentries) {
  int i;
  double cmin = arr[0];
  for(i = 1; i < nentries; i++) {
    if(arr[i] < cmin)
      cmin = arr[i];
  }

  return cmin;
}

double array_max(double *arr, int nentries) {
  int i;
  double cmax = arr[0];
  for(i = 1; i < nentries; i++) {
    if(arr[i] > cmax)
      cmax = arr[i];
  }

  return cmax;
  
}

/***************************************************
 * sign                                            *
 *                                                 *
 * Returns -1 if x < 0, 1 if x > 0 and 0 if x = 0. *
 ***************************************************/
int sign(double x) {
  return (x > 0) - (x < 0);
}

/**************************************************************
 * pow10  -- Calculates 10^n                                  *
 *                                                            *
 * from http://swtch.com/usr/local/plan9/src/lib9/fmt/pow10.c *
 **************************************************************/
double pow10(int n) {
  int m;
  static double	tab[] =
    {
      1.0e0, 1.0e1, 1.0e2, 1.0e3, 1.0e4, 1.0e5, 1.0e6, 1.0e7, 1.0e8, 1.0e9,
      1.0e10,1.0e11,1.0e12,1.0e13,1.0e14,1.0e15,1.0e16,1.0e17,1.0e18,1.0e19,
      1.0e20,1.0e21,1.0e22,1.0e23,1.0e24,1.0e25,1.0e26,1.0e27,1.0e28,1.0e29,
      1.0e30,1.0e31,1.0e32,1.0e33,1.0e34,1.0e35,1.0e36,1.0e37,1.0e38,1.0e39,
      1.0e40,1.0e41,1.0e42,1.0e43,1.0e44,1.0e45,1.0e46,1.0e47,1.0e48,1.0e49,
      1.0e50,1.0e51,1.0e52,1.0e53,1.0e54,1.0e55,1.0e56,1.0e57,1.0e58,1.0e59,
      1.0e60,1.0e61,1.0e62,1.0e63,1.0e64,1.0e65,1.0e66,1.0e67,1.0e68,1.0e69,
    };

  if(n < 0) {
    n = -n;
    if(n < (int)(sizeof(tab)/sizeof(tab[0])))
      return 1/tab[n];
    m = n/2;
    return pow10(-m) * pow10(m-n);
  }
  if(n < (int)(sizeof(tab)/sizeof(tab[0])))
    return tab[n];
  m = n/2;
  return pow10(m) * pow10(n-m);

}

/****************************************************
 * cross_product                                    *
 *                                                  *
 * Calculates u x v and stores result in res. *
 ****************************************************/
void cross_product(double u_in[], double v_in[], double res[]) {
  // Copy if res is u or v
  double u[] = {u_in[0], u_in[1], u_in[2]};
  double v[] = {v_in[0], v_in[1], v_in[2]};

  res[0] = u[1] * v[2] - u[2] * v[1];
  res[1] = u[2] * v[0] - u[0] * v[2];
  res[2] = u[0] * v[1] - u[1] * v[0];
}

/*********************************************************************
 * norm3d                                                            *
 *                                                                   *
 * Returns ||x|| = sqrt(x1*x1 + x2*x2 + x3*x3) given a 3d vector vec *
 *********************************************************************/
inline double norm3d(double vec[]) {
  return sqrt(vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2]);
}

/**********************************************************
 * angle_vec3d                                            *
 *                                                        *
 * Returns angle between v1 and v2 (which are 3D vectors) *
 **********************************************************/
inline double angle_vec3d(double v1[], double v2[]) {
  return acos((v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2])
              /(norm3d(v1) * norm3d(v2)));
}

/****************************************************************
 * distance_3d                                                  *
 *                                                              *
 * Returns distance between pos1[] and pos2[] (both 3d vectors) *
 ****************************************************************/
inline double distance_3d(double pos1[], double pos2[]) {
  return sqrt( (pos1[0] - pos2[0]) *  (pos1[0] - pos2[0]) +
               (pos1[1] - pos2[1]) *  (pos1[1] - pos2[1]) +
               (pos1[2] - pos2[2]) *  (pos1[2] - pos2[2])
               );
}

/*******************************************************************
 * rot3d_vec_angle                                                 *
 *                                                                 *
 * Rotates a given 3d vector (vec_in) around a normalized vector n *
 * by an angle alpha                                               *
 *                                                                 *
 * Return value is stored in vec_out                               *
 *******************************************************************/
void rot3d_vec_angle(double vec_in[], double n[], const double alpha,
                     double vec_out[]) {
  int i;
  double vec_in_orig[] = {vec_in[0], vec_in[1], vec_in[2]};
  double ca = cos(alpha);
  double sa = sin(alpha);
  double R[][3] = { { 
      n[0] * n[0] * (1. - ca) + ca,
      n[0] * n[1] * (1. - ca) - n[2] * sa,
      n[0] * n[2] * (1. - ca) + n[1] * sa
    },{
      n[1] * n[0] * (1. - ca) + n[2] * sa,
      n[1] * n[1] * (1. - ca) + ca,
      n[1] * n[2] * (1. - ca) - n[0] * sa
    }, {
      n[2] * n[0] * (1. - ca) - n[1] * sa,
      n[2] * n[1] * (1. - ca) + n[0] * sa,
      n[2] * n[2] * (1. - ca) + ca
    }
  };

  for(i = 0; i < 3; i++)
    vec_out[i] = R[i][0] * vec_in_orig[0] +
      R[i][1] * vec_in_orig[1] + R[i][2] * vec_in_orig[2];

}

/**********************************************************
 * approx_equal                                           *
 *                                                        *
 * Checks if two numbers a and b are approximately equal. *
 *                                                        *
 * Returns 1 if yes, otherwise 0.                         *
 **********************************************************/
int approx_equal(double a, double b) {
  const int relevant_digits = 9;

  return (round(a * pow10(relevant_digits) - b * pow10(relevant_digits)) == 0);
}

/*********************************************************************
 * cart2spherical                                                    *
 *                                                                   *
 * Transforms cartesian coordinates to spherical, i.e. to (r, theta, *
 * phi)                                                              *
 *********************************************************************/
void cart2spherical(double pos_cart[], double pos_spherical[]) {
  double ret[3];

  ret[0] = norm3d(pos_cart);
  ret[1] = acos(pos_cart[2] / ret[0]);
  ret[2] = atan2(pos_cart[1], pos_cart[0]);

  // Map atan2 from (-pi, pi) to (0, 2pi)
  if(ret[2] < 0)
    ret[2] += 2 * PI;

  for (int i = 0; i < 3; i++) {
    pos_spherical[i] = ret[i];
  }

}

/*********************************************************************
 * Spherical2cart                                                    *
 *                                                                   *
 * Transforms spherical (r, theta, phi) to cartesian coordinates (x, *
 * y, z)                                                             *
 *********************************************************************/
void spherical2cart(double pos_spherical[], double pos_cart[]) {
  double sth = sin(pos_spherical[1]);

  pos_cart[0] = pos_spherical[0] * sth * cos(pos_spherical[2]);
  pos_cart[1] = pos_spherical[0] * sth * sin(pos_spherical[2]);
  pos_cart[2] = pos_spherical[0] * cos(pos_spherical[1]);
}

/*********************************************************************
 * intersection_ray_cone                                             *
 *                                                                   *
 * Finds intersection between ray and cone. Cone has to be centered  *
 * around z-axis with opening angle `theta` and direction `cone_dir` *
 * +1 or -1. Ray is charazterized by position `pos` and direction    *
 * `dir`                                                             *
 *                                                                   *
 * Returns number of crossings and array with lambdas, i.e. the      *
 * solutions to cone = pos + dir * lambda                            *
 *                                                                   *
 * Explanation of routines, e.g., in http://www.geometrictools.com   *
 * Documentation/IntersectionLineCone.pdf                            *
 *********************************************************************/
int intersection_ray_cone(double pos[], double dir[], double theta, 
                          int cone_dir, double lambda[]) {
  double possq = pos[0] * pos[0] + pos[1] * pos[1] + pos[2] * pos[2];
  double sc_dir_pos = dir[0] * pos[0] + dir[1] * pos[1] + dir[2] * pos[2];
  double ha, hb, hc, hd;

#ifdef DEBUG
  if(theta >=  PI) {
    print_error("No cone possible with theta >= pi!");
    return -1;
  }
#endif

  ha = cos(theta);
  hb = 1.0 - 2.0 * dir[2] * dir[2] + ha;
  hc = possq - 2.0 * pos[2] * pos[2] + possq * ha;
  ha = sc_dir_pos - 2.0 * dir[2] * pos[2] + sc_dir_pos * ha;

  if(ha * ha - hb * hc < 0)
    return 0; // never crossed

  // get lambdas
  hd = sqrt(ha * ha - hb * hc);
  lambda[0] = (-ha - hd) / hb;
  lambda[1] = (-ha + hd) / hb;

  
         
  // check if true solutions or of mirrored cone
  ha = 1; hb = 1;
  if((pos[2] + dir[2] * lambda[0]) * cone_dir < 0)
    ha = 0;
  if((pos[2] + dir[2] * lambda[1]) * cone_dir < 0)
    hb = 0;
    
  // fix return values
  if(ha == 0)
    lambda[0] = lambda[1];

  return ha + hb;
   
}

/*********************************************************************
 * intersection_ray_sphere                                           *
 *                                                                   *
 * Finds intersection between ray and sphere. Sphere has an radius   *
 * R0 and a position pos_sphere[].                                   *
 *                                                                   *
 * Returns number of crossings and array with lambdas, i.e. the      *
 * solutions to cone = pos + dir * lambda                            *
 *                                                                   *
 * Explanation of routine, e.g., in                                  *
 * http://en.wikipedia.org/wiki/Line%E2%80%93sphere_intersection     *
 *********************************************************************/
int intersection_ray_sphere(double pos[], double dir[], const double R0,
                            const double pos_sphere[], double lambda[]) {
  double Delta_pos[] = { pos[0] - pos_sphere[0], pos[1] - pos_sphere[1],
                         pos[2] - pos_sphere[2] };
  double dir_sc_deltapos = scalar_product_3d(dir, Delta_pos);
  double det = dir_sc_deltapos * dir_sc_deltapos -
    scalar_product_3d(Delta_pos, Delta_pos) + R0 * R0;
  if(det < 0) return 0; // no solution

  lambda[0] = - dir_sc_deltapos + sqrt(det);
  if(det == 0) return 1;
  lambda[1] = - dir_sc_deltapos - sqrt(det);
  return 2;
}
                            
/*******************************************************
 * scalar_product_3d                                   *
 *                                                     *
 * Calculates scalar product in 3D and returns result. *
 *******************************************************/
inline double scalar_product_3d(double vec1[], double vec2[]) {
  return (vec1[0] * vec2[0] + vec1[1] * vec2[1] + vec1[2] * vec2[2]);
}

/****************************************************************/