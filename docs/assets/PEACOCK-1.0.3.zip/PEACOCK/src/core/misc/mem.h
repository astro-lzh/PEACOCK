#ifndef _MEM_H_
#define _MEM_H_
/*
 Memory handling functions
 */
#include <stdio.h>
#include <stdlib.h>

// Checked memory allocation and file access helpers
void* check_realloc(void* ptr, size_t size);

FILE* check_fopen(char* filename,char* mode);

// Allocate arrays as big chunk of data
// (which can be freed with one free(x) call)
double** allocate_2d_dbl_array(int ind1, int ind2);
char** allocate_2d_char_array(int ind1, int ind2);

/*********************************************************************
 * fseek_line_containing_string                                      *
 *                                                                   *
 * Moves cursor in `fp` to line containing `str`. On success returns *
 * 1, otherwise (if, e.g., `str` is not in the file), returns -1     *
 *********************************************************************/
int fseek_line_containing_string(FILE *fp, char* str);

#endif /* _MEM_H_ */
