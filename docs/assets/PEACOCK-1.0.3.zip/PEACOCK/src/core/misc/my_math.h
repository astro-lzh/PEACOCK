#ifndef _MY_MATH_H_
#define _MY_MATH_H_

/**************************
 * Mathematical constants *
 **************************/
#define PI 3.14159265358979323846



double array_min(double *arr, int nentries);
double array_max(double *arr, int nentries);


/***************************************************
 * sign                                            *
 *                                                 *
 * Returns -1 if x < 0, 1 if x > 0 and 0 if x = 0. *
 ***************************************************/
int sign(double x);


/**************************************************************
 * pow10  -- Calculates 10^n                                  *
 *                                                            *
 * from http://swtch.com/usr/local/plan9/src/lib9/fmt/pow10.c *
 **************************************************************/
double pow10(int n);

/**********************************************
 * cross_product                              *
 *                                            *
 * Calculates u x v and stores result in res. *
 **********************************************/
void cross_product(double u[], double v[], double res[]);


/*********************************************************************
 * norm3d                                                            *
 *                                                                   *
 * Returns ||x|| = sqrt(x1*x1 + x2*x2 + x3*x3) given a 3d vector vec *
 *********************************************************************/
double norm3d(double vec[]);

/**********************************************************
 * angle_vec3d                                            *
 *                                                        *
 * Returns angle between v1 and v2 (which are 3D vectors) *
 **********************************************************/
double angle_vec3d(double v1[], double v2[]);

/****************************************************************
 * distance_3d                                                  *
 *                                                              *
 * Returns distance between pos1[] and pos2[] (both 3d vectors) *
 ****************************************************************/
double distance_3d(double pos1[], double pos2[]);

/*******************************************************************
 * rot3d_vec_angle                                                 *
 *                                                                 *
 * Rotates a given 3d vector (vec_in) around a normalized vector n *
 * by an angle alpha                                               *
 *                                                                 *
 * Return value is stored in vec_out                               *
 *******************************************************************/
void rot3d_vec_angle(double vec_in[], double n[], const double alpha,
                     double vec_out[]);


/**********************************************************
 * approx_equal                                           *
 *                                                        *
 * Checks if two numbers a and b are approximately equal. *
 *                                                        *
 * Returns 1 if yes, otherwise 0.                         *
 **********************************************************/
int approx_equal(double a, double b);

/*********************************************************************
 * cart2spherical                                                    *
 *                                                                   *
 * Transforms certesian coordinates to spherical, i.e. to (r, theta, *
 * phi)                                                              *
 *********************************************************************/
void cart2spherical(double pos_cart[], double pos_spherical[]);

/*********************************************************************
 * spherical2cart                                                    *
 *                                                                   *
 * Transforms spherical (r, theta, phi) to cartesian coordinates (x, *
 * y, z)                                                             *
 *********************************************************************/
void spherical2cart(double pos_spherical[], double pos_cart[]);

/*********************************************************************
 * intersection_ray_cone                                             *
 *                                                                   *
 * Finds intersection between ray and cone. Cone has to be centered  *
 * around z-axis with opening angle `theta` and direction `cone_dir` *
 * +1 or -1. Ray is charazterized by position `pos` and direction    *
 * `dir`                                                             *
 *                                                                   *
 * Returns number of crossings and array with lambdas, i.e. the      *
 * solutions to cone = pos + dir * lambda                            *
 *********************************************************************/
int intersection_ray_cone(double pos[], double dir[], double theta, 
                          int cone_dir, double lambda[]);

/*********************************************************************
 * intersection_ray_sphere                                           *
 *                                                                   *
 * Finds intersection between ray and sphere. Sphere has an radius   *
 * R0 and a position pos_sphere[].                                   *
 *                                                                   *
 * Returns number of crossings and array with lambdas, i.e. the      *
 * solutions to cone = pos + dir * lambda                            *
 *********************************************************************/
int intersection_ray_sphere(double pos[], double dir[], const double R0,
                            const double pos_sphere[], double lambda[]);

/*******************************************************
 * scalar_product_3d                                   *
 *                                                     *
 * Calculates scalar product in 3D and returns result. *
 *******************************************************/
double scalar_product_3d(double vec1[], double vec2[]);


/****************************************************************/#endif /* _MY_MATH_H_ */

