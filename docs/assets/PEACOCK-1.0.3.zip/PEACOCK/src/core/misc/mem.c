#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "mem.h"
#include "messages.h"

void* check_realloc(void* ptr, size_t size) {
  void* ret;

  if (size == 0) {
    print_error("Cannot allocate a zero-length buffer.");
    exit(EXIT_FAILURE);
  }

  ret=realloc(ptr,size);
  if(ret == NULL) {
    print_error("Error reallocating memory!");
    exit(-1);
  }

  return ret;
}

FILE* check_fopen(char* filename, char* mode) {
  FILE *fp = fopen(filename, mode);
  if (fp == NULL) {
    print_error("Could not open file %s.", filename);
    exit(EXIT_FAILURE);
  }
  return fp;
}

static size_t array_2d_size(int rows, int columns, size_t pointer_size,
                            size_t element_size) {
  if (rows <= 0 || columns <= 0 ||
      (size_t)rows > SIZE_MAX / pointer_size ||
      (size_t)columns > SIZE_MAX / element_size ||
      (size_t)rows > (SIZE_MAX - (size_t)rows * pointer_size) /
                     ((size_t)columns * element_size)) {
    print_error("Invalid or oversized two-dimensional array (%d by %d).", rows, columns);
    exit(EXIT_FAILURE);
  }
  return (size_t)rows * pointer_size + (size_t)rows * columns * element_size;
}

double **allocate_2d_dbl_array(int rows, int columns) {
  double **array = check_realloc(NULL, array_2d_size(rows, columns,
                                                     sizeof(*array), sizeof(**array)));
  double *data = (double *)(array + rows);
  for (int i = 0; i < rows; i++) array[i] = data + (size_t)i * columns;
  return array;
}

char **allocate_2d_char_array(int rows, int columns) {
  char **array = check_realloc(NULL, array_2d_size(rows, columns,
                                                  sizeof(*array), sizeof(**array)));
  char *data = (char *)(array + rows);
  for (int i = 0; i < rows; i++) array[i] = data + (size_t)i * columns;
  return array;
}

/********************************************************************//**
 * fseek_line_containing_string
 *                                                                  
 * Moves cursor in `fp` to line containing `str`. On success returns
 * 1, otherwise (if, e.g., `str` is not in the file), returns -1
 ************************************************************************/
int fseek_line_containing_string(FILE *fp, char* str) {
  char line[4096];
  const long original = ftell(fp);
  if (original < 0) return -1;

  /* Search from the current cursor, then wrap once to earlier lines. */
  for (int pass = 0; pass < 2; pass++) {
    long position;
    while ((position = ftell(fp)) >= 0 &&
           (pass == 0 || position < original) &&
           fgets(line, sizeof(line), fp) != NULL) {
      if (strstr(line, str) != NULL)
        return fseek(fp, position, SEEK_SET) == 0 ? 1 : -1;
    }
    if (ferror(fp) || fseek(fp, 0, SEEK_SET) != 0) break;
  }
  clearerr(fp);
  (void)fseek(fp, original, SEEK_SET);
  return -1;
}
