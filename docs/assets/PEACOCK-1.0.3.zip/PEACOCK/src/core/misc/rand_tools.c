#include <stdlib.h>
#include <math.h>

#include <gsl/gsl_errno.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#ifdef USE_OMP
#include <omp.h>
#endif

#include "my_math.h"
#include "rand_tools.h"

/*********************************************************************//**
 * \file rand_tools.c
 * Pointer to GSL rand gen is used in this file Global variables used
 * in this file
 *************************************************************************/
static gsl_rng *gl_rng;
#ifdef USE_OMP
#pragma omp threadprivate(gl_rng)
#endif

/********************************************************************//**
 * init_rand_tools
 *                                                                  
 * Sets seed and rand gen type for GSL random number generators used
 * in this program
 ************************************************************************/
void init_rand_tools(long int seed) {
  int tid  = 0;
#ifdef USE_OMP
#pragma omp parallel shared(seed) private(tid)
  {
  tid = omp_get_thread_num();
#endif
  /* Use a Tausworthe-2 stream with a worker-specific seed offset.
     GSL_RNG_TYPE does not select this explicitly configured generator. */
  if (gl_rng != NULL) gsl_rng_free(gl_rng);
  gl_rng = gsl_rng_alloc(gsl_rng_taus2);
  if (gl_rng == NULL) abort();

  /* GSL accepts an unsigned seed. Add the worker offset without signed overflow. */
  gsl_rng_set(gl_rng, (unsigned long)seed + (unsigned long)tid);

#ifdef USE_OMP
  }
#endif
}

/****************************************//**
 * rand_uniform
 *                                    
 * Returns a uniform variable in [0,1). Zero is possible.
 ********************************************/
double rand_uniform(void) {
  return gsl_rng_uniform(gl_rng);
}

/* ------------------------------------------------------------ */
/**
   Returns an integer in [0, max] (including both)
**/
int rand_int(int max) {
  if (max < 0) {
    GSL_ERROR_VAL("rand_int requires a nonnegative upper bound", GSL_EINVAL, 0);
  }
  return (int)gsl_rng_uniform_int(gl_rng, (unsigned long)max + 1UL);
} 

/************************************************************//**
 * rand_direction_3d
 *                                                          
 * Returns a random vector in 3d so that x^2 + y^2 + z^2 = 1
 ****************************************************************/
void rand_direction_3d(double *ret_vec) {
  gsl_ran_dir_3d(gl_rng, &(ret_vec[0]),&(ret_vec[1]), &(ret_vec[2]));
}

/***********************************************************//**
 * rand_cauchy
 *                                                         
 * Returns a random variable drawn from a cauchy/lorentzian
 * distribution p(x) dx = {1 \over a\pi (1 + (x/a)^2) } dx
 ***************************************************************/
double rand_cauchy(double a) {
  return gsl_ran_cauchy(gl_rng, a);
}

/**********************************************************************//**
 * rand_gaussian
 *                                                       
 * Returns a random variable drawn from a gaussian/normal distribution
 **************************************************************************/
double rand_gaussian(double sigma) {
  return gsl_ran_gaussian(gl_rng, sigma);
}

/******************************************************************//**
 * rand_exponential
 *                                                                
 * Returns a random variable drawn from a exponential distribution
 * p(x) dx = {1 \over \mu} \exp(-x/\mu) dx
 **********************************************************************/
double rand_exponential(double mu) {
  return gsl_ran_exponential(gl_rng, mu);
}

/***************************************************************//**
 * rand_poisson This function returns a random integer from the
 * Poisson distribution with mean mu.
 *******************************************************************/
double rand_poisson(double mu) {
  return gsl_ran_poisson(gl_rng, mu);
}

 /***************************************//**
  * cleanup_rand_tools
  *                              
  * Frees memory occupied here...
  *******************************************/
void cleanup_rand_tools(void) {
#ifdef USE_OMP
#pragma omp parallel
  {
#endif
    if (gl_rng != NULL) gsl_rng_free(gl_rng);
    gl_rng = NULL;
#ifdef USE_OMP
  }
#endif
}

/*******************************************************************//**
 * rotrand3d_angle
 *                                                                 
 * Rotates a given vector by a random (uniform) angle and the angle
 * given. Hence, vec_in*vec_out = cos(angle)
 ***********************************************************************/
void rotrand3d_angle(double vec_in[], double angle, double vec_out[]) {
  int i;
  double r[3], b[3], norm_b;
  double input_norm = norm3d(vec_in);
  if (!(input_norm > 0.0) || !isfinite(input_norm) || !isfinite(angle)) {
    GSL_ERROR_VOID("rotation requires a finite nonzero vector and finite angle", GSL_EINVAL);
  }
  /* A sampled direction parallel to vec_in has no rotation axis. */
  do {
    rand_direction_3d(r);
    cross_product(vec_in, r, b);
    norm_b = norm3d(b);
  } while (norm_b == 0.0);
  for(i = 0; i < 3; i++)
    b[i] = b[i] / norm_b;

  rot3d_vec_angle(vec_in, b, angle, vec_out);
}

