#ifndef _MESSAGES_H_
#define _MESSAGES_H_

#include "../tlac_defs.h"

/***********************************************************
 *                                                         *
 * Print info text, warnings and errors                    *
 *                                                         *
 * Ideas for most macros from                              *
 * http://stackoverflow.com/a/1644898/1834164              *
 ***********************************************************/

/************************************
 * print_warning                    *
 *                                  *
 * Prints warning message to stdout *
 *                                  *
 * Args: ... - Same as printf       *
 *                                  *
 ************************************/
#define print_warning(...) \
               do { fprintf(stdout,\
                            "[Warning] " __VA_ARGS__);\
                 fprintf(stdout, " -- %s:%d:%s()\n",\
                            __FILE__, __LINE__, __func__); } while (0)

/***********************************
 * print_error                     *
 *                                 *
 *  Prints error message to stderr *
 *                                 *
 * Args: ... - Same as printf      *
 *                                 *
 ***********************************/
#define print_error(...) \
               do { fprintf(stdout,\
                            "[Error] " __VA_ARGS__);\
                 fprintf(stdout, " -- %s:%d:%s()\n",\
                            __FILE__, __LINE__, __func__); } while (0)

/****************************************************
 * print_info                                       *
 *                                                  *
 * Prints warning message to stdout if VERBOSE is 1 *
 *                                                  *
 * Args: ... - Same as printf                       *
 *                                                  *
 ****************************************************/
#define print_info(...) \
                 do { if (VERBOSE) fprintf(stdout,\
                                           __VA_ARGS__); } while (0)

#endif

