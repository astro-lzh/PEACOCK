#if (TLAC_GRID == GRID_CARTESIAN) || (TLAC_GRID == GRID_VARIABLE)
#ifndef _GRID_CART_H_
#define _GRID_CART_H_

#include <stdlib.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include "../grid.h"


/*******************************************************************//**
 * create_uniform_grid Creates a uniform grid with [nx,ny,nz] cells
 *                                             
 * Returns: 3D array of grid cells NULL if error occured
 *                                             
 * Arguments: Boxsize in each dimensision Number of cells for each
 * dimension
 ***********************************************************************/
grid *create_uniform_grid(double boxsize_x, double boxsize_y, double boxsize_z,
                          int nx, int ny, int nz);


/*************************************************//**
 * make_grid_periodic
 *                                               
 * Makes grid g periodic around `direction` (0-2)
 *****************************************************/
void make_grid_periodic(grid *g, const int direction);


/*********************************************************************//**
 * get_random_pos_in_cell_cart
 *                                                              
 * Given a cell it calculates a random (uniform) position in the cell
 * and returns the result to the pointer given.
 *************************************************************************/
void get_random_pos_in_cell_cart(grid_cell* c, grid* g, double ret_pos[]);

/****************************************************//**
 * is_pos_in_grid_cart
 *                                                  
 * Checks if position is on grid. Returns 1 if true;
 ********************************************************/
int is_pos_in_grid_cart(double *pos, grid *g);

/****************************************************//**
 * is_pos_in_cell
 *                                                  
 * Checks if position is on cell. Returns 1 if true;
 ********************************************************/
int is_pos_in_cell_cart(double *pos, grid_cell *c);

/*********************************************************************//**
 * get_next_cell_cart
 *                                                               
 * Given a cell, a position, a direction and a distance to travel
 * (cell, pos, dir, r), the functon calculates the cell in this
 * directiond and the intersection of the wall and the path. position
 * (new_cell, intersection). Also, the distance to the intersection
 * point `dist` is returned.
 *                                                               
 * Return code is status which wall was crossed: 1 = x+ (wall in
 * positive x direction) 2 = y+ 3 = z+ -1 = x- ...
 *************************************************************************/
int get_next_cell_cart(grid *grid, grid_cell *cell, double pos[], 
                       double dir[], grid_cell **new_cell, 
                       double intersection[], double* dist);


/********************************************************************//**
 * cell_velocity_scalar_product_cart
 *                                                                  
 * Calculates scalar product between `vec` and velocity of grid cell
 * `c`. Returns result.
 ************************************************************************/
double cell_velocity_scalar_product_cart(grid_cell *c, double vec[]);


/*******************************************************************//**
 * set_grid_values_ring_cart
 *                                                                 
 * Set values n_HI, n_D... given in all the cells lying in the ring
 * between Rin and Rout.
 * 
 * The velocity `vel` is spherically symettric.
 *                                                                 
 * Note: A negative value means the parameter is left unchanged
 * (except for vel there nan has the same effect)
 *                                                                 
 * Returns the numbers of cells modified.
 ***********************************************************************/
int set_grid_values_ring_cart(grid *g, double Rin, double Rout,
                              double n_HI, double n_D,
                              double T, double L, double vel);

/* ------------------------------------------------------------ */
/**
   Sets random velocity in ring.
   

   @param *g      -- Grid to fill
   @param Rin     -- Inner radius of ring in cm
   @param Rout    -- Outer radius of ring in cm
   @param sigma_v -- standard deviation of each component in cm/s
   
   @return Number of cells filled.
**/
int set_grid_values_random_velocity_cart(grid *g, const double Rin,
                                         const double Rout,
                                         const double sigma_v);



/* ------------------------------------------------------------ */
/**
   Returns closest distance to closest wall.

   @param *c    -- Cell
   @param pos[] -- Position from which to calculate.
   
   @return Distance to next wall in cm.
**/
double get_dist_to_wall_cart(grid_cell *c, double pos[]);

#endif
#endif
