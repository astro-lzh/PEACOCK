/**

   Spherical grid

   Notes: position of cells and bulk velocity are in spherical
   coordinates, i.e., (r, theta, phi) whereas the photon position &
   direction are still in Cartesian coordinates

   We use the `Physics` convention for spherical coordinates, i.e.,
   theta -> [0, pi]
   phi   -> [0, 2pi]

 **/

#if (TLAC_GRID == GRID_SPHERICAL) || (TLAC_GRID == GRID_VARIABLE)

#ifndef _GRID_SPHERICAL_H_
#define _GRID_SPHERICAL_H_

#include <stdlib.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include "../grid.h"

/*********************************************************************//**
 * create_spherical_grid
 *                                                                  
 * Creates a more or less uniform grid with [nR, nTheta, nPhi] cells
 *                                                                  
 * Returns: 3D array of grid cells NULL if error occured
 *                                                                  
 * Arguments: R of sphere and number of slices (R, Theta and Phi) are
 * sliced.
 *************************************************************************/
grid *create_spherical_grid(double R,
                            int nR, int nTheta, int nPhi);

/****************************************************//**
 * is_pos_in_grid_spherical
 *                                                  
 * Checks if position is on grid. Returns 1 if true;
 ********************************************************/
int is_pos_in_grid_spherical(double *pos, grid *g);

/****************************************************//**
 * is_pos_in_cell_spherical
 *                                                  
 * Checks if position is on cell. Returns 1 if true;
 ********************************************************/
int is_pos_in_cell_spherical(double *pos, grid_cell *c);

/* Draw a position uniformly in the cell volume, in (r, theta, phi). */
void get_random_spherical_coordinates_in_cell(const grid_cell *c, double coordinates[3]);

/* Return the volume-uniform sample in Cartesian coordinates. */
void get_random_pos_in_cell_spherical(grid_cell* c, grid* g, double ret_pos[]);

/*********************************************************************//**
 * get_next_cell_spherical
 *                                                               
 * Given a cell, a position, a direction and a distance to travel
 * (cell, pos, dir, r), the functon calculates the cell in this
 * directiond and the intersection of the wall and the path. position
 * (new_cell, intersection). Also, the distance to the intersection
 * point `dist` is returned.
 *                                                               
 * Return code is status which wall was crossed: 11 = r+ (wall in
 * positive r direction) 12 = theta+ 13 = phi+ -11 = r- ...
 *************************************************************************/
int get_next_cell_spherical(grid *grid, grid_cell *cell, double pos[], 
                              double dir[], grid_cell **new_cell, 
                              double intersection[], double* dist);

/*********************************************************************//**
 * cell_velocity_scalar_product_spherical
 *                                                                  
 * Calculates scalar product between `vec` and velocity of grid cell
 * `c`. Returns result.
 *                                                                  
 * Note that c->vel is given in spherical coordinates and, hence, the
 * posion `pos` must be given.
 *************************************************************************/
double cell_velocity_scalar_product_spherical(grid_cell *c, double vec[],
                                                double pos[]);

/*********************************************************************//**
 * set_grid_values_ring_spherical
 *                                                                 
 * Set values n_HI, n_D... given in all the cells lying in the ring
 * between Rin and Rout.
 *                                                                 
 * Note: A negative value means the parameter is left unchanged
 * (except for vel, there nan has the same effect)
 *                                                                 
 * Returns the numbers of cells modified.
 *************************************************************************/
int set_grid_values_ring_spherical(grid *g, double Rin, double Rout,
                                   double n_HI, double n_D,
                                   double T, double L, double vel);

#endif

#endif
