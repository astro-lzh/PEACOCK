#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <float.h>

#include "../tlac_defs.h"
#include "../grid.h"
#include "grid_spherical.h"
#include "../misc/mem.h"
#include "../misc/messages.h"
#include "../misc/rand_tools.h"
#include "../misc/my_math.h"
#include "../physical_properties.h"

#if (TLAC_GRID == GRID_SPHERICAL) || (TLAC_GRID == GRID_VARIABLE)

/*********************************************************************//**
 * create_spherical_grid
 *                                                                  
 * Creates a more or less uniform grid with [nR, nTheta, nPhi] cells
 *                                                                  
 * Returns: 3D array of grid cells NULL if error occured
 *                                                                  
 * Arguments: R of sphere and number of slices (R, Theta and Phi) are
 * sliced.
 *************************************************************************/
grid *create_spherical_grid(double R,
                            int nR, int nTheta, int nPhi) {

  if (!isfinite(R) || R <= 0 || nR <= 0 || nTheta <= 0 || nPhi <= 0) {
    print_error("Spherical grid requires a positive finite radius and positive cell counts.");
    exit(EXIT_FAILURE);
  }

#ifdef SIMPLE_SPHERICAL_GRID
  if(nTheta > 1 || nPhi > 1) {
    print_error("Use of nTheta and nPhi has been switched off! "
                "To switch it back on, alter tlac_defs.h");
    exit(-1);
  }
#endif
  
  grid_cell ***cells = allocate_grid_cells(nR, nTheta, nPhi);
  int i, j, k;
  grid *ret_grid;

  double* cell_sizes = (double*)check_realloc(NULL, 3 * sizeof(double));
  cell_sizes[0] = R / (double)nR;
  cell_sizes[1] = PI / (double)nTheta;
  cell_sizes[2] = 2.0 * PI / (double)nPhi;
  
  ret_grid = check_realloc(NULL, sizeof(grid));
  ret_grid->type = GRID_SPHERICAL;

  // ---- Set initial variables of cells right ----
  for(i = 0; i < nR; i++) {
    for(j = 0; j < nTheta; j++) {
      for(k = 0; k < nPhi; k++) {
        cells[i][j][k] = (grid_cell){ .T = 1e4, .size = cell_sizes };

        // Set Neighbours
        if(i == 0)
          cells[i][j][k].nbs[0] = NULL; // inner ring
        else
          cells[i][j][k].nbs[0] = &(cells[i - 1][j][k]);
        if(i == nR - 1)
          cells[i][j][k].nbs[1] = NULL;
        else
          cells[i][j][k].nbs[1] = &(cells[i + 1][j][k]);

        if(j == 0)
          cells[i][j][k].nbs[2] = NULL;
        else
          cells[i][j][k].nbs[2] = &(cells[i][j - 1][k]);
        if(j == nTheta - 1)
          cells[i][j][k].nbs[3] = NULL;
        else
          cells[i][j][k].nbs[3] = &(cells[i][j + 1][k]);

        if(k == 0)              // phi with periodic boundary conditions
          cells[i][j][k].nbs[4] = &(cells[i][j][nPhi - 1]);
        else
          cells[i][j][k].nbs[4] = &(cells[i][j][k - 1]);
        if(k == nPhi - 1)
          cells[i][j][k].nbs[5] = &(cells[i][j][0]);
        else
          cells[i][j][k].nbs[5] = &(cells[i][j][k + 1]);

        // Set positions
        cells[i][j][k].pos[0] = cell_sizes[0] / 2.0 + cell_sizes[0] * i;
        cells[i][j][k].pos[1] = cell_sizes[1] / 2.0 + cell_sizes[1] * j;
        cells[i][j][k].pos[2] = cell_sizes[2] / 2.0 + cell_sizes[2] * k;

      }
    }
  }

  /* --- Set grid variables ---- */
  ret_grid->ncells[0] = nR;
  ret_grid->ncells[1] = nTheta;
  ret_grid->ncells[2] = nPhi;

  ret_grid->boxsize[0] = R;
  ret_grid->boxsize[1] = PI;
  ret_grid->boxsize[2] = 2 * PI;

  ret_grid->center[0] = 0;
  ret_grid->center[1] = 0;
  ret_grid->center[2] = 0;

  ret_grid->L_tot = 0.0;
  ret_grid->nobservers = 0;
  ret_grid->observers = NULL;

  ret_grid->cells = cells;

  ret_grid->uniform = 1;
  
  return ret_grid;
}

/******************************************************************//**
 * is_pos_in_grid_spherical
 *                                                                
 * Checks if position (given in cartesian coordinates) is on grid.
 * Returns 1 if true;
 **********************************************************************/
int is_pos_in_grid_spherical(double *pos, grid *g) {
  // This margin admits intersections rounded just past the outer shell.
  const double outer_radius_tolerance = 1.000001;
  return outer_radius_tolerance > (norm3d(pos) / g->boxsize[0]);
}

/****************************************************//**
 * is_pos_in_cell_spherical
 *                                                  
 * Checks if position is on cell. Returns 1 if true;
 ********************************************************/
int is_pos_in_cell_spherical(double *pos, grid_cell *c) {
  double pos_spherical[3];
  int i;
  double const epsilon = EPSILON_CHECK;

  cart2spherical(pos, pos_spherical);

  // Angular coordinates are undefined at the origin, which all inner sectors share.
  if(pos_spherical[0] == 0.0)
    return c->pos[0] <= (0.5 + epsilon) * c->size[0];

  for(i = 0; i < 3; i++)
    if(!isfinite(pos_spherical[i]) ||
       pos_spherical[i] > c->pos[i] + (0.5 + epsilon) * c->size[i]
       || pos_spherical[i] < c->pos[i] - (0.5 + epsilon) * c->size[i]) {
      return 0;
    }

  return 1;
}

void get_random_spherical_coordinates_in_cell(const grid_cell *c, double coordinates[3]) {
  // The volume element is proportional to d(r^3) d(cos theta) d(phi).
  const double inner_radius_cubed = pow(c->pos[0] - 0.5 * c->size[0], 3);
  const double cos_lower_theta = cos(c->pos[1] - 0.5 * c->size[1]);
  coordinates[0] = pow(rand_uniform() *
    (pow(c->pos[0] + 0.5 * c->size[0], 3) - inner_radius_cubed) +
    inner_radius_cubed, 1.0 / 3.0);
  coordinates[1] = acos(rand_uniform() *
    (cos(c->pos[1] + 0.5 * c->size[1]) - cos_lower_theta) + cos_lower_theta);
  coordinates[2] = (rand_uniform() - 0.5) * c->size[2] + c->pos[2];
}

void get_random_pos_in_cell_spherical(grid_cell *c, grid *g, double ret_pos[]) {
  double pos_spherical[3];
  get_random_spherical_coordinates_in_cell(c, pos_spherical);
  spherical2cart(pos_spherical, ret_pos);

  assert(is_pos_in_grid(ret_pos, g));
  assert(is_pos_in_cell(ret_pos, c, g));
}

/*********************************************************************//**
 * get_next_cell_spherical
 *                                                               
 * Given a cell, a position, a direction and a distance to travel
 * (cell, pos, dir, r), the functon calculates the cell in this
 * directiond and the intersection of the wall and the path. position
 * (new_cell, intersection). Also, the distance to the intersection
 * point `dist` is returned.
 *                                                               
 * Return code is status which wall was crossed: 11 = r+ (wall in
 * positive r direction) 12 = theta+ 13 = phi+ -11 = r- ...
 * 
 * Technical detail is explained in B.1.2 of `tlac_notes.pdf'
 *************************************************************************/
int get_next_cell_spherical(grid *grid, grid_cell *cell, double pos[], 
                  double dir[], grid_cell **new_cell, 
                  double intersection[], double* dist) {
  double lambda[3], lambda_tmp[2];
  int i, iml = 0;
  int s_dir[3]; // sign of wall

  double sc_dir_pos = dir[0] * pos[0] + dir[1] * pos[1] + dir[2] * pos[2];
  double possq = pos[0] * pos[0] + pos[1] * pos[1] + pos[2] * pos[2];

  // Overlap neighboring shells enough to tolerate crossing-point roundoff.
  const double epsilon = 1e-15;
  double Rwsq[] = { (cell->pos[0] - (0.5 + epsilon) * cell->size[0]) *
                    (cell->pos[0] - (0.5 + epsilon) * cell->size[0]),
                    (cell->pos[0] + (0.5 + epsilon) * cell->size[0]) *
                    (cell->pos[0] + (0.5 + epsilon) * cell->size[0]) }; 
  double ha, hb;
  double tmp[3];

  assert(is_pos_in_cell(pos, cell, grid));
  assert(is_pos_in_grid(pos, grid));

  // Fix overlapping zone
  if(Rwsq[0] >= possq)
    Rwsq[0] = possq * (1 - epsilon);
  if(Rwsq[1] <= possq)
    Rwsq[1] = possq * (1 + epsilon);
  
  // --- r component ---
  assert(Rwsq[0] != Rwsq[1]);
  assert(Rwsq[0] < possq || (possq == 0.0 && Rwsq[0] == 0.0));
  assert(Rwsq[1] > possq);
  
  ha = sc_dir_pos * sc_dir_pos - possq;
  for(i = 0; i < 2; i++) { // check inner and outer wall
    if(Rwsq[i] == possq) {
      Rwsq[i] += (2 * i - 1) * epsilon * cell->size[0];
    }
    if(Rwsq[i] + ha > 0) {
      hb = sqrt(Rwsq[i] + ha);
      if( -sc_dir_pos - hb > 0)
        lambda_tmp[i] = -sc_dir_pos - hb;
      else if(-sc_dir_pos + hb > 0)
        lambda_tmp[i] = -sc_dir_pos + hb;
      else { // this crossing in the past (lambda <= 0)
        lambda_tmp[i] = DBL_MAX;
      }
    } else {
      lambda_tmp[i] = DBL_MAX;
    }
  }
  if(lambda_tmp[0] < lambda_tmp[1]) {
    lambda[0] = lambda_tmp[0];
    s_dir[0]  = -1;
  } else {
    lambda[0] = lambda_tmp[1];
    s_dir[0]  = 1;
  }
  // Error checks
#ifdef DEBUG
  if(lambda[0] <= 0 || lambda[0] == DBL_MAX) {
    print_error("Spherical ray at (%e, %e, %e) has no positive shell intersection. "
                "Shell radii: %e and %e cm. Candidate distances: %e and %e cm.",
                pos[0], pos[1], pos[2], sqrt(Rwsq[0]), sqrt(Rwsq[1]),
                lambda_tmp[0], lambda_tmp[1]);
  }
#endif
  assert(lambda[0] > 0);
  assert(lambda[0] != DBL_MAX);   // Check: Next shell has to be crossed
  for(i = 0; i < 3; i++)
    tmp[i] = pos[i] + lambda[0] * dir[i];
  ha = tmp[0] * tmp[0] + tmp[1] * tmp[1] + tmp[2] * tmp[2];
  assert(fabs(ha/Rwsq[(s_dir[0]+1)/2] - 1.0) < 1e-5);

#ifndef SIMPLE_SPHERICAL_GRID // switches theta & phi component off
  double thetaw, phiw, min_lambda = 0;
  // --- theta component ---
  lambda[1] = DBL_MAX;
  s_dir[1] = 0;
  for(i = 0; i < 2; i++) {
    thetaw = cell->pos[1] + (i * 2 - 1) * 0.5 * cell->size[1];
    if(thetaw == PI || thetaw == 0)
      continue;
    if(thetaw != 0.5 * PI) {
      if(thetaw > 0.5 * PI) {
        thetaw = PI - thetaw;
        ha = -1; // sign of cone
      } else {
        ha = 1;
      }
      lambda_tmp[0] = DBL_MAX;
      lambda_tmp[1] = DBL_MAX;
      ha = intersection_ray_cone(pos, dir, 2 * thetaw, 
                                 ha, lambda_tmp);
    } else {
      lambda_tmp[0] = -pos[2] / dir[2]; 
      if(lambda_tmp[0] < 0) lambda_tmp[0] = DBL_MAX;
    }
    if(lambda_tmp[0] < lambda[1]) {
      lambda[1] = lambda_tmp[0];
      s_dir[1] = (i * 2) - 1;
    }
  }
  assert(lambda[1] > 0);

  // --- phi component ---
  for(i = 0; i < 2; i++) {
    phiw = cell->pos[2] + ((i == 0) ? -1 : +1) * 0.5 * cell->size[2];
    ha = sin(phiw);
    hb = cos(phiw);
    lambda_tmp[i] = (ha * pos[0] - hb * pos[1]) / (hb * dir[1] - ha * dir[0]);
    if(lambda_tmp[i] <= 0)
      lambda_tmp[i] = DBL_MAX;
  }
  if(lambda_tmp[0] < lambda_tmp[1]) {
    lambda[2] = lambda_tmp[0];
    s_dir[2]  = -1;
  } else {
    lambda[2] = lambda_tmp[1];
    s_dir[2]  = 1;
  }
  // check
  assert(lambda[2] > 0);

  // --- Check which wall is the closest one ---
  iml = 0;
  min_lambda = lambda[0];
  if(lambda[1] < min_lambda) {
    iml = 1;
    min_lambda = lambda[1];
  }
  if(lambda[2] < min_lambda) {
    iml = 2;
    min_lambda = lambda[2];
  }
#endif /* end only spherical shells */

  assert(lambda[iml] >= 0);
  assert(lambda[iml] != 0);
  
  // --- How far is it to closest wall intersection ---
  *dist = lambda[iml];

  // --- Get neighboring cell & intersection point ---
  *new_cell = cell->nbs[2 * iml + (s_dir[iml] == 1)];

  assert(*dist > 0);
  for(i = 0; i < 3; i++) {
    intersection[i] = pos[i] +  (lambda[iml]) * dir[i];
    assert(!isnan(intersection[i]) && !isinf(intersection[i]));
  }

  // Return code (see above)
  return (iml + 11) * s_dir[iml];

}

/********************************************************************//**
 * cell_velocity_scalar_product_spherical
 *                                                                  
 * Calculates scalar product between `vec` and velocity of grid cell
 * `c`. Returns result.
 *                                                                  
 * Note that c->vel is given in spherical coordinates.
 ************************************************************************/
double cell_velocity_scalar_product_spherical(grid_cell *c, double vec[],
                                              double pos[]) {
  double d = norm3d(pos);
  if(d == 0)
    return 0;
  else
    return c->vel[0] * scalar_product_3d(vec, pos)  /  d;

}

/*********************************************************************//**
 * set_grid_values_ring_spherical
 *                                                                 
 * Set values n_HI, n_D... given in all the cells lying in the ring
 * between Rin and Rout.
 *                                                                 
 * Note: A negative value means the parameter is left unchanged
 * (except for vel, there nan has the same effect)
 *                                                                 
 * Returns the numbers of cells modified.
 *************************************************************************/
int set_grid_values_ring_spherical(grid *g, double Rin, double Rout,
                                   double n_HI, double n_D,
                                   double T, double L, double vel) {
  int i, j, k;
  double r;
  grid_cell *c;
  int n = 0;

  assert(Rout >= Rin);

  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        r = c->pos[0];
        
        if(r > Rin && r <= Rout) {
          if(n_HI >= 0)
            c->n_HI = n_HI;
          if(n_D >= 0)
            c->n_D = n_D;
          if(T >= 0)
            c->T = T;
          if(L >= 0)
            c->L = L;

          if(!isnan(vel) ) {
            c->vel[0] = vel / thermal_velocity_hydrogen(c->T);
          }
          n++;
        }
      }
    }
  }

  return n;

}

#endif
