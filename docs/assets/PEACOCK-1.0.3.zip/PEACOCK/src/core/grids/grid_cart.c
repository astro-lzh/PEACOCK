#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <float.h>

#include "grid_cart.h"
#include "../misc/mem.h"
#include "../misc/messages.h"
#include "../misc/rand_tools.h"
#include "../misc/my_math.h"
#include "../physical_properties.h"
#include "../grid.h"

/*******************************************************************//**
 * create_uniform_grid Creates a uniform grid with [nx,ny,nz] cells
 *                                             
 * Returns: 3D array of grid cells NULL if error occured
 *                                             
 * Arguments: Boxsize in each dimensision Number of cells for each
 * dimension
 ***********************************************************************/
grid *create_uniform_grid(double boxsize_x, double boxsize_y, double boxsize_z,
                          int nx, int ny, int nz) {
  if (!isfinite(boxsize_x) || !isfinite(boxsize_y) || !isfinite(boxsize_z) ||
      boxsize_x <= 0 || boxsize_y <= 0 || boxsize_z <= 0) {
    print_error("Cartesian grid lengths must be finite and positive.");
    exit(EXIT_FAILURE);
  }
  grid_cell ***cells = allocate_grid_cells(nx, ny, nz);
  int i, j, k;
  double *cell_sizes = check_realloc(NULL, 3 * sizeof(double));
  cell_sizes[0] = boxsize_x / nx;
  cell_sizes[1] = boxsize_y / ny;
  cell_sizes[2] = boxsize_z / nz;
  grid *ret_grid = check_realloc(NULL, sizeof(grid));
  ret_grid->type = GRID_CARTESIAN;

   // ---- Set initial variables of cells right ----
   for(i = 0; i < nx; i++) {
     for(j = 0; j < ny; j++) {
       for(k = 0; k < nz; k++) {
          cells[i][j][k] = (grid_cell){ .T = 1e4, .size = cell_sizes };

        // Set Neighbours
         if(i == 0)
           cells[i][j][k].nbs[0] = NULL;
         else
           cells[i][j][k].nbs[0] = &(cells[i - 1][j][k]);
         if(i == nx - 1)
           cells[i][j][k].nbs[1] = NULL;
         else
           cells[i][j][k].nbs[1] = &(cells[i + 1][j][k]);

         if(j == 0)
           cells[i][j][k].nbs[2] = NULL;
         else
           cells[i][j][k].nbs[2] = &(cells[i][j - 1][k]);
         if(j == ny - 1)
           cells[i][j][k].nbs[3] = NULL;
         else
           cells[i][j][k].nbs[3] = &(cells[i][j + 1][k]);

         if(k == 0)
           cells[i][j][k].nbs[4] = NULL;
         else
           cells[i][j][k].nbs[4] = &(cells[i][j][k - 1]);
         if(k == nz - 1)
           cells[i][j][k].nbs[5] = NULL;
         else
           cells[i][j][k].nbs[5] = &(cells[i][j][k + 1]);

         // Set positions
         cells[i][j][k].pos[0] = (0.5 + i) * cell_sizes[0];
         cells[i][j][k].pos[1] = (0.5 + j) * cell_sizes[1];
         cells[i][j][k].pos[2] = (0.5 + k) * cell_sizes[2];

       }
     }
   }

   /* --- Set grid variables ---- */
   ret_grid->ncells[0] = nx;
   ret_grid->ncells[1] = ny;
   ret_grid->ncells[2] = nz;

   ret_grid->boxsize[0] = boxsize_x;
   ret_grid->boxsize[1] = boxsize_y;
   ret_grid->boxsize[2] = boxsize_z;

   ret_grid->center[0] = 0.5 * boxsize_x;
   ret_grid->center[1] = 0.5 * boxsize_y;
   ret_grid->center[2] = 0.5 * boxsize_z;

   ret_grid->L_tot = 0;
   ret_grid->nobservers = 0;
   ret_grid->observers = NULL;

   ret_grid->cells = cells;

   ret_grid->uniform = 1;

   return ret_grid;
 }

 /*************************************************//**
  * make_grid_periodic
  *                                               
  * Makes grid g periodic around `direction` (0-2)
  *****************************************************/
 void make_grid_periodic(grid *g, const int direction) {
   int i,j;
   const int nx = g->ncells[0];
   const int ny = g->ncells[1];
   const int nz = g->ncells[2];

   switch(direction) {
   case 0: // x direction
     print_info("\tx-direction is periodic\n");
     for(i = 0; i < ny; i++) {
       for(j = 0; j < nz; j++) {
         g->cells[0][i][j].nbs[0] = &(g->cells[nx - 1][i][j]);
         g->cells[nx - 1][i][j].nbs[1] = &(g->cells[0][i][j]);
       } 
     }
     break;

   case 1: // y direction
     print_info("\ty-direction is periodic\n");
     for(i = 0; i < nx; i++) {
       for(j = 0; j < nz; j++) {
         g->cells[i][0][j].nbs[2] = &(g->cells[i][ny - 1][j]);
         g->cells[i][ny - 1][j].nbs[3] = &(g->cells[i][0][j]);
       } 
     }
     break;

   case 2: // z direction
     print_info("\tz-direction is periodic\n");
     for(i = 0; i < nx; i++) {
       for(j = 0; j < ny; j++) {
         g->cells[i][j][0].nbs[4] = &(g->cells[i][j][nz - 1]);
         g->cells[i][j][nz - 1].nbs[5] = &(g->cells[i][j][0]);
       } 
     }
     break;

   default:
     print_error("direction has to be in [0-2].");
     exit(-1);
     return;
   }

 #ifdef DEBUG
   int k, l;
   // Check that every cell has both neighbors along the periodic axis.
   for(i = 0; i < nx; i++) {
     for(j = 0; j < ny; j++) {
       for(k = 0; k < nz; k++) {
         for(l = 0; l <= 1; l++) {
           if(g->cells[i][j][k].nbs[direction * 2 + l] == NULL) {
             print_error("Neighbour (%d, %d, %d, %d) not set correctly!",
                         i, j, k, direction * 2 + l);
             exit(-1);
           }
         }
       }
     }
   }
 #endif

 }

 /*********************************************************************//**
  * get_random_pos_in_cell_cart
  *                                                              
  * Given a cell it calculates a random (uniform) position in the cell
  * and returns the result to the pointer given.
  *************************************************************************/
 void get_random_pos_in_cell_cart(grid_cell* c, grid* g, double ret_pos[]) {
   ret_pos[0] = (rand_uniform() - 0.5) * c->size[0] + c->pos[0];
   ret_pos[1] = (rand_uniform() - 0.5) * c->size[1] + c->pos[1];
   ret_pos[2] = (rand_uniform() - 0.5) * c->size[2] + c->pos[2];

   assert(is_pos_in_grid(ret_pos, g));
   assert(is_pos_in_cell(ret_pos, c, g));
 }

 /****************************************************//**
  * is_pos_in_grid_cart
  *                                                  
  * Checks if position is on grid. Returns 1 if true;
  ********************************************************/
 int is_pos_in_grid_cart(double *pos, grid *g) {
   const double epsilon = EPSILON_CHECK;
   int i;
   for(i = 0; i < 3; i++)
     if(!isfinite(pos[i]) || pos[i] > g->boxsize[i] * (1+epsilon) ||
        pos[i] < -g->boxsize[i] * epsilon) return 0;

   return 1;
 }

 /****************************************************//**
  * is_pos_in_cell_cart
  *                                                  
  * Checks if position is on cell. Returns 1 if true;
  ********************************************************/
 int is_pos_in_cell_cart(double *pos, grid_cell *c) {
   for(int axis = 0; axis < 3; axis++) {
     const double half_width = (0.5 + EPSILON_CHECK) * c->size[axis];
     if(!isfinite(pos[axis]) || pos[axis] > c->pos[axis] + half_width ||
        pos[axis] < c->pos[axis] - half_width) return 0;
   }

   return 1;
 }

 /*********************************************************************//**
  * get_next_cell_cart
  *                                                               
  * Given a cell, a position, a direction and a distance to travel
  * (cell, pos, dir, r), the functon calculates the cell in this
  * directiond and the intersection of the wall and the path. position
  * (new_cell, intersection). Also, the distance to the intersection
  * point `dist` is returned.
  *                                                               
  * Return code is status which wall was crossed: 1 = x+ (wall in
  * positive x direction) 2 = y+ 3 = z+ -1 = x- ...
  *************************************************************************/
 int get_next_cell_cart(grid *grid, grid_cell *cell, double pos[], 
                   double dir[], grid_cell **new_cell, 
                   double intersection[], double* dist) {
   double S[3][3];      // Intersecting points
   double W[3];         // wall position
   int s_dir[3];        // sign(n_i)
   double lambda[3];
   double min_lambda;
   const double periodic_boundary_tolerance = 1e-15;
   int i, j, iml;
   double dist_wp;      // distance to wall

   assert(is_pos_in_cell_cart(pos,cell));
   
  // --- Calculate wall intersections ---
  for(i = 0; i < 3; i++) {
    s_dir[i] = sign(dir[i]);
    if(s_dir[i] == 0) { // moving parallel to that wall
      lambda[i] = DBL_MAX;
      continue;
    }
    W[i] = cell->pos[i] + 0.5 * s_dir[i] * cell->size[i];
    lambda[i] = (W[i] - pos[i]) / (dir[i]);
    for(j = 0; j < 3; j++)
      S[i][j] = pos[j] + lambda[i] * dir[j];

  }

  // --- Check which wall is the closest one ---
  min_lambda = lambda[0];
  iml = 0;
  if(lambda[1] < min_lambda) {
    iml = 1;
    min_lambda = lambda[1];
  }
  if(lambda[2] < min_lambda) {
    iml = 2;
    min_lambda = lambda[2];
  }
  if(min_lambda == DBL_MAX || !isfinite(min_lambda)) {
    print_error("Cartesian ray has no finite wall intersection.");
    exit(EXIT_FAILURE);
  }

  // --- How far is it to closest wall intersection ---
  dist_wp = lambda[iml];

  // --- Get neighboring cell & intersection point ---
  *new_cell = cell->nbs[2 * iml + (s_dir[iml] == 1)];

  for(i = 0; i < 3; i++)
    intersection[i] = S[iml][i];

  // A periodic link reverses center ordering (or points to itself in a
  // one-cell dimension). Only the axis whose face was crossed can wrap.
  if(*new_cell != NULL) {
    const double box_length = grid->boxsize[iml];
    const double next_center = (*new_cell)->pos[iml];
    if(s_dir[iml] < 0 && next_center >= cell->pos[iml] &&
       intersection[iml] < periodic_boundary_tolerance * box_length)
      intersection[iml] = box_length;
    else if(s_dir[iml] > 0 && next_center <= cell->pos[iml] &&
            intersection[iml] > (1 - periodic_boundary_tolerance) * box_length)
      intersection[iml] = 0.0;
  }
  *dist = fabs(dist_wp);

  assert(*new_cell == NULL || is_pos_in_cell_cart(intersection, *new_cell));

  // Return code (see above)
  return (iml + 1) * s_dir[iml];

}

/********************************************************************//**
 * cell_velocity_scalar_product_cart
 *                                                                  
 * Calculates scalar product between `vec` and velocity of grid cell
 * `c`. Returns result.
 ************************************************************************/
inline double cell_velocity_scalar_product_cart(grid_cell *c, double vec[]) {
  return c->vel[0] * vec[0] + c->vel[1] * vec[1] + c->vel[2] * vec[2];
}

/*******************************************************************//**
 * set_grid_values_ring_cart
 *                                                                 
 * Set values n_HI, n_D... given in all the cells lying in the ring
 * between Rin and Rout.
 * 
 * The velocity `vel` is spherically symettric.
 *                                                                 
 * Note: A negative value means the parameter is left unchanged
 * (except for vel there nan has the same effect)
 *                                                                 
 * Returns the numbers of cells modified.
 ***********************************************************************/
int set_grid_values_ring_cart(grid *g, double Rin, double Rout,
                              double n_HI, double n_D,
                              double T, double L, double vel) {
  double center[] = { 0.5 * g->boxsize[0],
                      0.5 * g->boxsize[1],
                      0.5 * g->boxsize[2] };
  double relpos[3];
  int i, j, k;
  double r;
  grid_cell *c;
  int n = 0;

  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        relpos[0] = c->pos[0] - center[0];
        relpos[1] = c->pos[1] - center[1];
        relpos[2] = c->pos[2] - center[2];
        r = norm3d(relpos);

        if(r >= Rin && r < Rout) {
          if(n_HI >= 0)
            c->n_HI = n_HI;
          if(n_D >= 0)
            c->n_D = n_D;
          if(T >= 0)
            c->T = T;
          if(L >= 0)
            c->L = L;

          if(!isnan(vel) ) {
            if(r != 0) {
              c->vel[0] = relpos[0] / r * vel / thermal_velocity_hydrogen(c->T);
              c->vel[1] = relpos[1] / r * vel / thermal_velocity_hydrogen(c->T);
              c->vel[2] = relpos[2] / r * vel / thermal_velocity_hydrogen(c->T);
            } else if(vel == 0) {
              c->vel[0] = 0;
              c->vel[1] = 0;
              c->vel[2] = 0;
            }
          }

          n++;
        }
      }
    }
  }

  return n;
}

/* ------------------------------------------------------------ */
/**
   Sets random velocity in ring.

   @param *g      -- Grid to fill
   @param Rin     -- Inner radius of ring in cm
   @param Rout    -- Outer radius of ring in cm
   @param sigma_v -- standard deviation of each component in cm/s
   
   @return Number of cells filled.
**/
int set_grid_values_random_velocity_cart(grid *g, const double Rin,
                                         const double Rout,
                                         const double sigma_v) {
  double center[] = { 0.5 * g->boxsize[0],
                      0.5 * g->boxsize[1],
                      0.5 * g->boxsize[2] };
  double relpos[3];
  int i, j, k;
  double r;
  grid_cell *c;
  int nfilled = 0;
  
  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        relpos[0] = c->pos[0] - center[0];
        relpos[1] = c->pos[1] - center[1];
        relpos[2] = c->pos[2] - center[2];
        r = norm3d(relpos);

        if(r >= Rin && r < Rout) {
          c->vel[0] = rand_gaussian(sigma_v) / thermal_velocity_hydrogen(c->T);
          c->vel[1] = rand_gaussian(sigma_v) / thermal_velocity_hydrogen(c->T);
          c->vel[2] = rand_gaussian(sigma_v) / thermal_velocity_hydrogen(c->T);
          nfilled++;
        }
      }    
    } 
  }

  return nfilled;
}

/* ------------------------------------------------------------ */
/**
   Returns closest distance to closest wall.

   @param *g    -- Grid of cell
   @param *c    -- Cell
   @param pos[] -- Position from which to calculate.
   
   @return Distance to next wall in cm.
**/
double get_dist_to_wall_cart(grid_cell *c, double pos[]) {
  int i;
  double dist = DBL_MAX, cd;

  for(i = 0; i < 3; i++) {
    if(pos[i] > c->pos[i])
      cd = c->pos[i] + 0.5 * c->size[i] - pos[i];
    else
      cd = pos[i] - (c->pos[i] - 0.5 * c->size[i]);
    if(cd < dist)
      dist = cd;
  }

  assert(dist != DBL_MAX);

  // A point on a face or within the cell's roundoff tolerance needs no skip.
  return fmax(0.0, dist);
  
}
