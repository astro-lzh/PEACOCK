/* Cloud intersections and photon coordinate/frequency transformations.
 * Host geometry and motion setup live in cloud_placement.c and cloud_motion.c. */
#include "tlac_defs.h"
#ifdef CELL_CLOUDS
#include <assert.h>
#include <float.h>
#include <math.h>
#include <stdlib.h>
#include "clouds.h"
#include "grid.h"
#include "physical_properties.h"
#include "propagation.h"
#include "misc/messages.h"
#include "misc/my_math.h"

int get_cloud_intersection(grid_cell *c, double pos[], double dir[],
                           double intersection[], double *dist) {
  if(c->nclouds == 0) return -1;

  int n;
  double lambda_min = DBL_MAX, cmin;
  double lambda_tmp[2];
  int min_i = 0;
  // Enter slightly inside the cloud so rounding cannot leave the packet outside.
  const double entry_radius_margin = 1e-10;

  for(unsigned int i = 0; i < c->nclouds; i++) {
    lambda_tmp[0] = DBL_MAX; lambda_tmp[1] = DBL_MAX;
    
    n = intersection_ray_sphere(pos, dir,
                                c->cloud_grids[i]->boxsize[0] * (1.0 - entry_radius_margin),
                                c->pos_clouds[i],
                                lambda_tmp);
    if(n != 2)
      continue;

    // Outside the cloud, both roots must lie ahead. Interior packets are
    // already propagated in the cloud grid, and tangencies have no path inside.
    if(lambda_tmp[0] < 0 || lambda_tmp[1] < 0) continue;

    cmin = fmin( lambda_tmp[0], lambda_tmp[1]);
    if(cmin < lambda_min) {
      lambda_min = cmin;
      min_i = i;
    }
    
  }

  if(lambda_min == DBL_MAX)
    return -1;
  else {
    intersection[0] = pos[0] + dir[0] * lambda_min;
    intersection[1] = pos[1] + dir[1] * lambda_min;
    intersection[2] = pos[2] + dir[2] * lambda_min;
    assert(distance_3d(intersection, c->pos_clouds[min_i]) <
           c->cloud_grids[min_i]->boxsize[0]);
    *dist = lambda_min * norm3d(dir);
    return min_i;
  }
}

void shift_to_cloud(photon *p, grid_cell *mother_cell, int cloud_id,
                    const int find_new_cell) {
  if(find_new_cell != 0 && find_new_cell != 1) {
    print_error("Cloud entry cell lookup must be 0 (outer shell) or 1 (locate position).");
    exit(EXIT_FAILURE);
  }
  int i;
  grid *cloud = mother_cell->cloud_grids[cloud_id];

  assert(cloud->type == GRID_SPHERICAL);
  assert(p->curr_cell != NULL);
  
  p->grid_shifted = p->grid;  
  p->cell_shifted = mother_cell;
  
  for(i = 0; i < 3; i++) {
    p->pos_shifted[i] += mother_cell->pos_clouds[cloud_id][i];
    p->vel_shifted[i] += mother_cell->vel_clouds[cloud_id][i];
    p->pos[i] -= mother_cell->pos_clouds[cloud_id][i];
  }
  p->grid = cloud;
  if(find_new_cell == 0)
    p->curr_cell = &(cloud->cells[cloud->ncells[0] - 1][0][0]);    
  else
    p->curr_cell = find_grid_cell(p->grid, p->pos);

  // frequency update due to cloud motion
  update_photon_values(p);
#ifdef PEACOCK_MULTILEVEL
  const double width = p->Delta_nu_D;
  const double frequency = LYA_NU0 + p->x * width;
  const double cloud_beta = scalar_product_3d(p->vel_shifted, p->dir) * width / LYA_NU0;
  p->x = (rt_frame_frequency(frequency, 0, cloud_beta) - LYA_NU0) / width;
#else
  p->x -= scalar_product_3d(p->vel_shifted, p->dir);
#endif

  assert(p->grid->type == GRID_SPHERICAL);
  assert_photon_pos(p);
  
}

void unshift_from_cloud(photon *p) {
  int i;

  // comes from outermost cell in cloud
#ifdef DEBUG
  if(p->prev_cell != &(p->grid->cells[ p->grid->ncells[0] - 1][0][0])) {
      print_error("Not coming from outermost shell!");
      print_photon(p);
    }
#endif
  assert(p->curr_cell == NULL);
  assert(p->prev_cell == &(p->grid->cells[ p->grid->ncells[0] - 1][0][0]));
  
  p->curr_cell = p->cell_shifted;
  for(i = 0; i < 3; i++) {
    p->pos[i] += p->pos_shifted[i];
    p->pos_shifted[i] = 0;
  }
  p->grid = p->grid_shifted;

  p->grid_shifted = NULL;
  p->cell_shifted = NULL;

  // frequency change due to cloud motion
  double old_Delta_nu_D = p->Delta_nu_D;
#ifdef PEACOCK_MULTILEVEL
  const double frequency = LYA_NU0 + p->x * old_Delta_nu_D;
  const double cloud_beta = scalar_product_3d(p->vel_shifted, p->dir) * old_Delta_nu_D / LYA_NU0;
  p->x = (rt_frame_frequency(frequency, cloud_beta, 0) - LYA_NU0) / old_Delta_nu_D;
  update_photon_values(p);
#else
  update_photon_values(p);
  p->x += scalar_product_3d(p->vel_shifted, p->dir) * old_Delta_nu_D / p->Delta_nu_D;
#endif

  for(i = 0; i < 3; i++)
    p->vel_shifted[i] = 0;
  
  p->nclouds_passed++;

  assert(is_pos_in_grid(p->pos, p->grid));
  assert(is_pos_in_cell(p->pos, p->curr_cell, p->grid));

}

int get_cloud_id(grid_cell *c, double pos[]) {
  for(unsigned int i = 0; i < c->nclouds; i++) {
    if(distance_3d(pos, c->pos_clouds[i]) < c->cloud_grids[i]->boxsize[0])
      return i;
  }

  return -1;
}

void free_clouds(grid *g) {
  if (g == NULL || g->cells == NULL) return;
  for (int i = 0; i < g->ncells[0]; i++) {
    for (int j = 0; j < g->ncells[1]; j++) {
      for (int k = 0; k < g->ncells[2]; k++) {
        grid_cell *cell = &g->cells[i][j][k];
        size_t capacity = cloud_storage_capacity(cell->nclouds);
        for (size_t slot = 0; slot < capacity; slot++) {
          free(cell->pos_clouds[slot]);
          free(cell->vel_clouds[slot]);
        }
        free(cell->pos_clouds);
        free(cell->vel_clouds);
        free(cell->cloud_grids);
        free(cell->v_flag_clouds);
        cell->pos_clouds = NULL;
        cell->vel_clouds = NULL;
        cell->cloud_grids = NULL;
        cell->v_flag_clouds = NULL;
        cell->nclouds = 0;
      }
    }
  }
}

#endif /* CELL_CLOUDS */
