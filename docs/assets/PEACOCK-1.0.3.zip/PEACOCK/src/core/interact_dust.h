#ifndef PEACOCK_INTERACT_DUST_H
#define PEACOCK_INTERACT_DUST_H

#include "photon.h"

void interact_dust(photon *p);

#endif
