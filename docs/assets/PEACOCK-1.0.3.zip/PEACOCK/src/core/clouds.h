/* PEACOCK clumpy-medium setup and transport, derived from tlac.
 * See docs/provenance.md for attribution and redistribution terms. */
#ifndef PEACOCK_CLOUDS_H
#define PEACOCK_CLOUDS_H

#include "tlac_defs.h"

#ifdef CELL_CLOUDS
#include <stddef.h>
#include "photon.h"

/* Cloud placement and motion configuration uses schema 2.
 * See docs/cloud-model.md for the supported modes. */
#define PEACOCK_CLOUD_MODE_SCHEMA 2
typedef enum {
  CLOUD_PLACEMENT_UNIFORM = 1,
  CLOUD_PLACEMENT_LATTICE = 2,
  CLOUD_PLACEMENT_CATALOGUE = 3
} cloud_placement_mode;

typedef enum {
  CLOUD_MOTION_NONE = 0,
  CLOUD_MOTION_RADIAL = 1,
  CLOUD_MOTION_GAUSSIAN = 2,
  CLOUD_MOTION_WIND = 3
} cloud_motion_mode;

/* Geometry inputs are in cm; the configuration adapter converts from pc.
 * Catalogue mode uses complete, precomputed cloud positions in native units. */
void create_clouds(const double filling_factor, double Rin, double Rout,
                   grid *cloud_grid, grid *meta_grid, int mode, double params[]
#ifdef PEACOCK_PAIRED_CATALOGUE
                   , double other_filling_factor, int population_index
#endif
                   );

/* Motion parameters use km/s and pc, as in the configuration.
 * Gaussian dispersion is per Cartesian axis. Population flags track which
 * components have been applied. */
void add_clouds_velocity(grid *g, int mode, double *params);

/* Shared by native grid importers and placement; 1 on insertion, 0 on rejection. */
int create_cloud_in_cell(grid *meta_grid, grid *cloud_grid, grid_cell *cell,
                         double position[], const int check_other_clouds);
void cloud_placement_check_progress(unsigned long long *failures, int placed,
                                    int remaining, const char *context);

/* Positions and velocities own one vector for every allocated slot. */
static inline size_t cloud_storage_capacity(unsigned int count) {
  return ((size_t)count + CLOUDS_ALLOCATE_STEP - 1) /
    CLOUDS_ALLOCATE_STEP * CLOUDS_ALLOCATE_STEP;
}

/* Transform position and frequency between the main grid and cloud grid.
 * Cloud lookup functions return -1 when no cloud is found. */
int get_cloud_intersection(grid_cell *cell, double position[], double direction[],
                           double intersection[], double *distance);
int get_cloud_id(grid_cell *cell, double position[]);
void shift_to_cloud(photon *p, grid_cell *mother_cell, int cloud_id,
                    const int find_new_cell);
void unshift_from_cloud(photon *p);

/* Release cell-owned vectors; cloud grids are borrowed and remain registered. */
void free_clouds(grid *g);

#endif /* CELL_CLOUDS */
#endif /* PEACOCK_CLOUDS_H */
