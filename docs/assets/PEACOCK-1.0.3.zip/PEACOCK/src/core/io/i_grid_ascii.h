#ifndef _I_GRID_ASCII_H_
#define _I_GRID_ASCII_H_

#include <stdio.h>
#include "../grid.h"
/*
  i_grid_ascii

  Reading in a grid file (that was stored with o_grid)

  i_grid_ascii_defined_clouds is the function to use.
*/


/*******************************************************************
 * i_grid_ascii_defined clouds                                     *
 *                                                                 *
 * Loads grid from file `filename` and returns pointer to it. Uses *
 * grids in `clouds` array to set clouds in newly created grid.    *
 *                                                                 *
 * Employs sizes of cloud to identify right cloud type.            *
 *******************************************************************/
grid* i_grid_ascii_defined_clouds(char* filename, int ncloud_types,
                                  grid **clouds);

void i_grid_ascii_jump2block(FILE *fp, char *label);

void i_grid_ascii_read_header(FILE *fp);

grid* i_grid_ascii_read_grid_data(FILE *fp);

void i_grid_ascii_check_block_end(FILE *fp, char* label);

void i_grid_ascii_read_cell_data(FILE* fp, grid* g);

void i_grid_ascii_read_cloud_data(FILE *fp, grid *g, int ncloud_types,
                            grid** clouds);


#endif /* _I_GRID_ASCII_H_ */
