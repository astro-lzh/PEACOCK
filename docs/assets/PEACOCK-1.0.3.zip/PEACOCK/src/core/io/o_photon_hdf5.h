/**
   @file o_photon_hdf5.c

   @brief Provides functionality for output photon information as HDF5 file.

   See test/output_test.py for an example on usage and the source file header
   for technical details.
**/

#ifndef _O_PHOTON_HDF5_H_
#define _O_PHOTON_HDF5_H_


#include <stdlib.h>
#include <stdio.h>

#include "../photon.h"
#include "o_photon.h"

#ifdef USE_HDF5

#include "hdf5.h"



typedef struct o_photon_file_hdf5_s {
  char filename[512];
  int nout;

  /* hdf5 things */
  hid_t file;
  hid_t dataspace, dataset;
  hid_t      s1_tid;         ///< HDF5 File datatype identifier
} o_photon_file_hdf5;


/********************************************//**
 * o_photon_hdf5_init_lya
 * 
 * @brief Inits output for Lya via hdf5 file
 * 
 * Creates file.
 ************************************************/
int o_photon_hdf5_init_lya(int filenumber, char* filename_prefix);


/********************************************//**
 * o_photon_hdf5_init_uv
 * 
 * @brief Inits output for UV via hdf5 file
 * 
 * Opens file.
 ************************************************/
int o_photon_hdf5_init_uv(int filenumber, char* filename_prefix);


/********************************************//**
 * o_photon_hdf5_init_vlya
 * 
 * @brief Inits output for virtual Lya via hdf5 file
 * 
 * Creates file.
 ************************************************/
int o_photon_hdf5_init_vlya(int filenumber, char* filename_prefix);



/**********************************************************************//**
 * o_photon_hdf5_init
 * 
 * Generic function to intialize an hdf5 file for photon output.
 **************************************************************************/
int o_photon_hdf5_init(int filenumber, char* filename_prefix);



/*****************************************************************************//**
 * o_photon_hdf5_set_file_specifier
 * 
 * @brief Sets file specifier in `op_hdf5[fn]`. Decides what is stored.
 * 
 * @param fn - file number
 * @param nextra_dbl - Number of additional doubles stored (in p->extra_info)
 * @param extra_names - Labels for additional information
 * 
 * @return 0 if all went fine
 *********************************************************************************/
int o_photon_hdf5_set_file_specifier(int fn, const int nextra_dbl,
                                     const char** extra_names);


/*****************************//**
 * o_photon_hdf5_set_filename
 * 
 * Sets filename in struct.
 *********************************/
int o_photon_hdf5_set_filename(int fn,  char* filename_prefix);


/************************************************************//**
 * o_photon_hdf5_create_file
 * 
 * Creates hdf5 file. Throws error if file already exists.
 ****************************************************************/
int o_photon_hdf5_create_file(int fn);


/*****************************************************//**
 * o_photon_hdf5_open_file
 * 
 * Opens corresponging file. Error if not successful.
 *********************************************************/
int o_photon_hdf5_open_file(int fn);


/*******************************************************//**
 * o_photon_hdf5_create_dataspace
 * 
 * @brief Creates dataspace and dataset in file struct.
 ***********************************************************/
int o_photon_hdf5_create_dataspace(int fn, char* dataset_name);

/*************************************************************//**
 * o_photon_hdf5
 *                                                           
 * Output data from a photon to file specified by filenumber.
 *****************************************************************/
void o_photon_hdf5(int fn, photon *p);


/*************************************************************//**
 * o_photon_hdf5
 *                                                           
 * Output data from a photon to file specified by filenumber.
 *****************************************************************/
void o_photon_hdf5(int filenumber, photon *p);


/**********************************//**
 * o_photon_hdf5_finalize
 *                                
 * Closes hdf5 objects.
 **************************************/
int o_photon_hdf5_finalize(int filenumber);

/// Getters
int o_photon_hdf5_get_nout(int filenumber);
char* o_photon_hdf5_get_filename(int fn);

#endif // USE_HDF5

/*************************************************************//**
 * o_photon_ftype_hdf5_lya
 * 
 * @brief function defines ouput photon file type "HDF5_LYA"
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_hdf5_lya(void);


/*************************************************************//**
 * o_photon_ftype_hdf5_uv
 * 
 * @brief function defines ouput photon file type "HDF5_UV"
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_hdf5_uv(void);


o_photon_ftype *o_photon_ftype_hdf5_vlya(void);



#endif

