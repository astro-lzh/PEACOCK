#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "../grid.h"
#include "../misc/messages.h"

#include "o_grid.h"

#include "i_grid.h"
#include "i_grid_ascii.h"
#include "i_grid_hdf5.h"

/*******************************************************************
 * i_grid_defined clouds                                           *
 *                                                                 *
 * Loads grid from file `filename` and returns pointer to it. Uses *
 * grids in `clouds` array to set clouds in newly created grid.    *
 *                                                                 *
 * Employs sizes of cloud to identify right cloud type.            *
 *******************************************************************/
grid* i_grid_defined_clouds(char* filename, int ncloud_types,
                            grid **clouds) {
  char *ext;
  grid *g;
  ext = strrchr(filename, '.');
  if (!ext) {
    print_error("Cannot identify grid file type without a suffix.");
    exit(-1);
  }
  ext += 1;
  if(!strcmp(ext, "dat") || !strcmp(ext, "ascii")) {
    g = i_grid_ascii_defined_clouds(filename, ncloud_types, clouds);
  } else if(!strcmp(ext, "grid")) {
    print_warning("Deprecated file suffix for tlac grid file found. Use `dat`,"
                  " `ascii` or `hdf5` instead.");
    g = i_grid_ascii_defined_clouds(filename, ncloud_types, clouds);
  } else {
#ifdef USE_HDF5
    if (strcmp(ext, "hdf5") && strcmp(ext, "h5")) {
      print_warning("Unknown grid file suffix \"%s\". Assuming HDF5.", ext);
    }
    g = i_grid_hdf5_defined_clouds(filename, ncloud_types, clouds);
#else
    print_error("Cannot read grid file \"%s\". Use ASCII or build with HDF5 support.",
                filename);
    exit(-1);
#endif
  }

  g->L_tot = get_total_luminosity(g);
  print_info("\t\tTotal grid luminosity %e\n", g->L_tot);

  return g;

    
}


