#ifndef _I_GRID_HDF5_H_
#define _I_GRID_HDF5_H_
/*
  i_grid_hdf5

  Reading in a grid file stored in hdf5 format.

  i_grid_hdf5_defined_clouds is the function to use.
*/

#ifdef USE_HDF5

#include "hdf5.h"
#include "../grid.h"

/*******************************************************************
 * i_grid_hdf5_defined clouds                                     *
 *                                                                 *
 * Loads grid from file `filename` and returns pointer to it. Uses *
 * grids in `clouds` array to set clouds in newly created grid.    *
 *                                                                 *
 * Employs sizes of cloud to identify right cloud type.            *
 *******************************************************************/
grid* i_grid_hdf5_defined_clouds(char* filename, int ncloud_types,
                                  grid **clouds);


void i_grid_hdf5_read_header(hid_t file_id);

grid* i_grid_hdf5_read_grid_data(hid_t file_id);

void i_grid_hdf5_read_cell_data(hid_t file_id, grid* g);

void i_grid_hdf5_read_cloud_data(hid_t, grid *g, int ncloud_types,
                                 grid** clouds);


#endif /* USE_HDF5 */

#endif /* _I_GRID_HDF5_H_ */
