#ifndef _O_PHOTON_ASCII_H_
#define _O_PHOTON_ASCII_H_

#include <stdlib.h>
#include <stdio.h>

#include "../photon.h"
#include "o_photon.h"


typedef struct o_photon_file_ascii_s {
  char filename[255];
  FILE *fp;
  int nout;
} o_photon_file_ascii;


/*************************************************************//**
 * o_photon_ftype_ascii_lya
 * 
 * @brief function defines ouput photon file type "ASCII_LYA"
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_ascii_lya(void);

/*************************************************************//**
 * o_photon_ftype_ascii_uv
 * 
 * @brief function defines ouput photon file type "ASCII_UV"
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_ascii_uv(void);

/*****************************************************************//**
 * o_photon_ascii_init
 * 
 * Generic function to intialize an ascii file for photon output.
 *********************************************************************/
int o_photon_ascii_init(int filenumber, char* filename_prefix,
                        char* filename_suffix);


int o_photon_ascii_init_lya(int filenumber, char* filename_prefix);
int o_photon_ascii_init_uv(int filenumber, char* filename_prefix);


/********************************************//**
 * o_photon_ascii_write_header
 *                                          
 * Writes header of photon output file to fp
 ************************************************/
void o_photon_ascii_write_header(FILE *fp);

/*************************************************************//**
 * o_photon_ascii
 *                                                           
 * Output data from a photon to file specified by filenumber.
 *****************************************************************/
void o_photon_ascii(int filenumber, photon *p);

/**********************************//**
 * o_photon_ascii_finalize
 *                                
 * Writes a footer and closes file
 **************************************/
int o_photon_ascii_finalize(int filenumber);

/// For tracking output
void o_photon_ascii_simple_write_header(FILE *fp);
void o_photon_ascii_simple(FILE *fp, unsigned long long id, int scatter_status, photon *p);

/// Getters
int o_photon_ascii_get_nout(int filenumber);
char* o_photon_ascii_get_filename(int fn);


#endif
