#include <stdio.h>
#include <stdlib.h>

#include "../grid.h"
#include "../misc/mem.h"

#include "o_grid.h"

/********************************************************************
 * o_grid                                                           *
 *                                                                  *
 * Outputs grid `g` to file named `filename`. Also, a `comment` may *
 *  be given to describe the grid better.                           *
 ********************************************************************/
void o_grid(char* filename, grid *g, char* comment) {
  FILE* fp = check_fopen(filename, "w");

  o_grid_start_block(fp, "HEADER");
  o_grid_write_header(fp, comment);
  o_grid_end_block(fp, "HEADER");

  o_grid_start_block(fp, "GRID_DATA");
  o_grid_write_grid_data(fp, g);
  o_grid_end_block(fp, "GRID_DATA");

  o_grid_start_block(fp, "CELL_DATA");
  o_grid_write_cell_data(fp, g);
  o_grid_end_block(fp, "CELL_DATA");

  o_grid_start_block(fp, "CLOUD_DATA");
  o_grid_write_cloud_data(fp, g);
  o_grid_end_block(fp, "CLOUD_DATA");

  fclose(fp);
}


void o_grid_start_block(FILE* fp, char* label) {
  fprintf(fp, "### START %s ###\n", label);
}


void o_grid_end_block(FILE* fp, char* label) {
  fprintf(fp, "### END %s ###\n", label);
}


void o_grid_write_header(FILE *fp, char* comment) {
  fprintf(fp, "tlac_o_grid_magic_number\t%d\n"
          "%s\n",
          TLAC_O_GRID_MAGICNUMBER,
          (comment == NULL) ? "(none)" : comment);
}


void o_grid_write_grid_data(FILE *fp, grid *g) {
  fprintf(fp,"%d\n"
          "%d %d %d\n"
          "%e %e %e\n"
          "%e\n",
          g->type,
          g->ncells[0], g->ncells[1], g->ncells[2],
          g->boxsize[0], g->boxsize[1], g->boxsize[2],
          g->L_tot);
}


void o_grid_write_cell_data(FILE *fp, grid *g) {
  int i, j, k;
  grid_cell *c;

  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0 ; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        fprintf(fp, "%e %e %e %e %e %e %e %e %e %e ",
                c->L, c->T, c->n_HI, c->n_D,
                c->pos[0], c->pos[1], c->pos[2],
                c->vel[0], c->vel[1], c->vel[2]
                );
#ifdef CELL_CLOUDS
        fprintf(fp, "%u", c->nclouds);
#else
        fprintf(fp, "%d", 0);
#endif
        fprintf(fp, "\n");
      }
    }
  }
}


void o_grid_write_cloud_data(FILE *fp, grid *g) {
#ifdef CELL_CLOUDS
  int i, j, k, l;
  grid_cell *c;
  
  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0 ; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        for(l = 0; l < c->nclouds; l++) {
          fprintf(fp, "%e %e %e %e %e %e %e %.1f",
                  c->pos_clouds[l][0], c->pos_clouds[l][1], c->pos_clouds[l][2],
                  c->vel_clouds[l][0], c->vel_clouds[l][1], c->vel_clouds[l][2],
                  c->cloud_grids[l]->boxsize[0], c->v_flag_clouds[l]);
          fprintf(fp, "\n"); 
        }
      }
    }
  }
#endif
}


