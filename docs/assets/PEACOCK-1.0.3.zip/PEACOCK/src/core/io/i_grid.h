#ifndef _I_GRID_H_
/*
  i_grid

  Reading in a grid file -- meta file.

  Loads a grid file. Calls appropriate function depending on file type.
*/

#include "../grid.h"

/*******************************************************************
 * i_grid_ascii_defined clouds                                     *
 *                                                                 *
 * Loads grid from file `filename` and returns pointer to it. Uses *
 * grids in `clouds` array to set clouds in newly created grid.    *
 *                                                                 *
 * Employs sizes of cloud to identify right cloud type.            *
 *******************************************************************/
grid* i_grid_defined_clouds(char* filename, int ncloud_types,
                            grid **clouds);



#endif // _I_GRID_H_
