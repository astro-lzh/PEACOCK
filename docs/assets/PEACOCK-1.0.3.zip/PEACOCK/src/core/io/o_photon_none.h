#ifndef _O_PHOTON_NONE_H_
#define _O_PHOTON_NONE_H_

#include <stdlib.h>
#include <stdio.h>

#include "../photon.h"
#include "o_photon.h"



o_photon_ftype *o_photon_ftype_none(void);

int o_photon_none_init(int filenumber, char* filename_prefix);
void o_photon_none(int filenumber, photon *p);

int o_photon_none_finalize(int filenumber);
int o_photon_none_get_nout(int filenumber);

char* o_photon_none_get_filename(int fn);

#endif /* _O_PHOTON_NONE_H_ */
