#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../misc/messages.h"
#include "o_photon_momentum.h"

typedef struct {
  FILE *stream;
  char filename[512];
  int count;
} momentum_output;
static momentum_output files[O_PHOTON_MAX_FILES];

static int initialize(int number, char *prefix) {
  momentum_output *file = &files[number];
  if (file->stream != NULL) {
    print_error("Momentum output %d is already open.", number);
    return -1;
  }
  int length = snprintf(file->filename, sizeof(file->filename),
                        "%s.momentum.%02d.bin", prefix, number);
  if (length < 0 || (size_t)length >= sizeof(file->filename)) {
    print_error("Momentum output filename is too long.");
    return -1;
  }
  /* Exclusive creation protects an existing observation file. */
  file->stream = fopen(file->filename, "wbx");
  if (file->stream == NULL) {
    print_error("Could not create momentum output %s (it may already exist).",
                file->filename);
    return -1;
  }
  file->count = 0;
  return 0;
}

static void output(int number, photon *p) {
  const double record[10] = {
    p->pos[0], p->pos[1], p->pos[2],
    p->dir_last[0], p->dir_last[1], p->dir_last[2],
    p->dir[0], p->dir[1], p->dir[2], p->x_last
  };
#ifdef USE_OMP
#pragma omp critical(peacock_momentum_output)
#endif
  {
    momentum_output *file = &files[number];
    if (file->stream == NULL ||
        fwrite(record, sizeof(record), 1, file->stream) != 1) {
      print_error("Could not write momentum observation %s.", file->filename);
      exit(EXIT_FAILURE);
    }
    file->count++;
  }
}

static int finalize(int number) {
  momentum_output *file = &files[number];
  if (file->stream == NULL) return 0;
  int status = fclose(file->stream);
  file->stream = NULL;
  return status == 0 ? 0 : -1;
}
static int get_count(int number) { return files[number].count; }
static char *get_filename(int number) { return files[number].filename; }

o_photon_ftype *o_photon_ftype_momentum(void) {
  static o_photon_ftype type = {
    .type_str = "BINARY_MOMENTUM",
    .init = initialize, .output = output, .finalize = finalize,
    .get_nout = get_count, .get_filename = get_filename
  };
  return &type;
}
