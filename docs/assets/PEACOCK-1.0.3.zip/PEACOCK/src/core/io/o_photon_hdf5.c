/**
   @file o_photon_hdf5.c

   @brief Provides functionality for output photon information as HDF5 file.

   Currently the modes "HDF5_LYA" and "HDF5_UV" are provided.

   The main idea is to create an dataspace with infinity as maximum size in one
   dimension
   ([http://www.hdfgroup.org/ftp/HDF5/current/src/unpacked/examples/h5_extend.c])
   
   The datatype is a "compund" one so we can store integers & doubles.
   ([http://www.hdfgroup.org/HDF5/doc/Intro/IntroExamples.html#Compound])

   To add more into the hdf5 file, simply add the variable into
   `o_photon_hdf5_set_file_specifier`.

   I found (3.12.2014) that HDF5 is about 30 times faster reading data than
   ASCII (both only one column and reading all).
   This performance depends significantly on the chunk size which I found
   empirically. Could be set smarter...?
   
   See test/output_test.py for an example.
 **/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../misc/mem.h"
#include "../misc/messages.h"
#include "../photon.h"
#include "o_photon_hdf5.h"
#include "o_photon.h"

#ifdef USE_HDF5

#include "hdf5.h"

static o_photon_file_hdf5 op_hdf5[10];

/*************************************************************//**
 * o_photon_ftype_hdf5_lya
 * 
 * @brief function defines ouput photon file type "HDF5_LYA"
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_hdf5_lya(void) {
  static o_photon_ftype t;

  strcpy(t.type_str, "HDF5_LYA");
  t.init         = &o_photon_hdf5_init_lya;
  t.output       = &o_photon_hdf5;
  t.finalize     = &o_photon_hdf5_finalize;
  t.get_nout     = &o_photon_hdf5_get_nout;
  t.get_filename = &o_photon_hdf5_get_filename;

  return &t;
}

/*************************************************************//**
 * o_photon_ftype_hdf5_uv
 * 
 * @brief function defines ouput photon file type "HDF5_UV"
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_hdf5_uv(void) {
  static o_photon_ftype t;

  strcpy(t.type_str, "HDF5_UV");
  t.init         = &o_photon_hdf5_init_uv;
  t.output       = &o_photon_hdf5;
  t.finalize     = &o_photon_hdf5_finalize;
  t.get_nout     = &o_photon_hdf5_get_nout;
  t.get_filename = &o_photon_hdf5_get_filename;

  return &t;
}

/*************************************************************//**
 * o_photon_ftype_hdf5_vlya
 * 
 * @brief function defines ouput photon file type "HDF5_VLYA"
 * 
 * For `virtual Lya photon`, i.e., for observers
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_hdf5_vlya(void) {
  static o_photon_ftype t;

  strcpy(t.type_str, "HDF5_VLYA");
  t.init         = &o_photon_hdf5_init_vlya;
  t.output       = &o_photon_hdf5;
  t.finalize     = &o_photon_hdf5_finalize;
  t.get_nout     = &o_photon_hdf5_get_nout;
  t.get_filename = &o_photon_hdf5_get_filename;

  return &t;
}

/********************************************//**
 * o_photon_hdf5_init_lya
 * 
 * @brief Inits output for Lya via hdf5 file
 * 
 * Creates file.
 ************************************************/
int o_photon_hdf5_init_lya(int filenumber, char* filename_prefix) {

#ifdef EXTRA_PHOTON_INFORMATION
#if  EXTRA_PHOTON_INFORMATION == 1 // Additional intrinsic values
  const char* extra_names[] = {"pos_i0", "pos_i1", "pos_i2", "sc_dir_bulk_i",
                              "Delta_nu_D_i"};
  int nextra = 5;
#else
  print_error("EXTRA_PHOTON_INFORMATION_MODE = %d not know.", EXTRA_PHOTON_INFORMATION);
  exit(-1);
#endif
#else // default
  const char* extra_names[] = {NULL};
  int nextra = 0;
#endif // EXTRA_PHOTON_INFORMATION

  if(o_photon_hdf5_set_file_specifier(filenumber, nextra, extra_names) < 0) {
    print_error("Problem in set file specifier!");
    return -1;
  }

  if(o_photon_hdf5_set_filename(filenumber, filename_prefix) < 0) {
    print_error("Problem setting filename!");
    return -1;
  }

  if(o_photon_hdf5_create_file(filenumber)) {
    print_error("Problem creating file!");
    return -1;
  }

  if(o_photon_hdf5_create_dataspace(filenumber, "Lya")) {
    print_error("Problem creating dataspace!");
    return -1;
  }

  return 0;
}

/********************************************//**
 * o_photon_hdf5_init_uv
 * 
 * @brief Inits output for UV via hdf5 file
 * 
 * Opens file.
 ************************************************/
int o_photon_hdf5_init_uv(int filenumber, char* filename_prefix) {
  if(o_photon_hdf5_init(filenumber, filename_prefix)) {
    print_error("Error initializing hdf5 file.");
    return -1;
  }

  if(o_photon_hdf5_open_file(filenumber)) {
    print_error("Problem opening file %s",op_hdf5[filenumber].filename);
    return -1;
  }

  if(o_photon_hdf5_create_dataspace(filenumber, "UV")) {
    print_error("Problem creating dataspace!");
    return -1;
  }

  return 0;
}

/********************************************//**
 * o_photon_hdf5_init_vlya
 * 
 * @brief Inits output for virtual Lya via hdf5 file
 * 
 * Creates groups for observers if not yet there.
 ************************************************/
int o_photon_hdf5_init_vlya(int filenumber, char* filename_prefix) {
  char cname[64];
  int i;
  hid_t group;
  hid_t gcpl = H5Pcreate (H5P_LINK_CREATE);
  const char weight_name[] = {"log_w"};
  const char* lbl[] = { weight_name };
  H5Pset_create_intermediate_group (gcpl, 1);

  op_hdf5[filenumber].nout = 0;

  if(o_photon_hdf5_set_file_specifier(filenumber, 1, lbl) < 0) {
    print_error("Problem in set file specifier!");
    return -1;
  }

  if(o_photon_hdf5_set_filename(filenumber, filename_prefix) < 0) {
    print_error("Problem setting filename!");
    return -1;
  }

  if(o_photon_hdf5_open_file(filenumber)) {
    print_error("Problem opening file %s",op_hdf5[filenumber].filename);
    return -1;
  }

  // Switch off hdf5 errors
  herr_t (*old_func)(hid_t,void*);
  void *old_client_data;
  H5Eget_auto(H5E_DEFAULT, &old_func, &old_client_data);
  H5Eset_auto(H5E_DEFAULT, NULL, NULL);

  for(i = 0; i < TLAC_MAX_OBSERVER; i++) {
    sprintf(cname, "observers/%02d", i);
    if(H5Gget_objinfo (op_hdf5[filenumber].file, cname, 0, NULL) != 0)
      break;
  }
  if(i == TLAC_MAX_OBSERVER) {
    print_error("Too many observers or problem checkinf for HDF5 groups.");
    return -1;
  }
  // Switch back on HDF5 error
  H5Eset_auto(H5E_DEFAULT, old_func, old_client_data);

  group = H5Gcreate (op_hdf5[filenumber].file,
                     cname, gcpl, H5P_DEFAULT, H5P_DEFAULT);

  sprintf(cname,"observers/%02d/Lya",i);
  if(o_photon_hdf5_create_dataspace(filenumber, cname)) {
    print_error("Problem creating dataspace %s!", cname);
    return -1;
  }

  H5Gclose (group);

  // Add additional information

  return 0;
}

/**********************************************************************//**
 * o_photon_hdf5_init
 * 
 * Generic function to intialize an hdf5 file for photon output.
 **************************************************************************/
int o_photon_hdf5_init(int filenumber, char* filename_prefix) {

  op_hdf5[filenumber].nout = 0;

  if(o_photon_hdf5_set_file_specifier(filenumber, 0, NULL) < 0) {
    print_error("Problem in set file specifier!");
    return -1;
  }

  if(o_photon_hdf5_set_filename(filenumber, filename_prefix) < 0) {
    print_error("Problem setting filename!");
    return -1;
  }

  return 0;
}

/*****************************************************************************//**
 * o_photon_hdf5_set_file_specifier
 * 
 * @brief Sets file specifier in `op_hdf5[fn]`. Decides what is stored.
 * 
 * @param fn - file number
 * @param nextra_dbl - Number of additional doubles stored (in p->extra_info)
 * @param extra_names - Labels for additional information
 * 
 * @return 0 if all went fine
 *********************************************************************************/
int o_photon_hdf5_set_file_specifier(int fn, const int nextra_dbl,
                                     const char** extra_names) {
    size_t     not_stored;     ///< How much is not stored of `photon`
    int i;

    if(nextra_dbl > PHOTON_MAX_EXTRA_INFO) {
      print_error("Trying to add too much extra information to photon. "
                  "Please increase the value of PHOTON_MAX_EXTRA_INFO in"
                  "`photon.h` (current value: %d, trying to add: %d items)",
                  PHOTON_MAX_EXTRA_INFO, nextra_dbl);
      return -1;
    }
    
    /*
      Check how much is not stored
    */
    struct emission_cfg_s *tmp;
    not_stored = sizeof(tmp) + 2 * sizeof(grid_cell*) + sizeof(grid*) + \
      4 * sizeof(double) + (PHOTON_MAX_EXTRA_INFO - nextra_dbl) * sizeof(double);
    
#ifdef CELL_CLOUDS
    not_stored += 6 * sizeof(double) + sizeof(grid_cell*) +     \
      sizeof(grid*);
#endif // CELL_CLOUDS
  /*
    Calculate offsets in memory
    naming convention for the fields:
    exactly as in photon.h. for an array stick the indice (start=0) to it

    Also the order has to be the same as in photon.h
   */
  op_hdf5[fn].s1_tid = H5Tcreate (H5T_COMPOUND,
                                  sizeof(photon) - not_stored);

  if(H5Tinsert(op_hdf5[fn].s1_tid, "pos0", HOFFSET(photon, pos),
               H5T_NATIVE_DOUBLE) < 0) {
    print_error("Error in H5Tinsert.");
    return -1;
  }
  H5Tinsert(op_hdf5[fn].s1_tid, "pos1", HOFFSET(photon, pos) + sizeof(double),
            H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "pos2",
            HOFFSET(photon, pos) + 2 * sizeof(double), H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "dir0", HOFFSET(photon, dir),
            H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "dir1", HOFFSET(photon, dir) + sizeof(double),
            H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "dir2",
            HOFFSET(photon, dir) + 2 * sizeof(double), H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "x", HOFFSET(photon, x), H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "Delta_nu_D",
            HOFFSET(photon, Delta_nu_D), H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "sc_dir_bulk", HOFFSET(photon, sc_dir_bulk),
            H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "tau", HOFFSET(photon, tau), H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "dist", HOFFSET(photon, dist),
            H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "c_HI_total", HOFFSET(photon, c_HI_total),
            H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "c_D_total", HOFFSET(photon, c_D_total),
            H5T_NATIVE_DOUBLE);
  H5Tinsert(op_hdf5[fn].s1_tid, "nscatter", HOFFSET(photon, nscatter),
            H5T_NATIVE_INT);
  if(H5Tinsert(op_hdf5[fn].s1_tid, "x_i", HOFFSET(photon, x_i),
               H5T_NATIVE_DOUBLE) < 0) {
    print_error("Error in H5Tinsert.");
    return -1;
  }

  for(i = 0; i < nextra_dbl; i++) {
    if(H5Tinsert(op_hdf5[fn].s1_tid, extra_names[i],
                 HOFFSET(photon, extra_info) + i * sizeof(double),
                 H5T_NATIVE_DOUBLE) < 0) {
      print_error("Error in H5Tinsert (%s).", extra_names[i]);
      return -1;
    } 
  }

#ifdef CELL_CLOUDS
  if(H5Tinsert(op_hdf5[fn].s1_tid, "nclouds_passed",
               HOFFSET(photon, nclouds_passed), H5T_NATIVE_INT) < 0) {
    print_error("Error in H5Tinsert.");
    return -1;
  }
#endif // CELL_CLOUDS

  return 0;
}

/*****************************//**
 * o_photon_hdf5_set_filename
 * 
 * Sets filename in struct.
 *********************************/
int o_photon_hdf5_set_filename(int fn, char* filename_prefix) {
  int length = snprintf(op_hdf5[fn].filename, sizeof(op_hdf5[fn].filename),
                        "%s.h5", filename_prefix);
  if (length < 0 || (size_t)length >= sizeof(op_hdf5[fn].filename)) {
    print_error("HDF5 packet filename is too long.");
    return -1;
  }
  return 0;
}

#ifdef PEACOCK_MULTILEVEL
static int write_double_attribute(hid_t file, hid_t space, const char *name,
                                  const double *values) {
  hid_t attribute = H5Acreate2(file, name, H5T_NATIVE_DOUBLE, space,
                               H5P_DEFAULT, H5P_DEFAULT);
  if (attribute < 0)
    return -1;
  herr_t written = H5Awrite(attribute, H5T_NATIVE_DOUBLE, values);
  herr_t closed = H5Aclose(attribute);
  return written < 0 || closed < 0 ? -1 : 0;
}

static int write_atomic_metadata(hid_t file) {
  const char *scalar_names[] = {
    "reference_frequency_Hz", "reference_wavelength_A", "atomic_number",
    "ion_stage", "number_of_transitions", "ion_mass_g", "reference_transition_zero_based",
  };
  const double scalars[] = {
    LYA_NU0, 1e8 * LIGHT_SPEED / LYA_NU0, RT_Z, RT_STAGE, RT_NLINES, RT_MASS, RT_REFERENCE,
  };
  hid_t scalar_space = H5Screate(H5S_SCALAR);
  if (scalar_space < 0)
    return -1;
  for (size_t i = 0; i < sizeof(scalars) / sizeof(*scalars); ++i) {
    if (write_double_attribute(file, scalar_space, scalar_names[i], &scalars[i]) < 0) {
      H5Sclose(scalar_space);
      return -1;
    }
  }
  H5Sclose(scalar_space);

  const char *column_names[] = {
    "transition_wavelength_A", "transition_A_s-1", "transition_f", "transition_Gamma_s-1",
    "transition_lower_1based", "transition_upper_1based", "transition_W2_factor",
    "transition_population_ratio",
  };
  hsize_t count = RT_NLINES;
  hid_t vector_space = H5Screate_simple(1, &count, NULL);
  if (vector_space < 0)
    return -1;
  for (size_t column = 0; column < sizeof(column_names) / sizeof(*column_names); ++column) {
    double values[RT_MAX_LINES];
    for (int i = 0; i < RT_NLINES; ++i) {
      const rt_transition *line = &rt_lines[i];
      const double row[] = {
        1e8 * LIGHT_SPEED / line->nu, line->A, line->f, rt_gamma[line->upper],
        line->lower + 1, line->upper + 1, line->w2, rt_pop[line->lower],
      };
      values[i] = row[column];
    }
    if (write_double_attribute(file, vector_space, column_names[column], values) < 0) {
      H5Sclose(vector_space);
      return -1;
    }
  }
  H5Sclose(vector_space);
  return 0;
}
#endif

/************************************************************//**
 * o_photon_hdf5_create_file
 * 
 * Creates hdf5 file. Throws error if file already exists.
 ****************************************************************/
int o_photon_hdf5_create_file(int fn) {
  /* HDF5 performs the existence check and creation as one operation. */
  op_hdf5[fn].file = H5Fcreate(op_hdf5[fn].filename, H5F_ACC_EXCL,
                              H5P_DEFAULT, H5P_DEFAULT);
  if (op_hdf5[fn].file < 0) {
    print_error("Could not create HDF5 output %s (it may already exist).",
                op_hdf5[fn].filename);
    return -1;
  }
#ifdef PEACOCK_MULTILEVEL
  if (write_atomic_metadata(op_hdf5[fn].file) < 0) {
    print_error("Could not write atomic metadata to %s.", op_hdf5[fn].filename);
    H5Fclose(op_hdf5[fn].file);
    return -1;
  }
#endif

  return 0;
}

/*****************************************************//**
 * o_photon_hdf5_open_file
 * 
 * Opens corresponging file. Error if not successful.
 *********************************************************/
int o_photon_hdf5_open_file(int fn) {
  op_hdf5[fn].file = H5Fopen(op_hdf5[fn].filename,
                             H5F_ACC_RDWR, H5P_DEFAULT);
  if(op_hdf5[fn].file < 0)
    return -1;

  return 0;
}

/*******************************************************//**
 * o_photon_hdf5_create_dataspace
 * 
 * @brief Creates dataspace and dataset in file struct.
 ***********************************************************/
int o_photon_hdf5_create_dataspace(int fn, char* dataset_name) {
  hid_t prop;
  ///! Chunk size affects performance *significantly*!!!
  hsize_t chunksize[] = {196,1};
  hsize_t initsize[]  = {0,0};
  hsize_t maxsize[]   = {H5S_UNLIMITED, 1};
  
  /* Modify dataset creation properties, i.e. enable chunking  */
  prop = H5Pcreate(H5P_DATASET_CREATE);
  if (prop < 0) return -1;
  if (H5Pset_chunk(prop, 2, chunksize) < 0) {
    H5Pclose(prop);
    return -1;
  }

  op_hdf5[fn].dataspace = H5Screate_simple(2, initsize, maxsize);
  if (op_hdf5[fn].dataspace < 0) {
    H5Pclose(prop);
    return -1;
  }
  op_hdf5[fn].dataset = H5Dcreate2(op_hdf5[fn].file, dataset_name,
                                   op_hdf5[fn].s1_tid,
                                   op_hdf5[fn].dataspace,
                                   H5P_DEFAULT, prop, H5P_DEFAULT);
  H5Pclose(prop);
  if (op_hdf5[fn].dataset < 0) {
    H5Sclose(op_hdf5[fn].dataspace);
    return -1;
  }
  return 0;
}

/*************************************************************//**
 * o_photon_hdf5
 *                                                           
 * Output data from a photon to file specified by filenumber.
 *****************************************************************/
void o_photon_hdf5(int fn, photon *p) {
#ifdef USE_OMP
#pragma omp critical
{
#endif

  hsize_t extspace[]   = {1, 1};
  hsize_t offset[]     = { op_hdf5[fn].nout ,0};
  hsize_t newspace[]   = { op_hdf5[fn].nout + 1, 1 };
  hid_t memspace       = H5Screate_simple(2, extspace, NULL);
  
  if( (memspace < 0) || (H5Dset_extent(op_hdf5[fn].dataset, newspace )))
    print_error("Problem extending data space!");

  hid_t filespace = H5Dget_space(op_hdf5[fn].dataset);

  if(H5Sselect_hyperslab(filespace, H5S_SELECT_SET, offset, NULL,
                         extspace, NULL))
    print_error("Problem selection hyperslab!");

  /* Modify photon properties for output. */
#ifdef CELL_CLOUDS
  double *d = p->pos_shifted;
#else
  double d[] = {0, 0, 0};
#endif
  p->pos[0] -= p->dist * p->dir[0] - d[0]; // Position of last scattering
  p->pos[1] -= p->dist * p->dir[1] - d[1];
  p->pos[2] -= p->dist * p->dir[2] - d[2];
  
#ifdef PEACOCK_MULTILEVEL
  const double saved_local_x = p->x;
#endif
  p->x = o_photon_observer_detuning(p);

  /* Write to file */
  if(H5Dwrite(op_hdf5[fn].dataset, op_hdf5[fn].s1_tid, memspace, filespace,
              H5P_DEFAULT, p) < 0)
    print_error("Problem writing to hdf5 file!");

  /* Modify back  */
  p->pos[0] += p->dist * p->dir[0] + d[0]; // Position of last scattering
  p->pos[1] += p->dist * p->dir[1] + d[1];
  p->pos[2] += p->dist * p->dir[2] + d[2];
  
#ifdef PEACOCK_MULTILEVEL
  p->x = saved_local_x;
#else
  p->x -= p->sc_dir_bulk;
#endif

  op_hdf5[fn].nout++;

  H5Sclose (memspace);
  H5Sclose (filespace);

#ifdef USE_OMP
} // critical OMP clause ending
#endif

}

/**********************************//**
 * o_photon_hdf5_finalize
 *                                
 * Closes hdf5 objects.
 **************************************/
int o_photon_hdf5_finalize(int fn) {
  H5Tclose(op_hdf5[fn].s1_tid);
  H5Sclose(op_hdf5[fn].dataspace);
  H5Dclose(op_hdf5[fn].dataset);
  H5Fclose(op_hdf5[fn].file);

  return 0;
}

int o_photon_hdf5_get_nout(int filenumber) {
  return op_hdf5[filenumber].nout;
}

char* o_photon_hdf5_get_filename(int fn) {
  return op_hdf5[fn].filename;
}

#else // not compiled with hdf5 support

o_photon_ftype *o_photon_ftype_hdf5_lya(void) {
  print_error("tlac was not compiled with the hdf5 library enabled. "
              "Please re-compile tlac or select another ouput format!");
  exit(-1);

  return NULL;
}

o_photon_ftype *o_photon_ftype_hdf5_uv(void) {
  return o_photon_ftype_hdf5_lya();
}

o_photon_ftype *o_photon_ftype_hdf5_vlya(void) {
  return o_photon_ftype_hdf5_lya();
}

#endif // USE_HDF5

