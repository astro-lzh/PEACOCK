#include <stdio.h>
#include <errno.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "../grid.h"
#include "../misc/mem.h"
#include "../misc/messages.h"

#include "../clouds.h"

#include "o_grid.h"



#include "i_grid.h"
#include "i_grid_ascii.h"

/*******************************************************************
 * i_grid_ascii_defined clouds                                           *
 *                                                                 *
 * Loads grid from file `filename` and returns pointer to it. Uses *
 * grids in `clouds` array to set clouds in newly created grid.    *
 *                                                                 *
 * Employs sizes of cloud to identify right cloud type.            *
 *******************************************************************/
grid* i_grid_ascii_defined_clouds(char* filename, int ncloud_types, grid **clouds) {
  int i, j;
  FILE* fp = check_fopen(filename, "r");
  grid *ret;

  print_info("\tReading in grid from %s...\n", filename);
  
  for(i = 0; i < ncloud_types; i++) {
    for(j = 0 ; j < ncloud_types; j++) {
      if(i == j) continue;

      if(clouds[i]->boxsize[0] == clouds[j]->boxsize[0]) {
        print_error("Two given clouds have the same radius. As the radius is "
                    "used to tell them apart, this cannot be the case. Please "
                    "change the radius of one cloud type slightly to make "
                    "that work!");
        exit(-1);
      }
    }
  }

  i_grid_ascii_jump2block(fp, "HEADER");
  i_grid_ascii_read_header(fp);

  i_grid_ascii_jump2block(fp, "GRID_DATA");
  print_info("\t\tCreate grid...\n");
  ret = i_grid_ascii_read_grid_data(fp);
  print_info("\t\t...done!\n");
  i_grid_ascii_check_block_end(fp, "GRID_DATA");

  i_grid_ascii_jump2block(fp, "CELL_DATA");
  print_info("\t\tRead cell data...\n");
  i_grid_ascii_read_cell_data(fp, ret);
  print_info("\t\t...done!\n");
  i_grid_ascii_check_block_end(fp, "CELL_DATA");

  i_grid_ascii_jump2block(fp, "CLOUD_DATA");
  i_grid_ascii_read_cloud_data(fp, ret, ncloud_types, clouds);
  i_grid_ascii_check_block_end(fp, "CLOUD_DATA");

  fclose(fp);

  print_info("\t...done!\n");
  
  return ret;
}

void i_grid_ascii_jump2block(FILE *fp, char *label) {
  char marker[256];
  int length = snprintf(marker, sizeof(marker), "### START %s ###", label);
  if (length < 0 || (size_t)length >= sizeof(marker) ||
      fseek_line_containing_string(fp, marker) < 0 ||
      fgets(marker, sizeof(marker), fp) == NULL) {
    print_error("Grid file does not contain complete block %s.", label);
    exit(EXIT_FAILURE);
  }
}

void i_grid_ascii_read_header(FILE *fp) {
  int number;
  char line[256];
  if (fscanf(fp, "%*s %d", &number) != 1) {
    print_error("Grid header is missing its format version.");
    exit(EXIT_FAILURE);
  }
  if (number != TLAC_O_GRID_MAGICNUMBER) {
    print_warning("Grid format version differs (file %d, expected %d). "
                  "Attempting to read the grid.", number, TLAC_O_GRID_MAGICNUMBER);
  }
  print_info("\tComment of the file is the following:\n"
             "--------------------------------------------------\n");
  while (fgets(line, sizeof(line), fp) != NULL) {
    if (strstr(line, "### END HEADER ###") != NULL) {
      print_info("--------------------------------------------------\n");
      return;
    }
    print_info("%s", line);
  }
  print_error("Grid file ended before ### END HEADER ###.");
  exit(EXIT_FAILURE);
}

grid* i_grid_ascii_read_grid_data(FILE *fp) {
  int grid_type = 0;
  int ncells[3] = {0};
  double size[3] = {0};
  
  grid* ret;
  
  if((fscanf(fp, "%d\n", &grid_type) != 1) ||
     (fscanf(fp,"%d %d %d\n", &(ncells[0]), &(ncells[1]), &(ncells[2]))!=3) ||
     (fscanf(fp,"%lf %lf %lf\n", &(size[0]), &(size[1]), &(size[2]))!=3)) {
    print_error("More grid data expected! (%d, (%d, %d, %d), (%e, %e, %e)",
                grid_type,
                ncells[0], ncells[1], ncells[2],
                size[0], size[1], size[2]);
    exit(-1);
  }

  ret = create_grid(grid_type, size, ncells, 0);
  
  if(fscanf(fp, "%le\n", &(ret->L_tot))!= 1) {
    print_error("More data expected!");
    exit(-1);
  }
  
  return ret;
}

void i_grid_ascii_check_block_end(FILE *fp, char* label) {
  char line[256], marker[256];
  int length = snprintf(marker, sizeof(marker), "### END %s ###", label);
  if (length < 0 || (size_t)length >= sizeof(marker) ||
      fgets(line, sizeof(line), fp) == NULL || strstr(line, marker) == NULL) {
    print_error("Grid file is missing the end of block %s.", label);
    exit(EXIT_FAILURE);
  }
}

void i_grid_ascii_read_cell_data(FILE* fp, grid* g) {
  int i, j, k;
  grid_cell *c;
  
  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0 ; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);

        // Read general stuff
        if(fscanf(fp, "%le %le %le %le %le %le %le %le %le %le ",
                  &(c->L), &(c->T), &(c->n_HI), &(c->n_D),
                  &(c->pos[0]), &(c->pos[1]), &(c->pos[2]),
                  &(c->vel[0]), &(c->vel[1]), &(c->vel[2]) ) != 10) {
          print_error("Problem reading cell data at (%d,%d,%d)!", i, j, k);
          exit(-1);
        }        
        // Calculate cell sizes from position
        /* Cloud radii are matched to the registered cloud grids below. */
        if(i == 0)
          c->size[0] = 2 * c->pos[0];
        else if(i == g->ncells[0] - 1)
          c->size[0] = c->pos[0] - g->cells[i - 1][j][k].pos[0];
        else
          c->size[0] = 0.5 * (g->cells[i + 1][j][k].pos[0] -
                              g->cells[i - 1][j][k].pos[0]);
        if(j == 0)
          c->size[1] = 2 * c->pos[1];
        else if(j == g->ncells[1] - 1)
          c->size[1] = c->pos[1] - g->cells[i][j - 1][k].pos[1];
        else
          c->size[1] = 0.5 * (g->cells[i][j + 1][k].pos[1] -
                              g->cells[i][j - 1][k].pos[1]);
        if(k == 0)
          c->size[2] = 2 * c->pos[2];
        else if(k == g->ncells[2] - 1)
          c->size[2] = c->pos[2] - g->cells[i][j][k - 1].pos[2];
        else
          c->size[2] = 0.5 * (g->cells[i][j][k + 1].pos[2] -
                              g->cells[i][j][k - 1].pos[2]);

        char count[64], *end;
        if (fscanf(fp, "%63s\n", count) != 1 || strlen(count) == sizeof(count) - 1) {
          print_error("Problem reading nclouds at (%d,%d,%d).", i, j, k);
          exit(EXIT_FAILURE);
        }
        errno = 0;
        long parsed = strtol(count, &end, 10);
        if (errno || end == count || *end || parsed < 0 || parsed > INT_MAX) {
          print_error("Invalid nclouds at (%d,%d,%d).", i, j, k);
          exit(EXIT_FAILURE);
        }
#ifdef CELL_CLOUDS
        c->nclouds = (unsigned int)parsed;
#else
        if (parsed != 0) {
          print_error("Cloud data found but current compilation doesn't allow "
                      "for clouds.");
          exit(EXIT_FAILURE);
        }
#endif
      }
    }
  }

}

void i_grid_ascii_read_cloud_data(FILE *fp, grid *g, int ncloud_types,
                            grid** clouds) {
#ifdef CELL_CLOUDS
  int i, j, k, l, m;
  int ret;
  grid_cell *c;
  int nclouds;
  double pos[3], vel[3], radius;

  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0 ; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        nclouds = c->nclouds;
        c->nclouds = 0;
        for(l = 0; l < nclouds; l++) {
          char row[1024], extra;
          double velocity_flag = 0;
          do {
            if(fgets(row, sizeof(row), fp) == NULL) {
              print_error("Missing cloud record %d in cell (%d,%d,%d).", l, i, j, k);
              exit(EXIT_FAILURE);
            }
          } while(strspn(row, " \t\r\n") == strlen(row));
          if(strchr(row, '\n') == NULL && !feof(fp)) {
            print_error("Cloud record %d in cell (%d,%d,%d) is too long.", l, i, j, k);
            exit(EXIT_FAILURE);
          }
          ret = sscanf(row, "%le %le %le %le %le %le %le %le %c",
                       &pos[0], &pos[1], &pos[2],
                       &vel[0], &vel[1], &vel[2], &radius, &velocity_flag, &extra);
          if((ret != 7 && ret != 8) || !isfinite(radius) || radius <= 0 ||
             !isfinite(pos[0]) || !isfinite(pos[1]) || !isfinite(pos[2]) ||
             !isfinite(vel[0]) || !isfinite(vel[1]) || !isfinite(vel[2]) ||
             !isfinite(velocity_flag)) {
            print_error("Expected 7 or 8 finite values and a positive radius in cloud record %d in cell (%d,%d,%d).",
                        l, i, j, k);
            exit(EXIT_FAILURE);
          }
          for(m = 0; m < ncloud_types; m++) {
            if(fabs(radius / clouds[m]->boxsize[0] - 1) < 1e-5)
              break;
          }
          if(m == ncloud_types) {
            print_error("No cloud type matches radius %e.", radius);
            exit(EXIT_FAILURE);
          }
          if(create_cloud_in_cell(g, clouds[m], c, pos, 0) != 1) {
            print_error("Could not create cloud record %d in cell (%d,%d,%d).", l, i, j, k);
            exit(EXIT_FAILURE);
          }
          for(m = 0; m < 3; m++)
            c->vel_clouds[c->nclouds - 1][m] = vel[m];
          c->v_flag_clouds[c->nclouds - 1] = velocity_flag;
        } /* end cloud loop */
        if(c->nclouds != nclouds)
          print_warning("There is not as many clouds in the cell as wished!");
      }
    }
  }
#endif
}

