/**
@file o_photon.c
@brief Meta file for handling photon output.

The structure of the output is as this:
  - The functions defined in this file are to be called from the outside
  - These are wrapper functions that call to whatever is defined given
    in the `o_photon_ftype` structure which has been "registered"
This allows for easy extendibility as well as several outputs can be called.
    
Here is a summary how to extend the output functionality.
You need the following:
  - A filled `struct o_photon_ftype_s` (defined in `o_photon.h`)
  - A function to return a pointer to this structure.
  - Add a call to this function into `o_photon_register_type`

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../misc/mem.h"
#include "../misc/messages.h"
#include "../photon.h"
#include "o_photon.h"

#include "o_photon_ascii.h"
#include "o_photon_hdf5.h"
#include "o_photon_none.h"
#include "o_photon_momentum.h"

static o_photon_file o_photon_files[O_PHOTON_MAX_FILES];


/*********************************************************//**
 * o_photon_init
 *                                              
 * @brief Initializes output file for output of photons
 *                                              
 * Arguments: filenumber (0-9), filename_prefix and type.
 * 
 * Returns: 0 if all went fine, otherwise -1
 *************************************************************/
int o_photon_init(int filenumber, char* filename_prefix,
                   char* type_str) {
  if( (filenumber < 0) || (filenumber >= O_PHOTON_MAX_FILES)
  || (filename_prefix == NULL) || (type_str == NULL)) {
    print_error("Unexpected parameters.");
    return -1;
  }

  if(o_photon_register_type(filenumber, type_str)) {
    print_error("Error in registering type.");
    return -1;
  }

  if(o_photon_files[filenumber].type->init(filenumber, filename_prefix)) {
    print_error("Error initializing file.");
    return -1;
  }

  return 0;
  
}


/*************************************************************************//**
 * o_photon_register_type
 * 
 * @brief Registers file type corresponding to `type_str` into filenumber
 * 
 * Will link the function pointers to its right counterpart.
 *****************************************************************************/
int o_photon_register_type(int filenumber, char* type_str) {

  /// Add here your own output types!
  o_photon_ftype *ftypes[] = {
    o_photon_ftype_ascii_lya(),
    o_photon_ftype_ascii_uv(),
#ifdef USE_HDF5
    o_photon_ftype_hdf5_lya(),
    o_photon_ftype_hdf5_uv(),
    o_photon_ftype_hdf5_vlya(),
#endif
    o_photon_ftype_momentum(),
    o_photon_ftype_none()
  };
  
  const int ntypes = sizeof(ftypes) / sizeof(o_photon_ftype*);
  int i;

  for(i = 0; i < ntypes; i++) {
    if(!strcmp(type_str, ftypes[i]->type_str))
      break;
  }
  
  if(i == ntypes) {
    print_error("File type `%s` not found!", type_str);
    return -1;
  }

  o_photon_files[filenumber].type = ftypes[i];

  return 0;
}

/*********************************************************************//**
 * o_photon
 *                                                                
 * Wrapper function to output data from a photon to file specified by
 * filenumber (and the filetype therein).
 *************************************************************************/
void o_photon(int filenumber, photon *p) {
  o_photon_files[filenumber].type->output(filenumber, p);
}


/********************************************************//**
 * o_photon_finalize
 *                  
 * Wrapper function to call apropriate finalize function
 ************************************************************/
int o_photon_finalize(int filenumber) {
  return o_photon_files[filenumber].type->finalize(filenumber);
}

/*********************************************************************//**
 * o_photon_get_nout
 * 
 * Wrapper function to return the number of photons outputted in file
 * `filenumber`
 *************************************************************************/
int o_photon_get_nout(int filenumber) {
  return o_photon_files[filenumber].type->get_nout(filenumber);
}

/**********************************************************//**
 * o_photon_get_filename
 * 
 * Wrapper function to get (full) filename of `filenumber`
 **************************************************************/
char* o_photon_get_filename(int filenumber) {
  return o_photon_files[filenumber].type->get_filename(filenumber);
}

