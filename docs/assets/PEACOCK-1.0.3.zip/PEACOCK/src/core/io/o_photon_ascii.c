#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../misc/mem.h"
#include "../photon.h"
#include "o_photon_ascii.h"

static o_photon_file_ascii o_photon_files_ascii[10];


/*************************************************************//**
 * o_photon_ftype_ascii_lya
 * 
 * @brief function defines ouput photon file type "ASCII_LYA"
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_ascii_lya(void) {
  static o_photon_ftype t;

  strcpy(t.type_str, "ASCII_LYA");
  t.init         = &o_photon_ascii_init_lya;
  t.output       = &o_photon_ascii;
  t.finalize     = &o_photon_ascii_finalize;
  t.get_nout     = &o_photon_ascii_get_nout;
  t.get_filename = &o_photon_ascii_get_filename;

  return &t;
}


/*************************************************************//**
 * o_photon_ftype_ascii_uv
 * 
 * @brief function defines ouput photon file type "ASCII_UV"
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_ascii_uv(void) {
  static o_photon_ftype t;

  strcpy(t.type_str, "ASCII_UV");
  t.init         = &o_photon_ascii_init_uv;
  t.output       = &o_photon_ascii;
  t.finalize     = &o_photon_ascii_finalize;
  t.get_nout     = &o_photon_ascii_get_nout;
  t.get_filename = &o_photon_ascii_get_filename;

  return &t;
}

/*****************************************************************//**
 * o_photon_ascii_init
 * 
 * Generic function to intialize an ascii file for photon output.
 *********************************************************************/
int o_photon_ascii_init(int filenumber, char* filename_prefix,
                        char* filename_suffix) {
  o_photon_file_ascii *file = &o_photon_files_ascii[filenumber];
  int length = snprintf(file->filename, sizeof(file->filename), "%s%s",
                        filename_prefix, filename_suffix);
  if (length < 0 || (size_t)length >= sizeof(file->filename)) {
    fprintf(stderr, "ASCII packet filename is too long.\n");
    exit(EXIT_FAILURE);
  }
  file->fp = check_fopen(file->filename, "w");
  o_photon_files_ascii[filenumber].nout=0;
  
  o_photon_ascii_write_header(o_photon_files_ascii[filenumber].fp);

  return 0;
}


int o_photon_ascii_init_lya(int filenumber, char* filename_prefix) {
  return o_photon_ascii_init(filenumber, filename_prefix, ".dat");
}


int o_photon_ascii_init_uv(int filenumber, char* filename_prefix) {
  return o_photon_ascii_init(filenumber, filename_prefix, ".uvdat");
}


/********************************************//**
 * o_photon_write_header
 *                                          
 * Writes header of photon output file to fp
 ************************************************/
void o_photon_ascii_write_header(FILE *fp) {
  fprintf(fp, "# pos(1-3) dir(4-6) x(7) curr_tau(8) "
          "Delta_nu_D(9) a(10) x_cw(11) "
          "dist(12) nscatter(13) x_bulk(14) sc_dir_bulk(15) "
          "nclouds_passed(16) c_HI_total(17) c_D_total(18) x_i(19)\n");
}


/*************************************************************//**
 * o_photon_ascii
 *                                                           
 * Output data from a photon to file specified by filenumber.
 *****************************************************************/
void o_photon_ascii(int filenumber, photon *p) {
  const double xobs = o_photon_observer_detuning(p);
#ifdef USE_OMP
#pragma omp critical
{
#endif
  fprintf(o_photon_files_ascii[filenumber].fp, "%e %e %e %e %e %e %e %e %e %e %e %e"
          " %d %e %e %d %e %e %e"
          " ",
          p->pos[0] - p->dist * p->dir[0],
          p->pos[1] - p->dist * p->dir[1],
          p->pos[2] - p->dist * p->dir[2], 
          p->dir[0], p->dir[1], p->dir[2],
          xobs,
          p->curr_tau,
          p->Delta_nu_D,
          p->a,
          p->x_cw,
          p->dist,
          p->nscatter,
          p->x,
          p->sc_dir_bulk,
#ifdef CELL_CLOUDS
          p->nclouds_passed,
#else
          0,
#endif
          p->c_HI_total,
          p->c_D_total,
          p->x_i
          );
  
  fprintf(o_photon_files_ascii[filenumber].fp, "\n");
  o_photon_files_ascii[filenumber].nout++;
#ifdef USE_OMP
} // critical OMP clause ending
#endif

  
}


/**********************************//**
 * o_photon_ascii_finalize
 *                                
 * Writes a footer and closes file
 **************************************/
int o_photon_ascii_finalize(int filenumber) {
  
  fprintf(o_photon_files_ascii[filenumber].fp, "# %d photons written.\n",
          o_photon_files_ascii[filenumber].nout);

  fclose(o_photon_files_ascii[filenumber].fp);

  return 0;
}


void o_photon_ascii_simple_write_header(FILE *fp) {
  fprintf(fp, "# id(1) pos(2-4) dir(5-7) x(8) "
          "scatter_status(9) xobs(10) nscatter(11)\n");

}


void o_photon_ascii_simple(FILE *fp, unsigned long long id, int scatter_status, photon *p) {
  const double xobs = o_photon_observer_detuning(p);

#ifdef CELL_CLOUDS
  double *d = p->pos_shifted;
#else
  double d[] = {0, 0, 0};
#endif
  
  fprintf(fp, "%llu %e %e %e %e %e %e %e %d %e %d\n", 
          id,
          p->pos[0] + d[0],
          p->pos[1] + d[1],
          p->pos[2] + d[2],
          p->dir[0], p->dir[1], p->dir[2],
          p->x, scatter_status, xobs, p->nscatter);
}


int o_photon_ascii_get_nout(int filenumber) {
  return o_photon_files_ascii[filenumber].nout;
}


char* o_photon_ascii_get_filename(int fn) {
  return o_photon_files_ascii[fn].filename;
}

