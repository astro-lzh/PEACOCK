#ifndef _O_PHOTON_H_
#define _O_PHOTON_H_

#include <stdlib.h>
#include <stdio.h>

#include "../photon.h"
#ifdef PEACOCK_MULTILEVEL
#include "../physical_properties.h"
#endif

/* Output detuning in the observer frame, in the photon's Doppler units. */
static inline double o_photon_observer_detuning(const photon *p) {
#ifdef PEACOCK_MULTILEVEL
  const double width = p->Delta_nu_D;
  const double frequency = LYA_NU0 + p->x * width;
  const double beta = p->sc_dir_bulk * width / LYA_NU0;
  return (rt_frame_frequency(frequency, beta, 0) - LYA_NU0) / width;
#else
  return p->x + p->sc_dir_bulk;
#endif
}

/// Maximum files that can be open at once
#define O_PHOTON_MAX_FILES 10

/// File type structure
typedef struct o_photon_ftype_s {
  //!< Unique type string
  char type_str[64];
  
  //!< Init function
  //!< Arguments: filenumber, filename_prefix
  int (*init)(int, char*);

  //!< Output function, called from `o_photon`
  //!< Argument: filenumber, photon to output
  void (*output)(int, photon*);

  //!< Finalize function
  int (*finalize)(int);

  //!< Getters
  int (*get_nout)(int);
  char* (*get_filename)(int);
} o_photon_ftype;


typedef struct o_photon_file_s {
  o_photon_ftype* type; //!< type of output file
  int nout; //!< how many entries outputted.
} o_photon_file;


/*********************************************************//**
 * o_photon_init
 *                                              
 * @brief Initializes output file for output of photons
 *                                              
 * Arguments: filenumber (0-9), filename_prefix and type.
 * 
 * Returns: 0 if all went fine, otherwise -1
 *************************************************************/
int o_photon_init(int filenumber,   char* filename_prefix,
                    char* type_str);


/*************************************************************************//**
 * o_photon_register_type
 * 
 * @brief Registers file type corresponding to `type_str` into filenumber
 * 
 * Will link the function pointers to its right counterpart.
 *****************************************************************************/
int o_photon_register_type(int filenumber, char* type_str);


/*********************************************************************//**
 * o_photon
 *                                                                
 * Wrapper function to output data from a photon to file specified by
 * filenumber (and the filetype therein).
 *************************************************************************/
void o_photon(int filenumber, photon *p);


/***********************************
 * o_photon_finalize               *
 *                                 *
 * Writes a footer and closes file *
 ***********************************/
int o_photon_finalize(int filenumber);


/*********************************************************************//**
 * o_photon_get_nout
 * 
 * Wrapper function to return the number of photons outputted in file
 * `filenumber`
 *************************************************************************/
int o_photon_get_nout(int filenumer);


/**********************************************************//**
 * o_photon_get_filename
 * 
 * Wrapper function to get (full) filename of `filenumber`
 **************************************************************/
char* o_photon_get_filename(int filenumer);


#endif
