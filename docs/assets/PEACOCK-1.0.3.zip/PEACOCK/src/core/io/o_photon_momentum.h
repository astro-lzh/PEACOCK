#ifndef PEACOCK_O_PHOTON_MOMENTUM_H
#define PEACOCK_O_PHOTON_MOMENTUM_H
#include "o_photon.h"
/* Native-double records: position[3], incoming direction[3],
 * outgoing direction[3], incoming dimensionless frequency[1]. */
o_photon_ftype *o_photon_ftype_momentum(void);
#endif
