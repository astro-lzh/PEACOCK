#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <stdint.h>

#include "../grid.h"
#include "../clouds.h"
#include "../physical_properties.h"
#include "i_grid_hdf5.h"
#include "o_grid.h" // for magic number
#include "../misc/messages.h"
#include "../misc/mem.h"

#ifdef USE_HDF5

#include "hdf5.h"

/* H5S_ALL reads the complete file dataspace: a valid destination buffer alone
 * does not bound it. Check numeric type, shape and size before every read. */
static void invalid_hdf5(const char *name, const char *reason) {
  print_error("Invalid HDF5 grid field %s: %s.", name, reason);
  exit(EXIT_FAILURE);
}

static void check_numeric_type(hid_t type, hid_t memory_type, const char *name) {
  H5T_class_t kind = H5Tget_class(type);
  if (type < 0 || (kind != H5T_INTEGER && kind != H5T_FLOAT) ||
      (memory_type == H5T_NATIVE_LLONG && kind != H5T_INTEGER) ||
      H5Tget_size(type) == 0 || H5Tget_size(type) > sizeof(double))
    invalid_hdf5(name, "expected a supported numeric type (integer for counts)");
}

/* Cell scalars: [nx,ny,nz] or [N]. Cell vectors: [nx,ny,nz,3],
 * [N,3], or a flat [3N] stream. Cloud arrays: [N] for scalars and [N,3]
 * or a flat [3N] stream for vectors. A single scalar may
 * also use H5S_SCALAR, which has one unambiguous value. */
static void read_numeric_dataset(hid_t file, const char *name,
                                  hid_t memory_type, void *buffer,
                                  hsize_t count, int components,
                                  const int *cell_dimensions) {
  hid_t dataset = H5Dopen2(file, name, H5P_DEFAULT);
  if (dataset < 0) invalid_hdf5(name, "could not open dataset");
  hid_t space = H5Dget_space(dataset), type = H5Dget_type(dataset);
  if (space < 0 || type < 0) invalid_hdf5(name, "could not inspect dataset");
  check_numeric_type(type, memory_type, name);
  int rank = H5Sget_simple_extent_ndims(space);
  hsize_t shape[4] = {0};
  if (rank < 0 || rank > (cell_dimensions ? 4 : 2) ||
      H5Sget_simple_extent_dims(space, shape, NULL) < 0)
    invalid_hdf5(name, "unsupported dataset rank");
  if (count > (hsize_t)LLONG_MAX / (hsize_t)components ||
      H5Sget_simple_extent_npoints(space) != (hssize_t)(count * components))
    invalid_hdf5(name, "dataset element count does not match the grid/cloud count");
  int valid_shape = rank == 1 || (rank == 0 && components == 1 && count == 1);
  if (components == 3 && rank == 2)
    valid_shape = shape[0] == count && shape[1] == 3;
  if (cell_dimensions && rank == (components == 3 ? 4 : 3)) {
    valid_shape = shape[0] == (hsize_t)cell_dimensions[0] &&
                  shape[1] == (hsize_t)cell_dimensions[1] &&
                  shape[2] == (hsize_t)cell_dimensions[2] &&
                  (components != 3 || shape[3] == 3);
  }
  if (!valid_shape) invalid_hdf5(name, "dataset dimensions do not match the expected scalar/vector layout");
  if (H5Dread(dataset, memory_type, H5S_ALL, H5S_ALL, H5P_DEFAULT, buffer) < 0)
    invalid_hdf5(name, "dataset read/conversion failed");
  if (memory_type == H5T_NATIVE_DOUBLE) {
    const double *values = buffer;
    for (hsize_t i = 0; i < count * components; i++)
      if (!isfinite(values[i])) invalid_hdf5(name, "nonfinite numeric value");
  }
  H5Tclose(type); H5Sclose(space); H5Dclose(dataset);
}

/* Older files may store a three-value attribute either as a primitive
 * vector dataspace or as one fixed-array datatype. Convert both explicitly
 * to native memory types, never use the file datatype to size a C buffer. */
static void read_numeric_attribute(hid_t dataset, const char *name,
                                    hid_t memory_type, size_t expected, void *buffer) {
  hid_t attribute = H5Aopen(dataset, name, H5P_DEFAULT);
  if (attribute < 0) invalid_hdf5(name, "missing attribute");
  hid_t space = H5Aget_space(attribute), type = H5Aget_type(attribute);
  if (space < 0 || type < 0) invalid_hdf5(name, "could not inspect attribute");
  hssize_t points = H5Sget_simple_extent_npoints(space);
  int rank = H5Sget_simple_extent_ndims(space);
  hid_t base = type, memory_array = -1;
  size_t elements = 1;
  if (H5Tget_class(type) == H5T_ARRAY) {
    hsize_t dimensions[H5S_MAX_RANK];
    int array_rank = H5Tget_array_ndims(type);
    if (array_rank < 1 || array_rank > H5S_MAX_RANK ||
        H5Tget_array_dims2(type, dimensions) < 0)
      invalid_hdf5(name, "invalid fixed-array attribute type");
    for (int i = 0; i < array_rank; i++) {
      if (dimensions[i] == 0 || dimensions[i] > expected / elements)
        invalid_hdf5(name, "attribute array exceeds destination length");
      elements *= (size_t)dimensions[i];
    }
    base = H5Tget_super(type);
    memory_array = H5Tarray_create2(memory_type, array_rank, dimensions);
    if (base < 0 || memory_array < 0) invalid_hdf5(name, "could not convert fixed-array attribute");
  }
  check_numeric_type(base, memory_type, name);
  if (rank < 0 || rank > 1 || points <= 0 ||
      (size_t)points != expected / elements || expected % elements != 0)
    invalid_hdf5(name, "attribute element count does not match the expected length");
  if (H5Aread(attribute, memory_array >= 0 ? memory_array : memory_type, buffer) < 0)
    invalid_hdf5(name, "attribute read/conversion failed");
  if (memory_array >= 0) { H5Tclose(memory_array); H5Tclose(base); }
  H5Tclose(type); H5Sclose(space); H5Aclose(attribute);
}

static void read_comment_attribute(hid_t dataset) {
  hid_t attribute = H5Aopen(dataset, "comment", H5P_DEFAULT);
  if (attribute < 0) invalid_hdf5("comment", "missing attribute");
  hid_t type = H5Aget_type(attribute), space = H5Aget_space(attribute);
  if (type < 0 || space < 0 || H5Tget_class(type) != H5T_STRING ||
      H5Sget_simple_extent_npoints(space) != 1)
    invalid_hdf5("comment", "expected one string");
  char fixed[1025] = {0}, *variable = NULL;
  if (H5Tis_variable_str(type) > 0) {
    if (H5Aread(attribute, type, &variable) < 0)
      invalid_hdf5("comment", "string read failed");
  } else {
    hid_t memory_type = H5Tcopy(H5T_C_S1);
    H5Tset_size(memory_type, sizeof(fixed) - 1);
    H5Tset_strpad(memory_type, H5T_STR_NULLTERM);
    H5Tset_cset(memory_type, H5Tget_cset(type));
    if (H5Aread(attribute, memory_type, fixed) < 0)
      invalid_hdf5("comment", "string read failed");
    H5Tclose(memory_type);
  }
  print_info("\tComment of the file is the following:\n"
             "--------------------------------------------------\n");
  print_info("%.1024s\n", variable ? variable : fixed);
  print_info("--------------------------------------------------\n");
  if (variable) H5free_memory(variable);
  H5Tclose(type); H5Sclose(space); H5Aclose(attribute);
}

/***********************************************//**
 * i_grid_hdf5_defined_clouds
 * 
 * Reads hdf5 file containing grid information.
 ***************************************************/
grid* i_grid_hdf5_defined_clouds(char* filename, int ncloud_types,
                                  grid **clouds) {
  int i, j;
  grid *ret;

  hid_t file_id;
  
  print_info("Reading in grid from %s...\n", filename);

  for(i = 0; i < ncloud_types; i++) {
    for(j = 0 ; j < ncloud_types; j++) {
      if(i == j) continue;

      if(clouds[i]->boxsize[0] == clouds[j]->boxsize[0]) {
        print_error("Two given clouds have the same radius. As the radius is "
                    "used to tell them apart, this cannot be the case. Please "
                    "change the radius of one cloud type slightly to make "
                    "that work!");
        exit(-1);
      }
    }
  }

  file_id = H5Fopen(filename, H5F_ACC_RDONLY, H5P_DEFAULT);
  if(file_id < 0) {
    print_error("Could not open grid file \"%s\"!", filename);
    exit(-1);
  }

  print_info("\tReading header...\n");
  i_grid_hdf5_read_header(file_id);
  print_info("\tdone!\n");

  print_info("\tCreate grid...\n");
  ret = i_grid_hdf5_read_grid_data(file_id);
  print_info("\t...done!\n");

  // Switch off hdf5 errors
  herr_t (*old_func)(hid_t,void*);
  void *old_client_data;
  H5Eget_auto(H5E_DEFAULT, &old_func, &old_client_data);
  H5Eset_auto(H5E_DEFAULT, NULL, NULL);
  
  print_info("\tRead cell data...\n");
  i_grid_hdf5_read_cell_data(file_id, ret);
  print_info("\t...done!\n");

  print_info("\tRead cloud data...\n");
  i_grid_hdf5_read_cloud_data(file_id, ret, ncloud_types, clouds);
  print_info("\t...done!\n");

  // Switch back on HDF5 error
  H5Eset_auto(H5E_DEFAULT, old_func, old_client_data);

  H5Fclose(file_id);

  return ret;
}

grid* i_grid_hdf5_read_grid_data(hid_t file_id) {
  long long grid_type_value, cell_values[3];
  int grid_type, ncells[3];
  double size[3];
  grid *ret;
  hid_t dataset = H5Dopen2(file_id, "/grid_data", H5P_DEFAULT);
  if (dataset < 0) invalid_hdf5("/grid_data", "missing dataset");
  read_numeric_attribute(dataset, "grid_type", H5T_NATIVE_LLONG, 1, &grid_type_value);
  read_numeric_attribute(dataset, "ncells", H5T_NATIVE_LLONG, 3, cell_values);
  read_numeric_attribute(dataset, "boxsize", H5T_NATIVE_DOUBLE, 3, size);
  if (grid_type_value < INT_MIN || grid_type_value > INT_MAX)
    invalid_hdf5("grid_type", "value exceeds integer range");
  grid_type = (int)grid_type_value;
  for (int axis = 0; axis < 3; axis++) {
    if (cell_values[axis] <= 0 || cell_values[axis] > INT_MAX || !isfinite(size[axis]))
      invalid_hdf5("ncells/boxsize", "cell counts must be positive representable integers and sizes finite");
    ncells[axis] = (int)cell_values[axis];
  }
  H5Dclose(dataset);

  if(grid_type == GRID_CARTESIAN) {
    print_info("\tCreate cartesian grid size (%.2g,%.2g,%.2g)pc and "
               "(%d,%d,%d) cells.\n", size[0] / PARSEC, size[1] / PARSEC,
               size[2] / PARSEC, ncells[0], ncells[1], ncells[2]);
  } else if(grid_type == GRID_SPHERICAL) {
    print_info("\tCreate spherical grid with R=%.2gpc and "
               "(%d,%d,%d) cells.\n", size[0] / PARSEC,
               ncells[0], ncells[1], ncells[2]);
  } else {
    print_error("Unknown `grid_type` %d.", grid_type);
    exit(-1);
  }
  
  ret = create_grid(grid_type, size, ncells, 0);
  
  return ret;

}

void i_grid_hdf5_read_header(hid_t file_id) {
  long long number;
  hid_t dataset = H5Dopen2(file_id, "/header", H5P_DEFAULT);
  if (dataset < 0) invalid_hdf5("/header", "missing dataset");
  read_numeric_attribute(dataset, "tlac_o_grid_magic_number", H5T_NATIVE_LLONG, 1, &number);
  if (number != TLAC_O_GRID_MAGICNUMBER)
    print_warning("Grid format version differs (file %lld, expected %d); attempting import.",
                  number, TLAC_O_GRID_MAGICNUMBER);
  read_comment_attribute(dataset);
  H5Dclose(dataset);
}

void i_grid_hdf5_read_cell_data(hid_t file_id, grid* g) {
  long int i, j, k;
  int l;
  grid_cell *c;

  int nx = g->ncells[0];
  int ny = g->ncells[1];
  int nz = g->ncells[2];
  const size_t cell_count = (size_t)nx * ny * nz;
  if (cell_count > SIZE_MAX / (3 * sizeof(double)))
    invalid_hdf5("cell_data", "cell buffer size exceeds addressable range");
  double *buff = check_realloc(NULL, sizeof(double) * cell_count);
  long long *buff_int = NULL;
  double *buff_one = check_realloc(NULL, sizeof(double) * cell_count * 3);
  if((buff == NULL) || (buff_one == NULL)) {
    print_error("Error allocating memory.");
    exit(-1);
  }

  // position
  if(H5Gget_objinfo (file_id, "/cell_data/pos", 0, NULL) == 0) {
    print_info("\t\tPosition data found.");
    read_numeric_dataset(file_id, "/cell_data/pos", H5T_NATIVE_DOUBLE, buff_one, cell_count, 3, g->ncells);
    print_info("...\n");
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        for(k = 0 ; k < g->ncells[2]; k++) {
          c = &(g->cells[i][j][k]);
          for(l = 0; l < 3; l++)
            c->pos[l] = buff_one[i * ny * nz * 3 + j * nz * 3 + k * 3 + l];
        }
      }
    }
  } else {
    print_info("\t\tNo position data found. Assuming `natural' ordering.\n");
    g->uniform = 1;
  }

  // temperature
  if(H5Gget_objinfo (file_id, "/cell_data/T", 0, NULL) == 0) {
    print_info("\t\tTemperature data found.");
    read_numeric_dataset(file_id, "/cell_data/T", H5T_NATIVE_DOUBLE, buff, cell_count, 1, g->ncells);
    print_info("...\n");
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        for(k = 0 ; k < g->ncells[2]; k++) {
          c = &(g->cells[i][j][k]);
          c->T = buff[i * ((size_t)ny * nz) + j * nz + k];
        }
      }
    }
  } else {
    print_info("\t\tNo temperature data found!\n");
  }
  
  // luminosity
  if(H5Gget_objinfo (file_id, "/cell_data/L", 0, NULL) == 0) {
    print_info("\t\tLuminosity data found.");
    read_numeric_dataset(file_id, "/cell_data/L", H5T_NATIVE_DOUBLE, buff, cell_count, 1, g->ncells);
    print_info("...\n");
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        for(k = 0 ; k < g->ncells[2]; k++) {
          c = &(g->cells[i][j][k]);
          c->L = buff[i * ((size_t)ny * nz) + j * nz + k];
        }
      }
    }
  } else {
    print_info("\t\tNo luminosity data found.\n");
  }

  // n_HI
  if(H5Gget_objinfo (file_id, "/cell_data/n_HI", 0, NULL) == 0) {
    print_info("\t\tn_HI data found.");
    read_numeric_dataset(file_id, "/cell_data/n_HI", H5T_NATIVE_DOUBLE, buff, cell_count, 1, g->ncells);
    print_info("...\n");
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        for(k = 0 ; k < g->ncells[2]; k++) {
          c = &(g->cells[i][j][k]);
          c->n_HI = buff[i * ((size_t)ny * nz) + j * nz + k];
        }
      }
    }
  } else {
    print_info("\t\tNo hydrogen data found.\n");
  }

  // n_D
  if(H5Gget_objinfo (file_id, "/cell_data/n_D", 0, NULL) == 0) {
    print_info("\t\tDust data found.");
    read_numeric_dataset(file_id, "/cell_data/n_D", H5T_NATIVE_DOUBLE, buff, cell_count, 1, g->ncells);
    print_info("...\n");
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        for(k = 0 ; k < g->ncells[2]; k++) {
          c = &(g->cells[i][j][k]);
          c->n_D = buff[i * ((size_t)ny * nz) + j * nz + k];
        }
      }
    }
  } else {
    print_info("\t\tNo dust data found.\n");
  }

  // nclouds
  if(H5Gget_objinfo (file_id, "/cell_data/nclouds", 0, NULL) == 0) {
    print_warning("Clouds are under development with the hdf5 grid!");
    print_info("\t\tnclouds found.");

    if(buff_int == NULL)
      buff_int = check_realloc(NULL, sizeof(*buff_int) * cell_count);

    read_numeric_dataset(file_id, "/cell_data/nclouds", H5T_NATIVE_LLONG, buff_int, cell_count, 1, g->ncells);
    print_info("...\n");
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        for(k = 0 ; k < g->ncells[2]; k++) {
          c = &(g->cells[i][j][k]);
          if (buff_int[i * ((size_t)ny * nz) + j * nz + k] < 0 ||
              buff_int[i * ((size_t)ny * nz) + j * nz + k] > INT_MAX - CLOUDS_ALLOCATE_STEP)
            invalid_hdf5("/cell_data/nclouds", "cloud count must be nonnegative and below integer capacity");
#ifdef CELL_CLOUDS
          c->nclouds = buff_int[i * ((size_t)ny * nz) + j * nz + k];
#else
          if(buff_int[i * ((size_t)ny * nz) + j * nz + k] != 0) {
            print_error("Cloud data found but current compilation doesn't allow "
                        "for clouds.");
            exit(-1);
          }
#endif
        }
      }
    }
  } else {
    print_info("\t\tNo cloud data found.\n");
  }

  // velocity
  if(H5Gget_objinfo (file_id, "/cell_data/velocity", 0, NULL) == 0) {
    print_info("\t\tVelocity data found.");
    read_numeric_dataset(file_id, "/cell_data/velocity", H5T_NATIVE_DOUBLE, buff_one, cell_count, 3, g->ncells);
    print_info("...\n");
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        for(k = 0 ; k < g->ncells[2]; k++) {
          c = &(g->cells[i][j][k]);
          for(l = 0; l < 3; l++)
            c->vel[l] = buff_one[i * ny * nz * 3 + j * nz * 3 + k * 3 + l];
          // Check for one cell
        }
      }
    }
  } else {
    print_info("\t\tNo velocity data found.\n");
  }

  // Calculate cell sizes from position
  /* Cloud counts determine contiguous ranges in the imported cloud arrays. */
  if(!g->uniform) {
    print_info("Calculating cell sizes.");
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        for(k = 0 ; k < g->ncells[2]; k++) {
          c = &(g->cells[i][j][k]);

          // Have to allocate size memory for cells
          c->size = (double*)check_realloc(NULL, 3 * sizeof(double));

          if(i == 0)
            c->size[0] = 2 * c->pos[0];
          else if(i == g->ncells[0] - 1)
            c->size[0] = c->pos[0] - g->cells[i - 1][j][k].pos[0];
          else
            c->size[0] = 0.5 * (g->cells[i + 1][j][k].pos[0] -
                                g->cells[i - 1][j][k].pos[0]);
          if(j == 0)
            c->size[1] = 2 * c->pos[1];
          else if(j == g->ncells[1] - 1)
            c->size[1] = c->pos[1] - g->cells[i][j - 1][k].pos[1];
          else
            c->size[1] = 0.5 * (g->cells[i][j + 1][k].pos[1] -
                                g->cells[i][j - 1][k].pos[1]);
          if(k == 0)
            c->size[2] = 2 * c->pos[2];
          else if(k == g->ncells[2] - 1)
            c->size[2] = c->pos[2] - g->cells[i][j][k - 1].pos[2];
          else
            c->size[2] = 0.5 * (g->cells[i][j][k + 1].pos[2] -
                                g->cells[i][j][k - 1].pos[2]);
        
        }
      }
    }
    print_info("...\n");
  }

  free(buff);
  free(buff_one);

  if(buff_int != NULL)
    free(buff_int);

}

void i_grid_hdf5_read_cloud_data(hid_t file_id, grid *g, int ncloud_types,
                                 grid** clouds) {
#ifdef CELL_CLOUDS
  int i, j, k, l, m, check;
  grid *ccloud = NULL;
  grid_cell *c;
  unsigned long int nclouds_total = 0, nclouds_read = 0, n = 0;
  double csize, vth, rpos[3], cpos[3];
  int nx = g->ncells[0];
  int ny = g->ncells[1];
  int nz = g->ncells[2];
  const size_t cell_count = (size_t)nx * ny * nz;
  if (cell_count > SIZE_MAX / sizeof(int))
    invalid_hdf5("/cell_data/nclouds", "cell count buffer exceeds addressable range");
  int *nclouds_array = check_realloc(NULL, cell_count * sizeof(*nclouds_array));

  // First count all the clouds
  for(i = 0; i < g->ncells[0]; i++) {
    for(j = 0; j < g->ncells[1]; j++) {
      for(k = 0 ; k < g->ncells[2]; k++) {
        c = &(g->cells[i][j][k]);
        if (c->nclouds > INT_MAX - CLOUDS_ALLOCATE_STEP ||
            c->nclouds > ULONG_MAX - nclouds_total)
          invalid_hdf5("/cell_data/nclouds", "cloud count/total exceeds integer capacity");
        nclouds_total += c->nclouds;
        nclouds_array[((size_t)i * ny + j) * nz + k] = c->nclouds;
        c->nclouds = 0;
      }
    }
  }
  if(nclouds_total == 0 && ncloud_types == 0) {
    print_info("\t\tNo clouds wanted.\n");
    free(nclouds_array);
    return;
  } else if(nclouds_total == 0  || ncloud_types == 0){
    print_error("Something is wrong. nclouds(grid) = %ld, ncloud_types = %d. "
                "Did you forget to specify the cloud in the config file?\n",
                nclouds_total, ncloud_types);
    exit(-1);
  }
  if (nclouds_total > SIZE_MAX / (3 * sizeof(double)) ||
      nclouds_total > SIZE_MAX / sizeof(grid *) || nclouds_total > LLONG_MAX / 3)
    invalid_hdf5("cloud_data", "cloud buffer size exceeds addressable range");
  grid **clouds_to_place = check_realloc(NULL, (size_t)nclouds_total * sizeof(*clouds_to_place));
  double *buff_one = check_realloc(NULL, sizeof(double) * (size_t)nclouds_total);
  double *buff_three = check_realloc(NULL, sizeof(double) * (size_t)nclouds_total * 3);
  print_info("\t\t%lu clouds have to be placed.\n", nclouds_total);

  if(H5Gget_objinfo (file_id, "/cloud_data/size", 0, NULL) == 0) {
    print_info("\t\tCloud size data found.\n");
    read_numeric_dataset(file_id, "/cloud_data/size", H5T_NATIVE_DOUBLE, buff_one, nclouds_total, 1, NULL);
    for(i = 0; i < nx; i++) {
      for(j = 0; j < ny; j++) {
        for(k = 0 ; k < nz; k++) {
          c = &(g->cells[i][j][k]);
          for(n = 0; n < nclouds_array[((size_t)i * ny + j) * nz + k]; n++) {
              csize = buff_one[n + nclouds_read];
              for(m = 0; m < ncloud_types; m++) {
                ccloud = clouds[m];
                if(fabs(csize / ccloud->boxsize[0] - 1) < 1e-5)
                  break;
              }
              if(m == ncloud_types) {
                print_error("Cloud with size %e not found!", csize);
                exit(-1);
              }
              clouds_to_place[n + nclouds_read] = ccloud;
          }
          nclouds_read += nclouds_array[((size_t)i * ny + j) * nz + k];
        }
      }
    }
  } else {
    print_info("\t\tNo cloud size data found. Assuming first cloud.\n");
    for (n = 0; n < nclouds_total; n++)
      clouds_to_place[n] = clouds[0];
  }

  nclouds_read = 0;
  if(H5Gget_objinfo (file_id, "/cloud_data/pos", 0, NULL) == 0) {
    print_info("\t\tCloud position data found");
    read_numeric_dataset(file_id, "/cloud_data/pos", H5T_NATIVE_DOUBLE, buff_three, nclouds_total, 3, NULL);
    
    for(i = 0; i < nx; i++) {
      if(i % ((int)(nx / 10.) + 1) == 0)
        print_info(".");
      for(j = 0; j < ny; j++) {
        for(k = 0 ; k < nz; k++) { //             -- cell loops start -- 
          c = &(g->cells[i][j][k]);
          for(n = 0; n < nclouds_array[((size_t)i * ny + j) * nz + k]; n++) {
            for(l = 0; l < 3; l++) {
              cpos[l] = buff_three[3L * (n + nclouds_read) + l];
            }
            
            if (!isfinite(cpos[0]) || !isfinite(cpos[1]) || !isfinite(cpos[2]) ||
                !is_pos_in_cell(cpos, c, g)) {
              print_error("Stored cloud %lu lies outside its assigned cell (%d,%d,%d).",
                          (unsigned long)(n + nclouds_read), i, j, k);
              exit(EXIT_FAILURE);
            }
            // Check valid cloud positions only for the first few
            check = i < nx / 10.;
            if(!create_cloud_in_cell(g, clouds_to_place[n + nclouds_read],
                                     c, cpos, check)) {
              print_error("Cloud could not be placed in cell. "
                          "Please ensure the "
                          "cloud positions are in the right order. "
                          "Also check if the cloud radius is not too big. "
                          "Cloud position is (%e,%e,%e), radius %e. "
                          "Cell position below. "
                          "Is position in cell? %d. ",
                          cpos[0], cpos[1], cpos[2],
                          clouds_to_place[n + nclouds_read]->boxsize[0],
                          is_pos_in_cell(cpos, c, g)
                          );
              print_cell(c, g);
              exit(-1);
            }
          }
          nclouds_read += nclouds_array[((size_t)i * ny + j) * nz + k];

          if(nclouds_array[((size_t)i * ny + j) * nz + k] != c->nclouds) {
            print_error("%d clouds should be in this cell but only %u "
                        "positions found.", nclouds_array[((size_t)i * ny + j) * nz + k],
                        c->nclouds);
            exit(-1);
          }
        } // -->                                  -- cell loops end --
      }
    }
    print_info("!\n");
  } else {
    unsigned long long placement_failures = 0;
    print_info("\t\tNo clouds position data found. Assuming random order.\n");
    for(i = 0; i < nx; i++) {
      for(j = 0; j < ny; j++) {
        for(k = 0 ; k < nz; k++) {
          c = &(g->cells[i][j][k]);
          for(n = nclouds_read; n < nclouds_read+nclouds_array[((size_t)i * ny + j) * nz + k]; n++) {
            int placed;
            do {
              get_random_pos_in_cell(c, g, rpos);
              placed = create_cloud_in_cell(g, clouds_to_place[n], c, rpos, 1);
              cloud_placement_check_progress(&placement_failures, placed,
                                              nclouds_total - n,
                                              "HDF5 grid cloud placement");
            } while (!placed);
          }
          nclouds_read += nclouds_array[((size_t)i * ny + j) * nz + k];
          if(nclouds_array[((size_t)i * ny + j) * nz + k] != c->nclouds) {
            print_error("%d clouds should be in this cell but only %d "
                        "put there.", nclouds_array[((size_t)i * ny + j) * nz + k], c->nclouds);
            exit(-1);

          }
        }
      }
    }
  } // end cloud position
  if(nclouds_read != nclouds_total) {
      print_error("Not all cloud position data found (%lu vs %lu)!",
                  nclouds_read, nclouds_total);
      exit(-1);
    }

  nclouds_read = 0;
  if(H5Gget_objinfo (file_id, "/cloud_data/vel", 0, NULL) == 0) {
    print_info("\t\tCloud velocity data found.");
    read_numeric_dataset(file_id, "/cloud_data/vel", H5T_NATIVE_DOUBLE, buff_three, nclouds_total, 3, NULL);
    for(i = 0; i < nx; i++) {
      if(i % ((int)(nx / 10.) + 1) == 0)
        print_info(".");
      for(j = 0; j < ny; j++) {
        for(k = 0 ; k < nz; k++) {
          c = &(g->cells[i][j][k]);
          for(n = 0; n < nclouds_array[((size_t)i * ny + j) * nz + k]; n++) {
            ccloud = clouds_to_place[n + nclouds_read];
            vth = thermal_velocity_hydrogen(ccloud->cells[0][0][0].T);
            for(l = 0; l < 3; l++)
              c->vel_clouds[n][l] = \
                buff_three[3 * (nclouds_read + n) + l] / vth;
          }
          nclouds_read += nclouds_array[((size_t)i * ny + j) * nz + k];
          if(nclouds_array[((size_t)i * ny + j) * nz + k] != c->nclouds) {
            print_error("%d clouds should be in this cell but only %d "
                        "positions found.", nclouds_array[((size_t)i * ny + j) * nz + k], c->nclouds);
            exit(-1);
          }
        }
      }
    }
    print_info("!\n");
    if(nclouds_read != nclouds_total) {
      print_error("Not all cloud velocity data found (%lu vs %lu)!",
                  nclouds_read,
                  nclouds_total);
      exit(-1);
    }
  } else {
    print_info("\t\tNo clouds velocity data found.\n");
  } // end cloud velocity

  free(nclouds_array);
  free(buff_one);
  free(buff_three);
  free(clouds_to_place);
  
#endif
}

#endif /* USE_HDF5 */

