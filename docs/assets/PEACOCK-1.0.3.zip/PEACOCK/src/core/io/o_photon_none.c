#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../misc/mem.h"
#include "../photon.h"
#include "o_photon_none.h"


/*************************************************************//**
 * o_photon_ftype_none
 * 
 * @brief function defines ouput photon file type "NONE"
 * 
 * @return pointer to static ftype structure
 *****************************************************************/
o_photon_ftype *o_photon_ftype_none(void) {
  static o_photon_ftype t;

  strcpy(t.type_str, "NONE");
  t.init         = &o_photon_none_init;
  t.output       = &o_photon_none;
  t.finalize     = &o_photon_none_finalize;
  t.get_nout     = &o_photon_none_get_nout;
  t.get_filename = &o_photon_none_get_filename;

  return &t;
}


int o_photon_none_init(int filenumber, char* filename_prefix) {
  return 0;
}

void o_photon_none(int filenumber, photon *p) {
  // nothing
}


int o_photon_none_get_nout(int filenumber) {
  return 0;
}

int o_photon_none_finalize(int filenumber) {
  return 0;
}


char* o_photon_none_get_filename(int fn) {
  return NULL;
}


