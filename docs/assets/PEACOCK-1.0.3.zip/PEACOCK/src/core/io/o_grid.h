/*
  o_grid

  Can be used to output grid to file (in plain text).

  Use the o_grid function to do this.

  Data is structured in "blocks" which start with "### START `LABEL` ###" and
  end with "### END `LABEL` ###".
  The following blocks exist (in output order):
  HEADER, GRID_DATA, CELL_DATA, CLOUD_DATA

*/

#ifndef _O_GRID_H_
#define _O_GRID_H_

// Change this number if you change output format
#define TLAC_O_GRID_MAGICNUMBER 134227



/********************************************************************
 * o_grid                                                           *
 *                                                                  *
 * Outputs grid `g` to file named `filename`. Also, a `comment` may *
 *  be given to describe the grid better.                           *
 ********************************************************************/
void o_grid(char* filename, grid *g, char* comment);

void o_grid_start_block(FILE* fp, char* label);

void o_grid_end_block(FILE* fp, char* label);

void o_grid_write_header(FILE *fp, char* comment);

void o_grid_write_grid_data(FILE *fp, grid *g);

void o_grid_write_cell_data(FILE *fp, grid *g);

void o_grid_write_cloud_data(FILE *fp, grid *g);



#endif /* _O_GRID_H_ */
