#ifndef PEACOCK_EMISSION_H
#define PEACOCK_EMISSION_H

#include "emission_modes.h"

struct emission_cfg_s {
#if !defined(PEACOCK_MULTILEVEL) || defined(TLAC_HOST_EXPORT)
  double CII_ratio_21;
#endif
  int initial_pos_mode;
  double initial_pos_param;
  double p_cloud;
  int initial_freq_mode;
  double initial_freq_param;
};

#include "grid.h"
#include "photon.h"

void run_photons_with_tracking(grid *g, int nphot, struct emission_cfg_s cfg,
                               const char *tracking_filename);
void start_photon(photon *p, grid *g);
void set_photon_startpos(photon *p, grid *g);
void set_photon_startdir(photon *p);

#endif
