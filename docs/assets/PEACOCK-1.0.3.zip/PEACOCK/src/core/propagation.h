#ifndef PEACOCK_PROPAGATION_H
#define PEACOCK_PROPAGATION_H

#include <stdio.h>
#include "photon.h"

#define PHOTON_TAU_UNSAMPLED (-1.0)

/* Follow a packet to escape (1) or absorption (0). An optional stream
 * records events and outcomes with the ASCII tracking status codes. */
int propagate_photon(photon *p, FILE *tracking);

/* Draw an optical depth for the next interaction. */
double get_new_tau(void);

/* Advance to the nearer requested event or geometric boundary. Return 0
 * for an in-cell step or a wall/cloud code for a crossing. */
int update_photon_pos(photon *p, double distance, double *travelled);

#endif
