/* PEACOCK cloud geometry setup. Derived from tlac. See docs/provenance.md.
 * Uniform placement, jittered lattice placement and position catalogue
 * loading share cell storage. Geometry setup uses one serial RNG stream. */
#include "tlac_defs.h"
#ifdef CELL_CLOUDS
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef PEACOCK_MULTILEVEL
#include <dirent.h>
#endif
#include "clouds.h"
#include "grid.h"
#include "physical_properties.h"
#include "misc/messages.h"
#include "misc/mem.h"
#include "misc/my_math.h"
#include "misc/rand_tools.h"

typedef struct { double pos[3]; } catalogue_position;

static const double cloud_boundary_margin = 1.000001;
static const double grid_count_relative_tolerance = 0.05;
static const double grid_default_buffer = 1.54;
static const double cellwise_proposals_per_expected_cloud = 10.0;
static const double uniform_remaining_volume_tolerance = 0.01;

static double placement_shell_volume(double inner_radius, double outer_radius, grid *meta_grid);
static void place_uniform_clouds(int count, double inner_radius, double outer_radius, grid *cloud, grid *meta_grid);
static int seed_cartesian_cells(int count, double mean_count, double inner_radius, double outer_radius, grid *cloud, grid *meta_grid);
static int place_uniform_shell_candidates(int count, double inner_radius, double outer_radius, grid *cloud, grid *meta_grid);
static int place_lattice_clouds(int count, double buffer, double inner_radius, double outer_radius, grid *cloud, grid *meta_grid);
static void load_cloud_catalogue(int count, grid *cloud, grid *meta_grid
#ifdef PEACOCK_PAIRED_CATALOGUE
                                 , int companion_count, int population
#endif
                                 );

void cloud_placement_check_progress(unsigned long long *failures, int placed,
                                    int remaining, const char *context) {
  /* ceil(log(1e-12) / log1p(-1e-6)): at acceptance probability >=1e-6,
   * this many consecutive misses has probability <=1e-12. This operational
   * limit reports failure; it does not prove that geometry is impossible.
   * The exact integer is precomputed so each rejected proposal is inexpensive. */
  const unsigned long long failure_limit = 27631008ULL;
  if (placed) {
    *failures = 0;
  } else if (++*failures >= failure_limit) {
    print_error("Cloud placement (%s) made no progress in %llu proposals; "
                "%d clouds remain. Check radial distribution support, shell "
                "and cell dimensions/cloud radius, or reduce the filling factor. "
                "An extremely small acceptance probability can also cause this limit.",
                context, *failures, remaining);
    exit(EXIT_FAILURE);
  }
}

static void validate_cloud_placement(int nclouds, double Rin, double Rout,
                                      grid *cloud_grid, grid *meta_grid, int random_placement) {
  if (nclouds < 0 || cloud_grid == NULL || meta_grid == NULL ||
      cloud_grid->type != GRID_SPHERICAL || meta_grid->cells == NULL ||
      !isfinite(Rin) || !isfinite(Rout) || Rin < 0 || Rout <= Rin ||
      !isfinite(cloud_grid->boxsize[0]) || cloud_grid->boxsize[0] <= 0) {
    print_error("Cloud placement requires a nonnegative count, spherical clouds "
                "with finite positive radius, valid grids, and finite 0 <= Rin < Rout.");
    exit(EXIT_FAILURE);
  }
  size_t ncells = 1;
  for (int axis = 0; axis < 3; axis++) {
    if (meta_grid->ncells[axis] <= 0 ||
        ncells > (size_t)INT_MAX / (size_t)meta_grid->ncells[axis] ||
        !isfinite(meta_grid->center[axis])) {
      print_error("Cloud placement requires valid cell counts and a finite grid center.");
      exit(EXIT_FAILURE);
    }
    ncells *= (size_t)meta_grid->ncells[axis];
  }
  const double Rcloud = cloud_grid->boxsize[0];
  double maximum_center_radius;
  if (meta_grid->type == GRID_SPHERICAL) {
    if ((random_placement && ncells != 1) || !isfinite(meta_grid->boxsize[0]) ||
        meta_grid->boxsize[0] <= 0 ||
        (random_placement && !(meta_grid->boxsize[0] > cloud_boundary_margin * Rcloud))) {
      print_error("Spherical cloud placement supports one meta-grid cell, with "
                  "radius strictly larger than the cloud radius (including its boundary margin).");
      exit(EXIT_FAILURE);
    }
    maximum_center_radius = meta_grid->boxsize[0] - cloud_boundary_margin * Rcloud;
  } else if (meta_grid->type == GRID_CARTESIAN) {
    double farthest[3];
    for (int axis = 0; axis < 3; axis++) {
      const double cell_size = meta_grid->cells[0][0][0].size[axis];
      if (!isfinite(meta_grid->boxsize[axis]) || meta_grid->boxsize[axis] <= 0 ||
          !isfinite(cell_size) || cell_size <= 0 ||
          (random_placement && !(cell_size > 2 * cloud_boundary_margin * Rcloud))) {
        print_error("Cloud diameter including boundary margin must be smaller than "
                    "each Cartesian cell dimension (axis %d).", axis);
        exit(EXIT_FAILURE);
      }
      farthest[axis] = fmax(fabs(meta_grid->center[axis] - cloud_boundary_margin * Rcloud),
          fabs(meta_grid->boxsize[axis] - cloud_boundary_margin * Rcloud - meta_grid->center[axis]));
    }
    maximum_center_radius = norm3d(farthest);
  } else {
    print_error("Unsupported meta-grid type %d for cloud placement.", meta_grid->type);
    exit(EXIT_FAILURE);
  }
  if (random_placement && !(Rin < maximum_center_radius)) {
    print_error("No cloud centers fit outside Rin=%e within this grid after "
                "allowing for cloud radius=%e. Reduce Rin or the cloud size.", Rin, Rcloud);
    exit(EXIT_FAILURE);
  }
}

static void rollback_clouds(grid *g, const int *original_counts) {
  size_t index = 0;
  for (int i = 0; i < g->ncells[0]; i++)
    for (int j = 0; j < g->ncells[1]; j++)
      for (int k = 0; k < g->ncells[2]; k++, index++) {
        grid_cell *c = &g->cells[i][j][k];
        int keep = original_counts[index];
        size_t old_capacity = cloud_storage_capacity(c->nclouds);
        size_t keep_capacity = cloud_storage_capacity(keep);
        for (size_t slot = keep_capacity; slot < old_capacity; slot++) {
          free(c->pos_clouds[slot]);
          free(c->vel_clouds[slot]);
        }
        if (keep_capacity == 0) {
          free(c->pos_clouds); free(c->vel_clouds);
          free(c->cloud_grids); free(c->v_flag_clouds);
          c->pos_clouds = NULL; c->vel_clouds = NULL;
          c->cloud_grids = NULL; c->v_flag_clouds = NULL;
        } else if (old_capacity != keep_capacity) {
          c->pos_clouds = check_realloc(c->pos_clouds, keep_capacity * sizeof(*c->pos_clouds));
          c->vel_clouds = check_realloc(c->vel_clouds, keep_capacity * sizeof(*c->vel_clouds));
          c->cloud_grids = check_realloc(c->cloud_grids, keep_capacity * sizeof(*c->cloud_grids));
          c->v_flag_clouds = check_realloc(c->v_flag_clouds, keep_capacity * sizeof(*c->v_flag_clouds));
        }
        c->nclouds = keep;
      }
}

/* Cell storage is shared by checked placement and immutable catalogue import.
 * Grid templates are borrowed; only position/velocity vectors belong to cells.
 * Allocation uses blocks of CLOUDS_ALLOCATE_STEP slots. Rollback and
 * free_clouds use this capacity to release every allocated vector. */
static int append_cloud(grid_cell *cell, grid *cloud, const double position[3]) {
  if (!cell || !cloud || !position ||
      cell->nclouds > INT_MAX - CLOUDS_ALLOCATE_STEP ||
      !isfinite(cloud->boxsize[0]) || cloud->boxsize[0] <= 0) {
    print_error("Cloud insertion requires a valid cell/template, positive finite radius "
                "and a cloud count below integer capacity.");
    exit(EXIT_FAILURE);
  }
  for (int axis = 0; axis < 3; axis++)
    if (!isfinite(position[axis])) return 0;

  if (cell->nclouds % CLOUDS_ALLOCATE_STEP == 0) {
    const size_t capacity = (size_t)cell->nclouds + CLOUDS_ALLOCATE_STEP;
    cell->cloud_grids = check_realloc(cell->cloud_grids, capacity * sizeof(*cell->cloud_grids));
    cell->pos_clouds = check_realloc(cell->pos_clouds, capacity * sizeof(*cell->pos_clouds));
    cell->vel_clouds = check_realloc(cell->vel_clouds, capacity * sizeof(*cell->vel_clouds));
    cell->v_flag_clouds = check_realloc(cell->v_flag_clouds, capacity * sizeof(*cell->v_flag_clouds));
    for (size_t slot = cell->nclouds; slot < capacity; slot++) {
      cell->pos_clouds[slot] = check_realloc(NULL, 3 * sizeof(double));
      cell->vel_clouds[slot] = check_realloc(NULL, 3 * sizeof(double));
      cell->v_flag_clouds[slot] = 0.0;
    }
  }
  const unsigned int slot = cell->nclouds;
  for (int axis = 0; axis < 3; axis++) {
    cell->pos_clouds[slot][axis] = position[axis];
    cell->vel_clouds[slot][axis] = 0;
  }
  cell->v_flag_clouds[slot] = 0.0;
  cell->cloud_grids[slot] = cloud;
  cell->nclouds++;
  return 1;
}

void create_clouds(const double filling_factor, double Rin, double Rout,
                   grid *cloud_grid, grid *meta_grid, int mode, double params[]
#ifdef PEACOCK_PAIRED_CATALOGUE
                   , double other_filling_factor, int population
#endif
                   ) {
  if (mode != CLOUD_PLACEMENT_UNIFORM && mode != CLOUD_PLACEMENT_LATTICE &&
      mode != CLOUD_PLACEMENT_CATALOGUE) {
    print_error("Unsupported cloud placement model %d; select uniform, lattice or catalogue geometry.", mode);
    exit(EXIT_FAILURE);
  }
  if (!isfinite(filling_factor) || filling_factor < 0) {
    print_error("Cloud filling factor must be finite and nonnegative.");
    exit(EXIT_FAILURE);
  }
  if (filling_factor == 0) return;
  if (!isfinite(Rin) || !isfinite(Rout)) {
    print_error("Cloud shell radii must be finite.");
    exit(EXIT_FAILURE);
  }
  if (Rin < 0) Rin = 0; /* Clamp the inner radius to zero. */
  validate_cloud_placement(1, Rin, Rout, cloud_grid, meta_grid, 0);
#if TLAC_GRID != GRID_VARIABLE
  print_error("Cloud placement requires the variable-grid implementation.");
  exit(EXIT_FAILURE);
#endif
  const double radius = cloud_grid->boxsize[0];
  if (Rout < Rin + radius || 2 * radius > meta_grid->cells[0][0][0].size[0]) {
    print_error("The requested cloud radius does not fit the shell or meta-grid cells.");
    exit(EXIT_FAILURE);
  }
  const double shell_volume = placement_shell_volume(Rin, Rout, meta_grid);
  const double requested = filling_factor * shell_volume / (4.0/3.0 * PI * pow(radius, 3));
  if (!isfinite(shell_volume) || shell_volume <= 0 || !isfinite(requested) ||
      requested > INT_MAX - 0.5) {
    print_error("Cloud shell volume/count is invalid or exceeds integer capacity.");
    exit(EXIT_FAILURE);
  }
  if (filling_factor > 0.4)
    print_warning("This high filling factor can prevent placement of all requested clouds.");
  if (filling_factor > 0.7) {
    print_error("This filling factor is too close to the theoretical packing maximum.");
    exit(EXIT_FAILURE);
  }
  const int count = round(requested);
#ifdef PEACOCK_PAIRED_CATALOGUE
  const double other_requested = other_filling_factor * shell_volume /
    (4.0 / 3.0 * PI * pow(radius, 3));
  if (!isfinite(other_requested) || other_requested < 0 || other_requested > INT_MAX - 0.5) {
    print_error("The other cloud population count is invalid or exceeds integer capacity.");
    exit(EXIT_FAILURE);
  }
  const int companion_count = round(other_requested);
#endif
  print_info("Creating %d clouds between %.2g and %.2gpc (F_V=%g).\n",
              count, Rin/PARSEC, Rout/PARSEC, filling_factor);
  if (count == 0) {
    print_warning("The requested filling factor rounds to zero clouds.");
    return;
  }
  switch (mode) {
  case CLOUD_PLACEMENT_UNIFORM:
    place_uniform_clouds(count, Rin, Rout, cloud_grid, meta_grid);
    break;
  case CLOUD_PLACEMENT_LATTICE: {
    const double requested_buffer = params == NULL ? 0.0 : params[0];
    const double buffer = requested_buffer == 0.0 ? grid_default_buffer : requested_buffer;
    place_lattice_clouds(count, buffer, Rin, Rout, cloud_grid, meta_grid);
    break;
  }
  case CLOUD_PLACEMENT_CATALOGUE:
#ifdef PEACOCK_PAIRED_CATALOGUE
    load_cloud_catalogue(count, cloud_grid, meta_grid, companion_count, population);
#else
    load_cloud_catalogue(count, cloud_grid, meta_grid);
#endif
    break;
  }
}

static void place_uniform_clouds(int nclouds, double Rin, double Rout,
                           grid *cloud_grid, grid* meta_grid) {
  if (nclouds == 0) return;
  const int requested_count = nclouds;
  validate_cloud_placement(nclouds, Rin, Rout, cloud_grid, meta_grid, 1);
  const double Rcloud = cloud_grid->boxsize[0];
  double shellvol = placement_shell_volume(Rin, Rout, meta_grid);
  if (!isfinite(shellvol) || shellvol <= 0) {
    print_error("Cloud placement requires a finite positive shell volume.");
    exit(EXIT_FAILURE);
  }
  
  double cloudspercell;
  double fferror;
  double filling_factor = nclouds * 4.0 / 3.0 * PI
    * pow(Rcloud, 3) / shellvol;

  if(meta_grid->type == GRID_CARTESIAN) {
    cloudspercell = nclouds / (shellvol /
                               (meta_grid->cells[0][0][0].size[0] *
                                meta_grid->cells[0][0][0].size[1] *
                                meta_grid->cells[0][0][0].size[2]));
    print_info("\tclouds/cell=%.2e, ff=%.2e ==> ", cloudspercell,
               filling_factor);
  } else if(meta_grid->type == GRID_SPHERICAL) {
    cloudspercell = 0.0; // to force positionwise
    print_info("\tff=%.2e ==> ", filling_factor);
  } else {
    print_error("Unknown grid type.");
    exit(-1);
  }

  if(cloudspercell < 0.5 ||
     (meta_grid->ncells[0] * meta_grid->ncells[1] * meta_grid->ncells[2] == 1)) {
      print_info("sample uniform shell positions!\n\t");
      nclouds = place_uniform_shell_candidates(nclouds, Rin, Rout,
                                                   cloud_grid, meta_grid);
    } else {
      print_info("seed Cartesian cells!\n\t");
      nclouds = seed_cartesian_cells(nclouds, cloudspercell,
                                               Rin, Rout,
                                               cloud_grid, meta_grid);
    }
  
  /* Missing volume fraction equals the fraction of requested clouds still absent. */
  fferror = nclouds / (double)requested_count;
  
  if(fferror > uniform_remaining_volume_tolerance) {
    print_info("\n\t%.2e clouds not created. fferror=%.3f%%. Sample remaining shell positions.\n\t",
               (double)nclouds, fferror * 100);
    nclouds = place_uniform_shell_candidates(nclouds, Rin, Rout,
                                                 cloud_grid, meta_grid);
  }
    
  fferror = nclouds / (double)requested_count;

  print_info("\tPlaced %d of %d requested clouds (fraction missing: %.3f%%).\n",
             requested_count - nclouds, requested_count, fferror * 100);
}

static int seed_cartesian_cells(int nclouds, double ncloudspercell,
                                   double Rin, double Rout,
                                   grid *cloud_grid, grid *meta_grid) {
  if (nclouds == 0) return 0;
  validate_cloud_placement(nclouds, Rin, Rout, cloud_grid, meta_grid, 1);
  if (!isfinite(ncloudspercell) || ncloudspercell <= 0 ||
      ncloudspercell > INT_MAX / cellwise_proposals_per_expected_cloud) {
    print_error("Cellwise cloud placement requires a finite positive, representable mean count.");
    exit(EXIT_FAILURE);
  }
  int i, j, k, l;
  grid_cell *c;
  double rnd_pos[3], rel_pos[3], rsq;
  int ncreate;
  int modprint = (meta_grid->ncells[0] * meta_grid->ncells[1] *
                  meta_grid->ncells[2]) / 50 + 1;

  int notall = 0;
  int ncells = 0;

  if(meta_grid->type != GRID_CARTESIAN) {
    print_error("Not yet implemented for spherical meta grids.");
    exit(-1);
  }

  for(i = 0; i < meta_grid->ncells[0]; i++) {
    for(j = 0; j < meta_grid->ncells[1]; j++) {
      for(k = 0; k < meta_grid->ncells[2]; k++) {
        c = &(meta_grid->cells[i][j][k]);

        if(((i * meta_grid->ncells[1] + j) * meta_grid->ncells[2] + k) % modprint == 0)
          print_info(".");

        get_random_pos_in_cell(c, meta_grid, rnd_pos);

        rel_pos[0] = rnd_pos[0] - 0.5 * meta_grid->boxsize[0];
        rel_pos[1] = rnd_pos[1] - 0.5 * meta_grid->boxsize[1];
        rel_pos[2] = rnd_pos[2] - 0.5 * meta_grid->boxsize[2];
    
        rsq = scalar_product_3d(rel_pos, rel_pos);
    
        if(rsq > Rin * Rin && rsq < Rout * Rout) {
          ncells++;
          ncreate = rand_poisson(ncloudspercell);
          nclouds -= ncreate;
          for(l = 0; l < (cellwise_proposals_per_expected_cloud * ncloudspercell) &&  ncreate > 0;
              l++, get_random_pos_in_cell(c, meta_grid, rnd_pos)) {
            rel_pos[0] = rnd_pos[0] - 0.5 * meta_grid->boxsize[0];
            rel_pos[1] = rnd_pos[1] - 0.5 * meta_grid->boxsize[1];
            rel_pos[2] = rnd_pos[2] - 0.5 * meta_grid->boxsize[2];
        
            rsq = scalar_product_3d(rel_pos, rel_pos);
    
            if(rsq > Rin * Rin && rsq < Rout * Rout) {
              ncreate -= create_cloud_in_cell(meta_grid,
                                              cloud_grid, c, rnd_pos, 1);
            }
          }
          if(ncreate != 0) {
            notall++;
            nclouds += ncreate;
          }
        }
      }
    }
  }

  print_info("\n");
  print_info("\tUnderfilled cells=%d, eligible cells=%d\n", notall, ncells);

  return nclouds;
}

static int place_uniform_shell_candidates(int nclouds, double Rin, double Rout,
                                       grid *cloud_grid, grid *meta_grid) {
  if (nclouds == 0) return 0;
  validate_cloud_placement(nclouds, Rin, Rout, cloud_grid, meta_grid, 1);
  unsigned long long failures = 0;
  int modprint = (nclouds / 50) + 1;
  grid_cell *rnd_cell;
  int rnd1, rnd2, rnd3;
  int placed = 0;
  double rsq, rnd_pos[3], rel_pos[3];
  
  while(nclouds > 0) {
    if(nclouds % modprint == 0 && placed != 0)
      print_info(".");
      
    rnd1 = floor(rand_uniform() * meta_grid->ncells[0]);
    rnd2 = floor(rand_uniform() * meta_grid->ncells[1]);
    rnd3 = floor(rand_uniform() * meta_grid->ncells[2]);
    rnd_cell = &(meta_grid->cells[rnd1][rnd2][rnd3]);

    get_random_pos_in_cell(rnd_cell, meta_grid, rnd_pos);

    rel_pos[0] = rnd_pos[0] - meta_grid->center[0];
    rel_pos[1] = rnd_pos[1] - meta_grid->center[1];
    rel_pos[2] = rnd_pos[2] - meta_grid->center[2];
    
    rsq = scalar_product_3d(rel_pos, rel_pos);

    if(rsq > Rin * Rin && rsq < Rout * Rout) {
      placed = create_cloud_in_cell(meta_grid, cloud_grid, rnd_cell, rnd_pos, 1);
      nclouds -= placed;
    } else {
      placed = 0;
    }
    cloud_placement_check_progress(&failures, placed, nclouds, "uniform shell sampling");
  }

  print_info("\n");

  return nclouds;
}

static int place_lattice_clouds(int nclouds, double buffer, double Rin, double Rout,
                               grid *cloud_grid, grid *meta_grid) {
  if (nclouds == 0) return 0;
  validate_cloud_placement(nclouds, Rin, Rout, cloud_grid, meta_grid, 1);
  if (!isfinite(buffer) || buffer <= 0) {
    print_error("Lattice placement requires a finite positive buffer (got %e).", buffer);
    exit(EXIT_FAILURE);
  }
  const double Rcloud = cloud_grid->boxsize[0];
  const double shellvol = placement_shell_volume(Rin, Rout, meta_grid);
  const double Rin_placing = Rin > 0 ? Rin + Rcloud : 0;
  const double Rout_placing = Rout - Rcloud;
  if (!isfinite(shellvol) || shellvol <= 0 || Rin_placing > Rout_placing) {
    print_error("Lattice placement has no feasible center shell: Rin=%e, Rout=%e, "
                "Rcloud=%e. Widen the shell or reduce the cloud size.", Rin, Rout, Rcloud);
    exit(EXIT_FAILURE);
  }
  const double close_packing_fraction = PI / (3. * sqrt(2));
  /* The count controller uses damping and jitter to reach the +/-5%
   * tolerance and escape discrete lattice-count plateaus. A finite
   * retry budget bounds the search, which may fail for small counts
   * or narrow shells. */
  const double controller_gain = 0.88;
  const double controller_jitter_width = 0.08;
  const double minimum_spacing_radii = 2.05;
  const double retry_spacing_radii = 2.1;
  const unsigned max_grid_attempts = 256;
  double sphere_boxsize[3] = {2 * meta_grid->boxsize[0],
                              2 * meta_grid->boxsize[0], 2 * meta_grid->boxsize[0]};
  const double *boxsize = meta_grid->type == GRID_CARTESIAN ?
                         meta_grid->boxsize : sphere_boxsize;
  const size_t ncells = (size_t)meta_grid->ncells[0] * meta_grid->ncells[1] * meta_grid->ncells[2];
  int *original_counts = check_realloc(NULL, ncells * sizeof(*original_counts));
  size_t index = 0;
  for (int i = 0; i < meta_grid->ncells[0]; i++)
    for (int j = 0; j < meta_grid->ncells[1]; j++)
      for (int k = 0; k < meta_grid->ncells[2]; k++)
        original_counts[index++] = meta_grid->cells[i][j][k].nclouds;

  for (unsigned attempt = 0; attempt < max_grid_attempts; attempt++) {
    double dgrid = pow(6. * close_packing_fraction * shellvol /
                        (PI * buffer * nclouds), 1./3.);
    if (!isfinite(buffer) || buffer <= 0 || !isfinite(dgrid) || dgrid <= 0) {
      print_error("Lattice count controller produced invalid buffer=%e/spacing=%e "
                  "on attempt %u. Lower the filling factor or change placement mode.",
                  buffer, dgrid, attempt + 1);
      free(original_counts);
      exit(EXIT_FAILURE);
    }
    int nclouds_created = 0, nclouds_failed = 0;
    double err, d_rnd, rnd_dir[3], cpos_disp[3];
    grid_cell *ccell;
    int i, j, k, l;
    double d;
    print_info("\t\tCreate clouds on uniform grid with dgrid / rcloud = %.3g, "
               "buff = %.3f\n\t\t\t", dgrid / Rcloud, buffer);
    if (dgrid < 2. * Rcloud) {
      print_warning("Requested lattice spacing is below a cloud diameter; "
                    "using the minimum spacing of %.2f cloud radii.", minimum_spacing_radii);
      dgrid = minimum_spacing_radii * Rcloud;
    }
    for (int axis = 0; axis < 3; axis++) {
      if (boxsize[axis] / dgrid > INT_MAX / 4.) {
        print_error("Uniform cloud lattice has too many nodes for integer indexing; "
                    "increase the cloud size or reduce grid dimensions.");
        free(original_counts);
        exit(EXIT_FAILURE);
      }
    }
    double cpos[3] = {0.5 * dgrid, 0.5 * dgrid, 0.5 * dgrid};
    int nprint = (int)(nclouds / 20. + 1.);
    for(i = 1; cpos[0] < boxsize[0]; i++) {
      cpos[0] = i * sqrt(2/3.) * dgrid;
      cpos[1] = 0.5 * dgrid;
      cpos[2] = 0.5 * dgrid;
      for(j = 0; cpos[1] < boxsize[1]; j++) {
        cpos[1] = j * 0.5 * dgrid * sqrt(3) + (i % 2) * dgrid * sqrt(3) / 6.;
        cpos[2] = 0.5 * dgrid;
        for(k = 0; cpos[2] < boxsize[2]; k++) {
          cpos[2] = k * dgrid + ((j + i) % 2) * 0.5 * dgrid;

          // shift position on spherical grid
          if(meta_grid->type == GRID_SPHERICAL) {
            if(k == 0) {
              cpos[0] -= meta_grid->boxsize[0];
              cpos[1] -= meta_grid->boxsize[0];
            }
            cpos[2] -= meta_grid->boxsize[0];
          }
          if(!is_pos_in_grid(cpos, meta_grid))
            continue;
        
          d = distance_3d(cpos, meta_grid->center);
          if(d >= Rin_placing) {
            if(d <= Rout_placing) {
              // Add some random displacement
              d_rnd = (0.5 * dgrid - Rcloud) * rand_uniform();
              rand_direction_3d(rnd_dir);
              for(l = 0; l < 3; l++)
                cpos_disp[l] = cpos[l] + d_rnd * rnd_dir[l];

              ccell = find_grid_cell(meta_grid, cpos_disp);
              if((ccell != NULL) && (create_cloud_in_cell(meta_grid, cloud_grid,
                                                          ccell, cpos_disp, 0))) {
                nclouds_created++;
                if(nclouds_created % nprint == 0)
                  print_info(".");
              } else {
                nclouds_failed++;
                if(nclouds_failed % nprint == 0)
                  print_info("F");
              }
            }
          }
        }
      }
    }

    err = (1. * nclouds_created / (1. * nclouds) - 1.0);
    print_info("\n\t\t%d / %d clouds created (error = %.3f%%, F_V = %.2f)\n",
               nclouds_created, nclouds, 100 * err,
               nclouds_created * 4. / 3. * PI * pow(Rcloud, 3) / shellvol);
    if (fabs(err) <= grid_count_relative_tolerance) {
      free(original_counts);
      return nclouds_created;
    }
    rollback_clouds(meta_grid, original_counts);
    if ((dgrid <= retry_spacing_radii * Rcloud && err <= 0) ||
        attempt + 1 == max_grid_attempts) {
      print_error("Lattice placement did not reach %.1f%% count tolerance "
                  "after %u attempts (last count %d/%d, spacing/radius=%e). "
                  "Lower the filling factor, widen the shell, or choose another placement mode.",
                  grid_count_relative_tolerance * 100, attempt + 1,
                  nclouds_created, nclouds, dgrid / Rcloud);
      free(original_counts);
      exit(EXIT_FAILURE);
    }
    print_info("\tCount error too big (> %.2f%%). Try again!\n",
               grid_count_relative_tolerance * 100);
    buffer = buffer * (1 - err * buffer * controller_gain +
                        (controller_jitter_width * (rand_uniform() - 0.5)));
  }
  free(original_counts);
  return 0; /* All unsuccessful paths above report an error and exit. */
}

static double placement_shell_volume(double Rin, double Rout, grid* meta_grid) {
  double shellvol = 4./3. * PI * ( pow(Rout, 3) - pow(Rin, 3));
  
  if(meta_grid->type == GRID_CARTESIAN) {
    if(Rout > 0.5 * array_min(meta_grid->boxsize, 3))
      shellvol = meta_grid->boxsize[0] * meta_grid->boxsize[1] *
        meta_grid->boxsize[2] - 4/3. * PI * pow(Rin, 3);
  } else if(meta_grid->type == GRID_SPHERICAL) {
    if(Rout > meta_grid->boxsize[0])
      shellvol = 4 / 3. * PI * ( pow(meta_grid->boxsize[0], 3) - pow(Rin, 3));
  } else {
    print_error("Unknown grid type %d", meta_grid->type);
    exit(-1);
  }
  
  return shellvol;
}

#ifdef PEACOCK_PAIRED_CATALOGUE
enum { CATALOGUE_FIRST_POPULATION, CATALOGUE_SECOND_POPULATION };
static int first_population_count = -1;
#endif

enum { CATALOGUE_RECORD_CAPACITY = 1024 };

static int read_catalogue_record(FILE *file, char record[CATALOGUE_RECORD_CAPACITY]) {
  return fgets(record, CATALOGUE_RECORD_CAPACITY, file) != NULL &&
    (strchr(record, '\n') != NULL || feof(file));
}

#ifndef PEACOCK_MULTILEVEL
static void find_catalogue_path(char *path, size_t capacity, int first, int second) {
  const char *folder = getenv("TLAC_CLUMP_DIR");
  if (folder == NULL || folder[0] == '\0')
    folder = "clump_pos";

  DIR *directory = opendir(folder);
  if (directory == NULL) {
    print_error("Could not open cloud catalogue directory %s: %s.", folder, strerror(errno));
    exit(EXIT_FAILURE);
  }

#ifndef PEACOCK_PAIRED_CATALOGUE
  (void)second;
  char expected[64];
  snprintf(expected, sizeof(expected), "clump_pos_Ncl1_%d.txt", first);
#endif
  int length = 0;
  struct dirent *entry;
  while ((entry = readdir(directory)) != NULL) {
    const char *name = entry->d_name;
#ifdef PEACOCK_PAIRED_CATALOGUE
    int counts[2], consumed = 0;
    if (sscanf(name, "clump_pos_Ncl1_%d_Ncl2_%d.txt%n", &counts[0], &counts[1], &consumed) != 2 ||
        consumed == 0 || name[consumed] != '\0' || counts[0] != first || counts[1] != second)
      continue;
#else
    if (strcmp(name, expected) != 0)
      continue;
#endif
    length = snprintf(path, capacity, "%s/%s", folder, name);
    break;
  }
  closedir(directory);
  if (length <= 0 || (size_t)length >= capacity) {
    print_error("Missing cloud catalogue for the requested count or path too long in %s.", folder);
    exit(EXIT_FAILURE);
  }
}
#endif

#ifdef PEACOCK_PAIRED_CATALOGUE
static int paired_tail_start(FILE *file, int count, const char *path) {
  char record[CATALOGUE_RECORD_CAPACITY];
  int rows = 0;
  while (read_catalogue_record(file, record)) {
    if (rows == INT_MAX) {
      print_error("Cloud catalogue %s has too many records.", path);
      exit(EXIT_FAILURE);
    }
    rows++;
  }
  if (ferror(file) || !feof(file) || rows < count || fseek(file, 0, SEEK_SET) != 0) {
    print_error("Could not read the last %d records of cloud catalogue %s.", count, path);
    exit(EXIT_FAILURE);
  }
  const int first = rows - count;
  for (int i = 0; i < first; i++)
    if (!read_catalogue_record(file, record)) {
      print_error("Could not skip to record %d of cloud catalogue %s.", first + 1, path);
      exit(EXIT_FAILURE);
    }
  return first;
}
#endif

static void load_cloud_catalogue(int nclouds, grid *cloud_grid, grid *meta_grid
#ifdef PEACOCK_PAIRED_CATALOGUE
                                 , int companion_count, int population
#endif
                                 ) {
  if ((size_t)nclouds > SIZE_MAX / sizeof(catalogue_position)) {
    print_error("Cloud catalogue is too large to allocate.");
    exit(EXIT_FAILURE);
  }

#if defined(PEACOCK_PAIRED_CATALOGUE)
  if (population != CATALOGUE_FIRST_POPULATION && population != CATALOGUE_SECOND_POPULATION) {
    print_error("Invalid paired cloud population index %d.", population);
    exit(EXIT_FAILURE);
  }
  const int is_first = population == CATALOGUE_FIRST_POPULATION;
  if (!is_first && first_population_count < 0) {
    print_error("Load the first cloud population before the second.");
    exit(EXIT_FAILURE);
  }
  char paired_path[1024];
  find_catalogue_path(paired_path, sizeof(paired_path),
      is_first ? nclouds : first_population_count, is_first ? companion_count : nclouds);
  const char *path = paired_path;
#elif defined(PEACOCK_MULTILEVEL)
  const char *path = getenv("TLAC_CLUMP_POS_FILE");
  if (path == NULL || path[0] == '\0') {
    print_error("Set TLAC_CLUMP_POS_FILE for catalogue placement.");
    exit(EXIT_FAILURE);
  }
#else
  char single_path[512];
  const char *path = getenv("TLAC_CLUMP_FILE");
  if (path == NULL || path[0] == '\0') {
    find_catalogue_path(single_path, sizeof(single_path), nclouds, 0);
    path = single_path;
  }
#endif

  print_info("\n\t[Clump Placement] Loading %d clouds from %s.\n", nclouds, path);
  FILE *file = check_fopen(path, "r");
  int first_record = 0;
#ifdef PEACOCK_PAIRED_CATALOGUE
  if (!is_first)
    first_record = paired_tail_start(file, nclouds, path);
#endif

  catalogue_position *positions = check_realloc(NULL, (size_t)nclouds * sizeof(*positions));
  char record[CATALOGUE_RECORD_CAPACITY];
  for (int i = 0; i < nclouds; i++) {
    double *position = positions[i].pos;
    if (!read_catalogue_record(file, record) ||
        sscanf(record, "%lf %lf %lf", &position[0], &position[1], &position[2]) != 3 ||
        !isfinite(position[0]) || !isfinite(position[1]) || !isfinite(position[2])) {
      print_error("Missing or invalid cloud position at record %d in %s.", first_record + i + 1, path);
      fclose(file);
      free(positions);
      exit(EXIT_FAILURE);
    }
  }
#ifdef PEACOCK_MULTILEVEL
  if (fgets(record, sizeof(record), file) != NULL || ferror(file)) {
    print_error("Catalogue %s must contain exactly %d cloud records.", path, nclouds);
    fclose(file);
    free(positions);
    exit(EXIT_FAILURE);
  }
#endif
  fclose(file);
#ifdef PEACOCK_PAIRED_CATALOGUE
  if (is_first)
    first_population_count = nclouds;
#endif

  const int progress_interval = nclouds / 50 + 1;
  for (int i = 0; i < nclouds; i++) {
    double *position = positions[i].pos;
    grid_cell *cell = find_grid_cell(meta_grid, position);
    if (!cell || !append_cloud(cell, cloud_grid, position)) {
      print_error("Could not place catalogue cloud %d from %s.", i + 1, path);
      free(positions);
      exit(EXIT_FAILURE);
    }
    if ((i + 1) % progress_interval == 0)
      print_info(".");
  }
  print_info("\n All %d clumps placed successfully from file.\n", nclouds);
  free(positions);
}

int create_cloud_in_cell(grid *meta_grid,
                         grid *cloud_grid, grid_cell *c, double pos[],
                         const int check_other_clouds) {
  if (!meta_grid || !c || !cloud_grid || !pos ||
      c->nclouds > INT_MAX - CLOUDS_ALLOCATE_STEP ||
      !isfinite(cloud_grid->boxsize[0]) || cloud_grid->boxsize[0] <= 0) {
    print_error("Cloud insertion requires valid grids/cell/position, positive finite radius, "
                "and a cloud count below integer capacity.");
    exit(EXIT_FAILURE);
  }
  for (int axis = 0; axis < 3; axis++)
    if (!isfinite(pos[axis])) return 0;
  
  int i;
  const double border = cloud_boundary_margin;
  const double Rcloud = cloud_grid->boxsize[0];
  double r;

  if(meta_grid->type == GRID_SPHERICAL) {
    if (meta_grid->ncells[0] != 1 || meta_grid->ncells[1] != 1 ||
        meta_grid->ncells[2] != 1) {
      print_error("Generated placement in spherical grids requires one cell.");
      exit(EXIT_FAILURE);
    }
    r = sqrt(scalar_product_3d(pos, pos)) + Rcloud * border;
    if(r > meta_grid->boxsize[0]) {
      return 0;
    }
  } else {
    // Cartesian checking
    for(i = 0; i < 3; i++) {
      if((pos[i] - border * Rcloud < c->pos[i] - 0.5 * c->size[i]) ||
         (pos[i] + border * Rcloud > c->pos[i] + 0.5 * c->size[i])) {
        
        return 0; // unsuccessful placement, too close to wall
      }
    }
  }

  if(check_other_clouds) {
    for(i = 0; i < c->nclouds; i++) {
      double dx = (pos[0] - c->pos_clouds[i][0]) / PARSEC;
      double dy = (pos[1] - c->pos_clouds[i][1]) / PARSEC;
      double dz = (pos[2] - c->pos_clouds[i][2]) / PARSEC;
      double dist2 = dx*dx + dy*dy + dz*dz;
      double thresh = border * (cloud_grid->boxsize[0] / PARSEC + c->cloud_grids[i]->boxsize[0] / PARSEC);

      if (dist2 < thresh*thresh) {
        return 0; // unsuccessful placement, too close to other cloud
      }
    }
  }

  assert(is_pos_in_cell(pos, c, meta_grid));

  return append_cloud(c, cloud_grid, pos);
}

#endif /* CELL_CLOUDS */
