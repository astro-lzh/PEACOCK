#ifndef _OBSERVER_LASTSCATTER_H_
#define _OBSERVER_LASTSCATTER_H_

#include "../photon.h"


#include "observer.h"
#include "observer_types.h"


/* ------------------------------------------------------------ */
/**
   Processes observer that records last scatter. Has to be called
   with (a copy) of a photon that has just left the box.

   @param obs          -- Observer of type `TLAC_OBSERVER_LASTSCATTER`
   @param p            -- Copy of photon.
**/
void process_observer_lastscatter(observer* obs,
                                  photon p);

#endif /* _OBSERVER_LASTSCATTER_H_ */
