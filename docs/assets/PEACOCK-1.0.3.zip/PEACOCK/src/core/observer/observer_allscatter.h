#ifndef _OBSERVER_ALLSCATTER_H_
#define _OBSERVER_ALLSCATTER_H_



#include "../photon.h"


#include "observer.h"
#include "observer_types.h"


/* ------------------------------------------------------------ */
/**
   Processes observer that records all scattering events.

   @param obs          -- Observer of type `TLAC_OBSERVER_ALLSCATTER_FULL`
   @param p            -- Copy of photon.
**/
void process_observer_allscatter_full(observer* obs,
                                 photon p);


/* ------------------------------------------------------------ */
/**
   Processes observer that records momentum transfer in scattering
   event.

   STILL IN DEVELOPMENT
   
   @param obs          -- Observer of type `TLAC_OBSERVER_ALLSCATTER_MOMENTUM`
   @param p            -- Copy of photon.
**/
void process_observer_allscatter_momentum(observer* curr_obs, photon *p);

#endif /* _OBSERVER_ALLSCATTER_H_ */
