/**
   @file observer_allscatter.c

   @brief Defining observer that record only at last scatter.

**/
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "../photon.h"
#include "../propagation.h"
#include "../io/o_photon.h"

#include "../misc/mem.h"
#include "../misc/my_math.h"
#include "../misc/messages.h"

#include "observer.h"
#include "observer_types.h"
#include "observer_allscatter.h"

/* ------------------------------------------------------------ */
/**
   Processes observer that records all scattering events.

   STILL IN DEVELOPMENT
   
   @param obs          -- Observer of type `TLAC_OBSERVER_ALLSCATTER_FULL`
   @param p            -- Copy of photon.
**/
void process_observer_allscatter_full(observer* obs,
                                      photon p) {
  double Wmu;
  double tau_esc;

  assert(p.dist == 0); // should be zero as we just scattered!
  assert(obs->type == TLAC_OBSERVER_ALLSCATTER_FULL);
  assert_photon_values(&p);
  assert_photon_pos(&p);

  /* The current virtual-observer estimator assumes isotropic angular weight. */
  Wmu = 0.5;

  // Updates photon values according to fake scatter
  assert(p.dist == 0); // should be zero as we just scattered!
  observer_fakescatter(&p, obs);
  
  // Calculate escape tau
  tau_esc = get_tau_esc(&p);

  // Output as extra information
  if(tau_esc >= 0) {
    p.extra_info[0] = -tau_esc + log(Wmu);
    o_photon(obs->nout_file, &p);
  }
}

/* ------------------------------------------------------------ */
/**
   Processes observer that records momentum transfer in scattering
   event.

   STILL IN DEVELOPMENT
   
   @param obs          -- Observer of type `TLAC_OBSERVER_ALLSCATTER_MOMENTUM`
   @param p            -- Copy of photon.
**/
void process_observer_allscatter_momentum(observer *obs, photon *p) {
  /* A just-emitted photon has no incoming scattering direction. */
  if (p->dir_last[0] == 0 && p->dir_last[1] == 0 && p->dir_last[2] == 0)
    return;
  o_photon(obs->nout_file, p);
}
