/**
@file observer_types.h

@brief Defines various observer types
 **/

#ifndef _OBSERVER_TYPES_H_
#define _OBSERVER_TYPES_H_

#define TLAC_OBSERVER_LASTSCATTER 1
#define TLAC_OBSERVER_ALLSCATTER_FULL 2
#define TLAC_OBSERVER_ALLSCATTER_MOMENTUM 3

#endif /* _OBSERVER_TYPES_H_ */
