#ifndef _OBSERVER_H_
#define _OBSERVER_H_

#include "../grid.h"
#include "../photon.h"

#include "observer_types.h"

// Typedef in grid.h
struct observer_s {
  const int type;  ///< Type of observer
  double dir[3];  ///< Normed direction of observer
  int nout_file;  ///< ID of output file
};

/* ------------------------------------------------------------ */
/**
   @brief Processes observers that need updating at each scatter.

**/
void process_observers_scatter(photon* p, double (*scatter_pdf)(double, double*),
                               double* pdf_args);

/* ---------------------------------------------------------------------- */
/**
   @brief Processes all observers that work on only the last scatter.
 **/
void process_observers_exit(photon* p);

/*******************************************************************//**
 * observer_fakescatter
 * 
 * Sets photon back to point before last scatter & "scatters" it in
 * the direction of the observer `obs`
 ***********************************************************************/
void observer_fakescatter(photon *p, observer *obs);

/*******************************************************************
 * get_tau_esc                                                     *
 *                                                                 *
 * Calculates optical depth between position of p_tmp and the wall *
 *                                                                 *
 * Returns: tau_esc or -1 if tau_esc > `OBSERVER_TAU_ESC_CUTOFF`   *
 *******************************************************************/
double get_tau_esc(photon* p);

/******************************************//**
 * Free observer
 **********************************************/
void free_observer(observer *obs);

/* ------------------------------------------------------------ */
/**
   Adds oberver to grid.
   
   @param g             -- Grid to add observer.
   @param observer_type -- Type of observer (see observer_types.h)
   @param dir           -- Direction observer `is looking`
   
   @return 0 if nothing failed.
**/
int add_observer(grid* g, int observer_type, double* dir);

#endif
