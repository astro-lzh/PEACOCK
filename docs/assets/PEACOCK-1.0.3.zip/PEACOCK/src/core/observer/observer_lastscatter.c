/**
   @file observer_lastscatter.c

   @brief Defining observer that record only at last scatter.

**/
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "../photon.h"
#include "../propagation.h"
#include "../io/o_photon.h"

#include "../misc/mem.h"
#include "../misc/my_math.h"
#include "../misc/messages.h"

#include "observer.h"
#include "observer_types.h"
#include "observer_lastscatter.h"


/* ------------------------------------------------------------ */
/**
   Processes observer that records last scatter. Has to be called
   with (a copy) of a photon that has just left the box.

   @param obs          -- Observer of type `TLAC_OBSERVER_LASTSCATTER`
   @param p            -- Copy of photon.
**/
void process_observer_lastscatter(observer* obs,
                                  photon p) {
  double Wmu;
  double tau_esc;

  assert(obs->type == TLAC_OBSERVER_LASTSCATTER);
  assert_photon_values(&p);
  assert_photon_pos(&p);

  /* The current virtual-observer estimator assumes isotropic angular weight. */
  Wmu = 0.5;
  
  // Fake scatter in direction of the observer
  observer_fakescatter(&p, obs);
  
  tau_esc = get_tau_esc(&p);

  if(tau_esc >= 0) {
    p.extra_info[0] = -tau_esc + log(Wmu);
    o_photon(obs->nout_file, &p);
  }
  
}

