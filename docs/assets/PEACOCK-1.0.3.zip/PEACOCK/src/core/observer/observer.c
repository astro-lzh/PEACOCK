/**
@file observer.c

@brief Meta file for observers

In this file the common functions which several observer types use
are defined.


**/
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include "../photon.h"
#include "../propagation.h"
#include "../io/o_photon.h"
#include "../clouds.h"
#include "../physical_properties.h"

#include "../misc/mem.h"
#include "../misc/messages.h"
#include "../misc/my_math.h"
#include "../misc/rand_tools.h"

#include "observer.h"
#include "observer_types.h"
#include "observer_lastscatter.h"
#include "observer_allscatter.h"




/* ------------------------------------------------------------ */
/**
   @brief Processes observers that need updating at each scatter.

**/
void process_observers_scatter(photon* p, double (*scatter_pdf)(double, double*),
                               double* pdf_args) {

  int i;
  observer *curr_obs;
  assert(p->dist == 0); // should be zero as we just scattered!

  for(i = 0; i < p->grid->nobservers; i++) {
    curr_obs = &(p->grid->observers[i]);
    switch(curr_obs->type) {
    case TLAC_OBSERVER_ALLSCATTER_FULL:
      // Just a possibility that this event is recorded
      if(rand_uniform() > OBSERVER_ALLSCATTER_FULL_FRACTION)
        break;
      process_observer_allscatter_full(curr_obs, *p);
      break;

    case TLAC_OBSERVER_ALLSCATTER_MOMENTUM:
      if(rand_uniform() > OBSERVER_ALLSCATTER_MOMENTUM_FRACTION)
        break;
      process_observer_allscatter_momentum(curr_obs, p);
      break;
    }
  }

}


/* ---------------------------------------------------------------------- */
/**
   @brief Processes all observers that work on only the last scatter.

    Called when photon leaves box.
 **/
void process_observers_exit(photon* p) {
  int i;
  observer *curr_obs;

  
  for(i = 0; i < p->grid->nobservers; i++) {
    curr_obs = &(p->grid->observers[i]);
    switch(curr_obs->type) {
    case TLAC_OBSERVER_LASTSCATTER:
      process_observer_lastscatter(curr_obs, *p);
      break;
    }
  }
  
}



/*******************************************************************//**
 * observer_fakescatter
 * 
 * Sets photon back to point before last scatter & "scatters" it in
 * the direction of the observer `obs`
 ***********************************************************************/
void observer_fakescatter(photon *p, observer *obs) {
  double mu;
  int i;
  assert(p->dist == 0);
  // Minus because observer's direction is defined *towards* the box
  mu = (-1.0) * scalar_product_3d(p->dir_last, obs->dir);

  // Set values back to before scatter
#ifdef DEBUG
  if(p->dist != 0) {
    print_error("Distance is non-zero...but: %e", p->dist);
    print_photon(p);
  }
#endif
  assert(p->dist == 0); // should be zero as we just scattered!
  p->x = p->x_last;
  p->nscatter--;

  // Update photon frequency
  p->x = p->x - p->u_scatter_last[0] + p->u_scatter_last[0] * mu +       \
    p->u_scatter_last[1] * sqrt(1 - mu * mu);
  
  // Count virtual scatter as scatter
  p->nscatter++;
  
  p->dist = 0; // Set dist to zero this to get depth information

  // Aim in direction of observer
  for(i = 0; i < 3; i++)
    p->dir[i] = (-1.0) * obs->dir[i];

  // Important: u_bulk.k changes!
  p->sc_dir_bulk = cell_velocity_scalar_product(p->curr_cell, p->dir, p->pos,
                                                  p->grid);

  
}


/**********************************************************************//**
 * get_tau_esc
 *                                                                 
 * Calculates optical depth between position of p_tmp and the wall.
 *                                                                 
 * To do this the photon is propagated until the end of the box.
 * WARNING: The properties of the photon will be modified. So create a
 * copy!
 * 
 * Returns: tau_esc or -1 if tau_esc > `OBSERVER_TAU_ESC_CUTOFF`
 **************************************************************************/
double get_tau_esc(photon* p) {
  double tau_esc = 0, realdist;

  assert_photon_pos(p);
  assert_photon_values(p);

  while(p->curr_cell != NULL) {
    // update photon values
    update_photon_values(p);

    p->prev_cell = p->curr_cell;
    const int ret = update_photon_pos(p, HUGE_VAL, &realdist);
    (void)ret; /* Checked in DEBUG builds. */
    assert_photon_pos(p);
    assert_photon_values(p);
    
    tau_esc += p->curr_tau * realdist;
    p->dist += realdist;
#ifdef CELL_CLOUDS
    if(p->curr_cell == NULL) {
      if(p->cell_shifted != NULL) {
        assert(p->prev_cell != NULL);

        if(p->prev_cell != &(p->grid->cells[ p->grid->ncells[0] - 1][0][0])) {
          print_error("Virtual photon not coming from outermost shell!");
          print_photon(p);
        }
        unshift_from_cloud(p);
        assert(p->curr_cell != NULL);
      } else {
        break;
      }
    }
#endif
#ifdef DEBUG
    if((ret == 0) || (p->prev_cell == p->curr_cell)) {
      print_error("No wall crossed! (ret = %d)"
                  "pos: (%.3e, %.3e, %.3e), dist=%.3e", ret,
                  p->pos[0], p->pos[1], p->pos[2], realdist);
      if (p->curr_cell == NULL) {
        print_error("Current cell is NULL.");
      }

      assert_photon_pos(p);
      assert_photon_values(p);
      
      return -1;
    }

    if(isnan(tau_esc))
      print_error("Nan encoutered!");
#endif

    // Cutoff --> return negative number
    if(tau_esc > OBSERVER_TAU_ESC_CUTOFF)
      return -1;
    
  } // end of `propagation` loop
  
  return tau_esc;
}



/* ------------------------------------------------------------ */
/**
   Adds oberver to grid.
   
   @param g             -- Grid to add observer.
   @param observer_type -- Type of observer (see observer_types.h)
   @param dir           -- Direction observer `is looking`
   
   @return 0 if nothing failed.
**/
int add_observer(grid* g, int observer_type, double* dir) {
  int i;
  const int nalloc = 5;
  observer cobs = {.type = observer_type};

#ifdef PEACOCK_ATOM_FINE_STRUCTURE
  if(observer_type == TLAC_OBSERVER_LASTSCATTER ||
     observer_type == TLAC_OBSERVER_ALLSCATTER_FULL) {
    print_error("Legacy virtual-scatter observers do not support C II Raman branches or path phase functions. Use escaped-photon HDF5 output.");
    exit(EXIT_FAILURE);
  }
#endif

  if(fabs(norm3d(dir) - 1.0) > 1e-5) {
    print_error("Direction of new observer has to be normalized.");
    exit(-1);
  }

  if(observer_type != TLAC_OBSERVER_LASTSCATTER &&
     observer_type != TLAC_OBSERVER_ALLSCATTER_FULL &&
     observer_type != TLAC_OBSERVER_ALLSCATTER_MOMENTUM) {
    print_error("Observer type %d does not exist!", observer_type);
    return -1;
  }

  // allocate memory if necessary
  if(g->nobservers % nalloc == 0) {
    g->observers = check_realloc(g->observers,
                                 (g->nobservers + nalloc) * sizeof(observer));
  }

  // add observer
  for(i = 0; i < 3; i++)
    cobs.dir[i] = dir[i];
  memcpy((void*)&(g->observers[g->nobservers]), (void*)&cobs, sizeof(observer));
  
  g->nobservers++;

  return 0;
}


/******************************************//**
 * Free observer
 **********************************************/
void free_observer(observer *obs) {
  if(o_photon_finalize(obs->nout_file)) {
    print_error("Error finalizing observer output.");
    exit(-1);
  }
}
