#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef USE_OMP
#include <omp.h>
#endif

#include "emission.h"
#include "clouds.h"
#include "grids/grid_spherical.h"
#include "io/o_photon.h"
#include "io/o_photon_ascii.h"
#include "misc/messages.h"
#include "misc/my_math.h"
#include "misc/rand_tools.h"
#include "physical_properties.h"
#include "propagation.h"

#ifdef TLAC_CUDA
#include "gpu/gpu_rt.h"
#endif

#ifdef CELL_CLOUDS
static const double natural_cloud_fraction = -1.0;
#endif

static int emission_plane_axis(const struct emission_cfg_s *cfg) {
  const double axis = cfg->initial_pos_param;
  if (!isfinite(axis) || axis < 0 || axis > 2 || floor(axis) != axis) {
    print_error("Plane emission requires an integer axis 0, 1 or 2; got %g.", axis);
    exit(EXIT_FAILURE);
  }
  return (int)axis;
}

static void validate_emission_parameters(const struct emission_cfg_s *cfg) {
#ifdef CELL_CLOUDS
  if (!isfinite(cfg->p_cloud) ||
      (cfg->p_cloud != natural_cloud_fraction && (cfg->p_cloud < 0 || cfg->p_cloud > 1))) {
    print_error("Emission p_cloud must be -1 or a probability in [0, 1]; got %g.",
                cfg->p_cloud);
    exit(EXIT_FAILURE);
  }
#endif
  const int mode = cfg->initial_pos_mode;
  if (emission_position_is_plane(mode)) {
    (void)emission_plane_axis(cfg);
  } else if (mode == EMISSION_POS_EXPONENTIAL) {
    if (!isfinite(cfg->initial_pos_param) || cfg->initial_pos_param < 0 ||
        !isfinite(cfg->initial_pos_param * PARSEC)) {
      print_error("Exponential emission requires a finite nonnegative scale in pc.");
      exit(EXIT_FAILURE);
    }
  } else if (!emission_position_uses_luminosity(mode)) {
    print_error("Unknown emission position mode %d. Choose 1 through 7.", mode);
    exit(EXIT_FAILURE);
  }
}

static void validate_emission_frequency(const struct emission_cfg_s *cfg) {
  const int mode = cfg->initial_freq_mode;
#ifdef PEACOCK_ATOM_DOUBLET
  const int last_mode = EMISSION_FREQ_DOUBLET;
#else
  const int last_mode = EMISSION_FREQ_UNIFORM;
#endif
  if (mode < EMISSION_FREQ_THERMAL || mode > last_mode) {
    print_error("Emission frequency mode %d is unsupported. Choose 0 through %d.",
                mode, last_mode);
    exit(EXIT_FAILURE);
  }
  if (mode != EMISSION_FREQ_THERMAL &&
      (!isfinite(cfg->initial_freq_param) ||
       (mode != EMISSION_FREQ_FIXED && cfg->initial_freq_param < 0))) {
    print_error("Emission frequency mode %d requires a finite %sparameter.",
                mode, mode == EMISSION_FREQ_FIXED ? "" : "nonnegative width ");
    exit(EXIT_FAILURE);
  }
}

static void validate_emission_grid(const grid *g, const struct emission_cfg_s *cfg) {
  validate_emission_parameters(cfg);
  validate_emission_frequency(cfg);
#ifdef CELL_CLOUDS
  if (cfg->p_cloud > 0) {
    for (int i = 0; i < g->ncells[0]; i++)
      for (int j = 0; j < g->ncells[1]; j++)
        for (int k = 0; k < g->ncells[2]; k++)
          if (g->cells[i][j][k].nclouds > 0)
            return;
    print_error("Positive emission p_cloud requires at least one cloud in the emission grid.");
    exit(EXIT_FAILURE);
  }
#else
  (void)g;
#endif
}

void run_photons_with_tracking(grid *g, int nphot, struct emission_cfg_s cfg,
                               const char *tracking_filename) {
  if (nphot < 0) {
    print_error("The number of photons must be nonnegative.");
    exit(EXIT_FAILURE);
  }
  if (nphot > 0)
    validate_emission_grid(g, &cfg);

#if TLAC_XCRIT == 0
  print_info("Core skipping disabled.\n");
#elif TLAC_XCRIT < 0
  print_info("Dynamical core skipping with limit %d.\n", -TLAC_XCRIT);
#else
  print_info("Core skipping enabled with x_crit = %d.\n", TLAC_XCRIT);
#endif
#ifdef FIX_FREQUENCY
  print_info("Frequencies are fixed.\n");
#endif
#ifdef USE_OMP
  print_info("OpenMP enabled with at most %d threads.\n", omp_get_max_threads());
#endif

  FILE *tracking = NULL;
  if (tracking_filename != NULL) {
    tracking = fopen(tracking_filename, "wx");
    if (tracking == NULL) {
      print_error("Could not open photon tracking file %s.", tracking_filename);
      exit(EXIT_FAILURE);
    }
    o_photon_ascii_simple_write_header(tracking);
    print_info("Tracking photon histories in %s.\n", tracking_filename);
  }

  long launched = 0, escaped = 0, absorbed = 0;
  /* Complete every requested history. A time cutoff biases long paths. */
#ifdef USE_OMP
#pragma omp parallel reduction(+:launched, escaped, absorbed)
#endif
  {
    photon *p = create_photon();
    *p->emission_cfg = cfg;

#ifdef USE_OMP
#ifdef PEACOCK_MULTILEVEL
#pragma omp for schedule(guided, TLAC_OMP_MIN_CHUNKSIZE) nowait
#else
#pragma omp for schedule(guided, 1)
#endif
#endif
    for (int i = 0; i < nphot; i++) {
      start_photon(p, g);
      launched++;
      if (propagate_photon(p, tracking) == 1) {
        escaped++;
        o_photon(0, p);
      } else {
        absorbed++;
      }
    }
    pick_random_cell(NULL);
    free_photon(p);
  }

  if (tracking != NULL) {
    const int write_failed = ferror(tracking);
    const int close_failed = fclose(tracking) != 0;
    if (write_failed || close_failed) {
      print_error("Could not finish photon history output.");
      exit(EXIT_FAILURE);
    }
  }
  print_info("PHOTON_ACCOUNTING launched=%ld escaped=%ld absorbed=%ld\n",
             launched, escaped, absorbed);
  if (launched != nphot || launched != escaped + absorbed) {
    print_error("Photon count mismatch.");
    exit(EXIT_FAILURE);
  }
}

void set_photon_startdir(photon *p) {
  const int mode = p->emission_cfg->initial_pos_mode;
  if (mode == EMISSION_POS_BOUNDARY_DIRECTED || mode == EMISSION_POS_MIDPLANE_DIRECTED) {
    const int axis = emission_plane_axis(p->emission_cfg);
    for (int i = 0; i < 3; i++)
      p->dir[i] = i == axis ? 1.0 : 0.0;
  } else {
    rand_direction_3d(p->dir);
  }
  assert(approx_equal(norm3d(p->dir), 1.0));
}

void set_photon_startpos(photon *p, grid *g) {
  const struct emission_cfg_s *cfg = p->emission_cfg;
  validate_emission_parameters(cfg);
#ifdef CELL_CLOUDS
  const double requested_cloud_probability = cfg->p_cloud;
  const double cloud_draw = rand_uniform();
  const int select_by_geometry = cfg->p_cloud == natural_cloud_fraction;
  int emission_in_cloud = !select_by_geometry && cloud_draw < cfg->p_cloud;
#else
  const double requested_cloud_probability = 0;
  const int emission_in_cloud = 0;
#endif

  /* A source with acceptance >= 1e-6 exceeds this progress limit with
   * probability <= 1e-12. Each new proposal draws from the same RNG stream. */
  const double minimum_useful_acceptance = 1e-6;
  const double false_stall_probability = 1e-12;
  const unsigned long long failure_limit = (unsigned long long)ceil(
      log(false_stall_probability) / log1p(-minimum_useful_acceptance));
  const double max_radius = g->type == GRID_SPHERICAL ?
    g->boxsize[0] : array_min(g->boxsize, 3) * 0.5;
  const int mode = cfg->initial_pos_mode;
  int cloud_id = -1;

  for (unsigned long long attempt = 1; ; attempt++) {
    int accepted = 1;
    if (emission_position_uses_luminosity(mode)) {
      if (g->L_tot <= 0.0) {
        print_error("Cell-based emission requires positive grid luminosity; got %e.",
                    g->L_tot);
        exit(EXIT_FAILURE);
      }
      p->curr_cell = pick_random_cell(g);
    }

    switch (mode) {
    case EMISSION_POS_CELL_CENTER:
      if (g->type == GRID_SPHERICAL) {
        const double radial_jitter_fraction = 1e-3;
        double spherical[3];
        get_random_spherical_coordinates_in_cell(p->curr_cell, spherical);
        const double radial_jitter = radial_jitter_fraction * p->curr_cell->size[0] *
          (rand_uniform() - 0.5);
        spherical[0] = p->curr_cell->pos[0] + radial_jitter;
        spherical2cart(spherical, p->pos);
      } else if (g->type == GRID_CARTESIAN) {
        for (int i = 0; i < 3; i++)
          p->pos[i] = p->curr_cell->pos[i];
      }
      break;

    case EMISSION_POS_CELL_RANDOM:
      get_random_pos_in_cell(p->curr_cell, g, p->pos);
      break;

    case EMISSION_POS_EXPONENTIAL: {
      const double radius = rand_exponential(cfg->initial_pos_param * PARSEC);
      if (radius > max_radius) {
        accepted = 0;
        break;
      }
      get_pos_dist_from_center(g, radius, p->pos);
      p->curr_cell = find_grid_cell(g, p->pos);
      accepted = p->curr_cell != NULL;
      break;
    }

    case EMISSION_POS_MIDPLANE:
    case EMISSION_POS_BOUNDARY:
    case EMISSION_POS_BOUNDARY_DIRECTED:
    case EMISSION_POS_MIDPLANE_DIRECTED: {
      if (g->type == GRID_SPHERICAL) {
        print_error("Plane emission requires a Cartesian grid.");
        exit(EXIT_FAILURE);
      }
      const double boundary_offset_fraction = 1e-12;
      const int axis = (int)cfg->initial_pos_param;
      const int first = (axis + 1) % 3;
      const int second = (axis + 2) % 3;
      const int midplane = mode == EMISSION_POS_MIDPLANE || mode == EMISSION_POS_MIDPLANE_DIRECTED;
      p->pos[axis] = midplane ? 0.5 * g->boxsize[axis] :
        boundary_offset_fraction * g->boxsize[axis] / g->ncells[axis];
      p->pos[first] = rand_uniform() * g->boxsize[first];
      p->pos[second] = rand_uniform() * g->boxsize[second];
      p->curr_cell = find_grid_cell(g, p->pos);
      assert(p->curr_cell != NULL);
      break;
    }

    }

#ifdef CELL_CLOUDS
    if (accepted) {
#ifdef TLAC_CUDA
      cloud_id = cuda_emission_cloud_id(p->curr_cell, p->pos);
#else
      cloud_id = get_cloud_id(p->curr_cell, p->pos);
#endif
    }
    if (select_by_geometry)
      emission_in_cloud = cloud_id >= 0;
#endif
    if (accepted && (cloud_id >= 0) == emission_in_cloud)
      break;
    if (attempt >= failure_limit) {
      print_error("Photon emission rejected %llu consecutive position proposals "
                  "(mode %d, p_cloud=%g, requested in-cloud=%d, cloud_id=%d). "
                  "Check that the source distribution overlaps the requested "
                  "cloud/intercloud region. An extremely small acceptance "
                  "probability can also cause this limit. "
                  "Last position=(%e,%e,%e)pc.",
                  attempt, mode, requested_cloud_probability, emission_in_cloud,
                  cloud_id, p->pos[0] / PARSEC, p->pos[1] / PARSEC, p->pos[2] / PARSEC);
      exit(EXIT_FAILURE);
    }
  }

  assert(p->curr_cell != NULL);
  assert_photon_pos(p);
#ifdef CELL_CLOUDS
  if (emission_in_cloud) {
    shift_to_cloud(p, p->curr_cell, cloud_id, 1);
    const double center_jitter_fraction = 1e-5;
    while (norm3d(p->pos) == 0)
      for (int i = 0; i < 3; i++)
        p->pos[i] += (rand_uniform() - 0.5) * center_jitter_fraction * p->curr_cell->size[0];
  }
#endif
  if (p->curr_cell == NULL) {
    print_error("Could not set emission cell successfully.");
    exit(EXIT_FAILURE);
  }
  assert_photon_pos(p);
}

static void set_photon_startfreq(photon *p) {
  const double cm_per_km = 1e5;
  const double temperature = p->curr_cell->T;
  const double parameter = p->emission_cfg->initial_freq_param;
  switch (p->emission_cfg->initial_freq_mode) {
  case EMISSION_FREQ_FIXED:
    p->x = parameter;
    return;
  case EMISSION_FREQ_GAUSSIAN:
    p->x = rand_gaussian(cm_per_km * parameter / thermal_velocity_hydrogen(temperature));
    return;
  case EMISSION_FREQ_UNIFORM:
    p->x = cm_per_km * parameter * (2.0 * rand_uniform() - 1.0) /
      thermal_velocity_hydrogen(temperature);
    return;
#ifdef PEACOCK_ATOM_DOUBLET
  case EMISSION_FREQ_DOUBLET: {
    const int component_draw_max = 2;
    /* rand_int includes both endpoints. Two of the three outcomes are blue. */
    if (rand_int(component_draw_max) != 0) {
      p->x = rand_gaussian(cm_per_km * parameter / thermal_velocity_hydrogen(temperature));
    } else {
      const double red_offset = DELTA_NU_H_K / doppler_freq_shift_hydrogen(temperature);
      p->x = -red_offset + rand_gaussian(cm_per_km * parameter /
                                       thermal_velocity_hydrogen(temperature));
    }
    return;
  }
#endif
  case EMISSION_FREQ_THERMAL:
    break;
  }

  /* Natural broadening and projected thermal velocity, Laursen (2010), Eq. 7.2. */
#if defined(PEACOCK_ATOM_FINE_STRUCTURE) || defined(PEACOCK_MULTILEVEL)
  const double natural_width = LYA_DELTA_NU_L_1;
#else
  const double natural_width = LYA_DELTA_NU_L;
#endif
  const double doppler_width = doppler_freq_shift_hydrogen(temperature);
  const double rest_offset = rand_cauchy(natural_width / (2.0 * doppler_width));
  double thermal_velocity[3];
  for (int i = 0; i < 3; i++)
    thermal_velocity[i] = rand_gaussian(1.0 / sqrt(2.0));
  double projected_velocity = 0;
  for (int i = 0; i < 3; i++)
    projected_velocity += p->dir[i] * thermal_velocity[i];
  p->x = rest_offset + projected_velocity;
}

void start_photon(photon *p, grid *g) {
  validate_emission_frequency(p->emission_cfg);
  p->grid = g;
  p->nscatter = 0;
  p->dist = 0;
  p->tau = PHOTON_TAU_UNSAMPLED;
  p->c_HI_total = 0;
  p->c_D_total = 0;
  /* A source inside a cloud sets up its local grid before drawing a
   * frequency. Seed that temporary frame independently of the last packet. */
  p->x = 0;
  p->sc_dir_bulk = 0;
  p->curr_tau = 0;
  p->a = 0;
  p->x_cw = 0;
  p->Delta_nu_D = 1.0;
  p->prev_cell = NULL;
#ifdef CELL_CLOUDS
  p->nclouds_passed = 0;
  for (int i = 0; i < 3; i++) {
    p->pos_shifted[i] = 0;
    p->vel_shifted[i] = 0;
  }
  p->cell_shifted = NULL;
  p->grid_shifted = NULL;
#endif

  set_photon_startdir(p);
  set_photon_startpos(p, g);
  set_photon_startfreq(p);

  /* Seed the local frame before the first opacity update. */
  p->Delta_nu_D = doppler_freq_shift_hydrogen(p->curr_cell->T);
  p->sc_dir_bulk = cell_velocity_scalar_product(p->curr_cell, p->dir, p->pos, p->grid);
  assert_photon_values(p);
  update_photon_values(p);

  p->x_i = p->x;
  p->x_last = p->x;
  p->u_scatter_last[0] = 0;
  p->u_scatter_last[1] = 0;
  for (int i = 0; i < 3; i++)
    p->dir_last[i] = 0;
#if defined(EXTRA_PHOTON_INFORMATION) && EXTRA_PHOTON_INFORMATION == 1
  for (int i = 0; i < 3; i++)
    p->extra_info[i] = p->pos[i];
  p->extra_info[3] = p->sc_dir_bulk;
  p->extra_info[4] = p->Delta_nu_D;
#endif
  assert_photon_values(p);
}
