#ifndef _READ_CONFIG_H_
#define _READ_CONFIG_H_

#include "iniparser/iniparser.h"

typedef struct config_s {
  dictionary *dict;
  char filename[255];
} config;

/* Load an INI dictionary and supply optional defaults. The caller owns it. */
config *read_config(const char *filename);
void free_config(config *cfg);
void write_config(config *cfg);

/* Resolve native <N> placeholders before comparing compile-time settings. */
int cfg_replace_templates(config *cfg, int nreplace, char **repl);
int cfg_tlac_compatible(config *cfg);

#ifdef PEACOCK_MULTILEVEL
void cfg_load_population_ratios(const config *cfg);
#endif

int cfg_key_exists(const config *cfg, const char *key);
int cfg_names_equal(const char *left, const char *right);
char *cfg_get_str(const config *cfg, const char *key);
int cfg_get_int(const config *cfg, const char *key);
int cfg_get_bool(const config *cfg, const char *key);
double cfg_get_dbl(const config *cfg, const char *key);

/* An expected count of -1 accepts any number of items. Row widths are
 * capacities, including the terminator for strings and in elements for doubles. */
int cfg_count_array(const config *cfg, const char *key);
int cfg_get_strarray_sized(const config *cfg, const char *key,
                           int nentries, char **retarr, size_t width);
int cfg_get_intarray(const config *cfg, const char *key, int nentries, int *retarr);
int cfg_get_dblarray(const config *cfg, const char *key, int nentries, double *retarr);
int cfg_get_2d_dblarray_sized(const config *cfg, const char *key,
                             int nentries, double **retarr, int width);

#endif /* _READ_CONFIG_H_ */
