/**
@file process_config.c

Makes tlac things like grid from config struct.

Uses `read_config.c` functions to process the config file.

 **/
/* Request the POSIX strptime declaration before system headers. */
#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 700
#endif

#include <ctype.h>
#include <limits.h>
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef _WIN32
/* Only the fixed TLAC runtime timestamp uses strptime. */
static char *tlac_strptime(const char *s, const char *fmt, struct tm *t) {
  int y, m, d, hh, mm, ss;
  (void)fmt;
  memset(t, 0, sizeof(*t));
  t->tm_isdst = -1;
  if (sscanf(s, "%2d%2d%2d-%2d%2d%2d", &y, &m, &d, &hh, &mm, &ss) != 6) return NULL;
  t->tm_year = y + (y < 69 ? 100 : 0); t->tm_mon = m - 1; t->tm_mday = d;
  t->tm_hour = hh; t->tm_min = mm; t->tm_sec = ss;
  return (char *)s + 13;
}
#define strptime tlac_strptime
#endif

#include "process_config.h"
#ifdef TLAC_CUDA
#include "../gpu/gpu_rt.h"
#endif
#include "read_config.h"
#include "iniparser/iniparser.h"
#include "../misc/messages.h"
#include "../misc/my_math.h"
#include "../misc/mem.h"
#include "../misc/rand_tools.h"
#include "../tlac_defs.h"
#include "../io/o_photon.h"
#include "../io/i_grid.h"
#include "../io/o_grid.h"
#include "../emission.h"
#include "../emission_modes.h"
#include "../grid.h"
#include "../grids/grid_cart.h"
#include "../observer/observer.h"
#include "../clouds.h"
#include "../physical_properties.h"

enum { GRID_SECTION_SIZE = 64, CONFIG_KEY_SIZE = 128 };
static void cfg_set_grid_periodic(config *cfg, const char *sec, grid *g);
static void cfg_save_grid(config *cfg, const char *sec, grid *g);
static grid *cfg_load_grid(config *cfg, const char *sec);
static grid *cfg_create_grid(config *cfg, const char *sec);
static void cfg_fill_grid(config *cfg, const char *sec, grid *g);
static void cfg_fill_grid_velocity(config *cfg, const char *sec, grid *g, int nrings,
                                  double *Rmin, double *Rmax);
static void cfg_fill_grid_luminosity(config *cfg, const char *sec, grid *g, int nrings,
                                    double *Rmin, double *Rmax);
static void cfg_create_clouds(config *cfg, const char *section, grid *meta_grid);
static void cfg_create_observers(config *cfg, grid *g, int main_grid);
static void cfg_finalize_run(config *cfg);

/* ------------------------------------------------------------ */
/**
   Initializes tlac run.

   Sets random seed, inits output files.
 **/
static void cfg_init_run(config *cfg) {
  char filename_prefix[512], start_time_str[64];
  const int maxiter = 3;
  int iter = 0;
  
  time_t start_time;
  struct tm * start_time_s;
  print_info("Initialize run based on config file...");

  do {
    iniparser_set(cfg->dict, "result", NULL);
    
    /** Record start time */
    time(&start_time);
    start_time_s = localtime(&start_time);
    strftime(start_time_str, 64, "%y%m%d-%H%M%S", start_time_s);
    iniparser_set(cfg->dict, "result:start_time", start_time_str);
  
    /** Sets output files */
    const char *prefix = cfg_get_str(cfg, "run:filename_prefix");
    int length = snprintf(filename_prefix, sizeof(filename_prefix), "%s%s",
                          prefix, start_time_str);
    if (length < 0 || (size_t)length >= sizeof(filename_prefix)) {
      print_error("The output filename prefix is too long: %s", prefix);
      exit(EXIT_FAILURE);
    }
    iniparser_set(cfg->dict, "result:full_filename_prefix", filename_prefix);

    iter++;
    if(o_photon_init(0, filename_prefix, cfg_get_str(cfg, "output:lya"))) {
      if(iter >= maxiter) {
        print_error("Initialization of config failed! Exit.");
        exit(-1);
      } else {
        print_warning("Initialization of config failed! Wait for one second "
                      "and try again.");
        sleep(1);
      }
    } else {
      break; // success
    }
  } while(1);

  iniparser_set(cfg->dict, "result:dat_file", o_photon_get_filename(0));

  print_info("...done!\n");
  
}

/* ------------------------------------------------------------ */
/**
   Converts density string given to number density in ccm

   @param s     Density string
   @param sigma Cross section in cm^-2
   @param A     Albedo (chance to be scattered)
   @param d     (Mean) distance photons travel in cm
 **/
static double cfg_convert_density_str(const char *text, double sigma, double distance) {
  const char *number = text;
  while (isspace((unsigned char)*number)) number++;
  const int kind = tolower((unsigned char)*number);
  if (*number) number++;
#ifndef PEACOCK_ATOM_FINE_STRUCTURE
  /* Non-C II models also accept labels such as column or number. */
  while (*number && !isspace((unsigned char)*number)) number++;
#endif

  char *end;
  const double value = strtod(number, &end);
  const int has_number = end != number;
  while (isspace((unsigned char)*end)) end++;
  if (!has_number || *end || !isfinite(value)) {
    print_error("Invalid density specification %s.", text);
    exit(EXIT_FAILURE);
  }
  switch (kind) {
  case 't':
  case 'c':
    if (!isfinite(distance) || distance <= 0 ||
        (kind == 't' && (!isfinite(sigma) || sigma <= 0))) {
      print_error("Density specification %s requires a positive path length and valid cross section.", text);
      exit(EXIT_FAILURE);
    }
    return kind == 't' ? value / (distance * sigma) : value / distance;
  case 'n':
    return value;
  default:
    print_error("Unknown density specifier in %s.", text);
    exit(EXIT_FAILURE);
  }
}

/* ------------------------------------------------------------ */
/**
   Parses gridsec string and returns if its the main grid.
    
   @param gridsec -- Section of grid, e.g. "cloud1"
   
   @return 1 if its the main grid, otherwise 0
**/
static int cfg_sec_maingrid(const char *gridsec) {
  return cfg_names_equal("grid", gridsec);

}

/* ------------------------------------------------------------ */
/**
   Makes the meta grid based on config.

   @param cfg    Config structure to follow
   @param sec    Section name, e.g. "grid" or "cloud1"
 **/
static grid *cfg_make_grid(config *cfg, const char *sec) {
  if (sec == NULL || !sec[0] || strlen(sec) >= GRID_SECTION_SIZE) {
    print_error("Grid section names must contain between 1 and %d characters.", GRID_SECTION_SIZE - 1);
    exit(EXIT_FAILURE);
  }
  static const char *active_sections[MAX_CLOUDS + 1];
  static int depth = 0;
  for (int i = 0; i < depth; i++) {
    if (cfg_names_equal(active_sections[i], sec)) {
      print_error("Cyclic grid section reference to [%s].", sec);
      exit(EXIT_FAILURE);
    }
  }
  if (depth == MAX_CLOUDS + 1) {
    print_error("Nested grid sections exceed the cloud registry limit.");
    exit(EXIT_FAILURE);
  }
  const int level = depth;
  active_sections[depth++] = sec;
  int ismain = cfg_sec_maingrid(sec);
  char kstr[CONFIG_KEY_SIZE];
  grid *g = NULL;
  
  if(ismain) {
    print_info("Make tlac grid from config file...\n");
    
    // Initialize random seed for grid creation
    if(cfg_key_exists(cfg, "grid:random_seed"))
      init_rand_tools( cfg_get_int(cfg, "grid:random_seed") );
    else
      init_rand_tools( cfg_get_int(cfg, "run:random_seed") );
  } else {
    print_info("Create cloud \"%s\" at level = %d...\n",sec, level);
  }

  // Load or create grid
  sprintf(kstr, "%s:load", sec);
  if(cfg_key_exists(cfg, kstr)) {
    g = cfg_load_grid(cfg, sec);
    sprintf(kstr, "%s:filling_mode", sec);
    if(cfg_key_exists(cfg, kstr)) {
      print_info("\tAlso filling grid (loaded values will be overwritten!)!\n");
      cfg_fill_grid(cfg, sec, g);
    }
  } else {
    g = cfg_create_grid(cfg, sec);
    cfg_fill_grid(cfg, sec, g);
    cfg_create_clouds(cfg, sec, g);
  }

  // Save grid (optional)
  sprintf(kstr, "%s:save", sec);
  if(cfg_key_exists(cfg, kstr))
    cfg_save_grid(cfg, sec, g);

  // Check grid (optional)
  sprintf(kstr, "%s:check", sec);
  if(cfg_key_exists(cfg, kstr)) {
    if(cfg_get_bool(cfg, kstr)) {
      print_info("\tChecking grid...\n");
      check_grid(g);
      print_info("\t...done!\n");
    }
  }

  // Make grid periodic (optional)
  sprintf(kstr, "%s:periodic", sec);
  if(cfg_key_exists(cfg, kstr))
    cfg_set_grid_periodic(cfg, sec, g);

  cfg_create_observers(cfg, g, ismain);

  if(ismain) {
    cleanup_rand_tools();
    print_info("...done creating grid!\n");
  } else {
    print_info("...done creating cloud \"%s\" at level %d!\n",sec, level);
  }

  active_sections[--depth] = NULL;
  return g;
}

/**************************************************************//**
 * Sets grid as periodic according to config.
 * 
 * Reads entry `sec`:periodic to see what dimensions should be
 * periodic.
 ******************************************************************/
static void cfg_set_grid_periodic(config *cfg, const char *sec, grid *g) {
  char kstr[CONFIG_KEY_SIZE];
  int per_trig[3];

  if(g->type != GRID_CARTESIAN) {
    print_error("Grid has to be cartesian to switch periodicity on!\n");
    exit(-1);
  }
  
  sprintf(kstr, "%s:periodic", sec);
  cfg_get_intarray(cfg, kstr, 3, per_trig);
  print_info("\tMake grid periodic along (x,y,z)=(%d,%d,%d)...\n",
             per_trig[0], per_trig[1], per_trig[2]);
  
  if (per_trig[0] && per_trig[1] && per_trig[2]) {
    print_error("Something wrong with the value of `%s`. Remember that at "
                "least one dimension has to be non-periodic!", kstr);
    exit(-1);
  }

#ifdef _GRID_CART_H_
  int i;
  for(i = 0; i < 3; i++) {
    if(per_trig[i])
      make_grid_periodic(g, i);
  }
#endif
  
  print_info("\t...done making grid periodic!\n");
  
}

/***********************************************************//**
 * Saves grid `g` to filename stored in config (`sec`:save)
 ***************************************************************/
static void cfg_save_grid(config *cfg, const char *sec, grid *g) {
  char *filename;
  char *save_comment;
  char kstr[CONFIG_KEY_SIZE];

  /* Only the main grid can be saved through this configuration entry. */
  if(!cfg_sec_maingrid(sec)) {
    print_error("Only the main [grid] can be saved with the save option.");
    exit(-1);
  }

  sprintf(kstr, "%s:save", sec);
  filename = cfg_get_str(cfg, kstr);
  if((strcmp(filename, "") == 0) || (strcmp(filename, "NULL") == 0))
    return;

  sprintf(kstr, "%s:save_comment", sec);
  save_comment = cfg_get_str(cfg, kstr);

  print_info("\tSaving grid to \"%s\"...\n", filename);
  o_grid(filename, g, save_comment);
  print_info("\t...done!\n");
  
}

/*************************************//**
 * Loads grid from config parameters.
 * 
 * @return pointer to grid.
 *****************************************/
static grid *cfg_load_grid(config *cfg, const char *sec) {
  grid *g = NULL;
  char kstr[CONFIG_KEY_SIZE];
  char *filename;

  int i, nclouds = 0;
  char skey[CONFIG_KEY_SIZE];
  grid **clouds = NULL;
  
  sprintf(kstr, "%s:type", sec);
  if(cfg_key_exists(cfg, kstr)) {
    print_error("Cannot load & create grid. Ambiguous keys %s:type and "
                "%s:load detected!",sec,sec);
    exit(-1);
  }

  sprintf(kstr, "%s:load", sec);
  filename = cfg_get_str(cfg, kstr);
  print_info("\tLoading grid from \"%s\"...\n", filename);

  // Check if clouds are wanted
  sprintf(skey, "%s:clouds", sec);
  if(cfg_key_exists(cfg, skey)) {
    if(!cfg_get_bool(cfg, "tlac:cell_clouds")) {
      print_error("Trying to use clouds without CELL_CLOUDS preprocessor. "
                  "Please change `tlac_defs.h` and recompile.");
      exit(-1);
    }

    nclouds = cfg_count_array(cfg, skey);
    if (nclouds < 1 || nclouds > MAX_CLOUDS) {
      print_error("Loaded-grid cloud count must be between 1 and %d, got %d.", MAX_CLOUDS, nclouds);
      exit(EXIT_FAILURE);
    }
    char **cloud_secs = allocate_2d_char_array(nclouds, GRID_SECTION_SIZE);
    cfg_get_strarray_sized(cfg, skey, nclouds, cloud_secs, GRID_SECTION_SIZE);
    clouds = check_realloc(NULL, (size_t)nclouds * sizeof(*clouds));

    for(i = 0; i < nclouds; i++) {
      // Create grid if not created yet
      clouds[i] = cfg_lookup_cloud(cloud_secs[i], NULL);
      if(clouds[i] == NULL) {
        clouds[i] = cfg_make_grid(cfg, cloud_secs[i]);
        cfg_lookup_cloud(cloud_secs[i], clouds[i]);
      }
    }
    free(cloud_secs);
  }

  g = i_grid_defined_clouds(filename, nclouds, clouds);

  free(clouds);
  
  print_info("\t...done loading grid!\n");
  
  return g;
}

/***************************************//**
 * Creates grid from config parameters.
 * 
 * @return Pointer to grid.
 *******************************************/
static grid *cfg_create_grid(config *cfg, const char* sec) {
  double B[3] = {0}, d[3];
  int ncells[3];
  int i;

  grid *g = NULL;
  char kstr[CONFIG_KEY_SIZE];
  
  sprintf(kstr, "%s:type", sec);
  int grid_type = cfg_get_int(cfg, kstr);
  if (grid_type != GRID_CARTESIAN && grid_type != GRID_SPHERICAL) {
    print_error("Configuration key %s requires a Cartesian (%d) or spherical (%d) grid.",
                kstr, GRID_CARTESIAN, GRID_SPHERICAL);
    exit(EXIT_FAILURE);
  }

  sprintf(kstr, "%s:size", sec);
  if(grid_type == GRID_CARTESIAN)
    cfg_get_dblarray(cfg, kstr, 3, B);
  else
    B[0] = cfg_get_dbl(cfg, kstr);
  for(i = 0; i < 3; i++)
    B[i] *= PARSEC;

  sprintf(kstr, "%s:ncells", sec);
  cfg_get_dblarray(cfg, kstr, 3, d);
  for (i = 0; i < 3; i++) {
    if (d[i] < 1 || d[i] > INT_MAX || floor(d[i]) != d[i]) {
      print_error("Configuration key %s requires three positive integer counts, got %g.", kstr, d[i]);
      exit(EXIT_FAILURE);
    }
    ncells[i] = (int)d[i];
  }

  ///! Create grid
  if(grid_type == GRID_CARTESIAN) {
#if (TLAC_GRID == GRID_VARIABLE) || (TLAC_GRID == GRID_CARTESIAN)
    print_info("\tCreate cartesian grid with size=(%.2e, %.2e, %.2e)pc\n\t\t"
               "and ncells=(%d, %d, %d)\n",
               B[0] / PARSEC, B[1] / PARSEC, B[2] / PARSEC,
               ncells[0], ncells[1], ncells[2]);
    g = create_uniform_grid(B[0], B[1], B[2], ncells[0], ncells[1], ncells[2]);
#endif
  } else {
#if (TLAC_GRID == GRID_VARIABLE) || (TLAC_GRID == GRID_SPHERICAL)
     print_info("\tCreate spherical grid with R = %.2epc "
               "and ncells=(%d, %d, %d)\n",
               B[0] / PARSEC,
               ncells[0], ncells[1], ncells[2]);
    g =  create_spherical_grid(B[0], ncells[0], ncells[1], ncells[2]);
#endif
  }
  
  if(g == NULL) {
    print_error("Problem with grid creation! Correct tlac binary?");
    exit(-1);
  }

  return g;
}

/* Use the line-centre opacity corresponding to the active population model. */
static double reference_cross_section(const config *cfg, double temperature) {
#if defined(PEACOCK_ATOM_FINE_STRUCTURE)
  return cii_population_cross_section(0, temperature, cfg_get_dbl(cfg, "emission:CII_ratio_21"));
#elif defined(PEACOCK_MULTILEVEL)
  (void)cfg;
  return rt_cross_sections(0, temperature, NULL);
#else
  (void)cfg;
  return hydrogen_scattering_cross_section(0, temperature);
#endif
}

/**********************************************************************//**
 * Fills grid with number densities of hydrogen & dust based on config
 * file.
 * 
 * Calls functions to also fill the correct values of
 * velocities/luminosity.
 **************************************************************************/
static void cfg_fill_grid(config *cfg, const char* sec, grid *g) {
  ///! Fill grid
  enum { maxrings = 19, density_spec_size = 128 };
  int nrings = 0;
  int i, j, n;
  char kstr[CONFIG_KEY_SIZE];
  double Rmin[maxrings], Rmax[maxrings];
  double T[maxrings], n_HI[maxrings], n_D[maxrings];
  grid_cell *c;

  sprintf(kstr, "%s:filling_mode", sec);
  int filling_mode = cfg_get_int(cfg, kstr);
  
  switch(filling_mode) {
  case 0: // global filling
    print_info("\tGlobal filling.\n");
    Rmin[0] = 0;
    Rmax[0] = array_max(g->boxsize,3);
    nrings = 0;
    break;

  case 13:
  case 11: // ring minus one hole
    print_info("\tRing filling plus one hole.");
    if(g->type != GRID_CARTESIAN) {
      print_error("Can only be done with cartesian grid.");
      exit(-1);
    }

  case 1: // one ring
    print_info("\tOne ring filling.\n");
    sprintf(kstr, "%s:Rmin", sec);
    Rmin[0] = cfg_get_dbl(cfg, kstr) * PARSEC;
    sprintf(kstr, "%s:Rmax", sec);
    Rmax[0] = cfg_get_dbl(cfg, kstr) * PARSEC;
    nrings = 0;
    break;

  case 10: // Several rings
    print_info("\tSeveral rings filling --> ");
    sprintf(kstr, "%s:Rmin", sec);
    nrings = cfg_count_array(cfg, kstr);
    if (nrings < 1 || nrings > maxrings) {
      print_error("Ring count must be between 1 and %d.", maxrings);
      exit(EXIT_FAILURE);
    }
    cfg_get_dblarray(cfg, kstr, nrings, Rmin);
    print_info("%d rings.\n", nrings);
    sprintf(kstr, "%s:Rmax", sec);
    cfg_get_dblarray(cfg,kstr, nrings, Rmax);
    for(i = 0; i < nrings; i++) {
      Rmin[i] *= PARSEC;
      Rmax[i] *= PARSEC;
    }
    break;

    // slab modes
  case 20: // slab (xy excavated)
  case 21: // hole
  case 22: // hole
    print_info("\tFill one ring in slab except plane in xy direction.\n");
    sprintf(kstr, "%s:Rmin", sec);
    Rmin[0] = cfg_get_dbl(cfg, kstr) * PARSEC;
    sprintf(kstr, "%s:Rmax", sec);
    Rmax[0] = cfg_get_dbl(cfg, kstr) * PARSEC;
    nrings = 0;
    break;

  default:
    print_error("Unknown filling mode `%d`!", filling_mode);
    exit(-1);
  }

  sprintf(kstr, "%s:set_all_absorbing_dust", sec);
  /* With dust=t, this selects absorption optical depth rather than total
   * extinction optical depth for the input normalization. */
  int all_absorbing_dust = cfg_get_bool(cfg, kstr);

  if(nrings == 0) {
    sprintf(kstr, "%s:temperature", sec);
    T[0] = cfg_get_dbl(cfg, kstr);
    sprintf(kstr, "%s:hydrogen", sec);
    n_HI[0] = cfg_convert_density_str(cfg_get_str(cfg, kstr),
                                      reference_cross_section(cfg, T[0]),
                                      Rmax[0] - Rmin[0]);
    sprintf(kstr, "%s:dust", sec);
    n_D[0] = cfg_convert_density_str(cfg_get_str(cfg, kstr),
                                     gas_scattering_cs(0, T[0]), Rmax[0] - Rmin[0]);
    if(all_absorbing_dust)
      n_D[0] /= (1 - dust_albedo(0, T[0]));
    print_info("\tSet temperature on whole grid to %.2eK.\n",T[0]);
    set_grid_values(g, 0, 0, T[0], 0);
    nrings = 1; // Update nrings!
  } else {
    char **density_strs = allocate_2d_char_array(nrings, density_spec_size);

    if(!cfg_sec_maingrid(sec))
      print_warning("Non homogeneous temperatures not yet implemented!");
    
    sprintf(kstr, "%s:temperature", sec);
    cfg_get_dblarray(cfg, kstr, nrings, T);
    sprintf(kstr, "%s:hydrogen", sec);
    cfg_get_strarray_sized(cfg, kstr, nrings, density_strs, density_spec_size);
    for(i = 0; i < nrings; i++)
      n_HI[i] = cfg_convert_density_str(density_strs[i],
                                        reference_cross_section(cfg, T[i]),
                                        Rmax[i] - Rmin[i]);
    sprintf(kstr, "%s:dust", sec);
    cfg_get_strarray_sized(cfg, kstr, nrings, density_strs, density_spec_size);

    for(i = 0; i < nrings; i++) {
#ifdef PEACOCK_ATOM_FINE_STRUCTURE
      const int dust_ring = i;
#else
      /* Other operators use the first interval for dust normalization. */
      const int dust_ring = 0;
#endif
      n_D[i] = cfg_convert_density_str(density_strs[i],
                                       gas_scattering_cs(0, T[i]),
                                       Rmax[dust_ring] - Rmin[dust_ring]);
      if(all_absorbing_dust)
        n_D[i] /= (1 - dust_albedo(0, T[i]));
    }

    free(density_strs);
  }

  ///! Fill grid with contents
  for(i = 0; i < nrings; i++) {
    print_info("\tFill cells in R = [%.2e, %.2e]pc with n_HI=%.2eccm, "
               "n_D=%.2eccm\n", Rmin[i] / PARSEC, Rmax[i] / PARSEC,
               n_HI[i], n_D[i]);
    n = set_grid_values_ring(g, Rmin[i], Rmax[i], n_HI[i], n_D[i], T[i], 0,
                             NAN);
    print_info("\t\t%d/%d cells filled!\n", n,
               g->ncells[0] * g->ncells[1] * g->ncells[2]);

  }

  ///! Fill velocity & luminosity values
  cfg_fill_grid_velocity(cfg, sec, g, nrings, Rmin, Rmax);
  
  cfg_fill_grid_luminosity(cfg, sec, g, nrings, Rmin, Rmax);

  ///! Open plane in x-y direction
  if((filling_mode >= 20) && (filling_mode < 30)) {
    print_info("\tClearing z midplane.\n");
    for(i = 0; i < g->ncells[0]; i++) {
      for(j = 0; j < g->ncells[1]; j++) {
        c = &(g->cells[i][j][g->ncells[2]/2]);
        c->n_HI = 0;
        c->n_D = 0;
        c->vel[0] = 0; c->vel[1] = 0; c->vel[2] = 0;
      }
    }

  }

  ///! Open hole
  int ihole = 0;
  if(filling_mode == 13) {
    sprintf(kstr, "%s:filling_params", sec);
    double alpha = cfg_get_dbl(cfg, kstr);
    print_info("\tOpen conical hole in z direction with half opening angle: "
               "%g degrees.\n", alpha);
    i = set_grid_values_bicone(g, alpha * PI / 180., 0, 0, 0, 0, 0);
    print_info("\t\t...%d cells cleared.", i);

  } else if((filling_mode == 11) || (filling_mode == 21) || (filling_mode == 22)) {
    if(filling_mode == 22) {
      j = (g->ncells[2]/2);
      print_info("\tOpen hole in positive z direction from midplane.\n");
    } else {
      print_info("\tOpen hole in full z direction.\n");
      j = 0;
    }
    for(i = j; i < g->ncells[2]; i++) {
      c = &(g->cells[g->ncells[0] / 2][g->ncells[1] / 2][i]);
      if(c->n_HI) ihole++;
      c->n_HI = 0;
      c->n_D = 0;
      c->vel[0] = 0; c->vel[1] = 0; c->vel[2] = 0;
    }
    print_info("\t\tOpened up %d cells.\n", ihole);
  }

}

/**********************************************************************//**
 * Fills velocity values on grid based on config.
 * 
 * `Rmax`/`Rmin` are arrays of length `nrings` where the velocity will
 * be filled.
 **************************************************************************/
static double cfg_scalar_velocity(const config *cfg, const char *key) {
  const char *text = cfg_get_str(cfg, key);
  while (isspace((unsigned char)*text)) text++;
  if (*text == '(') {
    /* Scalar velocities accept a parenthesized single value such as (0). */
    double velocity;
    cfg_get_dblarray(cfg, key, 1, &velocity);
    return velocity;
  }
  return cfg_get_dbl(cfg, key);
}

static void cfg_fill_grid_velocity(config *cfg, const char* sec,
                            grid *g, int nrings, double *Rmin,
                            double *Rmax) {
  int i, j;
  long long nfilled = 0;
  int dim;
  double maxRmax = array_max(Rmax, nrings);
  double minRmin = array_min(Rmin, nrings);
  double min_cell_size;
  double onevel, v[nrings + 2];
  double dv, dR;
  char kstr[CONFIG_KEY_SIZE];

  sprintf(kstr, "%s:velocity_mode", sec);
  int velocity_mode = cfg_get_int(cfg, kstr);

  // Check if filling mode fits to velocity mode
  sprintf(kstr, "%s:filling_mode", sec);
  int filling_mode = cfg_get_int(cfg, kstr);
  if((velocity_mode > 10) && (filling_mode < 10)) {
    print_error("velocity_mode is %d, i.e., demands for several rings but "
                "filling mode is %d and does not. Please use, e.g. filling_mode=10.",
                velocity_mode, filling_mode);
    exit(-1);
  }

  sprintf(kstr, "%s:velocity_params", sec);
  
  switch(velocity_mode) {
  case -1:
    print_info("\tLeave velocities unchanged.\n");
    break;
    
  case 0:
    print_info("\tNo velocities.\n");
    nfilled = set_grid_values_ring(g, minRmin, maxRmax, -1, -1, -1, -1, 0);
    break;
    
  case 1:
    onevel = cfg_scalar_velocity(cfg, kstr);
    print_info("\tOne velocity. v=%.2ekm/s between R=[%.2e,%.2e]pc.\n",
               onevel, minRmin / PARSEC, maxRmax / PARSEC);
    nfilled = set_grid_values_ring(g, minRmin, maxRmax, -1, -1, -1, -1,
                                   onevel * 1e5);
    break;
    
  case 2: {
    cfg_get_dblarray(cfg, kstr, 2, v);
    print_info("\tLinear velocity. v=[%.2e, %.2e]km/s between "
               "R=[%.2e,%.2e]pc.\n",
               v[0], v[1], minRmin / PARSEC, maxRmax / PARSEC);
    if(g->type == GRID_SPHERICAL)
      min_cell_size = g->cells[0][0][0].size[0];
    else 
      min_cell_size = array_min(g->cells[0][0][0].size, 3);
    const double parts = 2 * ceil((maxRmax - minRmin) / min_cell_size);
    if (!isfinite(parts) || parts < 0 || parts > INT_MAX) {
      print_error("Linear velocity requires a finite radial subdivision count in range.");
      exit(EXIT_FAILURE);
    }
    const int nparts = (int)parts;
    if (nparts == 0) break;
    
    dR = (maxRmax - minRmin) / (1.0 * nparts);
    dv =  (v[1] - v[0]) / (1.0 * nparts);
    nfilled = 0;
    for(i = 0; i < nparts; i++) {
      nfilled += set_grid_values_ring(g, minRmin + i * dR,
                                      minRmin + (i + 1) * dR,
                                      -1, -1, -1, -1,  (i * dv + v[0]) * 1e5);
    }
    break;
  }

  case 3:
    onevel = cfg_scalar_velocity(cfg, kstr);
    print_info("\tRandom velocity. sigma_v=%.2ekm/s between "
               "R=[%.2e,%.2e]pc.\n",
               onevel, minRmin / PARSEC, maxRmax / PARSEC);
    if(g->type != GRID_CARTESIAN) {
      print_error("Random velocity not yet implemented for spherical grid.");
      exit(-1);
    }
#if TLAC_GRID == GRID_CARTESIAN
    nfilled = set_grid_values_random_velocity_cart(g, minRmin, maxRmax,
                                                   onevel * 1e5);
#else
    print_warning("Random Cartesian velocities require a Cartesian-only build. Velocities were left unchanged.");
#endif
    break;

  case 4:
    cfg_get_dblarray(cfg, kstr, 3, v);
    if (!isfinite(v[0]) || v[0] < 0 || v[0] > 2 || floor(v[0]) != v[0]) {
      print_error("Linear velocity axis must be an integer from 0 to 2.");
      exit(EXIT_FAILURE);
    }
    dim = (int)v[0];
    print_info("\tLinear velocity for dimension %d. v=[%.2e, %.2e]km/s between "
               "[%.2e,%.2e]pc from center.\n",
               dim, v[1], v[2], minRmin / PARSEC, maxRmax / PARSEC);
    print_warning("Most of the things done with this velocity mode can be done "
                  "with velocity_mode = 2. This mode has not been tested well.");
    nfilled = set_grid_linear_velocity(g, dim, minRmin, maxRmax,
                                       v[1] * 1e5, v[2] * 1e5);
    break;

  case 10:
    print_info("\tCustom velocity in each of the %d rings.\n", nrings);
    cfg_get_dblarray(cfg, kstr, nrings, v);
    for(i = 0; i < nrings; i++) {
      nfilled += set_grid_values_ring(g, Rmin[i], Rmax[i], -1, -1, -1, -1,
                                      v[i] * 1e5);
    }
    break;

  case 11:
    print_info("\tCustom (linearly scaled) velocity in each of the %d rings.\n", nrings);
    cfg_get_dblarray(cfg, kstr, nrings + 1, v);
    for(i = 0; i < nrings; i++) {
      j = set_grid_linear_velocity(g, 0, Rmin[i], Rmax[i],
                                   v[i] * 1e5, v[i+1] * 1e5);
      print_info("\t\tFilled %d cells in %g < R/pc < %g from v=%gkm/s to %gkm/s.\n",
                 j, Rmin[i] / PARSEC, Rmax[i] / PARSEC, v[i], v[i+1]);
      nfilled += j;
    }
    break;

  default:
    print_error("Unknown `velocity_mode` %d!", velocity_mode);
    exit(-1);
  }

  print_info("\t\t%lld cells filled.\n", nfilled);

}

/**********************************************************************//**
 * Fills luminosity values on grid based on config.
 * 
 * `Rmax`/`Rmin` are arrays of length `nrings` where the luminosity will
 * be filled.
 **************************************************************************/
static void cfg_fill_grid_luminosity(config *cfg, const char* sec,
                              grid *g, int nrings, double *Rmin, double *Rmax) {
  const int configured_mode = cfg_get_int(cfg, "emission:position_mode");
  const int position_mode = emission_position_from_config(configured_mode);
  if (!emission_position_uses_luminosity(position_mode)) {
    print_info("\t[Note] emission:position_mode=%d, "
               "ignoring grid:luminosity_* parameters.\n", configured_mode);
    return;
  }
  if (!cfg_sec_maingrid(sec))
    print_warning("Cell-based emission in a cloud grid has not been tested.");

  int nfilled = 0;
  int i;
  double L[nrings + 1];

  char kstr[CONFIG_KEY_SIZE];
  sprintf(kstr, "%s:luminosity_mode", sec);
  int luminosity_mode = cfg_get_int(cfg, kstr);
  
  switch(luminosity_mode) {
  case 0:
    print_info("\tUnchanged / no luminosity..\n");
    break;

  case 1: {
    print_info("\tPoint source.\n");
    const double diagonal = norm3d(g->cells[0][0][0].size);
    const double inner_fraction = -1e-5;
    const double outer_fraction = 0.5001;
    const double relative_luminosity = 10.0;
    /* Extend slightly past the centre and half diagonal to include boundary cells. */
    nfilled = set_grid_values_ring(g, inner_fraction * diagonal, outer_fraction * diagonal,
                                   -1, -1, -1, relative_luminosity, NAN);
    break;
  }
    
  case 10:
    print_info("\tCustom luminosity in each of the %d rings.\n", nrings);
      sprintf(kstr, "%s:luminosity_params", sec);
    cfg_get_dblarray(cfg, kstr, nrings, L);
    for(i = 0; i < nrings; i++) {
      nfilled += set_grid_values_ring(g, Rmin[i], Rmax[i], -1, -1, -1, L[i],
                                      NAN);
    }
    break;

  default:
    print_error("Unknown `luminosity_mode` %d!", luminosity_mode);
    exit(-1);
  }
  g->L_tot = get_total_luminosity(g);

  print_info("\t\t%d cells form the light source (L_tot = %g).\n", nfilled,
             g->L_tot);
  
  if((nfilled <= 0) && (luminosity_mode != 0)) {
    print_error("Cell-based emission requires at least one luminous cell.");
    exit(-1);
  }
  
}

/* ------------------------------------------------------------ */
/**
   Looks up if cloud was already created.
   Uses a static array to keep track of things.
   
   @param sec      -- Identifier string. Frees memory of grids in lookup
                      table if NULL is given.
   @param newcloud -- For registering a new grid in lookup table.
   
   @return NULL if not found, otherwise pointer to grid.
**/
grid *cfg_lookup_cloud(const char *sec, grid *newcloud) {
  int i;
  static int nclouds = 0;
  static grid *clouds[MAX_CLOUDS];
  static char cloud_secs[MAX_CLOUDS][GRID_SECTION_SIZE];

  // Freeing memory
  if(sec == NULL) {
    print_info("\tFreeing %d clouds...", nclouds);
    for(i = 0; i < nclouds; i++) {
      free_grid(clouds[i]);
    }
    nclouds = 0;
    print_info("done!\n");
    return NULL;
  }

  // Look up
  for(i = 0; i < nclouds; i++) {
    if (cfg_names_equal(cloud_secs[i], sec)) {
      if(newcloud != NULL) {
        print_error("%s already found in lookup table!", sec);
        exit(-1);
      }
      return clouds[i];
    }
  }
  if(newcloud == NULL)
    return NULL;

  // Register new
  if (nclouds == MAX_CLOUDS || strlen(sec) >= GRID_SECTION_SIZE) {
    print_error("Cloud registry capacity or section name length exceeded.");
    exit(EXIT_FAILURE);
  }
  strcpy(cloud_secs[nclouds], sec);
  clouds[nclouds] = newcloud;
  nclouds++;
  
  return newcloud;
}

/* ------------------------------------------------------------ */

static void cloud_config_key(char key[CONFIG_KEY_SIZE], const char *section, const char *name) {
  int length = snprintf(key, CONFIG_KEY_SIZE, "%s:%s", section, name);
  if (length < 0 || length >= CONFIG_KEY_SIZE) {
    print_error("Cloud configuration section/key is too long.");
    exit(EXIT_FAILURE);
  }
}

#ifdef CELL_CLOUDS
static int cloud_mode_code(double value, int first, int last, const char *kind) {
  if (!isfinite(value) || value < first || value > last || value != floor(value)) {
    print_error("Invalid cloud %s mode %g; choose an integer from %d to %d. "
                "See docs/cloud-model.md for the current mode numbers.",
                kind, value, first, last);
    exit(EXIT_FAILURE);
  }
  return (int)value;
}
#endif

static void cfg_create_clouds(config *cfg, const char *section, grid *meta_grid) {
  char key[CONFIG_KEY_SIZE];
  cloud_config_key(key, section, "clouds");
  if (!cfg_key_exists(cfg, key)) return;
#ifndef CELL_CLOUDS
  (void)meta_grid;
  print_error("Cloud configurations require a build with CELL_CLOUDS.");
  exit(EXIT_FAILURE);
#else
  if (!cfg_get_bool(cfg, "tlac:cell_clouds")) {
    print_error("Cloud configurations require CELL_CLOUDS.");
    exit(EXIT_FAILURE);
  }
  const int population_count = cfg_count_array(cfg, key);
  if (population_count == 0) return;
  enum { PRIMARY_POPULATION, SECONDARY_POPULATION };
#ifdef PEACOCK_PAIRED_CATALOGUE
  const int max_populations = SECONDARY_POPULATION + 1;
#else
  const int max_populations = MAX_CLOUDS;
#endif
  if (population_count < 0 || population_count > max_populations) {
    print_error("Invalid cloud population count in [%s]; maximum is %d.",
                section, max_populations);
    exit(EXIT_FAILURE);
  }
  char schema_key[CONFIG_KEY_SIZE];
  cloud_config_key(schema_key, section, "cloud_mode_schema");
  if (!cfg_key_exists(cfg, schema_key) ||
      cfg_get_int(cfg, schema_key) != PEACOCK_CLOUD_MODE_SCHEMA) {
    print_error("Set [%s] cloud_mode_schema=%d "
                "and select the cloud modes described in docs/cloud-model.md.",
                section, PEACOCK_CLOUD_MODE_SCHEMA);
    exit(EXIT_FAILURE);
  }
  char **cloud_sections = allocate_2d_char_array(population_count, GRID_SECTION_SIZE);
  cfg_get_strarray_sized(cfg, key, population_count, cloud_sections, GRID_SECTION_SIZE);

  enum { PLACEMENT_PARAMETERS = 4, MOTION_COMPONENTS = 2,
         WIND_PARAMETERS = 5, MOTION_PARAMETERS = 2 * WIND_PARAMETERS };
  double placement_modes[population_count];
  double filling_factors[population_count], inner[population_count], outer[population_count];
  double **placement_params = allocate_2d_dbl_array(population_count, PLACEMENT_PARAMETERS);
  double **motion_modes = allocate_2d_dbl_array(population_count, MOTION_COMPONENTS);
  double **motion_params = allocate_2d_dbl_array(population_count, MOTION_PARAMETERS);
  memset(placement_params[0], 0, (size_t)population_count * PLACEMENT_PARAMETERS * sizeof(double));
  memset(motion_modes[0], 0, (size_t)population_count * MOTION_COMPONENTS * sizeof(double));
  memset(motion_params[0], 0, (size_t)population_count * MOTION_PARAMETERS * sizeof(double));

  cloud_config_key(key, section, "cloud_placing_modes");
  cfg_get_dblarray(cfg, key, population_count, placement_modes);
  cloud_config_key(key, section, "cloud_filling_factors");
  cfg_get_dblarray(cfg, key, population_count, filling_factors);
  cloud_config_key(key, section, "cloud_Rin");
  cfg_get_dblarray(cfg, key, population_count, inner);
  cloud_config_key(key, section, "cloud_Rout");
  cfg_get_dblarray(cfg, key, population_count, outer);
  cloud_config_key(key, section, "cloud_placing_params");
  if (cfg_key_exists(cfg, key))
    cfg_get_2d_dblarray_sized(cfg, key, population_count, placement_params, PLACEMENT_PARAMETERS);
  cloud_config_key(key, section, "cloud_motion_modes");
  cfg_get_2d_dblarray_sized(cfg, key, population_count, motion_modes, MOTION_COMPONENTS);
  cloud_config_key(key, section, "cloud_motion_params");
  cfg_get_2d_dblarray_sized(cfg, key, population_count, motion_params, MOTION_PARAMETERS);

  for (int p = 0; p < population_count; p++) {
    int placement = cloud_mode_code(placement_modes[p], CLOUD_PLACEMENT_UNIFORM,
                                    CLOUD_PLACEMENT_CATALOGUE, "placement");
    int first_motion = cloud_mode_code(motion_modes[p][0], CLOUD_MOTION_NONE,
                                       CLOUD_MOTION_WIND, "motion");
    int second_motion = cloud_mode_code(motion_modes[p][1], CLOUD_MOTION_NONE,
                                        CLOUD_MOTION_WIND, "motion");
    if (!isfinite(inner[p]) || !isfinite(outer[p]) || inner[p] >= outer[p]) {
      print_error("Cloud population %d in [%s] needs finite Rin < Rout.", p + 1, section);
      exit(EXIT_FAILURE);
    }
    grid *cloud = cfg_lookup_cloud(cloud_sections[p], NULL);
    if (cloud == NULL) {
      cloud = cfg_make_grid(cfg, cloud_sections[p]);
      cfg_lookup_cloud(cloud_sections[p], cloud);
    }
#ifdef PEACOCK_PAIRED_CATALOGUE
    const int companion = p == PRIMARY_POPULATION ? SECONDARY_POPULATION : PRIMARY_POPULATION;
    const double other_fraction = population_count == 2 ? filling_factors[companion] : 0.0;
    const int apply_second_motion = 1;
    create_clouds(filling_factors[p], inner[p] * PARSEC, outer[p] * PARSEC,
                  cloud, meta_grid, placement, placement_params[p], other_fraction, p);
#else
    const int apply_second_motion = p != SECONDARY_POPULATION;
    create_clouds(filling_factors[p], inner[p] * PARSEC, outer[p] * PARSEC,
                  cloud, meta_grid, placement, placement_params[p]);
#endif
    add_clouds_velocity(meta_grid, first_motion, motion_params[p]);
    /* Native Lyα applies the second motion to the companion population too. */
    if (apply_second_motion) {
      int offset = first_motion == CLOUD_MOTION_WIND ? WIND_PARAMETERS : 1;
      add_clouds_velocity(meta_grid, second_motion, motion_params[p] + offset);
    }
  }

  free(cloud_sections);
  free(placement_params);
  free(motion_modes);
  free(motion_params);
#endif
}

/* ------------------------------------------------------------ */
/**
   cfg_set_emission

   Sets emission parameters based on config.
   If uv_switch != 0 it takes the UV parameters for the frequency
   instead (emission:uv_frequency_mode, emission:uv_frequency_param).
 **/
static void cfg_set_emission(config *cfg, struct emission_cfg_s *e,
                      int uv_switch) {
  const char *frequency_prefix = uv_switch ? "uv_" : "";
  char kstr[CONFIG_KEY_SIZE];
  
  print_info("Set up %s-emission according to config...\n",
             uv_switch ? "UV" : "Lya");

#ifdef PEACOCK_MULTILEVEL
  memset(e, 0, sizeof(*e));
#else
  e->CII_ratio_21 = cfg_get_dbl(cfg, "emission:CII_ratio_21");
#ifdef PEACOCK_ATOM_FINE_STRUCTURE
  if (!isfinite(e->CII_ratio_21) || e->CII_ratio_21 < 0.0) {
    print_error("C II emission:CII_ratio_21 (n2/n1) must be finite and >= 0.");
    exit(EXIT_FAILURE);
  }
#endif
#endif
    
  e->initial_pos_mode = emission_position_from_config(
      cfg_get_int(cfg, "emission:position_mode"));

#if defined(PEACOCK_PAIRED_CATALOGUE) || defined(PEACOCK_ATOM_FINE_STRUCTURE) || defined(PEACOCK_MULTILEVEL)
  if (!emission_position_uses_luminosity(e->initial_pos_mode))
#else
  if (e->initial_pos_mode == EMISSION_POS_EXPONENTIAL ||
      emission_position_is_plane(e->initial_pos_mode))
#endif
    e->initial_pos_param = cfg_get_dbl(cfg, "emission:position_param");

#ifdef CELL_CLOUDS
  e->p_cloud = cfg_get_dbl(cfg, "emission:p_cloud");
#endif

  sprintf(kstr, "emission:%sfrequency_mode", frequency_prefix);
  e->initial_freq_mode = cfg_get_int(cfg, kstr);
  
  sprintf(kstr, "emission:%sfrequency_param", frequency_prefix);
  if(e->initial_freq_mode > EMISSION_FREQ_THERMAL)
    e->initial_freq_param = cfg_get_dbl(cfg, kstr);
  
  print_info("...done!\n");

}

/* ------------------------------------------------------------ */
/**
   cfg_create_observers
   
   Adds observers to the grid.
**/
static void cfg_create_observers(config *cfg, grid *g, int main_grid) {
  if(!iniparser_find_entry(cfg->dict, "observer")) return;
#ifdef PEACOCK_MULTILEVEL
  (void)g;
  (void)main_grid;
  /* The elastic virtual-observer estimator does not support Raman paths. */
  print_error("Multilevel RT: virtual [observer] mode is not supported; use escaping-photon output.");
  exit(EXIT_FAILURE);
#else
  int i, j;
  int mode = cfg_get_int(cfg, "observer:mode");
  double norm = 0;
  
  if(!mode) return;

  // Change if more modes available
  if((mode > TLAC_OBSERVER_ALLSCATTER_MOMENTUM) || (mode < 0)) {
    print_error("Unknown observer:mode value %d.", mode);
    exit(-1);
  }

  int nobserver = cfg_get_2d_dblarray_sized(cfg, "observer:directions", -1, NULL, 3);
  if (nobserver <= 0 || nobserver >= O_PHOTON_MAX_FILES) {
    print_error("Observer count must be between 1 and %d.", O_PHOTON_MAX_FILES - 1);
    exit(EXIT_FAILURE);
  }
  double **directions = allocate_2d_dbl_array(nobserver, 3);
  /* Reject short direction rows through the same finite-vector check. */
  for (i = 0; i < nobserver; i++)
    for (j = 0; j < 3; j++) directions[i][j] = NAN;
  print_info("Adding %d observers with observer mode %d.\n", nobserver, mode);
  cfg_get_2d_dblarray_sized(cfg, "observer:directions", nobserver, directions, 3);

  for(i = 0; i < nobserver; i++) {
    norm = norm3d(directions[i]);
    if (!isfinite(norm) || norm <= 0) {
      print_error("Observer directions must be finite and nonzero.");
      exit(EXIT_FAILURE);
    }
    for(j = 0; j < 3; j++)
      directions[i][j] /= norm;
    print_info("\t(%d)\t--> (%.2f,%.2f,%.2f)\n", i, directions[i][0],
               directions[i][1],directions[i][2]);

    if(main_grid) {
      if(o_photon_init(i + 1, cfg_get_str(cfg, "result:full_filename_prefix"),
                       mode == TLAC_OBSERVER_ALLSCATTER_MOMENTUM ?
                         "BINARY_MOMENTUM" : "HDF5_VLYA")) {
        print_error("Initializing observer output failed!");
        exit(-1);
      }
    }

    // Initialize observer
    if(add_observer(g, mode, directions[i])) {
      print_error("Error initializing observer.");
      exit(-1);
    }
    g->observers[i].nout_file = i + 1;

  }

  free(directions);

  print_info("...done adding %d observers.", nobserver);
#endif
  
}

/* ------------------------------------------------------------ */
/**
   cfg_run_tlac

   Runs tlac as given in the (complete) config.

   Makes grid etc, shoots photons and cleans up after.

   @return 0 if ok. -1 when error.
**/
/* Tracking is explicitly requested and follows the configured output prefix.
 * The secondary UV pass gets a distinct path even with a custom main path. */
static const char *cfg_tracking_output(config *cfg, int uv, char *path, size_t capacity) {
  int custom = cfg_key_exists(cfg, "output:track_output");
  int enabled = custom || (cfg_key_exists(cfg, "output:track_photons") &&
                          cfg_get_bool(cfg, "output:track_photons"));
  if (!enabled) {
    if (!uv && access("track_photons.dat", F_OK) == 0)
      print_warning("Photon tracking is disabled. "
                    "To enable it, set output:track_photons=true or output:track_output. "
                    "The existing track_photons.dat was left untouched.");
    return NULL;
  }
  const char *prefix = custom ? cfg_get_str(cfg, "output:track_output") :
                               cfg_get_str(cfg, "result:full_filename_prefix");
  int length = snprintf(path, capacity, "%s%s", prefix,
                         custom ? (uv ? ".uv" : "") :
                                  (uv ? ".uv.tracks.dat" : ".tracks.dat"));
  if (prefix[0] == '\0' || length < 0 || (size_t)length >= capacity) {
    print_error("Photon tracking output path is empty or too long.");
    exit(EXIT_FAILURE);
  }
  return path;
}

int cfg_run_tlac(config *cfg) {
  char tracking_path[512];
  char fesc_str[32], ndat_str[32];
  
  /// --- Initialize run ---
  struct emission_cfg_s emission_cfg = {0};
  double ndat;
  int i;
  int Nphot    = cfg_get_int(cfg, "run:nphot");
  int Nphot_UV = cfg_get_int(cfg, "run:nphot_uv");
  if( (Nphot < 0) || (Nphot_UV < 0) ) {
    print_error("Nphot < 0 doesn't make sense. "
                "Found: Nphot = %d, Nphot_UV = %d", Nphot, Nphot_UV);
    exit(-1);
  }

#ifdef PEACOCK_MULTILEVEL
  cfg_load_population_ratios(cfg);
  rt_validate_atom();
  print_info("%s: reference %.9f A, %d lower / %d upper / %d transitions\n",
             RT_NAME, 1e8 * LIGHT_SPEED / LYA_NU0, RT_NLOWER, RT_NUPPER, RT_NLINES);
#endif
  cfg_init_run(cfg);
  
  grid *g = cfg_make_grid(cfg, "grid");
  if(g == NULL)
    return -1;
  cfg_set_emission(cfg, &emission_cfg, 0);

  /** Initialize random seed */
  init_rand_tools( cfg_get_int(cfg, "run:random_seed") );

  /// -- Shoot photons --
  print_info("Shoot %d photons...\n", Nphot);
  #ifdef TLAC_CUDA
  run_photons_cuda(g, Nphot, emission_cfg, (unsigned long long)cfg_get_int(cfg, "run:random_seed"), 0);
#else
  run_photons_with_tracking(g, Nphot, emission_cfg,
                            cfg_tracking_output(cfg, 0, tracking_path, sizeof(tracking_path)));
#endif

  ndat = o_photon_get_nout(0);

  sprintf(fesc_str, "%.5f",Nphot > 0 ? ndat / (double) Nphot : 0.0);
  iniparser_set(cfg->dict, "result:fesc", fesc_str);

  sprintf(ndat_str, "%.7e", ndat);
  iniparser_set(cfg->dict, "result:ndat", ndat_str);
  
  print_info("done (fesc=%s)!\n", fesc_str);

  // --- UV data ---
  if(Nphot_UV > 0) {
    print_info("Run with %d UV photons.\n",Nphot_UV);
    o_photon_finalize(0);

    if (o_photon_init(0, cfg_get_str(cfg, "result:full_filename_prefix"),
                      cfg_get_str(cfg, "output:uv"))) {
      print_error("Initializing UV photon output failed.");
      exit(EXIT_FAILURE);
    }
    cfg_set_emission(cfg, &emission_cfg, 1);
    
    run_photons_with_tracking(g, Nphot_UV, emission_cfg,
                              cfg_tracking_output(cfg, 1, tracking_path, sizeof(tracking_path)));

    ndat = (double)o_photon_get_nout(0);


    sprintf(fesc_str, "%.5f",ndat / (double) Nphot_UV);
    iniparser_set(cfg->dict, "result:fesc_uv", fesc_str);

    sprintf(ndat_str, "%.7e", ndat);
    iniparser_set(cfg->dict, "result:ndat_uv", ndat_str);

    iniparser_set(cfg->dict, "result:uvdat_file", o_photon_get_filename(0));
    
    print_info("done (fesc_uv=%s)!\n", fesc_str);
  }

  /// --- Finalize run ---
  print_info("Freeing memory...\n");
  cfg_lookup_cloud(NULL, NULL);

  for(i = 0; i < g->nobservers; i++) {
    Nphot = o_photon_get_nout(g->observers[i].nout_file);
    print_info("\tFree observer %-5d--> %d events saved.\n", i, Nphot);
    free_observer(&(g->observers[i]));
  }

  free_grid(g);
  print_info("done!\n");
  cfg_finalize_run(cfg);
  
  return 0;
}

/* ------------------------------------------------------------ */
/**
   Finalizes tlac run.

   Undoes the things done in @cfg_init_run
 **/
static void cfg_finalize_run(config *cfg) {
  time_t end_time;
  struct tm * end_time_s;
  char end_time_str[64];
  struct tm start_time_s = {0};
  start_time_s.tm_isdst = -1;
  double runtime;
  char rt_str[64];
  
  print_info("Finalize run...\n");
  
  o_photon_finalize(0);

  cleanup_rand_tools();
  
  /** Get running time */
  time(&end_time);
  end_time_s = localtime(&end_time);
  strftime(end_time_str, 64, "%y%m%d-%H%M%S", end_time_s);
  iniparser_set(cfg->dict, "result:end_time", end_time_str);

  if(!strptime(cfg_get_str(cfg, "result:start_time") , "%y%m%d-%H%M%S",
                &start_time_s ))
    print_warning("Could not obtain starting time. Runtime might be wrong");
  runtime = difftime(mktime(end_time_s), mktime(&start_time_s));
  sprintf(rt_str, "%.2f", runtime);

  print_info("\tRunning time = %s seconds\n", rt_str);
  iniparser_set(cfg->dict, "result:running_time", rt_str);

  /** Write config */
  write_config(cfg);

  print_info("...done!\n");
  
}

