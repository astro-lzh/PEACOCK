#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "iniparser/iniparser.h"
#include "../misc/mem.h"
#include "../tlac_defs.h"
#include "../misc/messages.h"

#include "read_config.h"

static void cfg_check_optional_keys(config *cfg);

#ifdef PEACOCK_MULTILEVEL
#include "../atomic_network.h"

enum { POPULATION_RATIO_KEY_SIZE = 64 };

static void population_ratio_key(char key[POPULATION_RATIO_KEY_SIZE], int lower_index) {
  snprintf(key, POPULATION_RATIO_KEY_SIZE, "emission:population_ratio_%d", lower_index + 1);
}

void cfg_load_population_ratios(const config *cfg) {
  rt_pop[0] = 1.0;
  for (int i = 1; i < RT_NLOWER; i++) {
    char key[POPULATION_RATIO_KEY_SIZE];
    population_ratio_key(key, i);
    rt_pop[i] = cfg_get_dbl(cfg, key);
  }
}
#endif

/*******************************************************************//**
 * read_config
 *                                                                 
 * Main function to call.
 *                                                                 
 * Loads the dictionary and supplies optional defaults before template resolution.
 *                                                                 
 * NULL is returned if something went wrong.
 ***********************************************************************/
config* read_config(const char *filename) {
  config *cfg;

  cfg = check_realloc(NULL, sizeof(config));
  if(cfg == NULL) {
    print_error("Problem allocating config.");
    return NULL;
  }

  if (strlen(filename) >= sizeof(cfg->filename)) {
    print_error("Configuration filename is too long.");
    free(cfg);
    return NULL;
  }
  strcpy(cfg->filename, filename);

  cfg->dict = iniparser_load(cfg->filename);
  if (cfg->dict == NULL) {
    free(cfg);
    return NULL;
  }

  cfg_check_optional_keys(cfg);
  return cfg;
}

/* ------------------------------------------------------------ */
/**
   cfg_replace_template
   Replaces values in config by given ones.

   Searches all keys in `cfg` for <X> pattern and replaces it by
   Xth entry in `repl` (starting from 0)

   @param cfg         Config to process
   @param nreplace    Number of entries in "repl"
   @param repl        Array of replacement strings

   @return Number of replacements done. -1 if error.
**/
int cfg_replace_templates(config *cfg, const int nreplace,
                          char **repl) {
  int n = 0;

  int error_found = 0;

  print_info("Replace %d parameters of config `%s`...\n", nreplace,
             cfg->filename);
  const int section_count = iniparser_getnsec(cfg->dict);
  for (int i = 0; i < section_count; i++) {
    char *section = iniparser_getsecname(cfg->dict, i);
    const int key_count = iniparser_getsecnkeys(cfg->dict, section);
    if (key_count <= 0) continue;
    char **keys = iniparser_getseckeys(cfg->dict, section);
    if (keys == NULL) {
      print_error("Could not list template keys in section %s.", section);
      return -1;
    }
    for (int j = 0; j < key_count; j++) {
      const char *value = iniparser_getstring(cfg->dict, keys[j], "(never)");
      if (value == NULL || value[0] != '<') continue;
      const size_t len = strlen(value);
      if (value[len - 1] != '>') continue;

      errno = 0;
      char *end;
      long index = strtol(value + 1, &end, 10);
      if (errno || end == value + 1 || end != value + len - 1 ||
          index < 0 || index >= nreplace) {
        print_error("Could not replace template %s for %s.", value, keys[j]);
        error_found = 1;
        continue;
      }
      print_info("  %-23s --> ", keys[j]);
      iniparser_set(cfg->dict, keys[j], repl[index]);
      print_info("%s\n", repl[index]);
      n++;
    }
    free(keys); /* The key strings belong to the dictionary. */
  }

  if(error_found) {
    print_error("Configuration contains an invalid template reference.");
    return -1;
  }

  if(n != nreplace) {
    print_error("Not all replacements done (only %d/%d)!", n, nreplace);
    return -1;
  }

  print_info("...done!\n");
  
  return n;
}

/* ------------------------------------------------------------ */
/**
   Checks for optional keys.
   If they don't exist, adds them with default values.

   @return 0 if successful
**/
static void cfg_check_optional_keys(config *cfg) {
#ifdef PEACOCK_MULTILEVEL
  for (int i = 1; i < RT_NLOWER; i++) {
    char key[POPULATION_RATIO_KEY_SIZE];
    population_ratio_key(key, i);
    if (!iniparser_find_entry(cfg->dict, key))
      iniparser_set(cfg->dict, key, "0");
  }
#endif
  const struct {
    const char *key;
    const char *value;
  } defaults[] = {
    {"grid:set_all_absorbing_dust", "False"},
    {"run:nphot_uv", "0"},
    {"output:lya", "ASCII_LYA"},
    {"output:uv", "ASCII_UV"},
    {"emission:uv_frequency_mode", "1"},
    {"emission:uv_frequency_param", "1e4"},
  };
  for (size_t i = 0; i < sizeof(defaults) / sizeof(defaults[0]); i++) {
    if (!iniparser_find_entry(cfg->dict, defaults[i].key))
      iniparser_set(cfg->dict, defaults[i].key, defaults[i].value);
  }

}

int cfg_key_exists(const config *cfg, const char *key) {
  return iniparser_find_entry(cfg->dict, key);
}

char *cfg_get_str(const config *cfg, const char *key) {
  char *value = iniparser_getstring(cfg->dict, key, NULL);
  if (value == NULL) {
    print_error("Configuration key %s is missing.", key);
    exit(EXIT_FAILURE);
  }
  return value;
}

int cfg_names_equal(const char *left, const char *right) {
  while (*left && *right && tolower((unsigned char)*left) == tolower((unsigned char)*right)) {
    left++;
    right++;
  }
  return *left == *right;
}

static const char *skip_space(const char *text) {
  while (isspace((unsigned char)*text)) text++;
  return text;
}

static int parse_int(const char *key, const char *text, int base) {
  errno = 0;
  char *end;
  long value = strtol(text, &end, base);
  if (end == text || *skip_space(end) || errno == ERANGE || value < INT_MIN || value > INT_MAX) {
    print_error("Configuration key %s requires an in-range integer, got \"%s\".", key, text);
    exit(EXIT_FAILURE);
  }
  return (int)value;
}

int cfg_get_int(const config *cfg, const char *key) {
  /* Scalar integers accept base prefixes, including 0x for hexadecimal. */
  return parse_int(key, cfg_get_str(cfg, key), 0);
}

int cfg_get_bool(const config *cfg, const char *key) {
  const char *value = cfg_get_str(cfg, key);
  const char *true_values[] = {"1", "true", "t", "yes", "y"};
  const char *false_values[] = {"0", "false", "f", "no", "n"};
  for (size_t i = 0; i < sizeof(true_values) / sizeof(true_values[0]); i++) {
    if (cfg_names_equal(value, true_values[i])) return 1;
    if (cfg_names_equal(value, false_values[i])) return 0;
  }
  print_error("Configuration key %s requires a boolean, got \"%s\".", key, value);
  exit(EXIT_FAILURE);
}

static double parse_double(const char *key, const char *text) {
  char *end;
  double value = strtod(text, &end);
  if (end == text || *skip_space(end) || !isfinite(value)) {
    print_error("Configuration key %s requires a finite number, got \"%s\".", key, text);
    exit(EXIT_FAILURE);
  }
  return value;
}

double cfg_get_dbl(const config *cfg, const char *key) {
  return parse_double(key, cfg_get_str(cfg, key));
}

static int check_build_integer(config *cfg, const char *key, int compiled,
                               int boolean, int write_default) {
  if (!cfg_key_exists(cfg, key)) {
    if (write_default) {
      char value[32];
      snprintf(value, sizeof(value), "%d", compiled);
      iniparser_set(cfg->dict, key, value);
    }
    return 0;
  }
  const int configured = boolean ? cfg_get_bool(cfg, key) : cfg_get_int(cfg, key);
  if (configured == compiled) return 0;
  print_error("Configuration key %s has value %d but this build requires %d.", key, configured, compiled);
  return -1;
}

static int check_build_double(config *cfg, const char *key, double compiled, int write_default) {
  if (!cfg_key_exists(cfg, key)) {
    if (!write_default) {
      print_error("Configuration key %s is required by this build.", key);
      return -1;
    }
    char value[32];
    snprintf(value, sizeof(value), "%e", compiled);
    iniparser_set(cfg->dict, key, value);
    return 0;
  }
  const double configured = cfg_get_dbl(cfg, key);
  if (configured == compiled) return 0;
  print_error("Configuration key %s has value %g but this build requires %g.", key, configured, compiled);
  return -1;
}

/* Check resolved configuration against the compiled transport settings. */
int cfg_tlac_compatible(config *cfg) {
#ifdef CELL_CLOUDS
  const int cell_clouds = 1;
#else
  const int cell_clouds = 0;
#endif
#ifdef SIMPLE_HYDROGEN_SCATTER
  const int simple_scattering = 1;
#else
  const int simple_scattering = 0;
#endif
#ifdef FIX_FREQUENCY
  const int fixed_frequency = 1;
#else
  const int fixed_frequency = 0;
#endif
  if (check_build_integer(cfg, "tlac:tlac_grid", TLAC_GRID, 0, 1) ||
      check_build_integer(cfg, "tlac:cell_clouds", cell_clouds, 1, 1) ||
      check_build_integer(cfg, "tlac:simple_hydrogen_scatter", simple_scattering, 1, 1) ||
      check_build_integer(cfg, "tlac:fix_frequency", fixed_frequency, 1, fixed_frequency) ||
      check_build_double(cfg, "tlac:tlac_xcrit", TLAC_XCRIT, 1) ||
      check_build_double(cfg, "tlac:observer_allscatter_full_fraction",
                         OBSERVER_ALLSCATTER_FULL_FRACTION, 1))
    return -1;

#ifdef TWO_PHOTON_DESTRUCTION
  if (check_build_double(cfg, "tlac:two_photon_destruction", TWO_PHOTON_DESTRUCTION, 0))
    return -1;
#else
  if (cfg_key_exists(cfg, "tlac:two_photon_destruction")) {
    print_error("This build does not enable two-photon destruction.");
    return -1;
  }
#endif
  if (cfg_key_exists(cfg, "tlac:extra_photon_information")) {
#ifdef EXTRA_PHOTON_INFORMATION
    return check_build_integer(cfg, "tlac:extra_photon_information", EXTRA_PHOTON_INFORMATION, 0, 0);
#else
    print_error("This build does not enable extra photon information.");
    return -1;
#endif
  }
  return 0;
}

/* ------------------------------------------------------------ */
/**
   Parses config array `s`
   (a,b,c) --> array[a,b,c]
   ((a,b),(c)) --> array[(a,b),(c)]
   If NULL is given as `retarr` then does not copy result.
   
   @return Number of items in array. -1 if error occured. 
**/
static int cfg_parse_array_with_width(const char *s, char **retarr, size_t width) {
  const char *begin = strchr(s, '(');
  const char *end = strrchr(s, ')');
  if (begin == NULL || end == NULL || end < begin) {
    print_error("Array expected in configuration value %s", s);
    return -1;
  }
  for (const char *p = s; p < begin; p++) {
    if (!isspace((unsigned char)*p)) return -1;
  }
  for (const char *p = end + 1; *p; p++) {
    if (!isspace((unsigned char)*p)) return -1;
  }
  if (skip_space(begin + 1) == end) return 0;

  int count = 0;
  int depth = 0;
  const char *start = begin + 1;
  for (const char *p = start; p <= end; p++) {
    if (p < end && *p == '(') depth++;
    if (p < end && *p == ')') depth--;
    if (depth < 0) return -1;
    if (p == end || (*p == ',' && depth == 0)) {
      const char *item = skip_space(start);
      const char *stop = p;
      while (stop > item && isspace((unsigned char)stop[-1])) stop--;
      if (item >= stop || (size_t)(stop - item) >= width) return -1;
      const size_t length = (size_t)(stop - item);
      if (retarr != NULL) {
        memcpy(retarr[count], item, length);
        retarr[count][length] = '\0';
      }
      count++;
      start = p + 1;
    }
  }
  return depth == 0 ? count : -1;
}

/**********************************************************************//**
 * cfg_get_strarray
 * 
 * Reads string array from config. Expects array in the form
 * (s1,s2,s3,...). Values will be copied in `retarr` If `nentries` > 0
 * then the number of entries has to be given and match.
 * 
 * Returns the number of entries.
 **************************************************************************/
int cfg_get_strarray_sized(const config *cfg, const char *key,
                           int nentries, char **retarr, size_t width) {
  char *value = iniparser_getstring(cfg->dict, key, NULL);
  int count = value == NULL ? -1 : cfg_parse_array_with_width(value, NULL, width);
  if (count < 0 || (nentries >= 0 && count != nentries)) {
    print_error("Invalid array or unexpected item count at %s.", key);
    exit(EXIT_FAILURE);
  }
  if (retarr != NULL) cfg_parse_array_with_width(value, retarr, width);
  return count;
}

int cfg_count_array(const config *cfg, const char *key) {
  return cfg_get_strarray_sized(cfg, key, -1, NULL, (size_t)-1);
}

/*********************************************************************//**
 * cfg_get_dblarray
 * 
 * Reads double array from config. Expects array in the form
 * (d1,d2,d3,...). Values will be copied in `retarr`. If `nentries`>0
 * then the number of entries has to be given and match.
 * 
 * Returns the number of entries found.
 *************************************************************************/
int cfg_get_dblarray(const config *cfg, const char *key,
                     int nentries, double *retarr) {
  int count = cfg_get_strarray_sized(cfg, key, nentries, NULL, (size_t)-1);
  if (count == 0) return 0;
  char *value = cfg_get_str(cfg, key);
  char **items = allocate_2d_char_array(count, strlen(value) + 1);
  cfg_get_strarray_sized(cfg, key, count, items, strlen(value) + 1);
  for (int i = 0; i < count; i++) retarr[i] = parse_double(key, items[i]);
  free(items);
  return count;
}

/*********************************************************************//**
 * cfg_get_2d_dblarray
 * 
 * Reads 2 dimensional double array from config. Expects array in the
 * form ((d1,d2),(d3),(d4,d5,...),...). Values will be copied in `retarr`. If
 * `nentries`>0 then the number of entries has to be given and match.
 * 
 * Returns the number of entries (that is subarrays) found.
 *************************************************************************/
int cfg_get_2d_dblarray_sized(const config *cfg, const char *key,
                             int nentries, double **retarr, int width) {
  int count = cfg_get_strarray_sized(cfg, key, nentries, NULL, (size_t)-1);
  if (count == 0) return 0;
  char *value = cfg_get_str(cfg, key);
  size_t length = strlen(value) + 1;
  char **rows = allocate_2d_char_array(count, length);
  cfg_get_strarray_sized(cfg, key, count, rows, length);
  for (int i = 0; i < count; i++) {
    int columns = cfg_parse_array_with_width(rows[i], NULL, length);
    if (columns < 0 || (width > 0 && columns > width)) {
      print_error("Invalid row or too many columns in %s.", key);
      exit(EXIT_FAILURE);
    }
    if (retarr != NULL && columns > 0) {
      char **items = allocate_2d_char_array(columns, length);
      cfg_parse_array_with_width(rows[i], items, length);
      for (int j = 0; j < columns; j++) retarr[i][j] = parse_double(key, items[j]);
      free(items);
    }
  }
  free(rows);
  return count;
}

/***********************************************//**
 * cfg_get_intarray
 * 
 * Same as `cfg_get_dblarray` but for integers.
 ***************************************************/
int cfg_get_intarray(const config *cfg, const char *key,
                     int nentries, int *retarr) {
  int count = cfg_get_strarray_sized(cfg, key, nentries, NULL, (size_t)-1);
  if (count == 0) return 0;
  char *value = cfg_get_str(cfg, key);
  char **items = allocate_2d_char_array(count, strlen(value) + 1);
  cfg_get_strarray_sized(cfg, key, count, items, strlen(value) + 1);
  for (int i = 0; i < count; i++) retarr[i] = parse_int(key, items[i], 10);
  free(items);
  return count;
}

/* ---------------------------------------------------------------------- */
/**
   Writes config to (loadable) file.

   Uses filename of data and appends "cfg" as suffix
 **/
void write_config(config *cfg) {
  char filename[256];
  FILE *fp;

  int length = snprintf(filename, sizeof(filename), "%s.cfg",
                        cfg_get_str(cfg, "result:full_filename_prefix"));
  if (length < 0 || (size_t)length >= sizeof(filename)) {
    print_error("Resolved configuration filename is too long.");
    exit(EXIT_FAILURE);
  }
  
  print_info("\tWrite config to %s ...", filename);

  fp = check_fopen(filename, "w+");
  iniparser_dump_ini(cfg->dict, fp);
  
  fclose(fp);

  print_info("done!\n");
}

/****************************************//**
 * free_config
 *                        
 * Frees memory of config.
 ********************************************/
void free_config(config *cfg) {
  iniparser_freedict(cfg->dict);

  free(cfg);
}

