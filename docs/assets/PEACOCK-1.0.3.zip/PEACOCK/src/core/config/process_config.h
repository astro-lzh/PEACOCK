#ifndef _PROCESS_CONFIG_H_
#define _PROCESS_CONFIG_H_

#include "read_config.h"

struct grid_s;

/* Reuse or register a cloud grid by section name. A NULL name clears the
 * registry and frees its grids. */
struct grid_s *cfg_lookup_cloud(const char *section, struct grid_s *newcloud);

/* Run a resolved configuration. The caller retains ownership of cfg. */
int cfg_run_tlac(config *cfg);

#endif /* _PROCESS_CONFIG_H_ */
