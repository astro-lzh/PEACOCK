#ifndef _TLAC_DEFS_H_
#define _TLAC_DEFS_H_

/* Compile-time model and transport defaults. Physical constants are in
 * physical_properties.h. Only the native CPU Lyα profile reads a paired
 * cloud catalogue. */
#if defined(PEACOCK_ATOM_RESONANT) && !defined(TLAC_CUDA) && !defined(TLAC_GPU_BUILD)
#define PEACOCK_PAIRED_CATALOGUE 1
#endif

/* Enable progress messages. */
#define VERBOSE 1

/* Tracking detail: 0 records all events, 1 records scatters and outcomes. */
#define TRACK_PHOTON_DAT_MODE 0

/* Native grid types. */
#define GRID_CARTESIAN 1
#define GRID_SPHERICAL 2
#define GRID_VARIABLE  3

/* The backend build selects the grid through MAKEFILE_GRID. */
#define TLAC_GRID MAKEFILE_GRID

/* Use radial cells in spherical geometry. */
#define SIMPLE_SPHERICAL_GRID

/* Optional scalar CPU switches. Enable via compiler definitions.
 * NO_SCATTER_MODE disables scattering. FIX_FREQUENCY holds the launch frequency. */

/* Parallel atom sampler: 0 one-piece, 1 Laursen, 2 five-piece. */
#define SCT_HYD_GET_ATOM_PARALLEL_VELOCITY_ALG 2

/* Core skipping: 0 disables it. Positive values set the detuning
 * threshold. Negative values use the distance to the cell boundary and
 * cap the adaptive threshold at the magnitude of the setting. */
#define TLAC_XCRIT 0

/* Optional scalar interactions: SIMPLE_HYDROGEN_SCATTER=1 selects an
 * isotropic phase function and =2 selects orthogonal scattering.
 * TWO_PHOTON_DESTRUCTION sets n_p/n_HI for collisional two-photon decay
 * (Dijkstra, Sobral & Gronke 2016). SIMPLE_DUST uses unit extinction. */

#if defined(PEACOCK_ATOM_FINE_STRUCTURE)
/* Draine (2003) SMC-bar values near C II 1334.53 Å. */
#define TLAC_DUST_ALBEDO 0.358
#define TLAC_DUST_HG_G 0.586
#elif defined(PEACOCK_ATOM_RESONANT)
#define TLAC_DUST_ALBEDO 0.32
#define TLAC_DUST_HG_G 0.73
#elif !defined(PEACOCK_MULTILEVEL)
/* Scalar doublet dust defaults. Multilevel uses the Draine table. */
#define TLAC_DUST_ALBEDO 0.40
#define TLAC_DUST_HG_G 0.65
#endif
/* Set to 1 to enable the scalar frequency-dependent dust fit. */
#define DUST_FREQUENCY_DEPENDENT 0

/* Variable-grid builds include cloud populations. */
#if TLAC_GRID == GRID_VARIABLE
#define CELL_CLOUDS
#endif

/* Maximum number of distinct cloud grid definitions. */
#define MAX_CLOUDS 10

/* Number of cloud records per allocation block. */
#define CLOUDS_ALLOCATE_STEP 100


/* Minimum guided-schedule chunk for multilevel CPU runs. */
#if defined(USE_OMP) && defined(PEACOCK_MULTILEVEL)
#define TLAC_OMP_MIN_CHUNKSIZE 1
#endif

/* Position tolerance for cell-boundary checks. Crossing offsets are
 * selected by the individual grid implementations. */
#define EPSILON_CHECK 1e-5

/* Virtual observer capacity, sampling fractions and escape cutoff. */
#define TLAC_MAX_OBSERVER 7
#define OBSERVER_ALLSCATTER_FULL_FRACTION 0.1
#define OBSERVER_ALLSCATTER_MOMENTUM_FRACTION 0.1
#define OBSERVER_TAU_ESC_CUTOFF 10

/* Multilevel photon output includes intrinsic transition information. */
#ifdef PEACOCK_MULTILEVEL
#ifndef TLAC_HOST_EXPORT
#define EXTRA_PHOTON_INFORMATION 1
#endif
#if TLAC_XCRIT != 0 || DUST_FREQUENCY_DEPENDENT != 0
#error Multilevel transfer requires the unaccelerated atom sampler and tabulated dust.
#endif
#if defined(TWO_PHOTON_DESTRUCTION) || defined(SIMPLE_HYDROGEN_SCATTER)
#error Multilevel transfer uses transition-specific decay and phase functions.
#endif
#endif


/* The GPU wrapper implements the default transport mode only. Reject host
 * switches that it cannot honor, instead of silently compiling another model. */
#if defined(TLAC_GPU_BUILD) || defined(TLAC_CUDA)
#if defined(FIX_FREQUENCY) || defined(NO_SCATTER_MODE)
#error GPU backend does not support FIX_FREQUENCY or NO_SCATTER_MODE
#endif
#if defined(PEACOCK_ATOM_DOUBLET) && \
    (TLAC_XCRIT != 0 || defined(SIMPLE_HYDROGEN_SCATTER) || defined(TWO_PHOTON_DESTRUCTION))
#error Independent-doublet GPU backend requires unaccelerated default scattering
#endif
#endif

#endif /* _TLAC_DEFS_H_ */
