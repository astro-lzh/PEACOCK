#include <stdio.h>
#include <stdlib.h>

#include "config/process_config.h"

int main(int argc, char **argv) {
  if (argc < 2) {
    fprintf(stderr, "Usage: %s CONFIG [TEMPLATE_VALUE ...]\n", argv[0]);
    return EXIT_FAILURE;
  }

  setbuf(stdout, NULL);

  config *cfg = read_config(argv[1]);
  if (cfg == NULL) {
    return EXIT_FAILURE;
  }

  if (cfg_replace_templates(cfg, argc - 2, argv + 2) < 0 ||
      cfg_tlac_compatible(cfg) != 0) {
    free_config(cfg);
    return EXIT_FAILURE;
  }
  const int result = cfg_run_tlac(cfg);
  free_config(cfg);
  return result == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
}

