#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "photon.h"
#include "physical_properties.h"
#include "scattering_fit.h"
#include "misc/mem.h"
#include "misc/messages.h"
#include "misc/my_math.h"

photon *create_photon(void) {
  photon *p = check_realloc(NULL, sizeof(*p));
  *p = (photon){0};
  p->emission_cfg = check_realloc(NULL, sizeof(*p->emission_cfg));
  *p->emission_cfg = (struct emission_cfg_s){0};
  return p;
}

void free_photon(photon *p) {
  if (p == NULL)
    return;
  free(p->emission_cfg);
  free(p);
}

static void update_photon_opacity(photon *p) {
  const grid_cell *cell = p->curr_cell;
  const double temperature = cell->T;
  /* Sum opacity over the populated transitions before selecting a scatter. */
#if defined(PEACOCK_ATOM_FINE_STRUCTURE)
  const double line_cross_section = cii_population_cross_section(
      p->x, temperature, p->emission_cfg->CII_ratio_21);
#elif defined(PEACOCK_ATOM_DOUBLET)
  const double line_cross_section = hydrogen_scattering_cross_section_double_line(p->x, temperature);
#elif defined(PEACOCK_MULTILEVEL)
  const double line_cross_section = rt_cross_sections(p->x, temperature, NULL);
#else
  const double line_cross_section = hydrogen_scattering_cross_section(p->x, temperature);
#endif
  const double dust_cross_section = gas_scattering_cs(p->x, temperature);
  p->curr_tau = cell->n_HI * line_cross_section + cell->n_D * dust_cross_section;
  if (!isfinite(p->curr_tau) || p->curr_tau < 0) {
    print_error("Photon extinction must be finite and nonnegative (x=%g, T=%g, extinction=%g).",
                p->x, temperature, p->curr_tau);
    exit(EXIT_FAILURE);
  }
}

void update_photon_values(photon *p) {
  assert_photon_values(p);
  assert(p->curr_cell != NULL);

  const double temperature = p->curr_cell->T;
  const double previous_width = p->Delta_nu_D;
  const double previous_bulk_shift = p->sc_dir_bulk;
  p->Delta_nu_D = doppler_freq_shift_hydrogen(temperature);
  p->sc_dir_bulk = cell_velocity_scalar_product(p->curr_cell, p->dir, p->pos, p->grid);
  if (!(previous_width > 0 && isfinite(previous_width) &&
        p->Delta_nu_D > 0 && isfinite(p->Delta_nu_D) && isfinite(p->sc_dir_bulk))) {
    print_error("Invalid photon frame at T=%g (Doppler widths %g and %g, bulk shift %g).",
                temperature, previous_width, p->Delta_nu_D, p->sc_dir_bulk);
    exit(EXIT_FAILURE);
  }

#ifdef PEACOCK_MULTILEVEL
  /* Transform absolute frequency between the two local frames. */
  const double frequency = LYA_NU0 + p->x * previous_width;
  const double previous_beta = previous_bulk_shift * previous_width / LYA_NU0;
  const double current_beta = p->sc_dir_bulk * p->Delta_nu_D / LYA_NU0;
  p->x = (rt_frame_frequency(frequency, previous_beta, current_beta) - LYA_NU0) / p->Delta_nu_D;
#else
  /* Update the local Doppler offset, Laursen (2010), Eq. 7.18. */
  p->x = (p->x + previous_bulk_shift) * previous_width / p->Delta_nu_D - p->sc_dir_bulk;
#endif

#if defined(PEACOCK_ATOM_FINE_STRUCTURE) || defined(PEACOCK_MULTILEVEL)
  const double natural_width = LYA_DELTA_NU_L_1;
#else
  const double natural_width = LYA_DELTA_NU_L;
#endif
  p->a = natural_width / (2.0 * p->Delta_nu_D);
  p->x_cw = core_wing_boundary(p->a);
  update_photon_opacity(p);
  assert_photon_values(p);
}

#ifdef FIX_FREQUENCY
void fix_photon_frequency(photon *p) {
  p->x = p->x_i;
  update_photon_opacity(p);
}
#endif

#ifdef DEBUG
void _assert_photon_pos(photon *p, const char *caller, int line) {
#else
void assert_photon_pos(photon *p) {
#endif
  if (p->curr_cell == NULL)
    return;

#ifdef DEBUG
  if (!is_pos_in_grid(p->pos, p->grid) || !is_pos_in_cell(p->pos, p->curr_cell, p->grid)) {
    print_error("Photon position is outside its grid or cell (%s:%d).", caller, line);
    print_photon(p);
  }
#endif
  assert(is_pos_in_grid(p->pos, p->grid));
  assert(is_pos_in_cell(p->pos, p->curr_cell, p->grid));
}

#ifdef DEBUG
void _assert_photon_values(photon *p, const char *caller, int line) {
  const double direction_tolerance = 1e-5;
  const double direction_norm = norm3d(p->dir);
  const int valid = isfinite(p->Delta_nu_D) && p->Delta_nu_D > 0 &&
    isfinite(p->x) && isfinite(p->sc_dir_bulk) && isfinite(p->a) && isfinite(p->x_cw) &&
    isfinite(p->curr_tau) && isfinite(p->tau) &&
    direction_norm > 1.0 - direction_tolerance && direction_norm < 1.0 + direction_tolerance;
  if (!valid) {
    print_error("Invalid photon state (%s:%d).", caller, line);
    print_photon(p);
  }
  assert(valid);
}
#else
void assert_photon_values(photon *p) {
  (void)p;
}
#endif

void print_photon(photon *p) {
  printf("--- photon ---\n");
  printf("pos = (%e, %e, %e)\n", p->pos[0], p->pos[1], p->pos[2]);
  printf("dir = (%e, %e, %e)\n", p->dir[0], p->dir[1], p->dir[2]);
  printf("x = %e, Delta_nu_D = %e, a = %e\n", p->x, p->Delta_nu_D, p->a);
  printf("x_cw = %e, curr_tau = %e, tau = %e\n", p->x_cw, p->curr_tau, p->tau);
  printf("dist = %e, c_HI_total = %e, c_D_total = %e\n", p->dist,
         p->c_HI_total, p->c_D_total);
  printf("nscatter = %d, x_i = %e, x_last = %e\n", p->nscatter, p->x_i, p->x_last);
  printf("dir_last = (%e, %e, %e)\n", p->dir_last[0], p->dir_last[1], p->dir_last[2]);
  printf("u_scatter_last = (%e, %e)\n", p->u_scatter_last[0], p->u_scatter_last[1]);
#ifdef CELL_CLOUDS
  printf("nclouds_passed = %d\n", p->nclouds_passed);
  printf("pos_shifted = (%e, %e, %e)\n", p->pos_shifted[0], p->pos_shifted[1], p->pos_shifted[2]);
  printf("vel_shifted = (%e, %e, %e)\n", p->vel_shifted[0], p->vel_shifted[1], p->vel_shifted[2]);
#endif
  if (p->curr_cell != NULL)
    printf("curr_cell->n_HI = %.3e\n", p->curr_cell->n_HI);
  else
    puts("curr_cell = NULL");
}
