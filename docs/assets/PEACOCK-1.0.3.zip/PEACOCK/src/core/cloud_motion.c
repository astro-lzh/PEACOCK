/* Shared cloud velocity law for every PEACOCK transition. Model-local
 * thermal speeds convert physical km/s to the transport's native units.
 * The paired-population adapter controls which clouds receive bulk motion. */
#include "tlac_defs.h"
#ifdef CELL_CLOUDS
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "clouds.h"
#include "physical_properties.h"
#include "misc/messages.h"
#include "misc/my_math.h"
#include "misc/rand_tools.h"

typedef struct {
  double speed, ratio, alpha, inner_radius, outer_radius;
} motion_parameters;

typedef void (*motion_function)(grid *, grid_cell *, unsigned int,
                                 const motion_parameters *);

static void motion_error(const char *message) {
  print_error("Cloud motion: %s.", message);
  exit(EXIT_FAILURE);
}

static double cloud_thermal_speed(grid_cell *cell, unsigned int cloud) {
  grid *model;
  if (cell->cloud_grids == NULL || (model = cell->cloud_grids[cloud]) == NULL ||
      model->cells == NULL || model->cells[0] == NULL || model->cells[0][0] == NULL)
    motion_error("missing cloud model");
  double speed = thermal_velocity_hydrogen(model->cells[0][0][0].T);
  if (!(speed > 0.0) || !isfinite(speed))
    motion_error("cloud temperature must give a finite positive thermal speed");
  return speed;
}

static double cloud_radius(grid *g, grid_cell *cell, unsigned int cloud,
                            double relative[3]) {
  if (cell->pos_clouds == NULL || cell->pos_clouds[cloud] == NULL)
    motion_error("missing cloud position");
  for (int axis = 0; axis < 3; axis++) {
    relative[axis] = cell->pos_clouds[cloud][axis] - g->center[axis];
    if (!isfinite(relative[axis]))
      motion_error("cloud positions and grid center must be finite");
  }
  double radius = norm3d(relative);
  if (!isfinite(radius))
    motion_error("cloud distance from the grid center exceeds the numeric range");
  return radius;
}

static void check_velocity(grid_cell *cell, unsigned int cloud) {
  if (cell->vel_clouds == NULL || cell->vel_clouds[cloud] == NULL)
    motion_error("missing cloud velocity");
  for (int axis = 0; axis < 3; axis++)
    if (!isfinite(cell->vel_clouds[cloud][axis]))
      motion_error("cloud velocity is nonfinite");
}

static void check_flag(grid_cell *cell, unsigned int cloud) {
  if (cell->v_flag_clouds == NULL || !isfinite(cell->v_flag_clouds[cloud]))
    motion_error("cloud motion flag is missing or nonfinite");
}

static void radial_motion(grid *g, grid_cell *cell, unsigned int cloud,
                           const motion_parameters *parameters) {
#ifdef PEACOCK_PAIRED_CATALOGUE
  check_flag(cell, cloud);
  if (cell->v_flag_clouds[cloud] >= 2.0) return;
#endif
  double vth = cloud_thermal_speed(cell, cloud);
  double relative[3];
  double radius = cloud_radius(g, cell, cloud, relative);
  if (radius == 0.0)
    motion_error("constant radial motion requires a cloud away from the grid center");
  double inverse_radius = 1.0 / radius;
  check_velocity(cell, cloud);
  /* Project the radial speed onto the Cartesian axes. */
  for (int axis = 0; axis < 3; axis++)
    cell->vel_clouds[cloud][axis] += parameters->speed / vth *
                                     relative[axis] * inverse_radius;
  check_velocity(cell, cloud);
}

/* Independent Cartesian draws: sigma is the standard deviation of each axis. */
static void gaussian_motion(grid *g, grid_cell *cell, unsigned int cloud,
                             const motion_parameters *parameters) {
  (void)g;
  check_flag(cell, cloud);
  if (cell->v_flag_clouds[cloud] < 1.0 && parameters->speed != 0.0) {
    double vth = cloud_thermal_speed(cell, cloud);
    check_velocity(cell, cloud);
    for (int axis = 0; axis < 3; axis++)
      cell->vel_clouds[cloud][axis] += rand_gaussian(parameters->speed) / vth;
    check_velocity(cell, cloud);
  }
  cell->v_flag_clouds[cloud] += 1.0;
}

static void wind_motion(grid *g, grid_cell *cell, unsigned int cloud,
                         const motion_parameters *parameters) {
  double vth = cloud_thermal_speed(cell, cloud);
  double relative[3];
  double radius = cloud_radius(g, cell, cloud, relative);
  if (radius < parameters->inner_radius || radius > parameters->outer_radius)
    return;
  double beta = radius / parameters->inner_radius;
  double energy = (1.0 - pow(beta, 1.0 - parameters->alpha)) *
                    parameters->ratio - log(beta);
  if (energy < 0.0)
    energy = 0.0;
  double speed = parameters->speed * sqrt(energy);
  if (!isfinite(speed))
    motion_error("wind parameters produce a nonfinite speed");
  check_velocity(cell, cloud);
  /* Project the radius-dependent wind speed onto the Cartesian axes. */
  for (int axis = 0; axis < 3; axis++)
    cell->vel_clouds[cloud][axis] += speed / vth * relative[axis] / radius;
  check_velocity(cell, cloud);
}

void add_clouds_velocity(grid *g, int mode, double *params) {
  const double centimeters_per_kilometer = 1e5;
  motion_parameters parameters = {0};
  motion_function apply = NULL;
  if (mode == CLOUD_MOTION_NONE)
    return;
  if (mode != CLOUD_MOTION_RADIAL && mode != CLOUD_MOTION_GAUSSIAN &&
      mode != CLOUD_MOTION_WIND) {
    print_error("Unsupported cloud motion mode %d; use NONE=%d, RADIAL=%d, "
                "GAUSSIAN=%d or WIND=%d.", mode, CLOUD_MOTION_NONE,
                CLOUD_MOTION_RADIAL, CLOUD_MOTION_GAUSSIAN, CLOUD_MOTION_WIND);
    exit(EXIT_FAILURE);
  }
  if (params == NULL || !isfinite(params[0]))
    motion_error("velocity parameter must be finite in km/s");
  parameters.speed = params[0] * centimeters_per_kilometer;
  if (!isfinite(parameters.speed))
    motion_error("velocity exceeds the supported numeric range");
  switch (mode) {
  case CLOUD_MOTION_RADIAL:
    apply = radial_motion;
    break;
  case CLOUD_MOTION_GAUSSIAN:
    if (params[0] < 0.0)
      motion_error("Gaussian dispersion must be nonnegative");
#ifndef PEACOCK_PAIRED_CATALOGUE
    if (params[0] == 0.0) return;
#endif
    /* In a paired population, zero sigma advances flags without drawing. */
    apply = gaussian_motion;
    break;
  case CLOUD_MOTION_WIND:
    if (!isfinite(params[1]) || params[1] < 0.0 || !isfinite(params[2]) ||
        !isfinite(params[3]) || !isfinite(params[4]) || !(params[3] > 0.0) ||
        params[4] < params[3])
      motion_error("wind needs finite R>=0, alpha and 0<Rmin<=Rmax in pc");
    parameters.ratio = params[1];
    parameters.alpha = params[2];
    parameters.inner_radius = params[3] * PARSEC;
    parameters.outer_radius = params[4] * PARSEC;
    if (!isfinite(parameters.inner_radius) ||
        !isfinite(parameters.outer_radius) || parameters.inner_radius == 0.0)
      motion_error("wind radii exceed the supported numeric range");
    apply = wind_motion;
    break;
  default:
    motion_error("unsupported motion mode");
  }
  if (g == NULL || g->cells == NULL ||
      g->ncells[0] <= 0 || g->ncells[1] <= 0 || g->ncells[2] <= 0)
    motion_error("grid must have positive dimensions and allocated cells");
  /* Apply the selected velocity law to each cloud in cell order. */
  for (int i = 0; i < g->ncells[0]; i++) {
    if (g->cells[i] == NULL) motion_error("missing grid row");
    for (int j = 0; j < g->ncells[1]; j++) {
      if (g->cells[i][j] == NULL) motion_error("missing grid cells");
      for (int k = 0; k < g->ncells[2]; k++) {
        grid_cell *cell = &g->cells[i][j][k];
        for (unsigned int cloud = 0; cloud < cell->nclouds; cloud++)
          apply(g, cell, cloud, &parameters);
      }
    }
  }
}
#endif /* CELL_CLOUDS */
