/**
  @file grid.h
  
  Main grid file. Functions are switches to check TLAC_GRID (or
  grid->grid_type in case of TLAC_GRID == GRID_VARIABLE) and calls
  function in apropriate file in `grids` directory.
                                                                   
  Functions include: - Grid creation/freeing - Finding grid cells -
  Setting gid values

 **/

#ifndef _GRID_H_
#define _GRID_H_

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include "tlac_defs.h"

typedef struct observer_s observer;
typedef struct grid_s grid;

typedef struct grid_cell_s {
  // Note that 3D arrays are (x,y,z) in cartesian and (r, theta, phi) in
  // spherical coordinate system.
  double L;                    // Luminosity in rel units
  double T;                    // Temperature in K
  double n_HI;                 // Absorber density in cm^-3 (n1 for populated atoms)
  double n_D;                  // Dust density in 1/ccm
  double pos[3];               // Position of center of cell in cm (cartesian)
                               // or (cm, rad, rad) in spherical grid
  double vel[3];               // velocity in units of the selected atom's thermal speed
  double* size;                // Cellsize in units mentioned above for `pos`
  struct grid_cell_s *nbs[6];  // Pointer to neighboring cells:
                               // 0 (1) towards neg. (pos.) direction along x
                               // 2 (3) towards neg. (pos.) direction along y ..
                               // points to NULL at domain border

#ifdef CELL_CLOUDS
  unsigned int nclouds;
  double **pos_clouds; // array of (3d) positions of clouds --> always in (x,y,z)
  double **vel_clouds; // same with cloud velocity (in v_th)
  double *v_flag_clouds;
  grid **cloud_grids;  // array of pointer to cloud grids
#endif
} grid_cell;

struct grid_s {
  int type;                    // For variable grid, is one of TLAC_GRID
  int uniform;                 // Is grid uniform?
  int ncells[3];               // Number of cells per dimension.
  double boxsize[3];           // Boxsize in units mentioned above for `pos`
  double L_tot;                // Total luminosity of grid
  double center[3];            // Center of grid

  grid_cell ***cells;

  // Observer related
  int nobservers;
  observer *observers;
};

#include "grids/grid_cart.h"
#include "grids/grid_spherical.h"

/*************************************************************************//**
 * create_grid
 * 
 * Creates grid.
 * 
 * @param grid_type Can be of GRID_SPHERICAL or GRID_CARTESIAN
 * @param size[3/1] Size in cm (array of x,y,z or radius).
 * @param ncells[3] Number of cells in each dimension
 * @param cell_placement_mode   Decides how cells are placed (so far only
 * uniform).
 * 
 * @return Pointer to grid.
 *****************************************************************************/
grid* create_grid(const int grid_type, double* size, int* ncells,
                  int cell_placement_mode);

/****************************************//**
 * free_grid
 *                     
 * Frees memory of grid
 ********************************************/
void free_grid(grid *g);

/*****************************************************//**
 * get_total_luminosity
 *                                                   
 * Recalculate and store the sum of cell luminosities.
 *                                                   
 * \return Sum over all individual cell luminosities
 *                                                   
 * \param g grid struct
 *********************************************************/
double get_total_luminosity(grid *g);

/********************************************************//**
 * pick_random_cell
 *                                                      
 * Return a cell weighted by luminosity. Pass NULL to release the thread's sampler.
 ************************************************************/
grid_cell *pick_random_cell(grid *g);

/*********************************************************************//**
 * find_grid_cell
 *                                                               
 * Given a grid and a position, the function returns a pointer to the
 * cell containing the position. If nothing is found, NULL is
 * returned.
 *************************************************************************/
grid_cell* find_grid_cell(grid *g, double pos[]);

/*********************************************************************//**
 * get_random_pos_in_cell
 *                                                              
 * Given a cell it calculates a random (uniform) position in the cell
 * and returns the result to the pointer given.
 *************************************************************************/
void get_random_pos_in_cell(grid_cell* c, grid* g, double ret_pos[]);

/****************************************************//**
 * is_pos_in_grid
 *                                                  
 * Checks if position is on grid. Returns 1 if true;
 ********************************************************/
int is_pos_in_grid(double *pos, grid *g);

/****************************************************//**
 * is_pos_in_cell
 *                                                  
 * Checks if position is on cell. Returns 1 if true;
 ********************************************************/
int is_pos_in_cell(double *pos, grid_cell *c, grid *g);

/*********************************************************************//**
 * get_next_cell
 *                                                               
 * Given a cell, a position, a direction and a distance to travel
 * (cell, pos, dir, r), the functon calculates the cell in this
 * directiond and the intersection of the wall and the path. position
 * (new_cell, intersection). Also, the distance to the intersection
 * point `dist` is returned.
 *                                                               
 * Return code is status which wall was crossed: 1 = x+ (wall in
 * positive x direction) 2 = y+ 3 = z+ -1 = x- ...
 *************************************************************************/
int get_next_cell(grid *grid, grid_cell *cell, double pos[], 
                       double dir[], grid_cell **new_cell, 
                       double intersection[], double* dist);

/********************************************************************//**
 * cell_velocity_scalar_product
 *                                                                  
 * Calculates scalar product between `vec` and velocity of grid cell
 * `c`. Returns result (at position `pos`).
 ************************************************************************/
double cell_velocity_scalar_product(grid_cell *c, double vec[], double pos[],
                                    grid *g);

/*****************************************************//**
 * set_grid_values
 *                                                   
 * Set values, n_HI, n_D, T,... to all cells in grid.
 *********************************************************/
 void set_grid_values(grid *g, const double n_HI, const double n_D,
                      const double T, const double L);

/*******************************************************************//**
 * set_grid_values_ring
 * 
 * Set grid values n_HI, n_D, ... to all cells with center in Rmin,
 * Rmax from center.
 * Note: A negative value means the parameter is left unchanged
 * (except for v, there nan has the same effect)
 * 
 * @param v  Out- (>0) or inflowing (<0) velocity (spherically symmetric).
 * 
 * @return Number of cells filled.
 ***********************************************************************/
int set_grid_values_ring(grid *g, const double Rin, const double Rout,
                         const double n_HI, const double n_D,
                         const double T, const double L,
                         const double v);

/**********************************************************************//**
 * set_grid_linear_velocity
 * 
 * Sets linear velocity for dimension `dim` between `Rmin` & `Rmax`
 * (from center) Velocity is scaled from `vmin` to `vmax`. Expects all
 * in cgs.
 * 
 * Can be used, e.g., for plane-parallel outflow in slab.
 * 
 * Returns number of cells filled.
 **************************************************************************/
int set_grid_linear_velocity(grid *g, int dim, double Rmin, double Rmax,
                             double vmin, double vmax);

/*
  set_grid_values_bicone

  Set values in grid in bicone with half-opening angle alpha
  Return number of cells filled.

  Alpha in radians.
*/
int set_grid_values_bicone(grid *g, double alpha,
                           double n_HI, double n_D, double T, double L,
                           double vz);

/********************************************************************//**
 * Checks grid `g` for constistency and throws error if something is
 * fishy...
 ************************************************************************/
void check_grid(grid *g);

/* ------------------------------------------------------------ */
/**
   Prints info about cell `c` (and neighbors)
**/
void print_cell(grid_cell *c, grid *g);

/* ------------------------------------------------------------ */

/**********************************************************************//**
 * get_pos_dist_from_center
 *                                                          
 * Calculates a random position which is `d` from the center of the
 * grid `g` and returns it to `ret_pos`.
 **************************************************************************/
void get_pos_dist_from_center(grid *g, double d, double ret_pos[]);

/* ------------------------------------------------------------ */
/**
   Returns closest distance to next wall.

   @param *g    -- Grid of cell
   @param *c    -- Cell
   @param pos[] -- Position from which to calculate.
   
   @return Distance to next wall in cm.
**/
double get_dist_to_wall(grid *g, grid_cell *c, double pos[]);

/* Contiguous cell storage shared by the Cartesian and spherical constructors. */
grid_cell ***allocate_grid_cells(int nx, int ny, int nz);

#endif /* _GRID_H_ */
