#include "scalar_atom.h"

#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

peacock_scalar_atom peacock_atom;

enum { ATOM_TOKEN_CAPACITY = 64 };

/* Return 1 for a complete token, 0 for EOF, and -1 for invalid input. */
static int read_token(FILE *file, char token[ATOM_TOKEN_CAPACITY]) {
  int next;
  do {
    next = fgetc(file);
  } while (next != EOF && isspace((unsigned char)next));
  if (next == EOF)
    return ferror(file) ? -1 : 0;

  size_t count = 0;
  do {
    if (count == ATOM_TOKEN_CAPACITY - 1 || next == '\0')
      return -1;
    token[count++] = (char)next;
    next = fgetc(file);
  } while (next != EOF && !isspace((unsigned char)next));
  token[count] = '\0';
  return ferror(file) ? -1 : 1;
}

static int read_values(FILE *file, double **fields, size_t count) {
  char token[ATOM_TOKEN_CAPACITY];
  for (size_t i = 0; i < count; i++) {
    if (read_token(file, token) != 1)
      return 0;
    char *end;
    errno = 0;
    const double value = strtod(token, &end);
    if (end == token || *end != '\0' || errno == ERANGE || !isfinite(value))
      return 0;
    *fields[i] = value;
  }
  return read_token(file, token) == 0;
}

static int atom_error(const char *path, const char *message) {
  fprintf(stderr, "PEACOCK atomic data %s: %s\n", path ? path : "(no path)", message);
  return 1;
}

int peacock_load_atom(const char *path) {
  if (path == NULL || *path == '\0')
    return atom_error(path, "select an atomic data file");
  FILE *file = fopen(path, "rb");
  if (file == NULL)
    return atom_error(path, strerror(errno));

  char format[ATOM_TOKEN_CAPACITY], operator_name[ATOM_TOKEN_CAPACITY], line[ATOM_TOKEN_CAPACITY];
  if (read_token(file, format) != 1 || strcmp(format, "PEACOCK_ATOM_V1") != 0 ||
      read_token(file, operator_name) != 1 || read_token(file, line) != 1) {
    fclose(file);
    return atom_error(path, "expected PEACOCK_ATOM_V1 followed by the operator and line");
  }

  peacock_scalar_atom atom = {0};
#if !defined(PEACOCK_ATOM_RESONANT)
  const double two_pi = 2.0 * 3.14159265358979323846;
#endif
  /* Numeric fields follow the header in the exact order listed here.
   * Wavenumbers are cm^-1, rates s^-1, frequencies and widths Hz, mass g. */
#if defined(PEACOCK_ATOM_RESONANT)
  const int valid_header = strcmp(operator_name, "resonant") == 0 && strcmp(line, "lya") == 0;
  double *fields[] = {&atom.mass_g, &atom.f12, &atom.nu0, &atom.natural_width};
#elif defined(PEACOCK_ATOM_FINE_STRUCTURE)
  const int valid_header = strcmp(operator_name, "fine_structure") == 0 && strcmp(line, "cii") == 0;
  double *fields[] = {&atom.mass_g, &atom.e1, &atom.e2, &atom.e3, &atom.e4,
                      &atom.f13, &atom.f23, &atom.f24, &atom.a31, &atom.a32, &atom.a42};
#else
  if (strcmp(line, "civ") == 0)
    atom.ion_name = "CIV";
  else if (strcmp(line, "mgii") == 0)
    atom.ion_name = "MgII";
  const int valid_header = strcmp(operator_name, "doublet") == 0 && atom.ion_name != NULL;
  double *fields[] = {&atom.mass_g, &atom.e_blue, &atom.e_red, &atom.f_blue, &atom.f_red,
                      &atom.gamma_blue, &atom.gamma_red};
#endif
  const int valid_values = valid_header && read_values(file, fields, sizeof(fields) / sizeof(*fields));
  const int close_status = fclose(file);
  if (!valid_header)
    return atom_error(path, "the operator and line do not match this scattering implementation");
  if (!valid_values || close_status != 0)
    return atom_error(path, "expected exactly the prescribed finite numeric fields");
  if (!(atom.mass_g > 0))
    return atom_error(path, "atomic mass must be positive");

#if defined(PEACOCK_ATOM_RESONANT)
  if (!(atom.f12 > 0 && atom.nu0 > 0 && atom.natural_width > 0))
    return atom_error(path, "oscillator strength, reference frequency and natural width must be positive");
#elif defined(PEACOCK_ATOM_FINE_STRUCTURE)
  if (!(atom.e1 < atom.e2 && atom.e2 < atom.e4 && atom.e4 < atom.e3 &&
        atom.f13 > 0 && atom.f23 > 0 && atom.f24 > 0 &&
        atom.a31 > 0 && atom.a32 > 0 && atom.a42 > 0))
    return atom_error(path, "invalid C II level ordering, oscillator strength or decay rate");
  atom.nu13 = LIGHT_SPEED * (atom.e3 - atom.e1);
  atom.nu23 = LIGHT_SPEED * (atom.e3 - atom.e2);
  atom.nu24 = LIGHT_SPEED * (atom.e4 - atom.e2);
  atom.fine_structure_nu = LIGHT_SPEED * (atom.e2 - atom.e1);
  atom.nu13_minus_nu24 = atom.nu13 - atom.nu24;
  atom.width13 = (atom.a31 + atom.a32) / two_pi;
  atom.width24 = atom.a42 / two_pi;
  if (!(isfinite(atom.nu13) && atom.nu13 > atom.nu23 && atom.nu23 > atom.nu24 &&
        atom.nu24 > 0 && atom.fine_structure_nu > 0 && isfinite(atom.width13) &&
        atom.width13 > 0 && atom.width24 > 0))
    return atom_error(path, "derived C II frequencies or widths are out of range");
#else
  if (!(atom.e_blue > atom.e_red && atom.e_red > 0 &&
        atom.f_blue > 0 && atom.f_red > 0 && atom.gamma_blue > 0 && atom.gamma_red > 0))
    return atom_error(path, "invalid doublet wavenumber ordering, oscillator strength or decay rate");
  atom.nu_blue = LINE_LIGHT_SPEED * atom.e_blue;
  atom.nu_red = LINE_LIGHT_SPEED * atom.e_red;
  atom.delta_nu = atom.nu_blue - atom.nu_red;
  atom.natural_width = atom.gamma_blue / two_pi;
  if (!(isfinite(atom.nu_blue) && atom.nu_blue > atom.nu_red &&
        atom.nu_red > 0 && atom.natural_width > 0))
    return atom_error(path, "derived doublet frequencies or width are out of range");
#endif
  peacock_atom = atom;
  return 0;
}
