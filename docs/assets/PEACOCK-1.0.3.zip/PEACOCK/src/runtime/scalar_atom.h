/* Runtime atomic data for the scalar scattering operators. The compiler
 * force-includes this header after any operator namespace definitions. */
#ifndef PEACOCK_RUNTIME_SCALAR_ATOM_H
#define PEACOCK_RUNTIME_SCALAR_ATOM_H

#if (defined(PEACOCK_ATOM_RESONANT) + defined(PEACOCK_ATOM_FINE_STRUCTURE) + \
     defined(PEACOCK_ATOM_DOUBLET)) != 1
#error Select one scalar scattering operator for the runtime atom.
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Read the native declarations and common constants before replacing the
 * operator's compile-time atom macros. Its include guard also covers later
 * includes in C++ exporter translation units. */
#include "physical_properties.h"

typedef struct {
  double mass_g;
#if defined(PEACOCK_ATOM_RESONANT)
  double f12, nu0, natural_width;
#elif defined(PEACOCK_ATOM_FINE_STRUCTURE)
  double e1, e2, e3, e4;
  double f13, f23, f24;
  double a31, a32, a42;
  double nu13, nu23, nu24, fine_structure_nu, nu13_minus_nu24;
  double width13, width24;
#else
  double e_blue, e_red, f_blue, f_red, gamma_blue, gamma_red;
  double nu_blue, nu_red, delta_nu, natural_width;
  const char *ion_name;
#endif
} peacock_scalar_atom;

extern peacock_scalar_atom peacock_atom;

/* Select the atom before reading the simulation configuration or starting
 * worker threads. On error, the previous atom stays intact. */
int peacock_load_atom(const char *path);

#ifdef __cplusplus
}
#endif

#undef HYDROGEN_MASS
#define HYDROGEN_MASS (peacock_atom.mass_g)

#if defined(PEACOCK_ATOM_RESONANT)
#undef LYA_F12
#undef LYA_NU0
#undef LYA_DELTA_NU_L
#define LYA_F12 (peacock_atom.f12)
#define LYA_NU0 (peacock_atom.nu0)
#define LYA_DELTA_NU_L (peacock_atom.natural_width)

#elif defined(PEACOCK_ATOM_FINE_STRUCTURE)
#undef CII_E1
#undef CII_E2
#undef CII_E3
#undef CII_E4
#undef CII_NU13
#undef CII_NU23
#undef CII_NU24
#undef CII_FINE_STRUCTURE_NU
#undef LYA_F1
#undef LYA_F2
#undef LYA_F3
#undef CII_A31
#undef CII_A32
#undef CII_A42
#undef LYA_DELTA_NU_L_1
#undef LYA_DELTA_NU_L_3
#undef DELTA_NU_13
#define CII_E1 (peacock_atom.e1)
#define CII_E2 (peacock_atom.e2)
#define CII_E3 (peacock_atom.e3)
#define CII_E4 (peacock_atom.e4)
#define CII_NU13 (peacock_atom.nu13)
#define CII_NU23 (peacock_atom.nu23)
#define CII_NU24 (peacock_atom.nu24)
#define CII_FINE_STRUCTURE_NU (peacock_atom.fine_structure_nu)
#define LYA_F1 (peacock_atom.f13)
#define LYA_F2 (peacock_atom.f23)
#define LYA_F3 (peacock_atom.f24)
#define CII_A31 (peacock_atom.a31)
#define CII_A32 (peacock_atom.a32)
#define CII_A42 (peacock_atom.a42)
#define LYA_DELTA_NU_L_1 (peacock_atom.width13)
#define LYA_DELTA_NU_L_3 (peacock_atom.width24)
#define DELTA_NU_13 (peacock_atom.nu13_minus_nu24)

#else
#undef LINE_ATOM_MASS
#undef LINE_E_BLUE
#undef LINE_E_RED
#undef LINE_F_BLUE
#undef LINE_F_RED
#undef LINE_GAMMA_BLUE
#undef LINE_GAMMA_RED
#undef LINE_NU_BLUE
#undef LINE_NU_RED
#undef LINE_DELTA_NU
#undef LINE_ION_NAME
#undef LYA_DELTA_NU_L
#define LINE_ATOM_MASS (peacock_atom.mass_g)
#define LINE_E_BLUE (peacock_atom.e_blue)
#define LINE_E_RED (peacock_atom.e_red)
#define LINE_F_BLUE (peacock_atom.f_blue)
#define LINE_F_RED (peacock_atom.f_red)
#define LINE_GAMMA_BLUE (peacock_atom.gamma_blue)
#define LINE_GAMMA_RED (peacock_atom.gamma_red)
#define LINE_NU_BLUE (peacock_atom.nu_blue)
#define LINE_NU_RED (peacock_atom.nu_red)
#define LINE_DELTA_NU (peacock_atom.delta_nu)
#define LINE_ION_NAME (peacock_atom.ion_name)
#define LYA_DELTA_NU_L (peacock_atom.natural_width)
#endif

#endif
