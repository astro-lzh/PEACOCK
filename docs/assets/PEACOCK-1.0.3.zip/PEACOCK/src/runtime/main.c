/* Select the atom and a linked operator before initializing native transport. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define OPERATOR(name) \
  int pc_##name##_peacock_load_atom(const char *path); \
  int pc_##name##_main(int argc, char **argv)

OPERATOR(resonant);
OPERATOR(fine_structure);
OPERATOR(multilevel);
#ifdef PEACOCK_EXPORTER
OPERATOR(doublet);
#endif

typedef struct {
  const char *name;
  int (*load_atom)(const char *path);
  int (*run)(int argc, char **argv);
} Operator;

#define ENTRY(name) {#name, pc_##name##_peacock_load_atom, pc_##name##_main}

static const Operator operators[] = {
  ENTRY(resonant), ENTRY(fine_structure), ENTRY(multilevel),
#ifdef PEACOCK_EXPORTER
  ENTRY(doublet),
#endif
};

static const struct {
  const char *line;
  const char *operator_name;
} line_registry[] = {
#include "line_registry.inc"
};

int main(int argc, char **argv) {
  if (argc < 6 || strcmp(argv[1], "--line") || strcmp(argv[3], "--atom")) {
    fprintf(stderr, "Usage: %s --line ID --atom ATOM_FILE CONFIG [TEMPLATE_VALUE ...]\n", argv[0]);
    return EXIT_FAILURE;
  }
  const char *requested_line = argv[2];
  const char *atom_path = argv[4];
  const char *expected_operator = NULL;
  for (size_t i = 0; i < sizeof(line_registry) / sizeof(line_registry[0]); i++) {
    if (strcmp(line_registry[i].line, requested_line) == 0) {
      expected_operator = line_registry[i].operator_name;
      break;
    }
  }
  if (!expected_operator) {
    fprintf(stderr, "Line %s is unavailable in this backend\n", requested_line);
    return EXIT_FAILURE;
  }
  FILE *file = fopen(atom_path, "r");
  if (!file) {
    perror(atom_path);
    return EXIT_FAILURE;
  }
  char signature[32], operator_name[32], line[64];
  int fields = fscanf(file, "%31s %31s %63s", signature, operator_name, line);
  fclose(file);
  if (fields != 3 || strcmp(signature, "PEACOCK_ATOM_V1") || strcmp(line, requested_line) ||
      strcmp(operator_name, expected_operator)) {
    fprintf(stderr, "Atomic table identity differs from --line %s\n", requested_line);
    return EXIT_FAILURE;
  }
  for (size_t i = 0; i < sizeof(operators) / sizeof(operators[0]); i++) {
    const Operator *selected = &operators[i];
    if (strcmp(selected->name, operator_name)) continue;
    if (selected->load_atom(atom_path) != 0) return EXIT_FAILURE;
    /* The linked entry expects argv[0] followed by the native configuration. */
    argv[4] = argv[0];
    return selected->run(argc - 4, argv + 4);
  }
  fprintf(stderr, "Operator %s is unavailable in this backend\n", operator_name);
  return EXIT_FAILURE;
}
