#define _DARWIN_C_SOURCE 1
#define _POSIX_C_SOURCE 200809L
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_rng.h>

#include "clouds.h"
#include "config/process_config.h"
#include "grid.h"
#include "io/i_grid_ascii.h"
#include "io/o_grid.h"
#include "misc/rand_tools.h"
#include "physical_properties.h"
#ifdef USE_HDF5
#include "io/i_grid_hdf5.h"
#endif

#define CHECK(condition) do { \
  if(!(condition)) { \
    fprintf(stderr, "Regression failed at %s:%d: %s\n", __FILE__, __LINE__, #condition); \
    exit(EXIT_FAILURE); \
  } \
} while(0)

static void check_poisson(void) {
  const double means[] = {0.5, 4, 20};
  const int samples = 8192;
  for(size_t j = 0; j < sizeof(means) / sizeof(means[0]); j++) {
    double sum = 0, squares = 0;
    const unsigned long seed = 20261105 + j;
    gsl_rng *reference = gsl_rng_alloc(gsl_rng_taus2);
    CHECK(reference != NULL);
    gsl_rng_set(reference, seed);
    init_rand_tools(seed);
    for(int i = 0; i < samples; i++) {
      double draw = rand_poisson(means[j]);
      CHECK(draw >= 0 && draw == floor(draw));
      CHECK(draw == gsl_ran_poisson(reference, means[j]));
      sum += draw;
      squares += draw * draw;
    }
    double mean = sum / samples;
    double variance = squares / samples - mean * mean;
    CHECK(fabs(mean - means[j]) < 8 * sqrt(means[j] / samples));
    CHECK(fabs(variance - means[j]) < 8 * sqrt((means[j] + 2 * means[j] * means[j]) / samples));
    cleanup_rand_tools();
    gsl_rng_free(reference);
  }
}

static void check_empty_cells(grid *g) {
  for(int i = 0; i < g->ncells[0]; i++) {
    for(int j = 0; j < g->ncells[1]; j++) {
      for(int k = 0; k < g->ncells[2]; k++) {
        grid_cell *c = &g->cells[i][j][k];
        CHECK(c->T == 1e4 && c->L == 0 && c->n_HI == 0 && c->n_D == 0);
        CHECK(c->vel[0] == 0 && c->vel[1] == 0 && c->vel[2] == 0);
        CHECK(c->nclouds == 0 && c->pos_clouds == NULL && c->vel_clouds == NULL);
        CHECK(c->v_flag_clouds == NULL && c->cloud_grids == NULL);
      }
    }
  }
}

static void check_ascii_grid(const char *directory, grid **clouds) {
  char current[1024], legacy[1024];
  CHECK(snprintf(current, sizeof(current), "%s/current.dat", directory) < (int)sizeof(current));
  CHECK(snprintf(legacy, sizeof(legacy), "%s/legacy.dat", directory) < (int)sizeof(legacy));
  grid *g = create_spherical_grid(1000 * PARSEC, 1, 1, 1);
  grid_cell *cell = &g->cells[0][0][0];
  double pos[3] = {100 * PARSEC, 0, 0};
  CHECK(create_cloud_in_cell(g, clouds[1], cell, pos, 0) == 1);
  cell->v_flag_clouds[0] = 2;
  pos[0] = -100 * PARSEC;
  CHECK(create_cloud_in_cell(g, clouds[1], cell, pos, 0) == 1);
  cell->v_flag_clouds[1] = 1;
  o_grid(current, g, "grid import regression");
  grid *loaded = i_grid_ascii_defined_clouds(current, 2, clouds);
  CHECK(loaded->cells[0][0][0].nclouds == 2);
  CHECK(loaded->cells[0][0][0].cloud_grids[0] == clouds[1]);
  CHECK(loaded->cells[0][0][0].v_flag_clouds[0] == 2);
  CHECK(loaded->cells[0][0][0].v_flag_clouds[1] == 1);
  free_grid(loaded);

  FILE *input = fopen(current, "r"), *output = fopen(legacy, "w");
  CHECK(input != NULL && output != NULL);
  char line[2048];
  int in_clouds = 0;
  while(fgets(line, sizeof(line), input)) {
    if(strstr(line, "### END CLOUD_DATA")) in_clouds = 0;
    if(in_clouds) {
      double values[8];
      CHECK(sscanf(line, "%le %le %le %le %le %le %le %le", &values[0], &values[1],
                   &values[2], &values[3], &values[4], &values[5], &values[6], &values[7]) == 8);
      CHECK(fprintf(output, "%.17g %.17g %.17g %.17g %.17g %.17g %.17g\n",
                    values[0], values[1], values[2], values[3], values[4], values[5], values[6]) > 0);
    } else {
      CHECK(fputs(line, output) >= 0);
    }
    if(strstr(line, "### START CLOUD_DATA")) in_clouds = 1;
  }
  CHECK(fclose(input) == 0 && fclose(output) == 0);
  loaded = i_grid_ascii_defined_clouds(legacy, 2, clouds);
  CHECK(loaded->cells[0][0][0].nclouds == 2);
  CHECK(loaded->cells[0][0][0].cloud_grids[0] == clouds[1]);
  CHECK(loaded->cells[0][0][0].v_flag_clouds[0] == 0);
  CHECK(loaded->cells[0][0][0].v_flag_clouds[1] == 0);
  free_grid(loaded);
  free_grid(g);
  CHECK(unlink(current) == 0 && unlink(legacy) == 0);
}

#ifdef USE_HDF5
static void write_dataset(hid_t file, const char *name, int rank, const hsize_t *dims,
                          const double *values) {
  hid_t space = H5Screate_simple(rank, dims, NULL);
  hid_t dataset = H5Dcreate2(file, name, H5T_NATIVE_DOUBLE, space,
                            H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
  CHECK(space >= 0 && dataset >= 0);
  CHECK(H5Dwrite(dataset, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, values) >= 0);
  CHECK(H5Dclose(dataset) >= 0 && H5Sclose(space) >= 0);
}

static void check_hdf5_grid(const char *directory, grid **clouds) {
  char filename[1024];
  CHECK(snprintf(filename, sizeof(filename), "%s/legacy.h5", directory) < (int)sizeof(filename));
  hid_t file = H5Fcreate(filename, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);
  CHECK(file >= 0);
  hid_t group = H5Gcreate2(file, "/cloud_data", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
  CHECK(group >= 0 && H5Gclose(group) >= 0);
  const hsize_t one[1] = {2}, three[2] = {2, 3};
  const double radii[2] = {10 * PARSEC, 10 * PARSEC};
  const double positions[6] = {100 * PARSEC, 0, 0, -100 * PARSEC, 0, 0};
  const double velocities[6] = {0, 0, 0, 0, 0, 0};
  write_dataset(file, "/cloud_data/size", 1, one, radii);
  write_dataset(file, "/cloud_data/pos", 2, three, positions);
  write_dataset(file, "/cloud_data/vel", 2, three, velocities);
  grid *g = create_spherical_grid(1000 * PARSEC, 1, 1, 1);
  g->cells[0][0][0].nclouds = 2;
  i_grid_hdf5_read_cloud_data(file, g, 2, clouds);
  CHECK(g->cells[0][0][0].nclouds == 2);
  CHECK(g->cells[0][0][0].cloud_grids[0] == clouds[1]);
  CHECK(g->cells[0][0][0].v_flag_clouds[0] == 0);
  CHECK(g->cells[0][0][0].v_flag_clouds[1] == 0);
  free_grid(g);
  g = create_spherical_grid(1000 * PARSEC, 1, 1, 1);
  i_grid_hdf5_read_cloud_data(file, g, 0, NULL);
  check_empty_cells(g);
  free_grid(g);
  CHECK(H5Fclose(file) >= 0 && unlink(filename) == 0);
}
#endif

int main(int argc, char **argv) {
  CHECK(argc == 2);
  if(strcmp(argv[1], "rng") == 0) {
    check_poisson();
    puts("Poisson integer, mean, variance and fixed-seed GSL checks passed.");
    return EXIT_SUCCESS;
  }
  CHECK(strcmp(argv[1], "io") == 0);
  grid *cartesian = create_uniform_grid(2000 * PARSEC, 2000 * PARSEC, 2000 * PARSEC, 2, 2, 2);
  grid *spherical = create_spherical_grid(1000 * PARSEC, 2, 1, 1);
  check_empty_cells(cartesian);
  check_empty_cells(spherical);
  free_grid(cartesian);
  free_grid(spherical);
  grid *clouds[2] = {create_spherical_grid(20 * PARSEC, 1, 1, 1),
                     create_spherical_grid(10 * PARSEC, 1, 1, 1)};
  char directory[] = "/tmp/peacock-grid-regression-XXXXXX";
  CHECK(mkdtemp(directory) != NULL);
  check_ascii_grid(directory, clouds);
#ifdef USE_HDF5
  check_hdf5_grid(directory, clouds);
#endif
  free_grid(clouds[0]);
  free_grid(clouds[1]);
  CHECK(rmdir(directory) == 0);
  for(int repeat = 0; repeat < 2; repeat++) {
    grid *cloud = create_spherical_grid(10 * PARSEC, 1, 1, 1);
    CHECK(cfg_lookup_cloud("cloud_cache_test", cloud) == cloud);
    CHECK(cfg_lookup_cloud("cloud_cache_test", NULL) == cloud);
    CHECK(cfg_lookup_cloud(NULL, NULL) == NULL);
  }
  CHECK(cfg_lookup_cloud(NULL, NULL) == NULL);
  puts("Empty-grid initialization and legacy/current grid imports passed.");
  return EXIT_SUCCESS;
}
