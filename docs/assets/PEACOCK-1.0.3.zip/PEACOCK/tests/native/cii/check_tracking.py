#!/usr/bin/env python3
"""Verify explicit tracking, clean defaults, preserved packets and protected files."""
import configparser
from pathlib import Path
import os
import subprocess
import sys
import tempfile
executable, template = map(lambda x: Path(x).resolve(), sys.argv[1:3])
with tempfile.TemporaryDirectory(prefix='peacock-tracking-') as temp:
    root = Path(temp)
    config = configparser.ConfigParser(interpolation=None)
    config.read(template)
    config['run']['filename_prefix'] = '<0>'
    config['run']['nphot'] = '64'
    config['run']['nphot_uv'] = '0'
    for key in list(config['grid']):
        if key.startswith('cloud'): del config['grid'][key]
    if 'cloud1' in config: config.remove_section('cloud1')
    config['grid']['hydrogen'] = 'n 0'
    config['grid']['dust'] = 'n 0'
    config['output']['lya'] = 'ASCII_LYA'
    sentinel = root/'track_photons.dat'
    sentinel.write_text('existing user data\n')
    def run(label):
        path = root/f'{label}.cfg'
        with path.open('w') as handle: config.write(handle)
        result = subprocess.run([str(executable),str(path),label+'_'],cwd=root,
                                env=dict(os.environ,OMP_NUM_THREADS='1'),
                                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20)
        (root/f'{label}.log').write_bytes(result.stdout)
        return result
    baseline=run('default')
    assert baseline.returncode == 0, baseline.stdout.decode()
    assert sentinel.read_text() == 'existing user data\n'
    assert not list(root.glob('*.tracks.dat'))
    config['output']['track_photons']='true'
    tracked=run('tracked')
    assert tracked.returncode == 0, tracked.stdout.decode()
    histories=list(root.glob('tracked_*.tracks.dat'))
    assert len(histories)==1 and histories[0].stat().st_size>0
    def packets(label):
        paths=[p for p in root.glob(label+'_*.dat') if '.tracks.' not in p.name]
        assert len(paths)==1, paths
        return [line for line in paths[0].read_text().splitlines() if line and not line.startswith('#')]
    assert packets('default') == packets('tracked'), 'Tracking changed escaped packet rows'
    custom=root/'chosen.tracks'
    config['output']['track_output']=str(custom)
    config['run']['nphot_uv']='8'
    explicit=run('explicit')
    assert explicit.returncode==0, explicit.stdout.decode()
    assert custom.is_file() and Path(str(custom)+'.uv').is_file()
    original=custom.read_bytes()
    collision=run('collision')
    assert collision.returncode!=0, 'Existing tracking path was accepted'
    assert custom.read_bytes()==original
    assert sentinel.read_text()=='existing user data\n'
print('Clean defaults, explicit history paths, separate UV histories, non-overwrite and exact packet equality passed.')
