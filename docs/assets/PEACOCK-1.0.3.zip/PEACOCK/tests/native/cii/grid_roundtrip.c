#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "clouds.h"
#include "config/process_config.h"
#include "grid.h"
#include "grids/grid_cart.h"
#include "grids/grid_spherical.h"
#include "io/i_grid.h"
#include "io/o_grid.h"

static void require(int condition, const char *message) {
  if (!condition) {
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
  }
}

static void check_restored(grid *restored, int legacy) {
  grid_cell *cell = &restored->cells[0][0][0];
  require(cell->nclouds == 2, "Cloud count changed during ASCII roundtrip.");
  for (int i = 0; i < 2; i++) {
    require(fabs(cell->cloud_grids[i]->boxsize[0] - (i ? 100 : 50)) < 1e-5,
            "Wrong cloud radius restored.");
    require(cell->v_flag_clouds[i] == (legacy ? 0 : i + 1),
            "Wrong legacy/current cloud velocity flag.");
    for (int j = 0; j < 3; j++) {
      require(cell->pos_clouds[i][j] == (i ? 750 : 250), "Cloud position changed.");
      require(cell->vel_clouds[i][j] == 10 * i + j, "Cloud velocity changed.");
    }
  }
}

int main(int argc, char **argv) {
  require(argc == 2, "Pass an existing directory for roundtrip files.");
  char current_path[512], legacy_path[512];
  snprintf(current_path, sizeof(current_path), "%s/current.grid", argv[1]);
  snprintf(legacy_path, sizeof(legacy_path), "%s/legacy.grid", argv[1]);
  grid *model = create_uniform_grid(1000, 1000, 1000, 1, 1, 1);
  grid *small = create_spherical_grid(50, 1, 1, 1);
  grid *large = create_spherical_grid(100, 1, 1, 1);
  grid_cell *cell = &model->cells[0][0][0];
  for (int j = 0; j < 3; j++) {
    require(cell->vel[j] == 0, "Cartesian velocity was not initialized.");
    require(small->cells[0][0][0].vel[j] == 0, "Spherical velocity was not initialized.");
  }
  for (int i = 0; i < 2; i++) {
    double position[3] = {i ? 750 : 250, i ? 750 : 250, i ? 750 : 250};
    require(create_cloud_in_cell(model, i ? large : small, cell, position, 0) == 1,
            "Could not prepare test cloud.");
    cell->v_flag_clouds[i] = i + 1;
    for (int j = 0; j < 3; j++) cell->vel_clouds[i][j] = 10 * i + j;
  }
  o_grid(current_path, model, "ASCII cloud record regression");
  FILE *input = fopen(current_path, "r");
  FILE *output = fopen(legacy_path, "w");
  require(input != NULL && output != NULL, "Could not open roundtrip files.");
  char line[2048];
  int in_clouds = 0;
  while (fgets(line, sizeof(line), input)) {
    if (strstr(line, "### END CLOUD_DATA")) in_clouds = 0;
    if (in_clouds && line[0] != '#') {
      char *last_space = strrchr(line, ' ');
      require(last_space != NULL, "Unexpected serialized cloud row.");
      last_space[0] = '\n';
      last_space[1] = '\0';
    }
    fputs(line, output);
    if (strstr(line, "### START CLOUD_DATA")) in_clouds = 1;
  }
  fclose(input);
  fclose(output);
  grid *cloud_types[] = {large, small};
  grid *restored = i_grid_defined_clouds(current_path, 2, cloud_types);
  check_restored(restored, 0);
  free_grid(restored);
  restored = i_grid_defined_clouds(legacy_path, 2, cloud_types);
  check_restored(restored, 1);
  free_grid(restored);
  free_grid(model);
  free_grid(small);
  free_grid(large);
  grid *registered = create_spherical_grid(50, 1, 1, 1);
  require(cfg_lookup_cloud("roundtrip_cloud", registered) == registered,
          "Cloud registration failed.");
  require(cfg_lookup_cloud("roundtrip_cloud", NULL) == registered,
          "Cloud lookup lost its section name.");
  cfg_lookup_cloud(NULL, NULL);
  registered = create_spherical_grid(50, 1, 1, 1);
  require(cfg_lookup_cloud("roundtrip_cloud", registered) == registered,
          "Cloud registration failed after cleanup.");
  require(cfg_lookup_cloud("roundtrip_cloud", NULL) == registered,
          "Cloud lookup failed after cleanup.");
  cfg_lookup_cloud(NULL, NULL);
  puts("Current 8-field and legacy 7-field cloud records passed.");
  return EXIT_SUCCESS;
}
