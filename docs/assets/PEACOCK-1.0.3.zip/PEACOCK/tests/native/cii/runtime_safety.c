#define _POSIX_C_SOURCE 200809L
#include <limits.h>
#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "grid.h"
#include "propagation.h"
#include "io/i_grid_ascii.h"
#include "io/o_photon.h"
#include "misc/mem.h"
#include "observer/observer.h"
#include "observer/observer_allscatter.h"
#include "physical_properties.h"
#ifndef PEACOCK_MULTILEVEL
#include "interact_hydrogen.h"
#include "misc/rand_tools.h"
#endif
#define CHECK(c) do { if (!(c)) { fprintf(stderr, "Failed: %s at %d\n", #c, __LINE__); exit(1); } } while (0)
static photon prepare(grid *g,double x,double y,double z,double dx,double dy,double dz) {
  static struct emission_cfg_s emission_cfg = {0};
  photon p={0};p.emission_cfg=&emission_cfg;p.grid=g;p.curr_cell=&g->cells[0][0][0];p.pos[0]=x;p.pos[1]=y;p.pos[2]=z;
  p.dir[0]=dx;p.dir[1]=dy;p.dir[2]=dz;p.Delta_nu_D=1;p.tau=1;
  return p;
}
static void check_boundary_requests(void) {
  grid *g=create_uniform_grid(2,4,6,1,1,1);
  photon a=prepare(g,1,2,3,.6,.8,0),b=a;
  double finite_distance,infinite_distance;
  int finite_result=update_photon_pos(&a,1e9*g->boxsize[0],&finite_distance);
  int infinite_result=update_photon_pos(&b,HUGE_VAL,&infinite_distance);
  CHECK(finite_result==infinite_result && finite_distance==infinite_distance);
  for(int i=0;i<3;i++)CHECK(a.pos[i]==b.pos[i]);
  CHECK(a.curr_cell==b.curr_cell);free_grid(g);
  g=create_spherical_grid(3,1,1,1);a=prepare(g,.5,0,0,1,0,0);b=a;
  finite_result=update_photon_pos(&a,1e9*g->boxsize[0],&finite_distance);
  infinite_result=update_photon_pos(&b,HUGE_VAL,&infinite_distance);
  CHECK(finite_result==infinite_result && finite_distance==infinite_distance);
  for(int i=0;i<3;i++)CHECK(a.pos[i]==b.pos[i]);
  CHECK(a.curr_cell==b.curr_cell);free_grid(g);
  /* A very thin box must not turn a distant y wall into repeated vacuum steps. */
  g=create_uniform_grid(1e-18,4,6,1,1,1);a=prepare(g,5e-19,2,3,0,1,0);
  double tau=get_tau_esc(&a);CHECK(tau==0 && a.curr_cell==NULL && a.dist==2);
  free_grid(g);
#ifdef NO_SCATTER_MODE
  CHECK(get_new_tau() == DBL_MAX);
#endif
  puts("Infinite boundary request matches finite crossings; anisotropic virtual escape is exact.");
}

#ifndef NO_SCATTER_MODE
static void check_boundary_rounding(void) {
  grid *g = create_uniform_grid(2, 4, 6, 1, 1, 1);
  photon p = prepare(g, .7, 2, 3, 1, 0, 0);
  p.Delta_nu_D = doppler_freq_shift_hydrogen(p.curr_cell->T);
  photon wall = p;
  double distance;
  CHECK(update_photon_pos(&wall, HUGE_VAL, &distance) != 0 && wall.curr_cell == NULL);
  const double dust_cross_section = gas_scattering_cs(0, p.curr_cell->T);
  int found = 0;
  for (int density = 1; density < 10000; density++) {
    const double extinction = density * dust_cross_section;
    const double optical_depth = distance * extinction;
    if (optical_depth / extinction > distance) {
      /* The optical step lies beyond the wall, but its residual rounds to zero. */
      p.curr_cell->n_D = density;
      p.tau = optical_depth;
      found = 1;
      break;
    }
  }
  CHECK(found);
  const double initial_depth = p.tau;
  CHECK(propagate_photon(&p, NULL) == 1);
  CHECK(p.curr_cell == NULL && p.nscatter == 0);
  /* A fused multiply-subtract can retain the small positive residual. */
  CHECK(p.tau >= 0 && p.tau <= DBL_EPSILON * initial_depth);
  free_grid(g);
  puts("Zero optical-depth residual at an outer boundary escapes without scattering.");
}
#endif

#ifdef FIX_FREQUENCY
static void check_fixed_frequency_opacity(void) {
  grid *g = create_uniform_grid(2, 4, 6, 1, 1, 1);
  photon p = prepare(g, 1, 2, 3, 1, 0, 0);
  p.Delta_nu_D = doppler_freq_shift_hydrogen(p.curr_cell->T);
  p.curr_cell->n_HI = 1.0;
  p.x = 5.0;
  p.x_i = 0;
  update_photon_values(&p);
  const double wing_extinction = p.curr_tau;
  fix_photon_frequency(&p);
  CHECK(p.x == p.x_i && p.curr_tau > wing_extinction);
  free_grid(g);
  puts("Fixed frequency refreshes opacity at the launch detuning.");
}
#endif

static FILE *text_file(const char *text) {
  FILE *file = tmpfile(); CHECK(file != NULL);
  CHECK(fputs(text, file) >= 0); rewind(file); return file;
}
static void check_seek(void) {
  FILE *file = text_file("first\nsecond\nthird\n");
  CHECK(fseek_line_containing_string(file, "second") == 1);
  CHECK(ftell(file) == 6);
  CHECK(fseek_line_containing_string(file, "first") == 1 && ftell(file) == 0);
  CHECK(fseek_line_containing_string(file, "missing") == -1 && ftell(file) == 0);
  fclose(file);
}
static void check_momentum(const char *prefix) {
  char path[1024];
  for (int run = 0; run < 2; run++) {
    char current[1024];
    CHECK(snprintf(current, sizeof(current), "%s_%d", prefix, run) < (int)sizeof(current));
    CHECK(o_photon_init(1, current, "BINARY_MOMENTUM") == 0);
    CHECK(snprintf(path, sizeof(path), "%s.momentum.01.bin", current) < (int)sizeof(path));
    observer obs = {.type = TLAC_OBSERVER_ALLSCATTER_MOMENTUM, .nout_file = 1};
    photon p = {.pos = {1,2,3}, .dir_last = {4,5,6}, .dir = {7,8,9}, .x_last = 10};
    process_observer_allscatter_momentum(&obs, &p);
    CHECK(o_photon_get_nout(1) == 1);
    free_observer(&obs);
    FILE *file = fopen(path,"rb"); CHECK(file != NULL);
    double record[10]; CHECK(fread(record,sizeof(record),1,file) == 1);
    CHECK(fgetc(file) == EOF); fclose(file);
    for (int i=0;i<10;i++) CHECK(record[i] == i+1);
    CHECK(o_photon_init(1,current,"BINARY_MOMENTUM") == -1);
    CHECK(unlink(path) == 0);
  }
}
#ifndef PEACOCK_MULTILEVEL
static void check_sampler(void) {
  double positive[512]; photon p = {.x=0.8,.a=0.2};
  init_rand_tools(19);
  for (int i=0;i<512;i++) positive[i]=sct_hyd_get_atom_parallel_vel_1piece(&p);
  cleanup_rand_tools(); p.x=-p.x; init_rand_tools(19);
  for (int i=0;i<512;i++) CHECK(sct_hyd_get_atom_parallel_vel_1piece(&p) == -positive[i]);
  cleanup_rand_tools();
}
#endif
int main(int argc,char **argv) {
  CHECK(argc >= 2);
  if (!strcmp(argv[1],"normal")) {
    CHECK(argc==3); check_boundary_requests(); check_seek(); check_momentum(argv[2]);
#ifndef NO_SCATTER_MODE
    check_boundary_rounding();
#endif
#ifdef FIX_FREQUENCY
    check_fixed_frequency_opacity();
#endif
#ifndef PEACOCK_MULTILEVEL
    check_sampler();
#endif
    puts("Bounded seek, momentum schema/lifetime/exclusivity and signed sampler checks passed.");
    return 0;
  }
  if (!strcmp(argv[1],"header")) i_grid_ascii_read_header(text_file("Magic 1\ntruncated\n"));
  if (!strcmp(argv[1],"block")) i_grid_ascii_jump2block(text_file("no block\n"),"HEADER");
  if (!strcmp(argv[1],"end")) i_grid_ascii_check_block_end(text_file(""),"CELL_DATA");
  if (!strcmp(argv[1],"cart")) create_uniform_grid(1,1,1,1,0,1);
  if (!strcmp(argv[1],"sphere")) create_spherical_grid(1,0,1,1);
  if (!strcmp(argv[1],"overflow")) create_uniform_grid(1,1,1,INT_MAX,INT_MAX,INT_MAX);
  if (!strcmp(argv[1],"file")) check_fopen("/nonexistent/peacock/test","r");
  fprintf(stderr,"Invalid input was unexpectedly accepted.\n"); return 0;
}
