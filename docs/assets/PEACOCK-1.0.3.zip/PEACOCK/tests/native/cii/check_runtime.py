#!/usr/bin/env python3
"""Exercise malformed inputs as subprocesses so failures cannot hang a test run."""
from pathlib import Path
import subprocess
import sys
import tempfile
executable=Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix="peacock-runtime-") as directory:
    subprocess.run([str(executable),"normal",str(Path(directory)/"momentum")],check=True,timeout=20)
    for mode in ["header","block","end","cart","sphere","overflow","file"]:
        result=subprocess.run([str(executable),mode],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=5)
        if result.returncode == 0:
            raise AssertionError(f"{mode} unexpectedly succeeded: {result.stdout.decode()}")
print("Malformed headers, missing blocks, invalid dimensions, overflow and file failures stop cleanly.")
