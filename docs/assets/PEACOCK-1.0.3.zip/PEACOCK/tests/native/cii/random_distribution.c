#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "misc/rand_tools.h"

/* Cloud counts must be integers with Poisson mean and variance. */
int main(void) {
  const double means[] = {0.3, 3.0};
  const int samples = 20000;
  init_rand_tools(20261105);
  for (int model = 0; model < 2; model++) {
    double sum = 0;
    double sum_squares = 0;
    for (int i = 0; i < samples; i++) {
      double count = rand_poisson(means[model]);
      if (count < 0 || count != floor(count)) {
        fprintf(stderr, "Poisson cloud count is not a nonnegative integer.\n");
        return EXIT_FAILURE;
      }
      sum += count;
      sum_squares += count * count;
    }
    double mean = sum / samples;
    double variance = sum_squares / samples - mean * mean;
    double mean_tolerance = 8 * sqrt(means[model] / samples);
    double variance_tolerance = 0.12 + 0.1 * means[model];
    if (fabs(mean - means[model]) > mean_tolerance ||
        fabs(variance - means[model]) > variance_tolerance) {
      fprintf(stderr, "Poisson moments failed for mean %g.\n", means[model]);
      return EXIT_FAILURE;
    }
    printf("Poisson mean %g, sampled mean %.6f, variance %.6f\n",
           means[model], mean, variance);
  }
  cleanup_rand_tools();
  return EXIT_SUCCESS;
}
