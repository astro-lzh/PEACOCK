import json,sys
import numpy as np
from scipy.integrate import quad
from scipy.special import wofz
checks=[];maxvoigt=0.
for l in open(sys.argv[1]):
 if l.startswith('VOIGT '):
  a,x,h=map(float,l.split()[1:]);expect=wofz(x+1j*a).real
  err=abs(h-expect)/expect;maxvoigt=max(err,maxvoigt)
  assert abs(h-expect)<1e-13+expect*1e-8,(a,x,h,expect)
 if not l.startswith('VELOCITY '):continue
 _,line,x,a,n,m,m2,m4=l.split();x,a,n,m,m2,m4=map(float,(x,a,n,m,m2,m4))
 edges=sorted(set([-12.,12.]+([x] if -12<x<12 else [])+[x+s*a*f for s in [-1,1] for f in [1,10,100,1000] if -12<x+s*a*f<12]))
 def moment(k):return sum(quad(lambda u:u**k*np.exp(-u*u)/((x-u)**2+a*a),lo,hi,epsabs=1e-10,epsrel=1e-9,limit=300)[0] for lo,hi in zip(edges[:-1],edges[1:]))
 z=moment(0);ex=[moment(k)/z for k in (1,2,4)]
 assert abs(m-ex[0])<7*np.sqrt(max(0,ex[1]-ex[0]**2)/n)+2e-4,(line,x,m,ex)
 assert abs(m2-ex[1])<7*np.sqrt(max(0,ex[2]-ex[1]**2)/n)+5e-4,(line,x,m2,ex)
 checks.append(dict(line=int(line),x=x,mean=m,expected_mean=ex[0],second=m2,expected_second=ex[1]))
assert checks and 'KERNEL_CHECKS_PASSED' in open(sys.argv[1]).read()
print(json.dumps(dict(passed=True,velocity=checks,voigt_max_relative_error=maxvoigt),indent=2))
