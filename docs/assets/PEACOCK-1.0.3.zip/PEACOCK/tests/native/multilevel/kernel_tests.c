#include "../interact_hydrogen.c"
#define CHECK(q) do{if(!(q)){fprintf(stderr,"FAIL %s line%d: %s\n",RT_NAME,__LINE__,#q);exit(2);}}while(0)
int main(int argc, char **argv) {
 if (argc != 2 || peacock_load_atom(argv[1]) != 0) return 2;
 init_rand_tools(17092026);rt_validate_atom();
 grid_cell c={0};c.T=1e5;photon p={0};p.curr_cell=&c;p.dir[0]=1;
 double D=doppler_freq_shift_hydrogen(c.T),width;
 for(int i=0;i<RT_NLOWER;i++)rt_pop[i]=1./(i+1);
 for(int j=0;j<RT_NLINES;j++) {
  p.x=(rt_lines[j].nu-LYA_NU0)/D;
  double sig[RT_MAX_LINES],total=rt_cross_sections(p.x,c.T,sig),sum=0;for(int i=0;i<RT_NLINES;i++)sum+=sig[i];
  CHECK(total>0 && total==sum && sig[j]>0);
  int l=rt_lines[j].lower;double pop=rt_pop[l],sj=sig[j];rt_pop[l]*=2;
  rt_cross_sections(p.x,c.T,sig);CHECK(fabs(sig[j]/sj-2)<1e-12);rt_pop[l]=pop;
  CHECK(fabs(rt_line_detuning(j,p.x,c.T))<1e-6);
  for(int k=0;k<RT_NLINES;k++)if(rt_lines[j].upper==rt_lines[k].upper) {
   const double ni=rt_lines[j].nu+D*.7,bi=2.1e-5,bo=-.6e-5;
   const double no=rt_raman_frequency(ni,j,k,bi,bo);
   const double shift=LIGHT_SPEED*(rt_lower_E[rt_lines[j].lower]-rt_lower_E[rt_lines[k].lower]);
   CHECK(fabs(no*(1-bo)-ni*(1-bi)-shift)<4.);
   CHECK(fabs(rt_raman_frequency(no,k,j,bo,bi)/ni-1)<1e-14);
   double W=rt_lines[j].w2*rt_lines[k].w2;
   CHECK(rt_phase_pdf(0,W)>0 && rt_phase_pdf(1,W)>0);
  }
 }
 double nu=rt_lines[RT_NLINES-1].nu;
 CHECK(fabs(rt_frame_frequency(rt_frame_frequency(nu,0,.001),.001,0)/nu-1)<1e-14);
 /* Population-weighted absorption frequencies, independent categorical test. */
 for(int q=0;q<3;q++) {
  p.x=q==0?0:(q==1?-13:13);double sig[RT_MAX_LINES],sum=rt_cross_sections(p.x,c.T,sig);int counts[RT_MAX_LINES]={0};int n=100000;
  for(int t=0;t<n;t++)counts[rt_select_transition(&p)]++;
  for(int j=0;j<RT_NLINES;j++){double pr=sig[j]/sum;CHECK(fabs(counts[j]/(double)n-pr)<7*sqrt(pr*(1-pr)/n)+3./n);}
 }
 /* Branch closure and scalar phase moments for every outgoing path. */
 for(int u=0;u<RT_NUPPER;u++) {
  int in=-1;for(int j=0;j<RT_NLINES;j++)if(rt_lines[j].upper==u){in=j;break;}
  int counts[RT_MAX_LINES]={0},n=200000;
  for(int k=0;k<n;k++)counts[rt_decay(in)]++;
  for(int j=0;j<RT_NLINES;j++)if(rt_lines[j].upper==u){double pr=rt_lines[j].A/rt_gamma[u];CHECK(fabs(counts[j]/(double)n-pr)<7*sqrt(pr*(1-pr)/n)+3./n);}
  for(int j=0;j<RT_NLINES;j++)if(rt_lines[j].upper==u) {
   rt_event e={in,j};double m=0,m2=0;int na=20000;
   for(int t=0;t<na;t++){double mu=rt_angle_mu(e);m+=mu;m2+=mu*mu;}
   CHECK(fabs(m/na)<.025);CHECK(fabs(m2/na-(1./3+rt_lines[in].w2*rt_lines[j].w2/15))<.02);
  }
  const double xs[]={0,2.4,5,-6,50,-1000};
  for(int k=0;k<6;k++) {
   /* solve x_line=(nu-nu_line)/(nu*b/c) exactly */
   double localnu=rt_lines[in].nu/(1-xs[k]*thermal_velocity_hydrogen(c.T)/LIGHT_SPEED);
   p.x=(localnu-LYA_NU0)/D;width=rt_line_width(p.x,c.T);
   double m=0,m2=0,m4=0;int nvel=100000;
   for(int t=0;t<nvel;t++){double v=rt_parallel_velocity(&p,in);m+=v;m2+=v*v;m4+=v*v*v*v;}
   printf("VELOCITY %d %.12g %.12g %d %.12g %.12g %.12g\n",in,rt_line_detuning(in,p.x,c.T),rt_gamma[u]/(4*PI*width),nvel,m/nvel,m2/nvel,m4/nvel);
  }
 }
 const double aa[]={1e-7,1e-5,1e-3,.1,1,10,100};
 const double xx[]={0,.1,1,2,3,5,10,20,39.99,40.01,100,10000};
 for(int i=0;i<7;i++)for(int j=0;j<12;j++)printf("VOIGT %.12g %.12g %.17g\n",aa[i],xx[j],voigt_function_approx(aa[i],xx[j]));
 for(int i=0;i<RT_NLINES;i++) {
  double x=(rt_lines[i].nu-LYA_NU0)/D;
  CHECK(gas_scattering_cs(x,c.T)>0);CHECK(dust_albedo(x,c.T)>=0&&dust_albedo(x,c.T)<=1);CHECK(fabs(HG_asymmetry_parameter(x,c.T))<1);
 }
 puts("KERNEL_CHECKS_PASSED");return 0;
}
