#!/usr/bin/env python3
"""Check emission inputs and bounded rejection, optionally against a baseline."""
import argparse
import json
from pathlib import Path
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("executable", type=Path)
parser.add_argument("--baseline", type=Path)
parser.add_argument("--report", type=Path)
args = parser.parse_args()
args.executable = args.executable.resolve()
if args.baseline:
    args.baseline = args.baseline.resolve()
report = {"valid": [], "invalid": []}
with tempfile.TemporaryDirectory(prefix="peacock-emission-") as temporary:
    directory = Path(temporary)

    def run(executable, parameters, timeout=20):
        result = subprocess.run([str(executable), *map(str, parameters)],
                                cwd=directory, text=True, capture_output=True,
                                timeout=timeout)
        log = result.stdout + result.stderr
        match = re.search(r"^EMISSION_TEST_JSON (.+)$", result.stdout, re.MULTILINE)
        return result, log, json.loads(match[1]) if match else None

    # Exact streams cover all source modes, axes, conditional choices and the
    # special zero-scale point source. No transport packets are needed here.
    fixtures = []
    for mode in (12, 13, 14, 15):
        for axis in (0, 1, 2):
            probabilities = (-1, 0, .35, 1) if mode in (12, 15) else (-1, 0)
            fixtures.extend((mode, axis, p, 0) for p in probabilities)
    fixtures.extend((mode, 0, -1, spherical)
                    for mode in (1, 2) for spherical in (0, 1))
    fixtures.extend((2, 0, p, spherical)
                    for p in (0, .35, 1) for spherical in (0, 1))
    fixtures.extend((11, 2, p, spherical)
                    for p in (-1, 0, .35, 1) for spherical in (0, 1))
    fixtures.extend((11, 0, -1, spherical) for spherical in (0, 1))
    for mode, axis, probability, spherical in fixtures:
        parameters = ("golden", mode, axis, probability, spherical, 64, 20261106)
        result, log, value = run(args.executable, parameters)
        assert result.returncode == 0 and value, (parameters, log[-2000:])
        if args.baseline:
            before, before_log, old = run(args.baseline, parameters)
            assert before.returncode == 0 and old, (parameters, before_log[-2000:])
            assert value == old, f"Accepted sample or RNG state changed: {parameters}"
        report["valid"].append({"mode": mode, "parameter": axis,
                                 "p_cloud": probability, "spherical": bool(spherical),
                                 "samples": 64, "baseline_equal": bool(args.baseline)})

    invalid = []
    for mode in (12, 13, 14, 15):
        for axis in (-1, 3, .5, "nan", "inf"):
            invalid.append(("axis-pos", mode, axis, -1, 0))
            if mode in (14, 15):
                invalid.append(("axis-dir", mode, axis, -1, 0))
    invalid.extend(("probability", 12, 0, p, 0) for p in (-2, -.5, 1.1, "nan", "inf"))
    invalid.extend([
        ("no-cloud-run", 12, 0, 1, 0),
        ("no-cloud-direct", 12, 0, 1, 0),
        # Boundary plane does not intersect the central cloud.
        ("disjoint", 13, 0, 1, 0),
        # A deterministic source at the cloud center has no intercloud support.
        ("disjoint", 1, 0, 0, 0),
    ])
    for parameters in invalid:
        result, log, value = run(args.executable, parameters)
        assert result.returncode > 0, (parameters, result.returncode, log[-2000:])
        assert "[Error]" in log or "Error" in log, (parameters, log[-2000:])
        if parameters[0] in ("no-cloud-direct", "disjoint"):
            assert "consecutive position proposals" in log, (parameters, log[-2000:])
            assert "27631008" in log, (parameters, log[-2000:])
        report["invalid"].append({"parameters": list(parameters),
                                   "diagnostic_exit": result.returncode})
    assert not list(directory.iterdir()), "Emission checks created unexpected files."
report["passed"] = True
if args.report:
    args.report.write_text(json.dumps(report, indent=2) + "\n")
print(f"Emission: {len(report['valid'])} valid seeded fixtures and "
      f"{len(report['invalid'])} diagnostic failures passed.")
