/* Test the physical dispersion independently of cloud position direction. */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "clouds.h"
#include "grids/grid_spherical.h"
#include "misc/rand_tools.h"
#include "physical_properties.h"

static void require(int valid, const char *message) {
  if (!valid) {
    fprintf(stderr, "Cloud dispersion test: %s\n", message);
    exit(EXIT_FAILURE);
  }
}

int main(void) {
  const int samples = 20000;
  const double sigma_kms = 25.0;
  grid *world = create_spherical_grid(1000 * PARSEC, 1, 1, 1);
  grid *cloud = create_spherical_grid(PARSEC, 1, 1, 1);
  grid_cell *cell = &world->cells[0][0][0];
  cloud->cells[0][0][0].T = 18040.415746206498;
  /* Cloud centers on the x axis isolate the transverse velocity dispersion. */
  double position[3] = {300 * PARSEC, 0, 0};
  for (int n = 0; n <= samples; n++)
    require(create_cloud_in_cell(world, cloud, cell, position, 0), "fixture insertion failed");
  cell->v_flag_clouds[samples] = 1.0;
  cell->vel_clouds[samples][0] = 3.0;
  init_rand_tools(20261106);
  double params[] = {sigma_kms};
  add_clouds_velocity(world, CLOUD_MOTION_GAUSSIAN, params);

  const double to_sigma = thermal_velocity_hydrogen(cloud->cells[0][0][0].T) /
                          (1e5 * sigma_kms);
  double sum[3] = {0}, products[3][3] = {{0}};
  for (int n = 0; n < samples; n++) {
    require(cell->v_flag_clouds[n] == 1.0, "new population flag not advanced");
    double v[3];
    for (int a = 0; a < 3; a++) {
      v[a] = cell->vel_clouds[n][a] * to_sigma;
      sum[a] += v[a];
    }
    for (int a = 0; a < 3; a++)
      for (int b = 0; b < 3; b++) products[a][b] += v[a] * v[b];
  }
  require(cell->v_flag_clouds[samples] == 2.0 &&
          cell->vel_clouds[samples][0] == 3.0 &&
          cell->vel_clouds[samples][1] == 0.0 && cell->vel_clouds[samples][2] == 0.0,
          "an existing population was redrawn");
  printf("samples=%d sigma_kms=%.1f\n", samples, sigma_kms);
  for (int a = 0; a < 3; a++) {
    require(fabs(sum[a] / samples) < 0.04, "component mean differs from zero");
    for (int b = 0; b < 3; b++) {
      double covariance = products[a][b] / samples - sum[a] / samples * (sum[b] / samples);
      double expected = a == b ? 1.0 : 0.0;
      require(fabs(covariance - expected) < 0.05, "component covariance differs from isotropic dispersion");
      printf("covariance[%d,%d]/sigma^2=%.9f\n", a, b, covariance);
    }
  }
  cleanup_rand_tools();
  free_grid(world);
  free_grid(cloud);
  puts("PASS Cartesian isotropic cloud dispersion");
  return EXIT_SUCCESS;
}
