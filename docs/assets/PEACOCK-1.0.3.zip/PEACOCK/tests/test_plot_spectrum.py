"""Scientific checks for the shared CPU/CUDA spectrum reader.

Tiny packet fixtures use the bundled C II atom and known observer velocities.
They do not compile transport code or require a GPU.
"""

import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backends.cuda.runtime.runner import load_atom
from tools.engine_layout import line_profiles
from tools.plot_spectrum import cpu_packets, cuda_packets, selected_profile, spectrum

C_KMS = 299792.458
PC_CM = 3.08567758e18
DOPPLER_KMS = 10.0


class SpectrumTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="peacock-spectrum-test-")
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.case_number = 0
        self.profile = next(p for p in line_profiles() if p["name"] == "CII1334")
        self.atom_path = ROOT / "lines/runtime/CII1334.atom"
        self.atom = load_atom(self.profile, self.atom_path)
        self.width_hz = self.atom.reference_hz * DOPPLER_KMS / C_KMS

    def make_case(self, backend, velocities=(), *, launched=8, positions_pc=None,
                  directions=None, bulk=0.0, mode=3, halfwidth=200.0,
                  report_status="COMPLETE", unfinished=0, archive_count=None,
                  archive_status=None):
        self.case_number += 1
        case = self.directory / f"{backend}-{self.case_number}"
        case.mkdir()
        shutil.copyfile(self.atom_path, case / "atomic.atom")
        (case / "resolved.cfg").write_text(
            f"[run]\nnphot = {launched}\nrandom_seed = 12345\n"
            f"[grid]\nrandom_seed = 17\n"
            f"[emission]\nfrequency_mode = {mode}\nfrequency_param = {halfwidth}\n",
            encoding="utf-8",
        )
        escaped = len(velocities)
        observer_x = -np.asarray(velocities, dtype=float) / DOPPLER_KMS
        positions = (np.zeros((escaped, 3)) if positions_pc is None
                     else np.asarray(positions_pc, dtype=float)) * PC_CM
        rays = (np.tile((0.0, 0.0, 1.0), (escaped, 1)) if directions is None
                else np.asarray(directions, dtype=float))
        bulk_values = np.broadcast_to(np.asarray(bulk, dtype=float), (escaped,))
        metadata = {"line": "CII1334", "backend": backend}

        if backend == "cpu":
            (case / "run.json").write_text(json.dumps(metadata), encoding="utf-8")
            packets = np.zeros((escaped, 19))
            packets[:, :3] = positions
            packets[:, 3:6] = rays
            packets[:, 6] = observer_x
            packets[:, 8] = self.width_hz
            packets[:, 9] = 1e-3
            # The observer column above already includes this local-frame shift.
            packets[:, 13] = observer_x - bulk_values
            packets[:, 14] = bulk_values
            np.savetxt(case / "packets_primary.dat", packets,
                       header="primary ASCII escape packets", fmt="%.17g")
        else:
            count = launched if archive_count is None else archive_count
            status = np.zeros(count, dtype=np.int32)
            status[:escaped] = 1
            if archive_status is not None:
                status = np.asarray(archive_status, dtype=np.int32)
                if len(status) != count:
                    raise ValueError("Fixture status and archive sizes differ")
            fields = {name: np.full(count, np.nan) for name in
                      ["x", "Delta_nu_D", "sc_dir_bulk"] +
                      [f"{prefix}{axis}" for prefix in ("pos", "dir") for axis in range(3)]}
            fields["x"][:escaped] = observer_x - bulk_values
            fields["Delta_nu_D"][:escaped] = self.width_hz
            fields["sc_dir_bulk"][:escaped] = bulk_values
            for axis in range(3):
                fields[f"pos{axis}"][:escaped] = positions[:, axis]
                fields[f"dir{axis}"][:escaped] = rays[:, axis]
            np.savez(case / "gpu_output_1024.npz", status=status, **fields)
            (case / "prepare_report.json").write_text(json.dumps(metadata), encoding="utf-8")
            (case / "gpu_run_report.json").write_text(json.dumps({
                "status": report_status,
                "unfinished_or_bad": unfinished,
                "output_path": "C:\\previous-host\\case\\gpu_output_1024.npz",
            }), encoding="utf-8")
        return case

    def test_cpu_cuda_observer_frequency_agrees_with_bulk_motion(self):
        # Local x=-5 and bulk x=10 give observer x=5, or -50 km/s.
        cpu = self.make_case("cpu", [-50], launched=2, bulk=10)
        cuda = self.make_case("cuda", [-50], launched=2, bulk=10)
        cpu_nu = cpu_packets(cpu, self.atom.reference_hz)[0]
        cuda_nu = cuda_packets(cuda, self.atom)[0]
        expected = self.atom.reference_hz * (1 + 50 / C_KMS)
        np.testing.assert_allclose(cpu_nu, [expected], rtol=1e-15)
        np.testing.assert_allclose(cuda_nu, cpu_nu, rtol=1e-15)
        cpu_result = spectrum(cpu, bins=4, velocity_range=(-200, 200))
        cuda_result = spectrum(cuda, bins=4, velocity_range=(-200, 200))
        np.testing.assert_array_equal(cpu_result[1], [0, 1, 0, 0])
        np.testing.assert_array_equal(cuda_result[1], cpu_result[1])
        np.testing.assert_allclose(cuda_result[2], cpu_result[2])
        self.assertEqual(cuda_result[-1]["escaped_packets"], 1)
        self.assertEqual(cuda_result[-1]["launched_packets"], 2)

    def test_continuum_uses_launched_count_and_keeps_window_losses(self):
        for backend in ("cpu", "cuda"):
            with self.subTest(backend=backend):
                case = self.make_case(backend, [-150, -50, -50, 350], launched=8)
                edges, counts, flux, sigma, _, info = spectrum(
                    case, bins=4, velocity_range=(-200, 200))
                # Eight injected packets across 400 km/s predict two per 100 km/s bin.
                np.testing.assert_array_equal(counts, [1, 2, 0, 0])
                np.testing.assert_allclose(flux, [0.5, 1.0, 0.0, 0.0])
                np.testing.assert_allclose(sigma, [0.5, np.sqrt(2) / 2, 0, 0])
                self.assertAlmostEqual(np.sum(flux * np.diff(edges)) / 400, 3 / 8)
                self.assertEqual(info["escaped_packets"], 4)
                self.assertEqual(info["binned_packets"], 3)

    def test_aperture_is_projected_distance_in_pc_and_includes_direct_rays(self):
        positions = [(1, 0, 100), (3, 0, 0), (0, 0, 100)]
        for backend in ("cpu", "cuda"):
            with self.subTest(backend=backend):
                case = self.make_case(backend, [-50, 50, 150], launched=4,
                                      positions_pc=positions)
                result = spectrum(case, bins=4, velocity_range=(-200, 200), aperture_pc=1.5)
                np.testing.assert_array_equal(result[1], [0, 1, 0, 1])
                np.testing.assert_allclose(result[2], [0, 1, 0, 1])
                self.assertEqual(result[-1]["escaped_packets"], 3)
                self.assertEqual(result[-1]["aperture_packets"], 2)
                self.assertEqual(spectrum(case, bins=4)[-1]["aperture_packets"], 3)

    def test_all_absorbed_is_zero_continuum_and_has_no_probability_shape(self):
        for backend in ("cpu", "cuda"):
            with self.subTest(backend=backend):
                case = self.make_case(backend, [], launched=4)
                result = spectrum(case, bins=4)
                np.testing.assert_array_equal(result[1], [0, 0, 0, 0])
                np.testing.assert_array_equal(result[2], [0, 0, 0, 0])
                self.assertEqual(result[-1]["escaped_packets"], 0)
                with self.assertRaisesRegex(ValueError, "No escaping packets"):
                    spectrum(case, bins=4, normalization="probability")

    def test_line_source_probability_is_conditional_unit_area(self):
        for backend in ("cpu", "cuda"):
            with self.subTest(backend=backend):
                case = self.make_case(backend, [-150, -50, 50, 350], launched=8, mode=2)
                result = spectrum(case, bins=4, velocity_range=(-200, 200),
                                  normalization="probability")
                self.assertAlmostEqual(np.sum(result[2] * np.diff(result[0])), 1.0)
                np.testing.assert_allclose(result[2], [1 / 300, 1 / 300, 1 / 300, 0])
                self.assertEqual(result[-1]["escaped_packets"], 4)
                self.assertEqual(result[-1]["binned_packets"], 3)
                with self.assertRaisesRegex(ValueError, "Continuum normalization needs"):
                    spectrum(case, bins=4)

    def test_incomplete_gpu_report_is_rejected(self):
        for status, unfinished in (("NEEDS_ATTENTION", 0), ("COMPLETE", 1)):
            with self.subTest(status=status, unfinished=unfinished):
                case = self.make_case("cuda", [-50], launched=2,
                                      report_status=status, unfinished=unfinished)
                with self.assertRaisesRegex(ValueError, "GPU run is incomplete"):
                    spectrum(case)

    def test_incomplete_gpu_packet_status_is_rejected(self):
        case = self.make_case("cuda", [-50], launched=2, archive_status=[1, -2])
        with self.assertRaisesRegex(ValueError, "incomplete or invalid photon histories"):
            spectrum(case)

    def test_gpu_archive_must_match_launched_packet_budget(self):
        case = self.make_case("cuda", [-50], launched=4, archive_count=2)
        with self.assertRaisesRegex(ValueError, "GPU packet count differs"):
            spectrum(case)

    def test_all_bundled_line_metadata_uses_its_real_atomic_reference(self):
        for profile in line_profiles():
            with self.subTest(line=profile["name"]):
                selected = selected_profile(self.directory, {"line": profile["name"]})
                atom = load_atom(selected, ROOT / "lines/runtime" / (profile["name"] + ".atom"))
                self.assertGreater(atom.reference_hz, 0)
                self.assertEqual(selected["name"], profile["name"])
                # The integer in each selector identifies its reference wavelength.
                # This also catches selecting a different multiplet component.
                nominal_angstrom = int("".join(c for c in profile["name"] if c.isdigit()))
                wavelength_angstrom = C_KMS * 1e13 / atom.reference_hz
                self.assertAlmostEqual(wavelength_angstrom, nominal_angstrom, delta=0.9)


if __name__ == "__main__":
    unittest.main()
