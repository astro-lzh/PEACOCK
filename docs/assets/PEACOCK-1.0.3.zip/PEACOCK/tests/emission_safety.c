#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "emission.h"
#include "clouds.h"
#include "grid.h"
#include "grids/grid_cart.h"
#include "grids/grid_spherical.h"
#include "misc/rand_tools.h"
#include "physical_properties.h"

#define REQUIRE(condition) do { if (!(condition)) { \
  fprintf(stderr, "Emission test failed: %s at line %d\n", #condition, __LINE__); \
  exit(EXIT_FAILURE); } } while (0)

int main(int argc, char **argv) {
  REQUIRE(argc >= 2);
  const char *which = argv[1];
  int mode = argc > 2 ? emission_position_from_config(atoi(argv[2])) : EMISSION_POS_MIDPLANE;
  double parameter = argc > 3 ? strtod(argv[3], NULL) : 0;
  double p_cloud = argc > 4 ? strtod(argv[4], NULL) : -1;
  int spherical = argc > 5 ? atoi(argv[5]) : 0;
  int count = argc > 6 ? atoi(argv[6]) : 64;
  long seed = argc > 7 ? strtol(argv[7], NULL, 10) : 20261106;
  grid *g = spherical ? create_spherical_grid(10 * PARSEC, 1, 1, 1) :
    create_uniform_grid(10 * PARSEC, 10 * PARSEC, 10 * PARSEC, 1, 1, 1);
  grid *cloud = create_spherical_grid(3 * PARSEC, 1, 1, 1);
  set_grid_values(g, 1e-6, 0, 1e4, 1);
  set_grid_values(cloud, 2e-6, 0, 1e4, 1);
  g->L_tot = get_total_luminosity(g);
  cloud->L_tot = get_total_luminosity(cloud);
  if (strcmp(which, "no-cloud-run") && strcmp(which, "no-cloud-direct")) {
    double position[3] = {0, 0, 0};
    if (!spherical)
      for (int i = 0; i < 3; i++) position[i] = 5 * PARSEC;
    REQUIRE(create_cloud_in_cell(g, cloud, &g->cells[0][0][0], position, 0) == 1);
  }
  photon *p = create_photon();
  p->grid = g;
  p->Delta_nu_D = 1;
  p->emission_cfg->initial_pos_mode = mode;
  p->emission_cfg->initial_pos_param = parameter;
  p->emission_cfg->p_cloud = p_cloud;
  p->emission_cfg->initial_freq_mode = EMISSION_FREQ_FIXED;
  p->emission_cfg->initial_freq_param = 17;
  init_rand_tools(seed);

  if (!strcmp(which, "axis-dir")) {
    set_photon_startdir(p);
  } else if (!strcmp(which, "axis-pos") || !strcmp(which, "probability") ||
             !strcmp(which, "no-cloud-direct") || !strcmp(which, "disjoint")) {
    set_photon_startpos(p, g);
  } else if (!strcmp(which, "no-cloud-run")) {
    run_photons_with_tracking(g, 1, *p->emission_cfg, NULL);
  } else {
    REQUIRE(!strcmp(which, "golden"));
    int in_cloud = 0;
    printf("EMISSION_TEST_JSON {\"samples\":[");
    for (int sample = 0; sample < count; sample++) {
      start_photon(p, g);
      int is_cloud = p->grid == cloud;
      in_cloud += is_cloud;
      REQUIRE(p->curr_cell != NULL);
      REQUIRE(p_cloud != 0 || !is_cloud);
      REQUIRE(p_cloud != 1 || is_cloud);
      printf("%s[%d", sample ? "," : "", is_cloud);
      for (int i = 0; i < 3; i++) printf(",%.17g", p->pos[i]);
      for (int i = 0; i < 3; i++) printf(",%.17g", p->dir[i]);
      printf(",%.17g,%.17g,%.17g]", p->x, p->Delta_nu_D, p->sc_dir_bulk);
    }
    printf("],\"in_cloud\":%d,\"next_rng\":%.17g}\n", in_cloud, rand_uniform());
  }
  free_photon(p);
  free_grid(g);
  free_grid(cloud);
  cleanup_rand_tools();
  return 0;
}
