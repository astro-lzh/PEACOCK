"""Compare runtime scalar atoms with the C reference constants."""

import os
from pathlib import Path
import shlex
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parents[1]
CC = shlex.split(os.environ.get("CC", "cc"))
FAMILIES = {
    "resonant": (("HI1216",), """
        HYDROGEN_MASS, LYA_F12, LYA_NU0, LYA_DELTA_NU_L
    """),
    "fine_structure": (("CII1334",), """
        HYDROGEN_MASS, CII_E1, CII_E2, CII_E3, CII_E4,
        LYA_F1, LYA_F2, LYA_F3, CII_A31, CII_A32, CII_A42,
        CII_NU13, CII_NU23, CII_NU24, CII_FINE_STRUCTURE_NU,
        DELTA_NU_12, DELTA_NU_13, LYA_DELTA_NU_L_1, LYA_DELTA_NU_L_2,
        LYA_DELTA_NU_L_3, CII_LAMBDA13_A, CII_LAMBDA23_A, CII_LAMBDA24_A
    """),
    "doublet": (("CIV1548", "MgII2796"), """
        HYDROGEN_MASS, LINE_ATOM_MASS, LINE_E_BLUE, LINE_E_RED,
        LINE_F_BLUE, LINE_F_RED, LINE_GAMMA_BLUE, LINE_GAMMA_RED,
        LINE_NU_BLUE, LINE_NU_RED, LINE_DELTA_NU, LYA_NU0,
        LYA_NU0_F_H, DELTA_NU_H_K, LYA_F12, LYA_F_H, LYA_DELTA_NU_L
    """),
}


def compile_probe(folder, family, line, macros, runtime):
    source = folder / "probe.c"
    source.write_text(
        f'''
#include "physical_properties.h"
#include <stdio.h>
static void snapshot(void) {{
  const double values[] = {{{macros}}};
  for (size_t i = 0; i < sizeof(values) / sizeof(*values); ++i)
    printf("%a ", values[i]);
  puts("");
}}
int main(int argc, char **argv) {{
#ifdef TEST_RUNTIME_ATOM
  if (argc < 2 || peacock_load_atom(argv[1]))
    return 1;
#endif
  snapshot();
#ifdef TEST_RUNTIME_ATOM
  for (int i = 2; i < argc; ++i) {{
    if (peacock_load_atom(argv[i]) == 0)
      return 2;
    snapshot();
  }}
#endif
  return 0;
}}
''',
        encoding="utf-8",
    )
    suffix = ".exe" if os.name == "nt" else ""
    executable = folder / (("runtime-" if runtime else "reference-") + line + suffix)
    includes = [ROOT / "src" / "physics", ROOT / "lines" / "atomic-data" / line]
    flags = ["-std=c99", "-O2", f"-DPEACOCK_ATOM_{family.upper()}",
             *(f"-I{path}" for path in includes)]
    files = [str(source)]
    if runtime:
        loader = ROOT / "src" / "runtime" / "scalar_atom.c"
        flags += ["-DTEST_RUNTIME_ATOM", "-include", str(loader.with_suffix(".h"))]
        files.append(str(loader))
    subprocess.run([*CC, *flags, *files, "-lm", "-o", str(executable)], check=True)
    return executable


def invalid_atoms(folder, good_atom):
    raw = good_atom.read_bytes()
    tokens = raw.split()
    cases = {
        "version": raw.replace(b"PEACOCK_ATOM_V1", b"PEACOCK_ATOM_V2", 1),
        "operator": b" ".join([tokens[0], b"other", *tokens[2:]]),
        "line": b" ".join([*tokens[:2], b"other", *tokens[3:]]),
        "short": b" ".join(tokens[:-1]),
        "trailing": raw + b"1\n",
        "nonfinite": b" ".join([*tokens[:3], b"nan", *tokens[4:]]),
        "mass": b" ".join([*tokens[:3], b"0", *tokens[4:]]),
        "overlong": b" ".join([*tokens[:3], b"1" * 80, *tokens[4:]]),
    }
    paths = []
    for name, data in cases.items():
        path = folder / f"bad-{name}.atom"
        path.write_bytes(data)
        paths.append(path)
    return paths


def main():
    with tempfile.TemporaryDirectory(prefix="peacock-atom-") as temporary:
        folder = Path(temporary)
        for family, (lines, macros) in FAMILIES.items():
            runtime = compile_probe(folder, family, lines[0], macros, True)
            for line in lines:
                reference = compile_probe(folder, family, line, macros, False)
                expected = subprocess.check_output([str(reference)])
                atom = ROOT / "lines" / "runtime" / f"{line}.atom"
                malformed = invalid_atoms(folder, atom)
                result = subprocess.run(
                    [str(runtime), str(atom), *(str(path) for path in malformed)],
                    capture_output=True,
                    check=True,
                )
                assert result.stdout == expected * (1 + len(malformed)), line
                assert len(result.stderr.splitlines()) == len(malformed), line
                print(f"{line}: exact atomic constants and {len(malformed)} invalid-file checks")


if __name__ == "__main__":
    main()
