# PEACOCK

Profiles of Emission and Absorption from Clumpy Outflows with Complex Kinematics

PEACOCK uses three-dimensional Monte Carlo radiative transfer to model UV
emission and absorption in clumpy galactic winds. It follows resonance
scattering, fluorescent re-emission in the applicable atomic networks, and
dust interactions. The engine builds on Max Gronke's `tlac`.

## Build once, then choose a line

Run these commands from the source directory. The catalog lists 14 line
profiles. All 14 support CUDA transport, and 12 also support CPU transport.

```sh
python3 peacock.py lines
```

The CPU build requires Python 3.9 or later, a C compiler, `nm`, and the GNU
Scientific Library (GSL). On Debian or Ubuntu, install `build-essential`,
`libgsl-dev` and `python3`. On macOS, install the Xcode command-line tools
and GSL with `brew install gsl`.

For GPU inputs and plotting, install the Python dependencies in a virtual
environment before running:

```sh
python3 -m pip install numpy scipy matplotlib
```

```sh
python3 peacock.py build --backend cpu
python3 peacock.py run --line CII1334 --backend cpu --output run/cii-cpu
```

All supported CPU lines use the same `peacock-cpu` executable. The selected line loads
its atomic table from `lines/runtime/` and chooses its scattering operator
when the run starts.

A full CUDA build creates one native input exporter and one `transport.ptx`
for the chosen CUDA architecture. The same module runs all 14 profiles.
The target below is for an RTX 5090. Replace `compute_120` with a target
compatible with your GPU and installed CUDA compiler library.

```sh
python3 peacock.py build --backend cuda --arch compute_120
python3 peacock.py run --line CII1334 --backend cuda --output run/cii-cuda
```

See the [CUDA guide](docs/gpu-workflow.md) for the Windows compiler setup,
NVRTC options and separate preparation and execution commands.

The two C II commands use one [quickstart wind](examples/cii/README.md),
with the same `examples/cii/quickstart.cfg` and complete FCC catalogue.
No geometry generation is needed. Check your release or inspect a
command's options with `python3 peacock.py --version` and
`python3 peacock.py run --help`.

## Make a spectrum

After either C II run, turn the escape packets into a continuum-normalized
spectrum. The same helper reads CPU and CUDA outputs:

```sh
python3 tools/plot_spectrum.py run/cii-cpu --output run/cii-cpu/spectrum.png
python3 tools/plot_spectrum.py run/cii-cuda --output run/cii-cuda/spectrum.png
```

Each command also writes a CSV spectrum and a JSON description of the
binning and normalization. The small, 4,096-photon example demonstrates
the workflow; increase `--nphot` in a new run to reduce sampling noise.
See the [installation guide](https://peacock-rt.readthedocs.io/en/latest/installation.html)
and [complete tutorial](https://peacock-rt.readthedocs.io/en/latest/getting-started.html)
for platform-specific setup and the physical parameters.

## Inputs and reproducibility

Give each run a new or empty output directory. Keep the resolved
configuration and the copied `atomic.atom` with the packet files. CPU
`run.json` records the line and SHA-256 checksums for the configuration,
atomic table and native executable. CUDA preparation and execution records
also identify the native inputs, device source and compiled PTX.

The C II quickstart also copies its input positions to `clumps.txt`.
Use a new build directory when changing optional build features or CUDA
architecture; select it in later runs with `--build-dir`.

The [line selection guide](docs/line-selection.md) lists the supported
networks and explains how to supply a custom configuration. The [cloud model
guide](docs/cloud-model.md) documents cloud schema 2, placement and the
common Cartesian Gaussian dispersion.

See [provenance and citation](docs/provenance.md) for source attribution,
papers and license information.

## Version and citation

This package is PEACOCK **1.0.1**. Cite the version you used, using the
metadata in [CITATION.cff](CITATION.cff). Version 1.0.1 unifies the C II
example inputs and includes the plotting helper; the transport physics
and atomic data are unchanged from 1.0.

The independently archived **1.0** release has this DOI:

Li, Z., & Gronke, M. (2026). *PEACOCK: Profiles of Emission and Absorption from Clumpy Outflows with Complex Kinematics* (Version 1.0) [Computer software]. Zenodo. [https://doi.org/10.5281/zenodo.24206426](https://doi.org/10.5281/zenodo.24206426).

See [CITATION.cff](CITATION.cff) for machine-readable citation metadata and
the [citation guide](https://peacock-rt.readthedocs.io/en/latest/citing.html)
for the methods and original `tlac` references.

## License

PEACOCK is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free
Software Foundation, either version 3 of the License, or (at your option)
any later version (SPDX: `GPL-3.0-or-later`). See [LICENSE](LICENSE) for the
complete terms.

This license applies to the PEACOCK software. Third-party components and
reference data retain their own notices and terms. In particular, the
bundled INI parser remains available under its upstream MIT license.
