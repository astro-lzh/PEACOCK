# CUDA transport

Build the CUDA backend once for your architecture. The build creates one
native exporter and one `transport.ptx`, shared by all 14 line profiles.

## Requirements and build

Install Python 3.9 or later with NumPy and SciPy, C and C++ compilers,
`nm`, GSL, and an NVIDIA driver. The build uses NVRTC and compatible
CUDA runtime, cuRAND and CCCL headers. The architecture option defaults
to `compute_120`. Set `--arch` to a target supported by your device and
installed NVRTC.

```sh
python3 peacock.py build --backend cuda --arch compute_120
```

On Windows, the MSYS2 UCRT64 prefix can supply the compiler, `nm` and GSL.
For an installation in the standard directory:

```powershell
python peacock.py build --backend cuda --arch compute_120 --compiler-prefix C:/msys64/ucrt64
```

The builder can locate the NVIDIA Python package tree automatically.
Use `--nvidia-root` to point to the directory containing
`cuda_nvrtc`, `cuda_runtime`, `curand` and `cuda_cccl`. For a separate
toolkit installation, pass the NVRTC library with `--nvrtc-library`
and repeat `--cuda-include` for each required header directory.

## Select a line

```sh
python3 peacock.py run --line CIV1548 --backend cuda --output run/civ
python3 peacock.py run --line SiII1190 --backend cuda --output run/si1190
```

Both commands use the same build. `run` prepares the grid and initial
packets with CPU photon transport disabled, then launches the CUDA
module with the selected atomic data. C II uses the same
[quickstart wind](../examples/cii/README.md) as CPU: 4,096 packets and the
bundled 685-cloud FCC catalogue selected by `examples/cii/quickstart.cfg`.
The Lyα, C IV and Mg II examples use 4,096 packets and a 69-cloud synthetic catalogue. The
multilevel profiles share a smooth-gas example with 100 packets. Use
`--nphot` to set the primary packet count.

## Build, prepare and execute separately

Use separate stages to inspect the inputs before running transport:

```sh
python3 peacock.py build --backend cuda --output build/cuda-staged
python3 peacock.py prepare --line CIV1548 --build-dir build/cuda-staged --output run/civ-staged
python3 peacock.py execute --line CIV1548 --build-dir build/cuda-staged --input run/civ-staged
```

Add `--host-only` to the build when you only need the native input exporter.
A host-only build prepares inputs without producing PTX. Use a complete
CUDA build to execute them.

For custom inputs, pass `--config file.cfg`. A custom catalogue
configuration uses `cloud_mode_schema = 2`, placement mode 3 and
`--clump-file` with the complete Cartesian position file. See the [cloud
model](cloud-model.md). Use a new or empty case directory. The optional
`--geometry-cache` selects the synthetic catalogue cache directory.
`--batch` sets the device batch size and defaults to 1,024.

## Reproduce a case

Keep `build.json`, `transport.ptx`, `transport.ptx.json`, the prepared
inputs, `prepare_report.json`, `atomic.atom`, and the resolved
configuration. The preparation report records the line, atom and
executable checksums and the native input checksums. Before transport,
execution checks the selected line and
atomic checksum against the prepared case. It checks the PTX and the
source files used to compile it, then verifies the native and device
structure layouts. For multilevel transfer, the exporter records the
configured lower-level population ratios for upload with the atom.

The packet archive and `gpu_run_report.json` record the outcomes and
identify the active atom and compiled PTX. The report counts numerical
errors and incomplete histories separately from escapes and physical
absorption.
