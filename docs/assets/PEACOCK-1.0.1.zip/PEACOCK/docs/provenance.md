# Provenance and citation

PEACOCK extends the `tlac` three-dimensional Lyα Monte Carlo radiative
transfer code developed by Max Gronke and described by Gronke & Dijkstra
(2014). The source retains the `tlac` lineage and existing attribution,
including the INI parser credit to Nicolas Devillard.

- Zhihui Li et al. (2026), [PEACOCK method and multi-ion application](https://arxiv.org/abs/2603.06546).
- Max Gronke and Mark Dijkstra (2014), [description of `tlac`](https://arxiv.org/abs/1406.6709).
- Zhihui Li et al. (2026), [C IV application](https://arxiv.org/abs/2609.11497).

## Current package

This package is PEACOCK **1.0.1**. It uses one shared C II quickstart
configuration and cloud catalogue and includes the spectrum plotting
helper. Its transport physics and atomic data are unchanged from 1.0.
Use the version and author metadata in [CITATION.cff](../CITATION.cff)
when citing this package.

## Archived version 1.0

The DOI below identifies the independently archived **1.0** release.

Li, Z., & Gronke, M. (2026). *PEACOCK: Profiles of Emission and Absorption from Clumpy Outflows with Complex Kinematics* (Version 1.0) [Computer software]. Zenodo. [https://doi.org/10.5281/zenodo.24206426](https://doi.org/10.5281/zenodo.24206426).

## Licensing

PEACOCK is distributed under the GNU General Public License, version 3 or
(at your option) any later version (`GPL-3.0-or-later`). See
[LICENSE](../LICENSE) for the complete terms.

The bundled INI parser retains its [upstream MIT license](../THIRD_PARTY/iniparser-LICENSE.txt).
Third-party components and reference data retain their own notices and terms.

See [UV atomic and dust data notices](uv-data-provenance.md) for the
multilevel reference tables.
